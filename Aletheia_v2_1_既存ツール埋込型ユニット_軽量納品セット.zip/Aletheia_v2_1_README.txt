Aletheia v2.1 既存ツール埋込型 Grimoire価格資料連携ユニット

概要:
- 既存譲渡所得ツールに標準モジュールとして組み込むためのAletheia v2.1実装です。
- Aletheia専用の表示シートは作らず、内部保存用のAL_Dataだけを作成します。
- 既存ツールの分析画面B43:Y62へ、Grimoire資料の要点を表示します。
- Grimoireが引き渡す価格情報サマリーA:BK、Aletheia連携データA:Zは欠落なくAL_Dataに保存します。
- 取引事例明細はAL_Dataに全件保存し、ボタンで表示します。

主なマクロ:
1. AL_SetupAletheiaV21
   - AL_Dataを作成
   - AL_OUT_GrimoireBlockTopLeftが定義済みならB43:Y62にボタン配置
2. AL_ImportGrimoireAndWriteBack
   - Grimoireブックをマクロ無効・読取専用・リンク更新なしで開く
   - 価格情報サマリーA:BK、Aletheia連携データA:ZをAL_Dataへ保存
   - B43:Y62に要点を表示
3. AL_ShowTradeDetails
   - AL_Dataを表示し、Aletheia連携データA:Zの保存領域へ移動
4. AL_HideTradeDetails
   - AL_DataをVeryHiddenに戻し、分析画面へ戻る
5. AL_ClearGrimoireOutput
   - B43:Y62の表示だけクリア
   - AL_Dataの保存データは削除しない

既存ツール側で必要な名前定義:

読取用:
- AL_SRC_TransferDate
- AL_SRC_TransferPrice
- AL_SRC_LandArea
- AL_SRC_PropertyType
- AL_SRC_LandAllocatedPrice

出力用:
- AL_OUT_GrimoireBlockTopLeft
  - 既存ツール分析画面の B43 セルを参照させること
  - A列とZ列は画面調整用として使わない
  - AletheiaはB43:Y62だけに書き込む

譲渡物件区分:
- 土地のみ
- 建物のみ
- 土地建物両方

比較対象土地価額の扱い:
- 土地のみ:
  - AL_SRC_LandAllocatedPriceを優先使用
  - 空欄又は0の場合のみAL_SRC_TransferPriceを補助使用
- 土地建物両方:
  - AL_SRC_LandAllocatedPriceを使用
  - 空欄又は0なら要確認
- 建物のみ:
  - 土地価格比較対象外

B43:Y62表示内容:
- 取込状態
- Grimoireバージョン
- SUMMARY/TRADE件数
- 価格資料サマリー
- 既存ツール情報との比較
- 注意フラグ、注意コメント
- 所在地確認、距離注記
- Grimoire取込・更新ボタン
- 取引事例明細ボタン
- 表示クリアボタン

AL_Data内部構造:
- A1:N18       取込ログ
- A20:BK21     価格情報サマリーA:BK 生データ
- A24:D90      価格情報サマリー縦展開
- A100:Z可変    Aletheia連携データA:Z 全行
- AB1:AK可変    CheckData
- AM1:AZ可変    InternalStatus

重要な安全仕様:
- GrimoireブックはReadOnly、UpdateLinks:=0、AutomationSecurity=3で開く
- APIキー混入チェックC3が1以上、空欄、非数値、エラーなら取込停止
- AL_OUT_GrimoireBlockTopLeftが未定義又はB43以外なら、分析画面への書戻し停止
- 長文コメントはB43:Y62では短縮表示し、全文はAL_Dataに保存
- 適正、不適正、否認可能、低額譲渡該当、時価、認定額などの断定文言は表示しない

導入手順:
1. 既存ツールを必ずバックアップする
2. 既存ツールに名前定義を作成又は変更する
3. Aletheia_v2_1_既存ツール埋込型ユニット_標準モジュール.bas をVBEにインポートする
4. VBEでコンパイルする
5. AL_SetupAletheiaV21 を実行する
6. 既存分析画面B43:Y62にボタンが配置されるか確認する
7. AL_ImportGrimoireAndWriteBack を実行してGrimoireブックを選択する
8. B43:Y62の表示、AL_Dataの保存、取引事例明細ボタンを確認する

注意:
- この環境ではVBEコンパイルと実際のGrimoireブック取込は実行できていません。
- 実機では必ずVBEコンパイル、名前定義確認、Grimoire実ブック取込を行ってください。


要チェック後の補正:
- AL_Data縦展開のGrimoire列表示がA1/B1形式になる補助表示バグを修正し、A/B形式に補正しました。
- 検証用ブックに必須名前定義6件を追加しました。
  - AL_SRC_TransferDate
  - AL_SRC_TransferPrice
  - AL_SRC_LandArea
  - AL_SRC_PropertyType
  - AL_SRC_LandAllocatedPrice
  - AL_OUT_GrimoireBlockTopLeft
