Aletheia v2.2 APIチェック撤去・AL_Data再設計版

概要:
- v2.1から設計を見直し、Aletheia側ではGrimoireのAPI関連検査を一切参照しない構成にしました。
- API関連検査の件数で取込停止しません。
- API関連検査のC3/E3を読みません。
- API関連検査の結果をB43:Y62にもAL_Dataにも保存しません。
- AL_Dataの20行目から突然Grimoire見出しが出る構造をやめ、ブロック見出し付きの構造に変更しました。

主な変更:
1. API関連検査を完全撤去
   - Grimoire側に検査シートがあっても、Aletheiaは要求しません。
   - 検査件数で停止しません。
   - 検査結果を表示・ログ保存しません。

2. AL_Data再設計
   - A1:L18       取込ログ
   - A20:BK20     ブロック見出し「Grimoire価格情報サマリー原本」
   - A21:BK21     Grimoire価格情報サマリー見出し A:BK
   - A22:BK22     Grimoire価格情報サマリー値 A:BK
   - A25:D25      ブロック見出し「価格情報サマリー縦展開」
   - A26:D89      縦展開
   - A100:Z100    ブロック見出し「Aletheia連携データ原本」
   - A101:Z可変   Aletheia連携データ A:Z 全行
   - AB1:AE可変   CheckData
   - AM1:AP可変   InternalStatus

3. 原因不明対策
   - AL_DiagnoseGrimoireWorkbook を追加
   - Grimoire取込失敗時に、工程名・Err.Number・Err.Description・選択ファイルを表示

4. ボタン配置
   - ボタン幅を固定化
   - セル幅に引っ張られてAJ列まで伸びる問題を避ける構造

公開マクロ:
- AL_SetupAletheiaV22
- AL_ImportGrimoireAndWriteBack
- AL_DiagnoseGrimoireWorkbook
- AL_ShowTradeDetails
- AL_HideTradeDetails
- AL_ClearGrimoireOutput
- AL_InstallAletheiaButtons

既存ツール側で必要な名前定義:
- AL_SRC_TransferDate
- AL_SRC_TransferPrice
- AL_SRC_LandArea
- AL_SRC_PropertyType
- AL_SRC_LandAllocatedPrice
- AL_OUT_GrimoireBlockTopLeft

AL_OUT_GrimoireBlockTopLeft:
- 既存ツールの分析画面 B43 を指してください。
- AletheiaはB43:Y62にだけ表示します。

注意:
- この環境ではVBEコンパイルとGrimoire実ブック取込は実行できていません。
- 実機ではVBEでコンパイルし、AL_SetupAletheiaV22、AL_DiagnoseGrimoireWorkbook、AL_ImportGrimoireAndWriteBackを順に確認してください。
