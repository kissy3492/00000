﻿Attribute VB_Name = "職場環境チェック"
Option Explicit

' Excel/VBA向けの簡易環境チェック。
' 新規ブックにこの標準モジュールをインポートし、CheckExcelWorkplaceEnvironment を実行してください。
' 外部通信なし。結果は新しいシートに出力します。

Public Sub CheckExcelWorkplaceEnvironment()
    Dim ws As Worksheet
    Dim r As Long
    Set ws = ThisWorkbook.Worksheets.Add
    ws.Name = "職場環境チェック_" & Format(Now, "hhmmss")
    r = 1
    PutRow ws, r, "項目", "値", "コメント": r = r + 1
    PutRow ws, r, "GeneratedAt", Format(Now, "yyyy-mm-dd hh:nn:ss"), "": r = r + 1
    PutRow ws, r, "Application.Version", Application.Version, "Excelバージョン差の確認": r = r + 1
    PutRow ws, r, "Application.Build", Application.Build, "": r = r + 1
    PutRow ws, r, "OperatingSystem", Application.OperatingSystem, "": r = r + 1
    PutRow ws, r, "UserName", Application.UserName, "共有時は個人名混入に注意": r = r + 1
    PutRow ws, r, "ThisWorkbook.Path", ThisWorkbook.Path, "OneDrive/SharePoint/ネットワークパスの場合は注意": r = r + 1
    PutRow ws, r, "ThisWorkbook.FullName", ThisWorkbook.FullName, "": r = r + 1
    PutRow ws, r, "AutomationSecurity", CStr(Application.AutomationSecurity), "マクロ自動化の制約に関係": r = r + 1
    PutRow ws, r, "EnableEvents", CStr(Application.EnableEvents), "イベントマクロ利用時に重要": r = r + 1
    PutRow ws, r, "DisplayAlerts", CStr(Application.DisplayAlerts), "": r = r + 1
    PutRow ws, r, "Calculation", CStr(Application.Calculation), "大量計算ツールで重要": r = r + 1
    PutRow ws, r, "DefaultFilePath", Application.DefaultFilePath, "": r = r + 1
    PutRow ws, r, "StartupPath", Application.StartupPath, "": r = r + 1
    PutRow ws, r, "TemplatesPath", Application.TemplatesPath, "": r = r + 1
    PutRow ws, r, "NetworkTemplatesPath", Application.NetworkTemplatesPath, "": r = r + 1
    PutRow ws, r, "RecentFiles.Count", CStr(Application.RecentFiles.Count), "": r = r + 1
    PutRow ws, r, "Printers", Application.ActivePrinter, "印刷ツールで重要": r = r + 1
    PutRow ws, r, "PathHint", GetPathHint(ThisWorkbook.Path), "": r = r + 1
    ws.Columns("A:C").AutoFit
End Sub

Private Sub PutRow(ByVal ws As Worksheet, ByVal r As Long, ByVal a As String, ByVal b As String, ByVal c As String)
    ws.Cells(r, 1).Value = a
    ws.Cells(r, 2).Value = b
    ws.Cells(r, 3).Value = c
End Sub

Private Function GetPathHint(ByVal p As String) As String
    Dim s As String
    s = LCase$(p)
    If Left$(p, 2) = "\\" Then
        GetPathHint = "ネットワーク共有パスの可能性"
    ElseIf InStr(s, "onedrive") > 0 Or InStr(s, "sharepoint") > 0 Or InStr(s, "teams") > 0 Then
        GetPathHint = "OneDrive/SharePoint/Teams同期パスの可能性"
    ElseIf Len(p) > 160 Then
        GetPathHint = "長いパス。古いAPIや外部連携で注意"
    Else
        GetPathHint = "大きな警告なし"
    End If
End Function
