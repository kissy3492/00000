# 印刷ズレ・transform 対策メモ

紙面位置合わせ系・印刷物系ツールで、ブラウザ印刷時のズレを防ぐためのノウハウ集です。

## ズレが起きる主な原因

| 原因 | 発生条件 | 対策 |
|---|---|---|
| ブラウザZoom倍率が100%でない | Ctrl+= / Ctrl+- 等で変更 | 起動時にZoom検出して警告表示 |
| CSS transform: scale | プリンタによってプレビューと実印字でズレ | 印刷時はtransformをリセット |
| @page margin が物理最小余白を下回る | プリンタの物理制約 | プリンタ別の最小余白を実測して補正値で対応 |
| display:none された要素の位置取得 | getBoundingClientRect が 0 を返す | 非表示要素を扱う前に表示状態を確認 |
| プリンタドライバの「拡大縮小して印刷」がオン | ユーザー操作 | 印刷前ダイアログで100%設定を促す |
| ブラウザの印刷ヘッダ/フッタが有効 | 既定ではオン | 印刷前ダイアログで非表示を促す |

## Zoom倍率の検出と扱い

### 検出方法

最も正確: 既知サイズの要素（例: width:100mm）を実体に作って `getBoundingClientRect()` で測定し、想定px値と比較。

```javascript
function getZoomRatio() {
  const probe = document.createElement('div');
  probe.style.cssText = 'position:absolute;width:100mm;height:0;left:-9999px';
  document.body.appendChild(probe);
  const rect = probe.getBoundingClientRect();
  document.body.removeChild(probe);
  const expectedPx = 100 * 96 / 25.4; // 100mm at 96 DPI
  return rect.width / expectedPx;
}
```

### 警告表示

起動時にZoom倍率を測定し、100%でない場合は印刷ボタンに警告:

```javascript
const z = getZoomRatio();
if (Math.abs(z - 1.0) > 0.05) {
  alert(`ブラウザのZoomが約${Math.round(z*100)}%です。100% (Ctrl+0) に戻してから印刷してください。`);
}
```

## CSS transform の扱い

### 印刷時にtransformをリセット

```css
@media print {
  .scaled-element {
    transform: none !important;
    /* 代わりに physical size を直接指定 */
    width: 50mm;
    height: 20mm;
  }
}
```

### 補正用 transform を使う場合の注意

紙面位置合わせで `transform: translate(Xmm, Ymm)` を使う場合、プリンタごとの補正値を保存して動的に適用します:

```javascript
const correction = getPrinterCorrection(selectedPrinterId);
element.style.transform = `translate(${correction.x}mm, ${correction.y}mm)`;
```

ただし、**ブラウザによっては印刷時に transform を無視する**ことがあります。実機テスト必須。

## getBoundingClientRect の罠

```javascript
// NG: 非表示要素の位置を取得しようとして 0,0,0,0 が返る
element.style.display = 'none';
const rect = element.getBoundingClientRect(); // {width:0, height:0, ...}

// OK: 位置取得が必要なら visibility:hidden を使う
element.style.visibility = 'hidden';
const rect2 = element.getBoundingClientRect(); // 正しい位置情報
```

### 印刷UI切替時の注意

`@media print` で `display:none` する要素の位置情報を、印刷直前に計算する設計は壊れやすい。位置情報は **画面表示時に取得しておき**、印刷時には保持してある値を使う。

## window.print の挙動

### beforeprint / afterprint イベント

```javascript
window.addEventListener('beforeprint', () => {
  // 印刷準備: UI隠す、印刷用レイアウトに切替
  document.body.classList.add('printing');
});

window.addEventListener('afterprint', () => {
  // 印刷終了 or キャンセル: 元に戻す
  document.body.classList.remove('printing');
});
```

**重要**: `afterprint` は印刷成功時もキャンセル時も発火する。これを使えば、キャンセル時の state 残留を防げる。

### Edge での afterprint 未発火

職場ポリシーや Edge のバージョンによっては afterprint が発火しないことがある。**フォールバック**として、`window.print()` の同期実行後にもクリーンアップを呼ぶ:

```javascript
function safePrint() {
  document.body.classList.add('printing');
  try {
    window.print();
  } finally {
    // フォールバック: afterprintが発火しなくてもクリーンアップ
    setTimeout(() => {
      document.body.classList.remove('printing');
    }, 1000);
  }
}
```

## プリンタ余白の実測

`browser/BrowserCapabilityCheck_v13.html` の「プリンタ余白測定用HTMLをダウンロード」ボタンで、A4 四辺に 5mm 刻みの目盛り入り HTML を生成できます。

### 測定手順

1. 生成HTMLを開く
2. ブラウザのZoomが100%であることを確認
3. ブラウザ印刷ダイアログで:
   - 拡大縮小: 100% / 既定 / なし
   - 余白: なし or カスタム 0mm
   - ヘッダーとフッター: オフ
4. 印刷
5. 定規で実印字範囲の最外周を測定
6. 例: 上 4mm, 下 5mm, 左 3mm, 右 3mm が最小余白

### 補正値の保存

プリンタごとに最小余白を保存し、デザイン側で内側に余裕を持たせる:

```javascript
const printerSafeArea = {
  'EPSON LP-S180': {top:4, bottom:5, left:3, right:3},
  'Canon LBP251': {top:5, bottom:5, left:5, right:5}
};
```

## ブラウザ印刷ダイアログのヘッダ・フッタ

職場のEdge設定で「ヘッダーとフッター」が既定オンの場合、A4の上下に URL や日付が印字される。これがあると位置がズレる。

**対策**: ユーザーに「印刷時はヘッダーとフッターをオフにしてください」と必ず案内。設定変更コードは存在しない（クライアント側の印刷ダイアログ設定はWeb APIから操作不可）。

```html
<div class="print-instruction">
  <p>印刷前に以下を確認してください:</p>
  <ul>
    <li>ブラウザのズーム: 100%</li>
    <li>余白: なし</li>
    <li>ヘッダーとフッター: オフ</li>
    <li>背景のグラフィック: オン</li>
    <li>拡大縮小: 既定 (100%)</li>
  </ul>
</div>
```

## プリンタドライバ側の設定

| 設定 | 推奨値 | 影響 |
|---|---|---|
| 拡大縮小 | 100% (拡大縮小なし) | 100%以外だと全部ズレる |
| 用紙サイズ | 実サイズ (A4 等) | 「ユーザー定義」だと予想外の挙動 |
| 余白 | 最小 (0mm 目標) | プリンタの物理最小に切り上げられる |
| 印刷品質 | 通常 or 高品質 | ドラフトモードだと位置が若干ズレる場合あり |
| 両面印刷 | オフ | 両面だと裏面位置を見越した補正が必要 |

## 環境依存文字とフォント

詳細は `docs/PDF印刷物開発チェックリスト.md` を参照。

要点:
- 配布先で確実に存在するフォントを指定（Yu Gothic, MS Mincho, Meiryo）
- `font-family` でフォールバック指定 `'Yu Gothic', 'Meiryo', sans-serif`
- 環境依存文字（髙、㈱）は使う前に `browser/BrowserCapabilityCheck_v13.html` で描画テスト

## トラブルシュート

### Q. プレビューと実印字が違う

1. Zoom倍率を確認（100%か）
2. プリンタドライバの拡大縮小設定を確認
3. プリンタの物理最小余白に達していないか
4. ブラウザのヘッダ・フッタ設定

### Q. 印刷後、画面が印刷用レイアウトのまま戻らない

1. `afterprint` イベントリスナーが登録されているか
2. キャンセル時にも発火するか実機確認
3. setTimeout でのフォールバック実装

### Q. 透明・半透明要素が印刷されない

1. CSS `-webkit-print-color-adjust: exact` を指定
2. `print-color-adjust: exact` (モダンブラウザ用)

### Q. transform を使った要素が印刷でズレる

1. 印刷専用CSSで transform をリセット
2. または、physical size を直接指定する設計に変える
