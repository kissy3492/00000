# PowerShell + Excel COM 作法

PowerShell から Excel を COM で操作するときの「正しい解放処理」と「やらかしパターン」をまとめたものです。

## なぜ重要か

`New-Object -ComObject Excel.Application` で Excel を起動した後、適切に解放しないと:

- **EXCEL.EXE プロセスがタスクマネージャに残り続ける**
- 次回 Excel を開いたとき、前回のプロセスが邪魔して挙動がおかしくなる
- メモリリークでスクリプトを何度も実行するとPCが重くなる
- スクリプトを Ctrl+C で中断すると確実に残留する

## 正しい解放手順

### 最小限のテンプレート

```powershell
$xl = $null
$wb = $null
$ws = $null
try {
    $xl = New-Object -ComObject Excel.Application
    $xl.Visible = $false
    $xl.DisplayAlerts = $false
    $xl.ScreenUpdating = $false  # 高速化

    $wb = $xl.Workbooks.Open('C:\path\to\file.xlsx')
    $ws = $wb.Worksheets.Item(1)

    # ===== ここで実処理 =====
    $cell = $ws.Cells.Item(1, 1)
    Write-Host $cell.Value2
    # =======================

    $wb.Save()
    $wb.Close($false)
    $xl.Quit()
}
catch {
    Write-Error "Excel COM処理失敗: $($_.Exception.Message)"
    if ($wb) { try { $wb.Close($false) } catch {} }
    if ($xl) { try { $xl.Quit() } catch {} }
}
finally {
    # 必ず解放（順序が重要：奥から手前へ）
    if ($cell) { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($cell) | Out-Null }
    if ($ws)   { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($ws) | Out-Null }
    if ($wb)   { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($wb) | Out-Null }
    if ($xl)   { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($xl) | Out-Null }
    $cell = $null; $ws = $null; $wb = $null; $xl = $null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
    [GC]::Collect()
}
```

### 重要な点

1. **`try / catch / finally` で必ず囲む** — エラーで途中終了してもfinallyで解放
2. **`Visible = $false`** — ウィンドウを出さない
3. **`DisplayAlerts = $false`** — 「上書き保存しますか？」等の確認を抑制
4. **`ReleaseComObject` の順序は奥から手前** — Cell → Worksheet → Workbook → Application
5. **`[GC]::Collect()` を2回呼ぶ** — 1回だけだと解放されないことがある
6. **変数を `$null` に再代入** — 参照を切る

## やらかしパターン

### NG1: `.Quit()` だけで終わらせる

```powershell
$xl = New-Object -ComObject Excel.Application
# 処理
$xl.Quit()
# ← これだけだと EXCEL.EXE が残る
```

### NG2: ワークブック・セルを変数に取らずチェーンで処理

```powershell
$xl = New-Object -ComObject Excel.Application
$value = $xl.Workbooks.Open('file.xlsx').Worksheets.Item(1).Cells.Item(1,1).Value2
# ← 中間オブジェクト（Workbooks, Workbook, Worksheets, Worksheet, Range, Cell）が
#   全部参照されたまま放置される。これは絶対NG
```

**正しくは:**

```powershell
$wb = $xl.Workbooks.Open('file.xlsx')
$ws = $wb.Worksheets.Item(1)
$cell = $ws.Cells.Item(1, 1)
$value = $cell.Value2
# 終わったら全部Release
```

### NG3: 値プロパティで `.Value` を使う

```powershell
$cell.Value   # ← Variant型を返すので遅い・型不定
$cell.Value2  # ← 速い・型予測しやすい（推奨）
```

### NG4: `New-Object Excel.Application` を使う

```powershell
$xl = New-Object Excel.Application  # NG（COM呼出にならない場合あり）
$xl = New-Object -ComObject Excel.Application  # OK
```

### NG5: Ctrl+C で中断する

開発中に Ctrl+C で止めると finally が走らず確実にプロセス残留します。

**残留したプロセスの掃除:**

```powershell
Get-Process EXCEL -ErrorAction SilentlyContinue | Stop-Process -Force
```

## 高速化テクニック

### 大量セル書込時

```powershell
$xl.ScreenUpdating = $false      # 画面更新オフ
$xl.Calculation = -4135          # xlCalculationManual（手動計算）
$xl.EnableEvents = $false        # イベント発火停止

# === 大量処理 ===

$xl.Calculation = -4105          # xlCalculationAutomatic（自動計算に戻す）
$xl.EnableEvents = $true
$xl.ScreenUpdating = $true
```

### 範囲一括書込

```powershell
# 遅い：1セルずつ
for ($i = 1; $i -le 1000; $i++) {
    $ws.Cells.Item($i, 1).Value2 = "row $i"
}

# 速い：2次元配列を一括代入
$data = New-Object 'object[,]' 1000, 1
for ($i = 0; $i -lt 1000; $i++) { $data[$i, 0] = "row $($i+1)" }
$range = $ws.Range($ws.Cells.Item(1, 1), $ws.Cells.Item(1000, 1))
$range.Value2 = $data
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($range) | Out-Null
```

## ファイル保存の作法

### 上書き保存

```powershell
$wb.Save()
```

### 別名保存

```powershell
# xlsx形式で保存 (FileFormat = 51 = xlOpenXMLWorkbook)
$wb.SaveAs('C:\path\to\new.xlsx', 51)

# xlsm形式で保存 (FileFormat = 52 = xlOpenXMLWorkbookMacroEnabled)
$wb.SaveAs('C:\path\to\new.xlsm', 52)

# CSV (UTF-8) 形式で保存 (FileFormat = 62 = xlCSVUTF8)
$wb.SaveAs('C:\path\to\new.csv', 62)
```

### 保存せずに閉じる

```powershell
$wb.Close($false)  # $false = 保存しない
```

## エラーハンドリング

### Excel が「読み取り専用で開かれてる」エラー

```powershell
# ファイルが既に他のプロセスで開かれている場合、ReadOnly で開く
$wb = $xl.Workbooks.Open('file.xlsx', $null, $true)  # 3番目の引数 = ReadOnly
```

### Excel が「リンク更新しますか」を聞いてくる

```powershell
$xl.AskToUpdateLinks = $false
# または
$wb = $xl.Workbooks.Open('file.xlsx', 0)  # 2番目の引数 = UpdateLinks (0=しない)
```

### マクロ警告を抑制

```powershell
$xl.AutomationSecurity = 3  # msoAutomationSecurityForceDisable
# 開いてから戻す
$xl.AutomationSecurity = 1  # msoAutomationSecurityLow
```

## デバッグ用：残留プロセス確認

```powershell
# 現在のEXCEL.EXE一覧
Get-Process EXCEL -ErrorAction SilentlyContinue |
  Select-Object Id, StartTime, MainWindowTitle, @{n='MB';e={[math]::Round($_.WorkingSet64/1MB,1)}}

# 全部強制終了
Get-Process EXCEL -ErrorAction SilentlyContinue | Stop-Process -Force
```

## チェッカーの検出パターン

PowerShell診断スクリプトで以下が検出されたら、上記の作法に従って修正してください:

- `Excel COM Quit missing` (WARN) — `New-Object Excel.Application` してるが `.Quit()` が見つからない
- `ReleaseComObject` (INFO) — 明示解放あり（OK）

これらは `tools/Invoke-WorkplaceEnvironmentAudit.ps1` を実行した際の `StaticScan` カテゴリに出ます。

## 参考

- Microsoft Office VBA リファレンス（Excel オブジェクトモデル）
- `Get-Help New-Object -Detailed`
