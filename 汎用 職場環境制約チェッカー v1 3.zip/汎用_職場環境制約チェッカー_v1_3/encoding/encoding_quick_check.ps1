<#
.SYNOPSIS
  文字コード・BOM・改行コード クイックチェッカー

.DESCRIPTION
  指定フォルダ内の全ファイルの文字コード、BOM有無、改行コードを
  「あるべき姿」と比較してレポートします。
  外部通信なし、書込みなし。

.EXAMPLE
  .\encoding_quick_check.ps1 -Path C:\path\to\project

.EXAMPLE
  .\encoding_quick_check.ps1 -Path . -Csv

#>
[CmdletBinding()]
param(
    [string]$Path = (Get-Location).Path,
    [switch]$Csv,
    [switch]$ShowAll
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

function Get-EncodingInfo {
    param([string]$FilePath)
    try {
        $bytes = [System.IO.File]::ReadAllBytes($FilePath)
        if ($bytes.Length -eq 0) {
            return @{Encoding='Empty'; HasBom=$false; Newline='None'; Bytes=0}
        }
        $enc = 'Unknown'; $hasBom = $false
        if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
            $enc = 'UTF-8'; $hasBom = $true
        } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
            $enc = 'UTF-16LE'; $hasBom = $true
        } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
            $enc = 'UTF-16BE'; $hasBom = $true
        } else {
            try {
                $utf8NoBom = New-Object System.Text.UTF8Encoding($false, $true)
                [void]$utf8NoBom.GetString($bytes)
                $enc = 'UTF-8 (no BOM)'
            } catch {
                $enc = 'Non-UTF-8 (Shift_JIS or other)'
            }
        }
        $crlf=0; $lf=0; $cr=0
        for ($i=0; $i -lt [Math]::Min($bytes.Length, 65536); $i++) {
            if ($bytes[$i] -eq 0x0D) {
                if ($i+1 -lt $bytes.Length -and $bytes[$i+1] -eq 0x0A) { $crlf++; $i++ }
                else { $cr++ }
            } elseif ($bytes[$i] -eq 0x0A) { $lf++ }
        }
        $nl = if ($crlf -gt 0 -and $lf -eq 0 -and $cr -eq 0) { 'CRLF' }
              elseif ($lf -gt 0 -and $crlf -eq 0 -and $cr -eq 0) { 'LF' }
              elseif ($cr -gt 0 -and $crlf -eq 0 -and $lf -eq 0) { 'CR' }
              elseif ($crlf+$lf+$cr -eq 0) { 'None' }
              else { "Mixed(CRLF=$crlf,LF=$lf,CR=$cr)" }
        return @{Encoding=$enc; HasBom=$hasBom; Newline=$nl; Bytes=$bytes.Length}
    } catch {
        return @{Encoding='Error'; HasBom=$false; Newline='Error'; Bytes=0}
    }
}

function Get-Verdict {
    param([string]$Ext, [hashtable]$Info)
    switch ($Ext) {
        { @('.ps1','.psm1','.psd1') -contains $_ } {
            if ($Info.Encoding -eq 'UTF-8 (no BOM)') { return @{Severity='WARN'; Message='PS 5.1ではBOM付きUTF-8推奨。日本語化けの可能性あり'} }
            return @{Severity='OK'; Message=''}
        }
        { @('.bat','.cmd') -contains $_ } {
            if ($Info.Encoding -match 'UTF-8') { return @{Severity='WARN'; Message='cmd/batはShift_JIS必須。echoの日本語化けの可能性'} }
            return @{Severity='OK'; Message=''}
        }
        { $_ -eq '.csv' } {
            if ($Info.Encoding -eq 'UTF-8 (no BOM)') { return @{Severity='WARN'; Message='ExcelでダブルクリックするとBOM無しUTF-8は文字化け'} }
            return @{Severity='OK'; Message=''}
        }
        { $_ -eq '.json' } {
            if ($Info.HasBom) { return @{Severity='WARN'; Message='JSONはBOM禁止(RFC 8259)'} }
            return @{Severity='OK'; Message=''}
        }
        { @('.bas','.cls','.frm','.vba') -contains $_ } {
            if ($Info.Encoding -match 'UTF-8') { return @{Severity='INFO'; Message='VBAはShift_JIS推奨。インポート時文字化けの可能性'} }
            return @{Severity='OK'; Message=''}
        }
        default {
            return @{Severity='OK'; Message=''}
        }
    }
}

$exts = @('.ps1','.psm1','.psd1','.bat','.cmd','.vbs','.bas','.cls','.frm','.vba','.js','.html','.htm','.css','.json','.xml','.csv','.tsv','.txt','.md')

$resolved = (Resolve-Path -LiteralPath $Path).Path
$files = Get-ChildItem -LiteralPath $resolved -Recurse -File -ErrorAction SilentlyContinue |
    Where-Object { $exts -contains $_.Extension.ToLowerInvariant() }

$results = New-Object System.Collections.Generic.List[object]
foreach ($f in $files) {
    $info = Get-EncodingInfo -FilePath $f.FullName
    $v = Get-Verdict -Ext $f.Extension.ToLowerInvariant() -Info $info
    $rel = $f.FullName.Substring($resolved.Length).TrimStart('\','/')
    $results.Add([pscustomobject]@{
        Path = $rel
        Ext = $f.Extension
        Encoding = $info.Encoding
        BOM = $info.HasBom
        Newline = $info.Newline
        Bytes = $info.Bytes
        Severity = $v.Severity
        Note = $v.Message
    })
}

if ($Csv) {
    $csvPath = Join-Path $env:TEMP "encoding_check_$(Get-Date -Format yyyyMMdd_HHmmss).csv"
    $results | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8
    Write-Host "CSV出力: $csvPath" -ForegroundColor Green
} else {
    # サマリ
    $warns = $results | Where-Object { $_.Severity -eq 'WARN' }
    $infos = $results | Where-Object { $_.Severity -eq 'INFO' }
    Write-Host ""
    Write-Host ("検査対象: {0} ファイル" -f $results.Count) -ForegroundColor Cyan
    Write-Host ("  WARN : {0} 件" -f $warns.Count) -ForegroundColor Yellow
    Write-Host ("  INFO : {0} 件" -f $infos.Count) -ForegroundColor Gray
    Write-Host ""
    if ($warns.Count -gt 0) {
        Write-Host "=== WARN ===" -ForegroundColor Yellow
        $warns | Format-Table Path, Encoding, BOM, Newline, Note -AutoSize
    }
    if ($ShowAll) {
        Write-Host "=== 全ファイル ===" -ForegroundColor Cyan
        $results | Format-Table Path, Encoding, BOM, Newline, Severity, Note -AutoSize
    }
}
