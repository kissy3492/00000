# 汎用 職場環境制約チェッカー v1.3

職場向けツール開発前に、HTML/JavaScript、Excel/VBA、PowerShell、保存方式、印刷、外部通信、配布方式、文字コード、フォント、個人情報取扱、拡張機能レディネス、印字バグ、配布クリーンアップまでを点検する独立チェックキットです。

## v1.3 で追加した検査（v1.2からの差分）

### 印字システム特有の追加検出（#1〜#5）

| 追加 | 何の地雷か |
|---|---|
| CSS transform 印刷時挙動 | `transform: scale()` 等が印刷プレビューと実印字でズレるバグ |
| 物理単位 mm 指定 | ブラウザZoom倍率100%以外で崩れる |
| `@media print` 内の `display:none` | 非表示要素の `getBoundingClientRect()` が0になる |
| `afterprint` イベント未使用 | 印刷キャンセル時のstate残留 |
| グローバル名前空間の重複定義 | 後勝ちで前の登録が消える |

### 一般的な追加検出（#6〜#15）

| 追加 | 何の地雷か |
|---|---|
| `innerHTML` への変数代入 | XSS脆弱性 |
| `JSON.parse` の try/catch なし | 破損データで起動不能 |
| CSS `@import` / `font-face` の外部URL | 職場プロキシで遮断 |
| `setInterval` | clearInterval対応漏れ |
| `addEventListener` | removeEventListener対応漏れ |
| `<input type="file">` の accept 未指定 | ゴミファイル選択でクラッシュ |
| TODO/FIXME/console.log 等の残置 | 配布前クリーンアップ漏れ |
| node_modules / .git / .bak 混入 | 配布物のサイズ膨大、情報漏えい |
| Windows パス長 240 文字超 | MAX_PATH=260 制約 |
| HTML lang/charset/viewport 未指定 | 文字化け・アクセシビリティ問題 |

### 拡張機能観点の追加（#16〜#19）

| 追加 | 何の地雷か |
|---|---|
| スキーマバージョンの欠如 | 拡張時の旧データ互換性 |
| キーボードショートカット競合 | Ctrl+S/Ctrl+P をブラウザ既定に取られる |
| 単位mm/px/pt/inchの混在 | 座標計算ミス |
| testsフォルダの実体確認 | 空のtests/が残置 |

### ブラウザチェック側の追加（実機計測）

| 追加 | 用途 |
|---|---|
| Zoom倍率検出 | 100mm要素の実測でZoomを逆算 |
| transform を含む印刷テストパターン | A/B/C の比較で実印字ズレを目視確認 |
| `afterprint` 実機発火確認 | 印刷キャンセル時のクリーンアップが効くか |
| キーボードショートカット競合検出 | Ctrl+S/P/R の preventDefault 実機テスト |
| タイマー生成・解放テスト | setInterval 30個 → clearInterval の挙動 |
| innerHTML XSS シミュレーション | textContent との差を実感 |

## v1.2 から引き継いだ機能

- PowerShell 静的スキャン 66パターン（v1.3 で 89パターンに拡張）
- 文字コード/BOM/改行コード診断
- HTML依存関係グラフ（動的script注入先の同梱チェック）
- localStorage 使用キー一覧
- 拡張機能レディネス検査（7機能）
- PowerShell 監査ログ設定確認
- フォント存在確認
- OneDrive パス動的解決
- 一時ディレクトリ書込テスト
- ブラウザ側 localStorage 容量実測、canvas toDataURL、showSaveFilePicker、IndexedDB永続化、環境依存文字、印刷余白測定

## v1.1 から引き継いだ機能

- 外部通信検出、PowerShell Bypass検出、Edge/Chrome/AppLockerポリシー、Mark of the Web、機密ワード/APIキー検出、Office COM、レジストリ書込、ファイルサイズ、Excelポリシー、プリンタ列挙

## 使い方

### 1. PowerShell診断（フル機能）

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\Invoke-WorkplaceEnvironmentAudit.ps1 -TargetRoot "C:\Temp\診断したいツール" -OpenReport
```

#### 主なオプション

- `-TestTargetWrite` … 対象フォルダへの一時書込・読込・削除テスト
- `-DeepScan` … 2MB超ファイルもスキャン対象
- `-SkipPolicyScan` … レジストリポリシースキャンをスキップ
- `-SkipStaticScan` … 静的コードスキャンをスキップ

### 2. ブラウザ診断 v1.3

`browser/BrowserCapabilityCheck_v13.html` を職場Edgeで開きます。推奨ボタン操作:

1. **全チェック実行**（自動）
2. **現在の使用量を測る** → localStorage の状態
3. **A4 300dpi で toDataURL** → 画像保存時の容量地雷
4. **showSaveFilePicker 実書込** → 保存先指定機能
5. **IndexedDB 永続化 → リロード → 復元** → 次回起動時の保存先継承
6. **このページを印刷** → 印刷ダイアログ挙動
7. **プリンタ余白測定HTMLをダウンロード → 別途印刷 → 定規で実測**
8. **文字描画幅測定** → 環境依存文字
9. **Zoom倍率を測定** → 100%以外なら印刷崩れ警告
10. **テストボックス表示 → 印刷** → transform の実印字ズレ確認
11. **afterprint 監視 → 印刷キャンセル** → イベント発火確認
12. **ショートカット監視 → Ctrl+S/P/R 押下** → preventDefault確認
13. **タイマー生成・解放テスト**
14. **XSS サニタイズテスト**

### 3. 旧版（互換のため残存）

- `browser/BrowserCapabilityCheck.html` (v1.1)
- `browser/BrowserCapabilityCheck_v12.html` (v1.2)

## 出力レポート

- `workplace_env_audit_report.html` … ブラウザ閲覧用（推奨）
- `workplace_env_audit_report.json` … 機械処理用
- `workplace_env_audit_findings.csv` … Excel分析用
- `workplace_env_audit_summary.txt` … テキスト要約

## ジャンル別「このツール作るときに使うチェック」

### HTML/JavaScript 単体ツール

PowerShell 9c/9d/9e/9j/9k/9n + ブラウザ v1.3 の全項目

### 紙面位置合わせ系・印刷物系

特に v1.3 の transform / Zoom / afterprint / プリンタ余白 / 環境依存文字 を必ず実機テスト

### PowerShell + Excel COM ツール

PowerShell 9b/9f + Excel COM 作法ドキュメント

### CSV出力ツール

文字コード診断（CSV BOM）+ 個人情報パターン検出

### PDF生成・印刷物ツール

フォント存在確認 + 環境依存文字 + プリンタ余白測定 + transform 検出

## 注意

この診断は、職場での利用許可を保証するものではありません。技術的に可能でも、情報管理・配布範囲・保存先・取り扱うデータの性質によって、別途判断が必要です。

診断レポートには端末名、ユーザー名、パス、プリンタ名、ポリシー情報、localStorage キー、使用フォント等が含まれる場合があります。**外部共有する場合は必ず伏せてください。**

## 既知の限界

このチェッカーは**静的解析と環境列挙が中心**であり、以下は**原理的に検出できません**:

- 実行時のメモリ使用量・パフォーマンス
- 実プリンタの印字精度（ブラウザv1.3で生成したテストHTMLを実機印刷して人間が確認）
- 文字列連結で組み立てたAPI呼び出し（`window['local'+'Storage']` 等）
- eval / Function コンストラクタ経由の動的コード
- ロジックバグ・データ設計の妥当性
- 職場固有の運用ルール（保存禁止フォルダ等）

新ツール開発で「このチェッカーが拾わなかった地雷」が見つかったら、次バージョンで検出パターンを追加してください。

## ファイル構成

```text
README.md                                  本ファイル
Run_職場環境チェック.cmd                   PS診断のランチャー
tools/
  Invoke-WorkplaceEnvironmentAudit.ps1     PS診断メイン (v1.3, 89検出パターン, 13セクション)
  Minimal_職場環境チェック.cmd             PowerShell不可環境向け
  PasteMode_Commands.txt                   貼付実行用コマンド
browser/
  BrowserCapabilityCheck.html              v1.1（互換のため残存）
  BrowserCapabilityCheck_v12.html          v1.2（互換のため残存）
  BrowserCapabilityCheck_v13.html          v1.3（推奨）
excel_vba/
  ExcelWorkplaceEnvironmentCheck.bas       Excel/VBA向け診断
docs/
  職場向けツール開発前チェックリスト.md
  判定基準メモ.md
  保存方式判定メモ.md
  個人情報取扱チェックリスト.md            v1.2
  拡張機能レディネスチェックリスト.md      v1.2
  文字コード判定早見表.md                  v1.2
  PDF印刷物開発チェックリスト.md           v1.2
  Excel_COM作法.md                         v1.2
  印刷ズレ・transform対策.md               v1.3 新規
  配布前クリーンアップチェックリスト.md    v1.3 新規
encoding/
  encoding_quick_check.ps1                 v1.2 単独で文字コード診断
samples/
  README.txt
```
