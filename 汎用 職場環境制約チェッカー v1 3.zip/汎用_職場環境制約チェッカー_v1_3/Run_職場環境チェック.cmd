@echo off
setlocal
chcp 65001 >nul
echo ==========================================
echo 汎用 職場環境制約チェッカー v1.1
echo ==========================================
echo.
set /p TARGET=診断したいツールのフォルダパスを入力してください: 
if "%TARGET%"=="" (
  echo 入力がありません。
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\Invoke-WorkplaceEnvironmentAudit.ps1" -TargetRoot "%TARGET%" -OpenReport
echo.
pause
