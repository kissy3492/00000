@echo off
setlocal
echo === Minimal Workplace Environment Check ===
echo Date: %date% %time%
echo Computer: %COMPUTERNAME%
echo User: %USERNAME%
echo.
echo [OS]
ver
echo.
echo [Commands]
where powershell 2>nul
where pwsh 2>nul
where node 2>nul
where python 2>nul
where git 2>nul
where excel 2>nul
echo.
echo [PowerShell policy quick check]
powershell -NoProfile -Command "Write-Host ('PSVersion=' + $PSVersionTable.PSVersion); Get-ExecutionPolicy -List; Write-Host ('LanguageMode=' + $ExecutionContext.SessionState.LanguageMode)" 2>nul
echo.
echo [Printers]
wmic printer get name,default,drivername 2>nul
echo.
echo Done.
pause
