﻿<#
.SYNOPSIS
  汎用・職場環境制約チェッカー

.DESCRIPTION
  職場PC・配布先フォルダ・開発予定ツールのソースを読み取り中心で点検し、
  HTML/JS/Excel/VBA/PowerShell系ツールの開発可否判断に使う材料を出力します。

  外部通信は行いません。
  既定では診断レポート出力先以外を書き換えません。
  -TestTargetWrite を付けた場合のみ、対象フォルダに一時ファイルを作成して削除します。

.EXAMPLE
  powershell -NoProfile -ExecutionPolicy RemoteSigned -File .\tools\Invoke-WorkplaceEnvironmentAudit.ps1 -TargetRoot C:\Work\MyTool

.EXAMPLE
  . .\tools\Invoke-WorkplaceEnvironmentAudit.ps1
  Invoke-WorkplaceEnvironmentAudit -TargetRoot C:\Work\MyTool -DeepScan
#>

[CmdletBinding()]
param(
    [string]$TargetRoot = (Get-Location).Path,
    [string]$OutputDir = "",
    [switch]$DeepScan,
    [switch]$TestTargetWrite,
    [switch]$SkipPolicyScan,
    [switch]$SkipStaticScan,
    [switch]$OpenReport
)

function Invoke-WorkplaceEnvironmentAudit {
    [CmdletBinding()]
    param(
        [string]$TargetRoot = (Get-Location).Path,
        [string]$OutputDir = "",
        [switch]$DeepScan,
        [switch]$TestTargetWrite,
        [switch]$SkipPolicyScan,
        [switch]$SkipStaticScan,
        [switch]$OpenReport
    )

    Set-StrictMode -Version Latest
    $ErrorActionPreference = "Continue"

    $findings = New-Object System.Collections.Generic.List[object]

    function Add-Finding {
        param(
            [string]$Category,
            [string]$Severity,
            [string]$Item,
            [string]$Detail,
            [string]$Evidence = "",
            [string]$Recommendation = ""
        )
        $findings.Add([pscustomobject]@{
            Time           = (Get-Date).ToString("s")
            Category       = $Category
            Severity       = $Severity
            Item           = $Item
            Detail         = $Detail
            Evidence       = $Evidence
            Recommendation = $Recommendation
        })
    }

    function Read-TextSafe {
        param([string]$Path)
        try {
            if (Test-Path -LiteralPath $Path) {
                return Get-Content -LiteralPath $Path -Raw -Encoding UTF8
            }
        } catch {
            Add-Finding "File" "WARN" "Read failed" "ファイル読込に失敗しました。" $Path $_.Exception.Message
        }
        return ""
    }

    function Resolve-RelPath {
        param([string]$Base, [string]$Path)
        try {
            $baseFull = (Resolve-Path -LiteralPath $Base).Path.TrimEnd('\') + '\'
            $pathFull = (Resolve-Path -LiteralPath $Path).Path
            $baseUri = [Uri]$baseFull
            $pathUri = [Uri]$pathFull
            return [Uri]::UnescapeDataString($baseUri.MakeRelativeUri($pathUri).ToString()).Replace('/', '\')
        } catch {
            return $Path
        }
    }

    function Select-MatchingLines {
        param([string]$Text, [string]$Pattern, [int]$Max = 8)
        $out = New-Object System.Collections.Generic.List[string]
        if ([string]::IsNullOrEmpty($Text)) { return "" }
        $lines = $Text -split "`r?`n"
        for ($i = 0; $i -lt $lines.Count; $i++) {
            if ($lines[$i] -match $Pattern) {
                $line = $lines[$i].Trim()
                if ($line.Length -gt 260) { $line = $line.Substring(0, 260) + "..." }
                $out.Add(("L{0}: {1}" -f ($i + 1), $line))
                if ($out.Count -ge $Max) { break }
            }
        }
        return ($out -join "`n")
    }

    function Command-Exists {
        param([string]$Name)
        return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue)
    }

    function Get-RegValuesRecursive {
        param([string]$Path, [int]$Depth = 3)
        $items = New-Object System.Collections.Generic.List[object]
        if (-not (Test-Path $Path)) { return $items }
        function Walk {
            param([string]$P, [int]$D)
            if ($D -lt 0) { return }
            try {
                $props = Get-ItemProperty -Path $P -ErrorAction Stop
                foreach ($prop in $props.PSObject.Properties) {
                    if ($prop.Name -notmatch '^PS') {
                        $items.Add([pscustomobject]@{ Path=$P; Name=$prop.Name; Value=[string]$prop.Value })
                    }
                }
            } catch {}
            try {
                Get-ChildItem -Path $P -ErrorAction SilentlyContinue | ForEach-Object { Walk $_.PSPath ($D - 1) }
            } catch {}
        }
        Walk $Path $Depth
        return $items
    }

    function HtmlEncode {
        param([string]$Value)
        return [System.Net.WebUtility]::HtmlEncode($Value)
    }

    # ------------------------------------------------------------
    # 0. root / output
    # ------------------------------------------------------------
    try {
        $resolvedRoot = (Resolve-Path -LiteralPath $TargetRoot).Path
    } catch {
        throw "TargetRoot が見つかりません: $TargetRoot"
    }

    if ([string]::IsNullOrWhiteSpace($OutputDir)) {
        $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $OutputDir = Join-Path $env:TEMP "WorkplaceEnvAudit_$stamp"
    }
    New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null

    Add-Finding "Summary" "INFO" "TargetRoot" "診断対象フォルダです。" $resolvedRoot ""
    Add-Finding "Summary" "INFO" "OutputDir" "診断レポート出力先です。" $OutputDir ""

    # ------------------------------------------------------------
    # 1. OS / shell / user
    # ------------------------------------------------------------
    Add-Finding "Environment" "INFO" "ComputerName" "端末名です。" $env:COMPUTERNAME ""
    Add-Finding "Environment" "INFO" "UserName" "実行ユーザーです。" $env:USERNAME ""
    Add-Finding "Environment" "INFO" "PowerShellVersion" "PowerShellバージョンです。" $PSVersionTable.PSVersion.ToString() ""
    Add-Finding "Environment" "INFO" "LanguageMode" "PowerShell言語モードです。ConstrainedLanguageだと高度なスクリプトが制限されます。" $ExecutionContext.SessionState.LanguageMode.ToString() ""

    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($id)
        $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        Add-Finding "Environment" "INFO" "Administrator" "管理者権限で実行されているかです。" ([string]$isAdmin) "通常の職場ツールは管理者権限不要で動く設計にしてください。"
    } catch {}

    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        Add-Finding "Environment" "INFO" "OS" "OS情報です。" ("{0} / {1} / Build {2}" -f $os.Caption, $os.Version, $os.BuildNumber) ""
    } catch {
        Add-Finding "Environment" "WARN" "OS" "OS情報取得に失敗しました。" "" $_.Exception.Message
    }

    try {
        $execPolicies = Get-ExecutionPolicy -List | Out-String
        Add-Finding "PowerShell" "INFO" "ExecutionPolicy" "PowerShell実行ポリシー一覧です。" $execPolicies.Trim() "ps1配布可否、貼り付け実行方式の必要性を判断してください。"
    } catch {
        Add-Finding "PowerShell" "WARN" "ExecutionPolicy" "ExecutionPolicy取得に失敗しました。" "" $_.Exception.Message
    }

    # ------------------------------------------------------------
    # 2. path constraints
    # ------------------------------------------------------------
    if ($resolvedRoot.StartsWith("\\")) {
        Add-Finding "Path" "WARN" "NetworkPath" "ネットワーク共有上のフォルダです。読み込み速度、権限、file://扱いに注意が必要です。" $resolvedRoot "ローカル展開版との挙動差を比較してください。"
    } else {
        Add-Finding "Path" "OK" "LocalPath" "ローカルパスです。" $resolvedRoot ""
    }

    if ($resolvedRoot -match "(?i)(OneDrive|SharePoint|Teams|同期|共有ドキュメント)") {
        Add-Finding "Path" "WARN" "CloudSyncPath" "OneDrive/SharePoint/Teams同期フォルダらしきパスです。同期遅延、パス変換、Mark of the Web、権限差に注意が必要です。" $resolvedRoot "ローカル短パスでも同じ挙動になるか確認してください。"
    }

    if ($resolvedRoot.Length -gt 160) {
        Add-Finding "Path" "WARN" "LongPath" "パスが長めです。一部ツールや古いAPIで問題になる可能性があります。" ("Length={0}; {1}" -f $resolvedRoot.Length, $resolvedRoot) "短いフォルダ名での運用も検討してください。"
    }

    if ($TestTargetWrite) {
        $testFile = Join-Path $resolvedRoot ".workplace_env_audit_write_test.tmp"
        try {
            "write test $(Get-Date -Format s)" | Set-Content -LiteralPath $testFile -Encoding UTF8 -ErrorAction Stop
            $readBack = Get-Content -LiteralPath $testFile -Raw -Encoding UTF8 -ErrorAction Stop
            Remove-Item -LiteralPath $testFile -Force -ErrorAction Stop
            Add-Finding "Path" "OK" "TargetWriteTest" "対象フォルダへの一時書込・読込・削除に成功しました。" $testFile ""
        } catch {
            Add-Finding "Path" "ERROR" "TargetWriteTest" "対象フォルダへの一時書込・読込・削除に失敗しました。" $testFile $_.Exception.Message
            try { if (Test-Path -LiteralPath $testFile) { Remove-Item -LiteralPath $testFile -Force -ErrorAction SilentlyContinue } } catch {}
        }
    } else {
        Add-Finding "Path" "INFO" "TargetWriteTestSkipped" "対象フォルダ書込テストは未実施です。" "Use -TestTargetWrite to enable" "本番配布前に一時書込テストを行うと、保存・ログ出力可否の判断材料になります。"
    }

    # ------------------------------------------------------------
    # 3. tools availability
    # ------------------------------------------------------------
    $commands = @("node", "git", "python", "pwsh", "powershell", "bash", "cscript", "wscript", "mshta")
    foreach ($cmd in $commands) {
        if (Command-Exists $cmd) {
            $src = (Get-Command $cmd -ErrorAction SilentlyContinue).Source
            Add-Finding "Tooling" "INFO" $cmd "コマンドが見つかりました。" $src ""
        } else {
            Add-Finding "Tooling" "INFO" $cmd "コマンドは見つかりませんでした。" "" "必要な開発方式でなければ問題ありません。"
        }
    }

    # ------------------------------------------------------------
    # 4. browser / Office / printer
    # ------------------------------------------------------------
    $browserExeCandidates = @(
        "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
        "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe"
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
    if ($browserExeCandidates.Count -gt 0) {
        Add-Finding "Browser" "INFO" "InstalledBrowsers" "主要ブラウザ実行ファイル候補です。" ($browserExeCandidates -join "`n") ""
    } else {
        Add-Finding "Browser" "WARN" "InstalledBrowsers" "Edge/Chromeの実行ファイル候補が標準位置に見つかりません。" "" "管理された環境では配置が異なる場合があります。"
    }

    try {
        $officeVersions = Get-ChildItem "HKCU:\Software\Microsoft\Office" -ErrorAction SilentlyContinue |
            Where-Object { $_.PSChildName -match '^\d+\.\d+$' } |
            Select-Object -ExpandProperty PSChildName
        if ($officeVersions) {
            Add-Finding "Office" "INFO" "OfficeVersionsHKCU" "HKCU上のOfficeバージョン候補です。" ($officeVersions -join ", ") "Excel/VBAツールを作る場合、バージョン差を意識してください。"
        }
    } catch {}

    $excelSecurityRoots = @(
        "HKCU:\Software\Microsoft\Office\16.0\Excel\Security",
        "HKCU:\Software\Policies\Microsoft\Office\16.0\Excel\Security",
        "HKLM:\Software\Policies\Microsoft\Office\16.0\Excel\Security"
    )
    foreach ($rp in $excelSecurityRoots) {
        if (Test-Path $rp) {
            try {
                $props = Get-ItemProperty -Path $rp
                $lines = $props.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object { "{0}={1}" -f $_.Name, $_.Value }
                Add-Finding "OfficePolicy" "WARN" $rp "Excelセキュリティ/ポリシー設定が見つかりました。マクロ、VBA、外部コンテンツの制約に関係する可能性があります。" ($lines -join "`n") "VBAツールを作る前に実機で空マクロ・署名・保存場所を確認してください。"
            } catch {}
        }
    }

    try {
        if (Command-Exists "Get-Printer") {
            $printers = Get-Printer -ErrorAction Stop
            $table = $printers | Select-Object Name, DriverName, PortName, Shared, Default | Format-Table -AutoSize | Out-String
            Add-Finding "Printer" "INFO" "Printers" "プリンタ一覧です。" $table.Trim() "印字系ツールでは、プリンタ名・ドライバ・既定プリンタを検証ログに残してください。"
        } else {
            $printers = Get-CimInstance Win32_Printer -ErrorAction Stop
            $table = $printers | Select-Object Name, DriverName, PortName, Default | Format-Table -AutoSize | Out-String
            Add-Finding "Printer" "INFO" "Printers" "プリンタ一覧です。" $table.Trim() ""
        }
    } catch {
        Add-Finding "Printer" "WARN" "Printers" "プリンタ情報取得に失敗しました。" "" $_.Exception.Message
    }

    # ------------------------------------------------------------
    # 5. browser policies / security policy
    # ------------------------------------------------------------
    if (-not $SkipPolicyScan) {
        $policyRoots = @(
            "HKLM:\Software\Policies\Microsoft\Edge",
            "HKCU:\Software\Policies\Microsoft\Edge",
            "HKLM:\Software\Policies\Google\Chrome",
            "HKCU:\Software\Policies\Google\Chrome",
            "HKLM:\Software\Policies\Microsoft\Windows\Safer",
            "HKLM:\Software\Policies\Microsoft\Windows\AppLocker"
        )
        $policyInterest = '(?i)(Download|URLBlock|URLAllow|JavaScript|Script|Clipboard|Print|FileSystem|Extension|SmartScreen|InternetExplorerIntegration|LocalFile|Auth|DeveloperTools|SafeBrowsing)'
        foreach ($rp in $policyRoots) {
            if (Test-Path $rp) {
                $values = Get-RegValuesRecursive -Path $rp -Depth 5
                if ($values.Count -eq 0) {
                    Add-Finding "Policy" "INFO" $rp "ポリシーキーはありますが、値は見つかりませんでした。" "" ""
                } else {
                    $all = $values | ForEach-Object { "{0} :: {1}={2}" -f $_.Path, $_.Name, $_.Value }
                    $hits = $values | Where-Object { $_.Name -match $policyInterest -or $_.Path -match $policyInterest } | ForEach-Object { "{0} :: {1}={2}" -f $_.Path, $_.Name, $_.Value }
                    $severity = if ($hits.Count -gt 0) { "WARN" } else { "INFO" }
                    $evidence = if ($hits.Count -gt 0) { ($hits -join "`n") } else { ($all | Select-Object -First 30) -join "`n" }
                    Add-Finding "Policy" $severity $rp "ブラウザ/実行制御系ポリシーが見つかりました。" $evidence "DownloadRestrictions、URLBlocklist、JavaScript、印刷、クリップボード、拡張機能、SmartScreen関連を確認してください。"
                }
            } else {
                Add-Finding "Policy" "INFO" $rp "該当ポリシーキーは見つかりませんでした。" "" ""
            }
        }

        try {
            $appIdSvc = Get-Service -Name AppIDSvc -ErrorAction SilentlyContinue
            if ($appIdSvc) {
                Add-Finding "Policy" "INFO" "AppIDSvc" "AppLocker関連サービスの状態です。" $appIdSvc.Status.ToString() "AppLocker/WDACがある環境ではexe化、ps1、vbs、htaが制限される可能性があります。"
            }
        } catch {}

        if (Command-Exists "Get-AppLockerPolicy") {
            try {
                $policy = Get-AppLockerPolicy -Effective -ErrorAction Stop
                $xml = $policy.ToXml()
                $ruleCount = ([regex]::Matches($xml, '<File')).Count
                Add-Finding "Policy" "INFO" "AppLockerPolicy" "AppLocker有効ポリシーの取得に成功しました。" "ApproxRuleCount=$ruleCount" "詳細判定はIT管理者のルール確認が必要です。"
            } catch {
                Add-Finding "Policy" "WARN" "AppLockerPolicy" "AppLockerポリシー取得に失敗しました。" "" $_.Exception.Message
            }
        }

        if (Command-Exists "Get-MpComputerStatus") {
            try {
                $mp = Get-MpComputerStatus -ErrorAction Stop
                Add-Finding "Security" "INFO" "MicrosoftDefender" "Microsoft Defender状態の概要です。" ("AMServiceEnabled={0}; RealTimeProtectionEnabled={1}; BehaviorMonitorEnabled={2}" -f $mp.AMServiceEnabled, $mp.RealTimeProtectionEnabled, $mp.BehaviorMonitorEnabled) ""
            } catch {
                Add-Finding "Security" "WARN" "MicrosoftDefender" "Defender状態取得に失敗しました。" "" $_.Exception.Message
            }
        }
    }

    # ------------------------------------------------------------
    # 6. Mark of the Web scan
    # ------------------------------------------------------------
    $motwExtensions = @('.ps1','.psm1','.bat','.cmd','.vbs','.js','.html','.hta','.xlsm','.xlam','.zip','.exe','.dll','.json','.css')
    try {
        $motwFiles = Get-ChildItem -LiteralPath $resolvedRoot -Recurse -File -ErrorAction SilentlyContinue |
            Where-Object { $motwExtensions -contains $_.Extension.ToLowerInvariant() }
        $motwCount = 0
        foreach ($file in $motwFiles) {
            try {
                $stream = Get-Item -LiteralPath $file.FullName -Stream Zone.Identifier -ErrorAction SilentlyContinue
                if ($null -ne $stream) {
                    $motwCount++
                    $rel = Resolve-RelPath $resolvedRoot $file.FullName
                    Add-Finding "MOTW" "WARN" "Zone.Identifier" "Mark of the Web が付いています。ダウンロード由来として扱われ、実行・マクロ・SmartScreen等に影響する可能性があります。" $rel "職場ルールに従い、配布方法・展開方法・信頼済み場所を確認してください。"
                    if (-not $DeepScan -and $motwCount -ge 20) { break }
                }
            } catch {}
        }
        if ($motwCount -eq 0) {
            Add-Finding "MOTW" "OK" "Zone.Identifier" "主要対象ファイルにMark of the Webは検出されませんでした。" "" ""
        }
    } catch {
        Add-Finding "MOTW" "WARN" "Zone.Identifier" "Mark of the Web検査に失敗しました。" "" $_.Exception.Message
    }

    # ------------------------------------------------------------
    # 7. static code scan
    # ------------------------------------------------------------
    if (-not $SkipStaticScan) {
        $extensions = @('.ps1','.psm1','.bat','.cmd','.vbs','.js','.html','.css','.json','.xml','.bas','.cls','.frm','.vba','.hta','.md','.txt')
        $files = Get-ChildItem -LiteralPath $resolvedRoot -Recurse -File -ErrorAction SilentlyContinue |
            Where-Object { $extensions -contains $_.Extension.ToLowerInvariant() }

        if (-not $DeepScan) {
            $files = $files | Where-Object { $_.Length -lt 2MB }
        }

        $patterns = @(
            @{Name='External URL'; Pattern='https?://'; Severity='WARN'; Rec='外部参照・外部通信・公開URL混入の有無を確認してください。'},
            @{Name='fetch'; Pattern='\bfetch\s*\('; Severity='ERROR'; Rec='外部通信の可能性があります。職場ツールでは送信先・送信データ・必要性を明文化してください。'},
            @{Name='XMLHttpRequest'; Pattern='\bXMLHttpRequest\b'; Severity='ERROR'; Rec='外部通信の可能性があります。'},
            @{Name='WebSocket'; Pattern='\bWebSocket\b'; Severity='ERROR'; Rec='常時通信の可能性があります。'},
            @{Name='sendBeacon'; Pattern='\bsendBeacon\s*\('; Severity='ERROR'; Rec='バックグラウンド送信の可能性があります。'},
            @{Name='Invoke-WebRequest'; Pattern='\bInvoke-WebRequest\b|\biwr\b|\bcurl\b|\bwget\b'; Severity='WARN'; Rec='PowerShellからの外部通信・ダウンロードの可能性があります。'},
            @{Name='Invoke-RestMethod'; Pattern='\bInvoke-RestMethod\b|\birm\b'; Severity='WARN'; Rec='API通信の可能性があります。'},
            @{Name='Start-BitsTransfer'; Pattern='\bStart-BitsTransfer\b'; Severity='WARN'; Rec='BITSによるダウンロードの可能性があります。'},
            @{Name='eval/new Function'; Pattern='\beval\s*\(|\bnew\s+Function\b'; Severity='ERROR'; Rec='任意コード実行につながるため避けてください。'},
            @{Name='PowerShell Bypass/Encoded'; Pattern='(?i)(-ExecutionPolicy\s+Bypass|-EncodedCommand|-WindowStyle\s+Hidden)'; Severity='ERROR'; Rec='職場環境では強く警戒されます。原則避けてください。'},
            @{Name='Add-Type'; Pattern='\bAdd-Type\b'; Severity='WARN'; Rec='.NET/Win32呼出しの可能性があります。必要性を説明できる場合のみ。'},
            @{Name='Win32/VBA Declare'; Pattern='(?i)\bDeclare\s+(PtrSafe\s+)?Function\b|\bDeclare\s+(PtrSafe\s+)?Sub\b|user32\.dll|kernel32\.dll|advapi32\.dll'; Severity='WARN'; Rec='Win32 API利用は職場セキュリティで警戒されやすいです。'},
            @{Name='WScript/Shell'; Pattern='(?i)WScript\.Shell|ShellExecute|CreateObject\(["'']WScript\.Shell'; Severity='WARN'; Rec='外部プロセス起動やショートカット操作の可能性があります。'},
            @{Name='mshta/cscript/wscript'; Pattern='(?i)\bmshta\b|\bcscript\b|\bwscript\b'; Severity='WARN'; Rec='スクリプトホスト実行は制限対象になりやすいです。'},
            @{Name='Task Scheduler'; Pattern='(?i)\bschtasks\b|ScheduledTask|Register-ScheduledTask'; Severity='WARN'; Rec='常駐・自動実行に関わるため、職場利用では説明が必要です。'},
            @{Name='Registry write'; Pattern='(?i)\breg\s+add\b|Set-ItemProperty|New-ItemProperty'; Severity='WARN'; Rec='レジストリ変更は避けるか、必要性を明確にしてください。'},
            @{Name='localStorage'; Pattern='\blocalStorage\b'; Severity='INFO'; Rec='HTML/JSツールでは保存キー・容量・バックアップ導線を確認してください。'},
            @{Name='FileReader'; Pattern='\bFileReader\b'; Severity='INFO'; Rec='ブラウザでのローカルファイル読込が必要です。職場Edgeで実機確認してください。'},
            @{Name='canvas'; Pattern='\bcanvas\b|getContext\s*\('; Severity='INFO'; Rec='画像/PDF処理や描画に使います。ブラウザ実機確認が必要です。'},
            @{Name='download attr'; Pattern='\.download\s*=|download='; Severity='INFO'; Rec='ブラウザダウンロード制限の影響を受けます。'},
            @{Name='showSaveFilePicker'; Pattern='\bshowSaveFilePicker\s*\('; Severity='INFO'; Rec='保存先指定・上書き保存候補です。職場Edgeで browser/BrowserCapabilityCheck.html の実動作テストを行ってください。'},
            @{Name='FileSystemWritableFileStream'; Pattern='\bcreateWritable\s*\(|\bFileSystemWritableFileStream\b'; Severity='INFO'; Rec='File System Access API による書込み候補です。権限・HTTPS/file://・Edgeポリシー依存を確認してください。'},
            @{Name='showOpenFilePicker'; Pattern='\bshowOpenFilePicker\s*\('; Severity='INFO'; Rec='ファイル選択API候補です。通常の input type=file より環境依存が強い場合があります。'},

            @{Name='clipboard'; Pattern='navigator\.clipboard|Clipboard|Get-Clipboard|Set-Clipboard'; Severity='WARN'; Rec='クリップボード操作は制限・監査対象になり得ます。'},
            @{Name='console.log'; Pattern='\bconsole\.log\s*\('; Severity='WARN'; Rec='個人情報や内部情報がログに出ないか確認してください。'},
            @{Name='innerHTML'; Pattern='\.innerHTML\s*='; Severity='INFO'; Rec='ユーザー入力を直接挿入していないか確認してください。'},
            @{Name='Office COM'; Pattern='(?i)CreateObject\(["''](Excel|Word|Outlook|Access)\.Application'; Severity='WARN'; Rec='Office自動操作は権限・警告・誤送信に注意してください。'},
            @{Name='Outlook send'; Pattern='(?i)\.Send\s*\(|Send-MailMessage'; Severity='WARN'; Rec='メール自動送信は誤送信・監査リスクがあります。'},
            @{Name='Hard-coded path'; Pattern='[A-Za-z]:\\[^\s"'']+'; Severity='INFO'; Rec='固定パスは他端末で壊れやすいです。'},
            @{Name='Secrets keywords'; Pattern='(?i)(api[_-]?key|secret|token|password|passwd|client[_-]?secret)'; Severity='WARN'; Rec='キー・トークン・パスワード混入を確認してください。'},
            @{Name='Email address'; Pattern='[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}'; Severity='WARN'; Rec='個人メール・職場メール・内部アドレス混入を確認してください。'},
            @{Name='Japanese confidential words'; Pattern='(社外秘|機密|秘|取扱注意|個人情報|内部資料|部外秘)'; Severity='WARN'; Rec='機密文書由来の文言が混入していないか確認してください。'},

            # ==== v1.2 追加検出パターン ====

            # --- 動的script注入（pdf.min.js問題型） ---
            @{Name='Dynamic script injection'; Pattern='(?i)createElement\s*\(\s*["'']script["'']'; Severity='WARN'; Rec='実行時にscriptタグを差し込む方式は静的解析を回避しがちです。注入先URL、同梱有無、職場ポリシーへの影響を確認してください。'},
            @{Name='Dynamic script src assign'; Pattern='(?i)\.src\s*=\s*["''][^"'']+\.js["'']'; Severity='WARN'; Rec='動的scriptのsrc先（特に pdf.min.js のような任意ライブラリ）の同梱有無を確認してください。'},

            # --- localStorage 単一障害点 / 拡張機能 ---
            @{Name='IndexedDB usage'; Pattern='\bindexedDB\b|\bIDBDatabase\b|\bIDBObjectStore\b'; Severity='INFO'; Rec='IndexedDB使用。FileSystemFileHandleの永続化や大容量保存に使えますが、職場Edgeのデータ削除ポリシーの影響を受けます。'},
            @{Name='localStorage backup pair'; Pattern='(?i)BACKUP_KEY|backup.*localStorage|localStorage.*backup'; Severity='INFO'; Rec='バックアップキーを実装している痕跡があります。エクスポート導線（Blob+download）も別途用意してください。'},

            # --- canvas メモリ爆発系 ---
            @{Name='canvas toDataURL'; Pattern='\.toDataURL\s*\('; Severity='WARN'; Rec='toDataURLは画像サイズに比例して文字列が肥大化します。localStorage保存に流す場合は容量見積もりとMB単位の上限テストが必須です。'},
            @{Name='canvas toBlob'; Pattern='\.toBlob\s*\('; Severity='INFO'; Rec='toBlobはtoDataURLよりメモリ効率は良いです。Blob+download保存に向きます。'},
            @{Name='getImageData'; Pattern='\bgetImageData\s*\('; Severity='INFO'; Rec='画像ピクセル走査。file://でtainted canvasになるとSecurityErrorで停止します。'},

            # --- 印刷系 ---
            @{Name='print CSS @page'; Pattern='@page\s*\{'; Severity='INFO'; Rec='@pageでmargin:0を指定してもプリンタ最小余白に切り上げられます。実機プリンタ別の最小マージン測定を行ってください。'},
            @{Name='window.print'; Pattern='\bwindow\.print\s*\('; Severity='INFO'; Rec='印刷プレビューは実印字と数mm単位でズレることがあります。プレビュー任せにせず実機印字テストを行ってください。'},

            # --- 個人情報 平文保存 ---
            @{Name='Japanese personal data (name+address)'; Pattern='(?i)(zip|postal|address|name|tel|phone|郵便|住所|氏名|電話)\s*[:=]'; Severity='WARN'; Rec='個人情報フィールド名が見つかりました。localStorageに平文で保存している場合、ブラウザのデータ削除で全消失します。エクスポート/インポート導線とサンプル/本番データの混在検出を実装してください。'},
            @{Name='Phone number pattern'; Pattern='\b0\d{1,4}-\d{1,4}-\d{4}\b'; Severity='WARN'; Rec='電話番号らしき文字列があります。サンプルか本番データか確認してください。'},
            @{Name='Japanese postal code'; Pattern='〒?\s*\d{3}-\d{4}'; Severity='INFO'; Rec='郵便番号らしき文字列があります。サンプルか本番データか確認してください。'},

            # --- file:// 限定の地雷 ---
            @{Name='crypto.subtle'; Pattern='crypto\.subtle'; Severity='WARN'; Rec='crypto.subtleはfile://起動だと使えません。HTTPS or localhost必須です。'},
            @{Name='SharedArrayBuffer'; Pattern='\bSharedArrayBuffer\b'; Severity='WARN'; Rec='SharedArrayBufferはCOOP/COEPヘッダ要求があり、file://やCDN無し環境では動きません。'},
            @{Name='Web Worker'; Pattern='\bnew\s+Worker\s*\(|\bnew\s+SharedWorker\s*\('; Severity='INFO'; Rec='Web Workerは別ファイル読込が必要。file://起動でクロスオリジン扱いになり動かない環境があります。'},

            # --- IIFE / classic script の依存問題 ---
            @{Name='global namespace assignment'; Pattern='(?i)window\.[A-Z_][A-Za-z0-9_]*\s*=|globalThis\.[A-Z_][A-Za-z0-9_]*\s*='; Severity='INFO'; Rec='グローバル名前空間への登録があります。classic script順序読込型では1ファイルの読込漏れで沈黙クラッシュします。tests側の到達性検査を併用してください。'},

            # --- Excel COM 作法 ---
            @{Name='Excel COM Quit missing'; Pattern='(?i)New-Object\s+-ComObject\s+Excel\.Application|CreateObject\(["'']Excel\.Application'; Severity='WARN'; Rec='Excel COMを生成しています。.Quit()、$xl=$null、[GC]::Collect() / ReleaseComObject の解放処理が必須です。EXCEL.EXEプロセス残留に注意してください。'},
            @{Name='ReleaseComObject'; Pattern='\bReleaseComObject\b'; Severity='INFO'; Rec='COMオブジェクト明示解放あり。良い実装です。'},

            # --- フォント関連 ---
            @{Name='Specific Japanese font'; Pattern='(?i)(游ゴシック|游明朝|メイリオ|MS\s*ゴシック|MS\s*明朝|Yu\s*Gothic|Yu\s*Mincho|Meiryo|MS\s*Gothic|MS\s*Mincho|Noto\s*Sans\s*JP)'; Severity='INFO'; Rec='日本語フォント指定があります。配布先で未インストールの場合は別フォントへ置換され、印刷物の位置がズレることがあります。'},

            # --- 環境依存文字 ---
            @{Name='Environment dependent kanji samples'; Pattern='[髙﨑德彅㈱㈲]'; Severity='WARN'; Rec='環境依存文字がコード/サンプルに含まれます。フォント・コードページ・PDF埋込で豆腐化のリスクがあります。'},

            # --- ScriptBlockLogging / 監査 ---
            @{Name='PowerShell verbose data exposure'; Pattern='(?i)Write-Host\s+.*\$|Write-Output\s+.*\$|Out-String'; Severity='INFO'; Rec='個人情報を含む変数を出力すると、ScriptBlockLogging有効環境で監査ログに残ります。Get-WinEventで PowerShell Operational ログを確認してください。'},

            # --- OneDrive 動的パス ---
            @{Name='OneDrive path pattern'; Pattern='(?i)OneDrive\s*-\s*[^\\\s]+|\$env:OneDrive|\$env:OneDriveCommercial'; Severity='INFO'; Rec='OneDriveパスを参照しています。環境変数 $env:OneDrive / $env:OneDriveCommercial を使うとテナント名変更に強くなります。'},

            # --- exec / spawn 系（Node使う場合） ---
            @{Name='child_process exec'; Pattern='(?i)require\(["'']child_process["'']\)|\.exec\s*\(|\.spawn\s*\('; Severity='WARN'; Rec='Node.js child_process使用。職場PCにNode配布が必要、AppLockerに引っかかる可能性があります。'},

            # ==== v1.3 追加検出パターン ====

            # --- 印字系の追加地雷 (#1-#5) ---
            @{Name='CSS transform on print'; Pattern='transform\s*:\s*(?:scale|rotate|matrix|translate)'; Severity='WARN'; Rec='transformによる拡縮・回転は、プリンタによって印刷プレビューと実印字がズレる既知の問題があります。@media print内での使用は特に注意。実機で必ず印字テストを行ってください。'},
            @{Name='Physical unit mm'; Pattern='\b\d+(?:\.\d+)?\s*mm\b'; Severity='INFO'; Rec='物理単位mm指定があります。ブラウザのZoom倍率が100%以外だと印刷時に崩れます。ツール起動時にZoomチェックを入れることを推奨。'},
            @{Name='display none in print media'; Pattern='(?ms)@media\s+print[^{]*\{[^}]*display\s*:\s*none'; Severity='INFO'; Rec='@media print内でdisplay:noneを使用しています。非表示要素のgetBoundingClientRect()は0を返すため、位置計算が壊れる可能性があります。'},
            @{Name='afterprint event'; Pattern='\bafterprint\b|onafterprint'; Severity='INFO'; Rec='afterprintイベント使用あり。印刷キャンセル時のクリーンアップに必須です。検出されない場合は印刷後のstate残留リスクあり。'},
            @{Name='beforeprint event'; Pattern='\bbeforeprint\b|onbeforeprint'; Severity='INFO'; Rec='beforeprintイベント使用あり。'},

            # --- 一般的な地雷 (#6-#15) ---
            @{Name='innerHTML with variable'; Pattern='\.innerHTML\s*=\s*[^''"`;]*[a-zA-Z_$][a-zA-Z0-9_$]*'; Severity='WARN'; Rec='innerHTMLに変数を代入しています。ユーザー入力が混入するとXSSになります。textContentまたはサニタイズ処理を検討してください。'},
            @{Name='JSON.parse without try'; Pattern='(?<!try\s*\{[^}]*?)JSON\.parse\s*\('; Severity='INFO'; Rec='JSON.parseの呼出。localStorage等の破損データを読むときtry/catchが無いと起動できなくなります。各JSON.parseがtry/catchで囲まれているか確認してください。'},
            @{Name='CSS @import external'; Pattern='@import\s+url\s*\(\s*["'']?https?://'; Severity='WARN'; Rec='CSS @importで外部URLを参照しています。職場のファイアウォール/プロキシで遮断される可能性。同梱に切り替えてください。'},
            @{Name='CSS font-face external'; Pattern='@font-face[\s\S]{0,200}?src\s*:[\s\S]{0,200}?url\s*\(\s*["'']?https?://'; Severity='WARN'; Rec='@font-faceで外部URLを参照しています。職場環境ではフォント取得失敗→代替フォントへ置換→印字位置ズレの原因になります。'},
            @{Name='setInterval'; Pattern='\bsetInterval\s*\('; Severity='INFO'; Rec='setInterval使用。対応するclearIntervalがあるか確認してください。タイマーが解放されないとメモリリークと意図しない実行継続が起きます。'},
            @{Name='addEventListener without removeEventListener'; Pattern='\baddEventListener\s*\('; Severity='INFO'; Rec='addEventListener使用。同じ要素に複数回登録すると重複発火します。SPA的に再描画する設計ならremoveEventListenerと対にしてください。'},
            @{Name='input type=file without accept'; Pattern='<input[^>]*type\s*=\s*["'']file["''](?![^>]*\baccept\s*=)'; Severity='INFO'; Rec='input type=file に accept属性がありません。ユーザーが想定外のファイルを選んで実行時エラーになる可能性。'},
            @{Name='Mock/test/debug remnants'; Pattern='(?i)\b(TODO|FIXME|XXX|HACK|DEBUG|console\.log|debugger|alert\s*\()\b'; Severity='INFO'; Rec='開発中マーカーまたはデバッグコードが残っている可能性があります。配布前に確認してください。'},

            # --- 拡張機能観点の追加 (#16-#19) ---
            @{Name='Schema version field'; Pattern='(?i)schemaVersion|schema_version|"version"\s*:|dataVersion|migration'; Severity='INFO'; Rec='スキーマバージョンまたはマイグレーション機構の痕跡。拡張時のデータ互換性確保のため、明示的なバージョンフィールドを持つことを推奨します。'},
            @{Name='preventDefault for shortcut'; Pattern='\.preventDefault\s*\(\s*\).*(?:ctrlKey|metaKey)|(?:ctrlKey|metaKey).*\.preventDefault'; Severity='INFO'; Rec='キーボードショートカットでpreventDefault使用。Ctrl+S/Ctrl+Pの上書きは要注意。'},
            @{Name='Unit mixing risk'; Pattern='(?i)(\bmm\b.*\bpx\b|\bpx\b.*\bmm\b|\bpt\b.*\bmm\b|\binch\b.*\bmm\b)'; Severity='INFO'; Rec='同一ファイル内でmm/px/pt/inch等の単位が混在しています。座標計算で単位変換ミスが起きやすいです。'}
        )

        foreach ($file in $files) {
            $rel = Resolve-RelPath $resolvedRoot $file.FullName
            $text = Read-TextSafe $file.FullName
            if ([string]::IsNullOrEmpty($text)) { continue }
            foreach ($p in $patterns) {
                if ($text -match $p.Pattern) {
                    $evidence = Select-MatchingLines -Text $text -Pattern $p.Pattern -Max 6
                    Add-Finding "StaticScan" $p.Severity $p.Name "該当パターンが見つかりました: $rel" $evidence $p.Rec
                }
            }
        }
    } else {
        Add-Finding "StaticScan" "INFO" "Skipped" "静的スキャンはスキップされました。" "" ""
    }

    # ------------------------------------------------------------
    # 8. generic project layout hints
    # ------------------------------------------------------------
    $indexHtml = Join-Path $resolvedRoot 'index.html'
    if (Test-Path -LiteralPath $indexHtml) {
        $indexText = Read-TextSafe $indexHtml
        $scriptMatches = [regex]::Matches($indexText, '<script[^>]+src=["'']([^"'']+)["'']', 'IgnoreCase')
        foreach ($m in $scriptMatches) {
            $src = $m.Groups[1].Value
            if ($src -match '^https?://') {
                Add-Finding "HtmlProject" "ERROR" "ExternalScript" "index.htmlに外部scriptがあります。" $src "職場向け配布では原則ローカル同梱にしてください。"
            } else {
                $p = Join-Path $resolvedRoot ($src -replace '/', '\')
                if (Test-Path -LiteralPath $p) {
                    Add-Finding "HtmlProject" "OK" "ScriptExists" "script参照先が存在します。" $src ""
                } else {
                    Add-Finding "HtmlProject" "ERROR" "MissingScript" "script参照先が見つかりません。" $src "ZIP展開漏れ・README漏れ・読込順定義漏れを確認してください。"
                }
            }
        }

        $linkMatches = [regex]::Matches($indexText, '<link[^>]+href=["'']([^"'']+)["'']', 'IgnoreCase')
        foreach ($m in $linkMatches) {
            $href = $m.Groups[1].Value
            if ($href -match '^https?://') {
                Add-Finding "HtmlProject" "ERROR" "ExternalCss" "index.htmlに外部CSSがあります。" $href "職場向け配布では原則ローカル同梱にしてください。"
            } else {
                $p = Join-Path $resolvedRoot ($href -replace '/', '\')
                if (Test-Path -LiteralPath $p) {
                    Add-Finding "HtmlProject" "OK" "CssExists" "CSS参照先が存在します。" $href ""
                } else {
                    Add-Finding "HtmlProject" "ERROR" "MissingCss" "CSS参照先が見つかりません。" $href ""
                }
            }
        }
    }

    # ------------------------------------------------------------
    # 9. size / file counts
    # ------------------------------------------------------------
    try {
        $allFiles = Get-ChildItem -LiteralPath $resolvedRoot -Recurse -File -ErrorAction SilentlyContinue
        $total = ($allFiles | Measure-Object Length -Sum).Sum
        Add-Finding "Size" "INFO" "TotalSize" "対象フォルダ全体サイズです。" ("{0:N2} MB / Files={1}" -f ($total / 1MB), $allFiles.Count) ""
        $large = $allFiles | Where-Object { $_.Length -gt 1MB } | Sort-Object Length -Descending | Select-Object -First 20
        if ($large) {
            $table = $large | Select-Object @{n='Relative';e={Resolve-RelPath $resolvedRoot $_.FullName}}, @{n='MB';e={"{0:N2}" -f ($_.Length/1MB)}} | Format-Table -AutoSize | Out-String
            Add-Finding "Size" "INFO" "LargeFiles" "1MB超ファイル一覧です。" $table.Trim() "HTML localStorage保存やメール添付配布では容量に注意してください。"
        }
    } catch {}

    # ------------------------------------------------------------
    # 9b. v1.2 文字コード / BOM / 改行コード 診断
    # ------------------------------------------------------------
    function Get-FileEncodingInfo {
        param([string]$Path)
        try {
            $bytes = [System.IO.File]::ReadAllBytes($Path)
            if ($bytes.Length -eq 0) {
                return [pscustomobject]@{Encoding='Empty'; HasBom=$false; Newline='None'; Bytes=0}
            }
            $encoding = 'Unknown'
            $hasBom = $false
            # BOM判定
            if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
                $encoding = 'UTF-8'; $hasBom = $true
            } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
                $encoding = 'UTF-16LE'; $hasBom = $true
            } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
                $encoding = 'UTF-16BE'; $hasBom = $true
            } else {
                # BOMなし：UTF-8 valid判定
                try {
                    $utf8NoBom = New-Object System.Text.UTF8Encoding($false, $true)
                    [void]$utf8NoBom.GetString($bytes)
                    $encoding = 'UTF-8 (no BOM)'
                } catch {
                    # UTF-8として読めない → Shift_JIS可能性
                    $encoding = 'Non-UTF-8 (probably Shift_JIS or other)'
                }
            }
            # 改行判定
            $crlf = 0; $lf = 0; $cr = 0
            for ($i = 0; $i -lt [Math]::Min($bytes.Length, 65536); $i++) {
                if ($bytes[$i] -eq 0x0D) {
                    if ($i + 1 -lt $bytes.Length -and $bytes[$i+1] -eq 0x0A) { $crlf++; $i++ }
                    else { $cr++ }
                } elseif ($bytes[$i] -eq 0x0A) { $lf++ }
            }
            $newline = if ($crlf -gt 0 -and $lf -eq 0 -and $cr -eq 0) { 'CRLF' }
                       elseif ($lf -gt 0 -and $crlf -eq 0 -and $cr -eq 0) { 'LF' }
                       elseif ($cr -gt 0 -and $crlf -eq 0 -and $lf -eq 0) { 'CR' }
                       elseif ($crlf + $lf + $cr -eq 0) { 'None' }
                       else { ("Mixed (CRLF={0}, LF={1}, CR={2})" -f $crlf, $lf, $cr) }
            return [pscustomobject]@{Encoding=$encoding; HasBom=$hasBom; Newline=$newline; Bytes=$bytes.Length}
        } catch {
            return [pscustomobject]@{Encoding='Error'; HasBom=$false; Newline='Error'; Bytes=0}
        }
    }

    $encodingTargets = @('.ps1','.psm1','.psd1','.bat','.cmd','.vbs','.bas','.cls','.frm','.vba','.js','.html','.htm','.css','.json','.xml','.csv','.tsv','.txt','.md')
    try {
        $encFiles = Get-ChildItem -LiteralPath $resolvedRoot -Recurse -File -ErrorAction SilentlyContinue |
            Where-Object { $encodingTargets -contains $_.Extension.ToLowerInvariant() }
        if (-not $DeepScan) { $encFiles = $encFiles | Where-Object { $_.Length -lt 2MB } }

        foreach ($f in $encFiles) {
            $info = Get-FileEncodingInfo -Path $f.FullName
            $rel = Resolve-RelPath $resolvedRoot $f.FullName
            $ext = $f.Extension.ToLowerInvariant()

            # 拡張子ごとの「あるべき姿」と比較
            $sev = 'INFO'
            $rec = ''
            switch ($ext) {
                # PowerShellは UTF-8 BOM 付き or UTF-16LE BOM 推奨（5.1で日本語が確実に読める）
                { @('.ps1','.psm1','.psd1') -contains $_ } {
                    if ($info.Encoding -eq 'UTF-8 (no BOM)') {
                        $sev = 'WARN'
                        $rec = 'PowerShell 5.1 では BOM 無し UTF-8 だと日本語が Shift_JIS として読まれて文字化けします。UTF-8 BOM 付きで保存し直してください。PowerShell 7 のみ運用なら BOM 無しでもOKです。'
                    }
                }
                # cmd/bat は Shift_JIS（CP932）必須
                { @('.bat','.cmd') -contains $_ } {
                    if ($info.Encoding -match 'UTF-8') {
                        $sev = 'WARN'
                        $rec = 'cmd/bat は Shift_JIS (CP932) で保存しないと日本語 echo が文字化けします。エディタの保存形式を Shift_JIS に変更してください。'
                    }
                }
                # CSVは要件次第だが、ExcelダブルクリックではBOM付きUTF-8 or Shift_JISが安全
                { $_ -eq '.csv' } {
                    if ($info.Encoding -eq 'UTF-8 (no BOM)') {
                        $sev = 'WARN'
                        $rec = 'CSV を BOM 無し UTF-8 で出力すると、ユーザーがダブルクリックで Excel 開いた時に文字化けします。BOM 付き UTF-8 で出力してください。'
                    }
                }
                # JSは UTF-8 (BOM無し推奨)
                { $_ -eq '.js' } {
                    if ($info.HasBom) {
                        $sev = 'INFO'
                        $rec = 'JavaScript ファイルに BOM が付いています。classic script 読込でも通常は無視されますが、Node 等で稀に問題になることがあります。'
                    }
                }
                # VBA .bas は Shift_JIS (CP932) 推奨
                { @('.bas','.cls','.frm','.vba') -contains $_ } {
                    if ($info.Encoding -match 'UTF-8') {
                        $sev = 'INFO'
                        $rec = 'VBA モジュールは通常 Shift_JIS で保存されます。インポート時に文字化けの可能性があります。'
                    }
                }
            }

            $detail = "{0} | {1} | newline={2} | {3:N0} bytes" -f $rel, $info.Encoding, $info.Newline, $info.Bytes
            Add-Finding "Encoding" $sev "FileEncoding" $detail "" $rec
        }
    } catch {
        Add-Finding "Encoding" "WARN" "EncodingScan" "文字コード診断に失敗しました。" "" $_.Exception.Message
    }

    # ------------------------------------------------------------
    # 9c. v1.2 HTML 依存関係グラフ（classic script 順序読込型）
    # ------------------------------------------------------------
    $htmlFiles = Get-ChildItem -LiteralPath $resolvedRoot -Recurse -File -Filter '*.html' -ErrorAction SilentlyContinue
    foreach ($htmlFile in $htmlFiles) {
        $htmlText = Read-TextSafe $htmlFile.FullName
        if ([string]::IsNullOrEmpty($htmlText)) { continue }
        $htmlRel = Resolve-RelPath $resolvedRoot $htmlFile.FullName
        $htmlDir = Split-Path -LiteralPath $htmlFile.FullName -Parent

        $scriptMatches = [regex]::Matches($htmlText, '<script[^>]+src=["'']([^"'']+)["'']', 'IgnoreCase')
        $scriptCount = $scriptMatches.Count
        if ($scriptCount -ge 20) {
            Add-Finding "Dependency" "WARN" "Many classic scripts" ("{0} には {1} 個の script src があります。" -f $htmlRel, $scriptCount) "" 'classic script の順序読込は、1ファイルの欠落・順序ミスで沈黙クラッシュします。tests側で各モジュールの到達性検査を必ず実装してください。'
        }

        # 動的注入されてる可能性のあるscriptをJSから検出してHTML側に同梱されてるかチェック
        $jsFiles = Get-ChildItem -LiteralPath $htmlDir -Recurse -File -Filter '*.js' -ErrorAction SilentlyContinue
        $dynScriptRefs = New-Object System.Collections.Generic.HashSet[string]
        foreach ($jsf in $jsFiles) {
            $jt = Read-TextSafe $jsf.FullName
            if ([string]::IsNullOrEmpty($jt)) { continue }
            $matches = [regex]::Matches($jt, '\.src\s*=\s*["'']([^"''\s]+\.js)["'']', 'IgnoreCase')
            foreach ($m in $matches) {
                $ref = $m.Groups[1].Value
                if ($ref -notmatch '^https?://') { [void]$dynScriptRefs.Add($ref) }
            }
        }
        foreach ($ref in $dynScriptRefs) {
            $resolved = Join-Path $htmlDir ($ref -replace '^\./','' -replace '/', '\')
            if (Test-Path -LiteralPath $resolved) {
                Add-Finding "Dependency" "OK" "DynamicScriptBundled" ("動的script注入先が同梱されています: " + $ref) $resolved ""
            } else {
                Add-Finding "Dependency" "WARN" "DynamicScriptMissing" ("動的に注入される script が同梱されていません: " + $ref) "ユーザー手動配置が必要" '配布時に "$ref" を同梱するか、README に明示してください。pdf.min.js のような外部ライブラリ依存はZIP配布物に同梱推奨です。'
            }
        }
    }

    # ------------------------------------------------------------
    # 9d. v1.2 localStorage 使用キー一覧
    # ------------------------------------------------------------
    $storageKeys = New-Object System.Collections.Generic.HashSet[string]
    try {
        $jsAllFiles = Get-ChildItem -LiteralPath $resolvedRoot -Recurse -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Extension -in '.js','.html' }
        foreach ($jsf in $jsAllFiles) {
            $jt = Read-TextSafe $jsf.FullName
            if ([string]::IsNullOrEmpty($jt)) { continue }
            $matches = [regex]::Matches($jt, "localStorage\.(?:setItem|getItem|removeItem)\s*\(\s*['""]([^'""]+)['""]")
            foreach ($m in $matches) { [void]$storageKeys.Add($m.Groups[1].Value) }
            $matches2 = [regex]::Matches($jt, "STORAGE_KEY\s*[:=]\s*['""]([^'""]+)['""]|BACKUP_KEY\s*[:=]\s*['""]([^'""]+)['""]")
            foreach ($m in $matches2) {
                foreach ($g in $m.Groups) {
                    if ($g.Value -and $g.Value -ne $m.Value) { [void]$storageKeys.Add($g.Value) }
                }
            }
        }
        if ($storageKeys.Count -gt 0) {
            $keyList = ($storageKeys | Sort-Object) -join "`n"
            $sev = if ($storageKeys.Count -ge 10) { 'WARN' } else { 'INFO' }
            Add-Finding "Storage" $sev "LocalStorageKeys" ("検出された localStorage キー: " + $storageKeys.Count + "個") $keyList 'localStorage の上限は概ね 5MB です。キー数が多い場合は browser/BrowserCapabilityCheck_v12.html の容量実測を行ってください。'
        }
    } catch {}

    # ------------------------------------------------------------
    # 9e. v1.2 拡張機能レディネス検査
    # ------------------------------------------------------------
    function Test-FeaturePresence {
        param([string[]]$Files, [string]$Pattern)
        foreach ($f in $Files) {
            $t = Read-TextSafe $f.FullName
            if ([string]::IsNullOrEmpty($t)) { continue }
            if ($t -match $Pattern) { return $true }
        }
        return $false
    }

    $allCodeFiles = Get-ChildItem -LiteralPath $resolvedRoot -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in '.js','.html','.ps1','.psm1','.bas','.cls','.vba' }

    $features = @(
        @{Name='保存先指定保存 (showSaveFilePicker)'; Pattern='\bshowSaveFilePicker\s*\('; Rec='browser/BrowserCapabilityCheck_v12.html で職場Edgeでの実動作を必ず確認してください。'},
        @{Name='ファイルハンドル永続化 (IndexedDB)'; Pattern='\bindexedDB\b.*(?:FileSystemFileHandle|put.*handle)|put\s*\([^)]*FileSystemFileHandle'; Rec='showSaveFilePicker を「次回起動時も同じ場所」で使うにはIndexedDBへFileSystemFileHandleを永続化する実装が必要です。'},
        @{Name='バックアップ強制エクスポート'; Pattern='(?i)BACKUP_KEY|export.*backup|backup.*export|Blob.*download.*json'; Rec='localStorage 単一障害点回避のため、定期 or 手動の JSON エクスポート導線を必ず用意してください。'},
        @{Name='インポート復元'; Pattern='\bFileReader\b.*JSON\.parse|JSON\.parse.*reader\.result'; Rec='エクスポートだけでなく JSON 復元導線も実装しないと、データ消失時に救済できません。'},
        @{Name='印刷プレビュー検査'; Pattern='@media\s+print|@page'; Rec='印刷CSSがあります。実機プリンタ別に位置ズレを測定し、補正値テンプレートを用意してください。'},
        @{Name='テスト到達性検査'; Pattern='audit_marker|registry.*check|verify_structure'; Rec='classic script順序読込型では、各ファイルが実際に読み込まれたかの到達性検査を tests/ で必ず実装してください。'},
        @{Name='Excel COM 解放処理'; Pattern='ReleaseComObject|\[GC\]::Collect'; Rec='Excel COM を使うなら ReleaseComObject と GC.Collect を必ず呼んで EXCEL.EXE プロセス残留を防いでください。'}
    )
    foreach ($feat in $features) {
        $found = Test-FeaturePresence -Files $allCodeFiles -Pattern $feat.Pattern
        if ($found) {
            Add-Finding "FeatureReadiness" "OK" $feat.Name "拡張・対策コードが検出されました。" "" $feat.Rec
        } else {
            Add-Finding "FeatureReadiness" "INFO" $feat.Name "該当する拡張・対策コードは見つかりませんでした。" "" ("未実装の可能性: " + $feat.Rec)
        }
    }

    # ------------------------------------------------------------
    # 9f. v1.2 PowerShell 監査ログ設定の確認
    # ------------------------------------------------------------
    if (-not $SkipPolicyScan) {
        $psLogPaths = @(
            @{Path='HKLM:\Software\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging'; Name='ScriptBlockLogging'},
            @{Path='HKLM:\Software\Policies\Microsoft\Windows\PowerShell\Transcription'; Name='Transcription'},
            @{Path='HKLM:\Software\Policies\Microsoft\Windows\PowerShell\ModuleLogging'; Name='ModuleLogging'}
        )
        foreach ($pl in $psLogPaths) {
            if (Test-Path $pl.Path) {
                try {
                    $props = Get-ItemProperty -Path $pl.Path -ErrorAction Stop
                    $enabled = if ($props.PSObject.Properties.Match('EnableScriptBlockLogging').Count -gt 0) { $props.EnableScriptBlockLogging }
                               elseif ($props.PSObject.Properties.Match('EnableTranscripting').Count -gt 0) { $props.EnableTranscripting }
                               elseif ($props.PSObject.Properties.Match('EnableModuleLogging').Count -gt 0) { $props.EnableModuleLogging }
                               else { 'Unknown' }
                    $sev = if ($enabled -eq 1) { 'WARN' } else { 'INFO' }
                    Add-Finding "Audit" $sev $pl.Name ("{0} = {1}" -f $pl.Name, $enabled) $pl.Path '個人情報や顧客データを扱うツールでは、PowerShellのログにデータが残ると監査上の問題になります。Write-Host/Write-Output に変数を直接渡さず、マスク処理を入れてください。'
                } catch {
                    Add-Finding "Audit" "INFO" $pl.Name "設定取得に失敗しました。" $pl.Path $_.Exception.Message
                }
            } else {
                Add-Finding "Audit" "INFO" $pl.Name "設定キー無し（既定では無効）" $pl.Path ""
            }
        }
    }

    # ------------------------------------------------------------
    # 9g. v1.2 フォント存在確認
    # ------------------------------------------------------------
    try {
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop
        $installedFonts = New-Object System.Collections.Generic.HashSet[string]
        $fc = New-Object System.Drawing.Text.InstalledFontCollection
        foreach ($fam in $fc.Families) { [void]$installedFonts.Add($fam.Name) }
        $checkFonts = @('Yu Gothic','Yu Mincho','Meiryo','MS Gothic','MS Mincho','Noto Sans JP','Noto Serif JP','BIZ UDPGothic','UD Digi Kyokasho NK-R')
        foreach ($fn in $checkFonts) {
            if ($installedFonts.Contains($fn)) {
                Add-Finding "Font" "OK" $fn "フォントがインストールされています。" "" ""
            } else {
                Add-Finding "Font" "INFO" $fn "フォントが見つかりません。" "" "PDF生成・印刷ツールで指定する場合は、代替フォントへの置換ロジックを必ず入れてください。"
            }
        }
    } catch {
        Add-Finding "Font" "WARN" "FontEnumeration" "フォント列挙に失敗しました。" "" $_.Exception.Message
    }

    # ------------------------------------------------------------
    # 9h. v1.2 OneDrive パス動的解決テスト
    # ------------------------------------------------------------
    try {
        $oneDriveEnv = $env:OneDrive
        $oneDriveCommercialEnv = $env:OneDriveCommercial
        $oneDriveConsumerEnv = $env:OneDriveConsumer
        $detail = @()
        if ($oneDriveEnv)           { $detail += "OneDrive=$oneDriveEnv" }
        if ($oneDriveCommercialEnv) { $detail += "OneDriveCommercial=$oneDriveCommercialEnv" }
        if ($oneDriveConsumerEnv)   { $detail += "OneDriveConsumer=$oneDriveConsumerEnv" }
        if ($detail.Count -gt 0) {
            Add-Finding "OneDrive" "INFO" "OneDrivePaths" "OneDrive環境変数が見つかりました。" ($detail -join "`n") '保存先指定でハードコードせず、$env:OneDrive / $env:OneDriveCommercial を使えばテナント名変更に強くなります。'
        } else {
            Add-Finding "OneDrive" "INFO" "OneDrivePaths" "OneDrive環境変数が見つかりません。" "" "OneDrive未セットアップか、サインインしていない可能性があります。"
        }
    } catch {}

    # ------------------------------------------------------------
    # 9i. v1.2 一時ディレクトリ書込テスト
    # ------------------------------------------------------------
    $tempDirs = @(
        @{Name='TEMP'; Path=$env:TEMP},
        @{Name='APPDATA'; Path=$env:APPDATA},
        @{Name='LOCALAPPDATA'; Path=$env:LOCALAPPDATA},
        @{Name='USERPROFILE_Desktop'; Path=(Join-Path $env:USERPROFILE 'Desktop')}
    )
    foreach ($td in $tempDirs) {
        if ([string]::IsNullOrEmpty($td.Path)) {
            Add-Finding "TempDir" "WARN" $td.Name "環境変数未設定" "" "ログ・一時ファイル出力先として使う場合は別パスを検討してください。"
            continue
        }
        if (-not (Test-Path -LiteralPath $td.Path)) {
            Add-Finding "TempDir" "WARN" $td.Name "ディレクトリが存在しません。" $td.Path ""
            continue
        }
        $testFile = Join-Path $td.Path (".workplace_env_v12_" + [Guid]::NewGuid().ToString('N').Substring(0,8) + ".tmp")
        try {
            "test" | Set-Content -LiteralPath $testFile -Encoding UTF8 -ErrorAction Stop
            Remove-Item -LiteralPath $testFile -Force -ErrorAction SilentlyContinue
            Add-Finding "TempDir" "OK" $td.Name "書込・削除可能です。" $td.Path ""
        } catch {
            Add-Finding "TempDir" "WARN" $td.Name "書込テストに失敗しました。" $td.Path $_.Exception.Message
        }
    }

    # ------------------------------------------------------------
    # 9j. v1.3 グローバル名前空間の重複定義検出
    # ------------------------------------------------------------
    try {
        $globalAssignments = @{}
        $jsScanFiles = Get-ChildItem -LiteralPath $resolvedRoot -Recurse -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Extension -in '.js','.html' }
        foreach ($jsf in $jsScanFiles) {
            $jt = Read-TextSafe $jsf.FullName
            if ([string]::IsNullOrEmpty($jt)) { continue }
            $rel = Resolve-RelPath $resolvedRoot $jsf.FullName
            # window.X = / globalThis.X = / global.X = の代入を抽出
            $matches = [regex]::Matches($jt, '(?:window|globalThis|global)\.([A-Za-z_$][A-Za-z0-9_$]*)\s*=')
            foreach ($m in $matches) {
                $name = $m.Groups[1].Value
                if (-not $globalAssignments.ContainsKey($name)) { $globalAssignments[$name] = @() }
                if ($globalAssignments[$name] -notcontains $rel) { $globalAssignments[$name] += $rel }
            }
        }
        $duplicates = $globalAssignments.GetEnumerator() | Where-Object { $_.Value.Count -ge 2 }
        foreach ($dup in $duplicates) {
            $files = ($dup.Value -join ', ')
            Add-Finding "Namespace" "WARN" "DuplicateGlobalAssignment" ("同名のグローバル登録が複数ファイルで行われています: " + $dup.Key) $files '後から読み込まれたファイルが先のファイルの定義を上書きします。stage5/6/7/8 のように段階追加する設計では、登録APIを介して衝突を検出する仕組みを推奨します。'
        }
        if ($duplicates.Count -eq 0 -and $globalAssignments.Count -gt 0) {
            Add-Finding "Namespace" "OK" "NoDuplicateGlobals" ("グローバル登録の重複なし。検出済みグローバル: " + $globalAssignments.Count + "個") "" ""
        }
    } catch {
        Add-Finding "Namespace" "WARN" "DuplicateGlobalScan" "重複グローバル検出に失敗しました。" "" $_.Exception.Message
    }

    # ------------------------------------------------------------
    # 9k. v1.3 配布物クリーンアップ検査（node_modules / .git / バックアップ混入）
    # ------------------------------------------------------------
    try {
        $junkPatterns = @(
            @{Name='node_modules'; Pattern='node_modules'; Sev='WARN'; Rec='配布前にnode_modulesは除外してください。サイズ膨大、不要、職場ポリシー違反の可能性。'},
            @{Name='.git'; Pattern='\\\.git\\|/\.git/|\\\.git$|/\.git$'; Sev='WARN'; Rec='配布前に.gitフォルダは除外してください。コミット履歴に個人情報・秘密情報が含まれている可能性。'},
            @{Name='.vscode'; Pattern='\\\.vscode\\|/\.vscode/'; Sev='INFO'; Rec='.vscode設定が含まれています。配布物としては不要です。'},
            @{Name='.idea'; Pattern='\\\.idea\\|/\.idea/'; Sev='INFO'; Rec='.ideaフォルダ（JetBrains系IDE設定）が含まれています。配布物としては不要です。'},
            @{Name='Backup files'; Pattern='\.(bak|backup|old|orig|tmp)$|~$'; Sev='WARN'; Rec='バックアップファイルが混入しています。古い情報・個人情報の漏えいリスク。'},
            @{Name='DS_Store'; Pattern='\.DS_Store$'; Sev='INFO'; Rec='macOSの.DS_Storeファイルが含まれています。配布前に削除してください。'},
            @{Name='Thumbs.db'; Pattern='Thumbs\.db$|desktop\.ini$'; Sev='INFO'; Rec='Windowsのシステムファイルが含まれています。配布前に削除してください。'}
        )
        $allFilesForJunk = Get-ChildItem -LiteralPath $resolvedRoot -Recurse -Force -ErrorAction SilentlyContinue
        foreach ($jp in $junkPatterns) {
            $hits = $allFilesForJunk | Where-Object { $_.FullName -match $jp.Pattern }
            if ($hits) {
                $samples = ($hits | Select-Object -First 5 | ForEach-Object { Resolve-RelPath $resolvedRoot $_.FullName }) -join "`n"
                Add-Finding "Cleanup" $jp.Sev $jp.Name ("該当: " + $hits.Count + "個") $samples $jp.Rec
            }
        }
    } catch {
        Add-Finding "Cleanup" "INFO" "CleanupScan" "クリーンアップ検査に失敗しました。" "" $_.Exception.Message
    }

    # ------------------------------------------------------------
    # 9l. v1.3 パス長制限（Windows MAX_PATH=260）検査
    # ------------------------------------------------------------
    try {
        # 配布先パス候補での想定長を考慮：C:\Users\<user>\Desktop\<this-dir>\ の長さを差し引いた残りで260を計算
        $rootLen = $resolvedRoot.Length
        $longPaths = @()
        $allF = Get-ChildItem -LiteralPath $resolvedRoot -Recurse -File -Force -ErrorAction SilentlyContinue
        foreach ($f in $allF) {
            $rel = $f.FullName.Substring($rootLen).TrimStart('\','/')
            # 想定配布先パスを仮定: "C:\Users\username1234567890\Desktop\配布フォルダ\" = 約60文字
            $assumedDeployPathLen = 60
            $projectedTotal = $assumedDeployPathLen + $rel.Length
            if ($projectedTotal -ge 240) {
                $longPaths += [pscustomobject]@{Rel=$rel; Projected=$projectedTotal}
            }
        }
        if ($longPaths.Count -gt 0) {
            $tbl = $longPaths | Sort-Object Projected -Descending | Select-Object -First 10 |
                ForEach-Object { ("{0,4} chars: {1}" -f $_.Projected, $_.Rel) }
            Add-Finding "PathLength" "WARN" "LongPathRisk" ("想定総パス長が240文字を超えるファイル: " + $longPaths.Count + "個") ($tbl -join "`n") 'Windows既定のMAX_PATH=260を超える可能性。配布先のフォルダ構造によっては開けない/開発・展開時にエラーになります。階層を浅くする・ファイル名を短くする等を検討してください。'
        } else {
            Add-Finding "PathLength" "OK" "PathLengthSafe" ("最大パス長は安全範囲内です。ファイル数: " + $allF.Count) "" ""
        }
    } catch {
        Add-Finding "PathLength" "INFO" "PathLengthScan" "パス長検査に失敗しました。" "" $_.Exception.Message
    }

    # ------------------------------------------------------------
    # 9m. v1.3 testsフォルダ存在と内容簡易検査
    # ------------------------------------------------------------
    try {
        $testsDirs = Get-ChildItem -LiteralPath $resolvedRoot -Recurse -Directory -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match '^(tests?|spec|__tests__)$' }
        if ($testsDirs) {
            foreach ($td in $testsDirs) {
                $testFiles = Get-ChildItem -LiteralPath $td.FullName -Recurse -File -ErrorAction SilentlyContinue |
                    Where-Object { $_.Extension -in '.js','.ts','.html','.ps1' }
                $rel = Resolve-RelPath $resolvedRoot $td.FullName
                if ($testFiles.Count -eq 0) {
                    Add-Finding "Tests" "WARN" "EmptyTestsDir" ("testsフォルダが空です: " + $rel) "" 'テストフォルダはあるが中身がない。tests/ の実装を進めるか、配布前に空フォルダを削除してください。'
                } else {
                    Add-Finding "Tests" "OK" "TestsExist" ("testsフォルダにテストファイルが " + $testFiles.Count + " 個あります: " + $rel) "" 'テストファイルの存在は確認できましたが、実際にPASSするかは静的解析では分かりません。配布前に必ず実機で実行してください。'
                }
            }
        } else {
            Add-Finding "Tests" "INFO" "NoTestsDir" "testsフォルダが見つかりません。" "" '個人専用ツールなら不要ですが、複雑なロジックを含む場合は最低限の到達性テストを推奨します。'
        }
    } catch {}

    # ------------------------------------------------------------
    # 9n. v1.3 HTML lang属性 / charset / meta viewport の確認
    # ------------------------------------------------------------
    try {
        $htmlFilesForMeta = Get-ChildItem -LiteralPath $resolvedRoot -Recurse -File -Filter '*.html' -ErrorAction SilentlyContinue
        foreach ($hf in $htmlFilesForMeta) {
            $ht = Read-TextSafe $hf.FullName
            if ([string]::IsNullOrEmpty($ht)) { continue }
            $rel = Resolve-RelPath $resolvedRoot $hf.FullName
            $hasLang = $ht -match '<html[^>]+lang\s*=\s*["''][^"'']+["'']'
            $hasCharset = $ht -match '<meta[^>]+charset'
            $hasViewport = $ht -match '<meta[^>]+name\s*=\s*["'']viewport["'']'

            if (-not $hasLang) {
                Add-Finding "HtmlMeta" "INFO" "MissingLang" ($rel + ": html lang属性が未指定です。") "" 'lang="ja" を指定するとフォント選択・読み上げソフト等で改善します。'
            }
            if (-not $hasCharset) {
                Add-Finding "HtmlMeta" "WARN" "MissingCharset" ($rel + ": meta charset未指定です。") "" 'charset未指定だと一部環境でShift_JIS解釈されて文字化けします。<meta charset="utf-8"> を必ず入れてください。'
            }
            if (-not $hasViewport) {
                Add-Finding "HtmlMeta" "INFO" "MissingViewport" ($rel + ": meta viewport未指定です。") "" 'モバイル/タブレット対応するなら必要です。デスクトップ専用なら不要。'
            }
        }
    } catch {}

    # ------------------------------------------------------------
    # 10. scoring
    # ------------------------------------------------------------
    $errorCount = ($findings | Where-Object { $_.Severity -eq 'ERROR' }).Count
    $warnCount = ($findings | Where-Object { $_.Severity -eq 'WARN' }).Count
    $grade = if ($errorCount -gt 0) { 'RED' } elseif ($warnCount -gt 0) { 'YELLOW' } else { 'GREEN' }
    Add-Finding "Summary" $grade "OverallGrade" "総合判定です。REDは要修正、YELLOWは要確認、GREENは重大警告なしです。" ("ERROR={0}; WARN={1}" -f $errorCount, $warnCount) "最終判断は職場ルールと実機確認に従ってください。"

    # ------------------------------------------------------------
    # 11. report output
    # ------------------------------------------------------------
    $summary = $findings | Group-Object Severity | Sort-Object Name | ForEach-Object { [pscustomobject]@{ Severity=$_.Name; Count=$_.Count } }
    $report = [pscustomobject]@{
        ToolName    = 'Workplace Environment Audit Kit'
        ToolVersion = 'v1.3'
        GeneratedAt = (Get-Date).ToString('s')
        TargetRoot  = $resolvedRoot
        OutputDir   = $OutputDir
        Grade       = $grade
        Summary     = $summary
        Findings    = $findings
    }

    $jsonPath = Join-Path $OutputDir 'workplace_env_audit_report.json'
    $csvPath  = Join-Path $OutputDir 'workplace_env_audit_findings.csv'
    $txtPath  = Join-Path $OutputDir 'workplace_env_audit_summary.txt'
    $htmlPath = Join-Path $OutputDir 'workplace_env_audit_report.html'

    $report | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $jsonPath -Encoding UTF8
    $findings | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8

    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('汎用・職場環境制約チェッカー レポート')
    [void]$sb.AppendLine("GeneratedAt: $($report.GeneratedAt)")
    [void]$sb.AppendLine("TargetRoot : $resolvedRoot")
    [void]$sb.AppendLine("Grade      : $grade")
    [void]$sb.AppendLine('')
    [void]$sb.AppendLine('Summary:')
    foreach ($s in $summary) { [void]$sb.AppendLine(("  {0}: {1}" -f $s.Severity, $s.Count)) }
    [void]$sb.AppendLine('')
    [void]$sb.AppendLine('ERROR/WARN/YELLOW/RED:')
    foreach ($f in ($findings | Where-Object { $_.Severity -in @('ERROR','WARN','YELLOW','RED') })) {
        [void]$sb.AppendLine(("[{0}] {1} / {2}" -f $f.Severity, $f.Category, $f.Item))
        [void]$sb.AppendLine("  Detail: $($f.Detail)")
        if ($f.Evidence) { [void]$sb.AppendLine("  Evidence: $($f.Evidence)") }
        if ($f.Recommendation) { [void]$sb.AppendLine("  Recommendation: $($f.Recommendation)") }
        [void]$sb.AppendLine('')
    }
    $sb.ToString() | Set-Content -LiteralPath $txtPath -Encoding UTF8

    $rows = $findings | ForEach-Object {
        $sevClass = $_.Severity.ToLowerInvariant()
        '<tr class="{0}"><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td><pre>{5}</pre></td><td>{6}</td></tr>' -f (HtmlEncode $sevClass), (HtmlEncode $_.Severity), (HtmlEncode $_.Category), (HtmlEncode $_.Item), (HtmlEncode $_.Detail), (HtmlEncode $_.Evidence), (HtmlEncode $_.Recommendation)
    }
    $html = @"
<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>職場環境制約チェッカー レポート</title>
<style>
body{font-family:"Yu Gothic",Meiryo,sans-serif;margin:24px;background:#f7f7fb;color:#202033;}
header{padding:18px 22px;background:#fff;border-radius:14px;box-shadow:0 2px 12px rgba(0,0,0,.08);}
.badge{display:inline-block;padding:6px 12px;border-radius:999px;font-weight:700;background:#eee;}
.badge.RED,.badge.red{background:#ffd8d8;color:#920000}.badge.YELLOW,.badge.yellow{background:#fff0c2;color:#775100}.badge.GREEN,.badge.green{background:#dff7df;color:#145214}
table{border-collapse:collapse;width:100%;margin-top:18px;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.08);}
th,td{border-bottom:1px solid #e5e5ef;padding:8px 10px;vertical-align:top;font-size:13px;}th{background:#efeefd;text-align:left;position:sticky;top:0;}
tr.error, tr.red{background:#fff3f3;} tr.warn, tr.yellow{background:#fff9e8;} tr.ok{background:#f4fff4;} pre{white-space:pre-wrap;margin:0;max-width:540px;}
</style>
</head>
<body>
<header>
<h1>汎用・職場環境制約チェッカー レポート</h1>
<p><b>GeneratedAt:</b> $(HtmlEncode $report.GeneratedAt)</p>
<p><b>TargetRoot:</b> $(HtmlEncode $resolvedRoot)</p>
<p><b>Grade:</b> <span class="badge $grade">$(HtmlEncode $grade)</span></p>
</header>
<table>
<thead><tr><th>Severity</th><th>Category</th><th>Item</th><th>Detail</th><th>Evidence</th><th>Recommendation</th></tr></thead>
<tbody>
$($rows -join "`n")
</tbody>
</table>
</body>
</html>
"@
    $html | Set-Content -LiteralPath $htmlPath -Encoding UTF8

    Write-Host ""
    Write-Host "診断完了" -ForegroundColor Green
    Write-Host "Grade: $grade"
    Write-Host "JSON : $jsonPath"
    Write-Host "CSV  : $csvPath"
    Write-Host "TXT  : $txtPath"
    Write-Host "HTML : $htmlPath"
    Write-Host ""
    $summary | Format-Table -AutoSize

    if ($OpenReport) {
        try { Start-Process $htmlPath } catch {}
    }

    return $report
}

# ファイル実行時はそのまま実行。ドットソース時は関数だけ利用可能。
if ($MyInvocation.InvocationName -ne '.') {
    Invoke-WorkplaceEnvironmentAudit -TargetRoot $TargetRoot -OutputDir $OutputDir -DeepScan:$DeepScan -TestTargetWrite:$TestTargetWrite -SkipPolicyScan:$SkipPolicyScan -SkipStaticScan:$SkipStaticScan -OpenReport:$OpenReport | Out-Null
}
