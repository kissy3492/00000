#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LIB="$ROOT/lib"
TMP="$ROOT/_download_tmp"
CORE="$LIB/core"
PPOCR="$LIB/ppocr"
mkdir -p "$LIB" "$TMP" "$CORE" "$PPOCR"

PDFJS="3.11.174"
TESS="5.1.1"
ORT="1.18.0"
OPENCV="4.10.0"

download(){
  local url="$1" out="$2"
  echo "GET $url"
  curl -L --fail "$url" -o "$out"
  test -s "$out"
}

# OpenCV.js
download "https://docs.opencv.org/$OPENCV/opencv.js" "$LIB/opencv.js"

# PDF.js classic non-module build
download "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/$PDFJS/pdf.min.js" "$LIB/pdf.min.js"
download "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/$PDFJS/pdf.worker.min.js" "$LIB/pdf.worker.min.js"

# Tesseract.js + worker
download "https://registry.npmjs.org/tesseract.js/-/tesseract.js-$TESS.tgz" "$TMP/tesseract.js-$TESS.tgz"
rm -rf "$TMP/tesseractjs" && mkdir -p "$TMP/tesseractjs"
tar -xzf "$TMP/tesseract.js-$TESS.tgz" -C "$TMP/tesseractjs"
cp "$TMP/tesseractjs/package/dist/tesseract.min.js" "$LIB/tesseract.min.js"
cp "$TMP/tesseractjs/package/dist/worker.min.js" "$LIB/worker.min.js"

# Tesseract.js core files
download "https://registry.npmjs.org/tesseract.js-core/-/tesseract.js-core-$TESS.tgz" "$TMP/tesseract.js-core-$TESS.tgz"
rm -rf "$TMP/tesseractcore" && mkdir -p "$TMP/tesseractcore"
tar -xzf "$TMP/tesseract.js-core-$TESS.tgz" -C "$TMP/tesseractcore"
find "$TMP/tesseractcore/package" -maxdepth 1 -type f \( -name 'tesseract-core*.js' -o -name 'tesseract-core*.wasm' \) -exec cp -f {} "$CORE/" \;

# Tesseract language data
download "https://tessdata.projectnaptha.com/4.0.0/eng.traineddata.gz" "$LIB/eng.traineddata.gz"
download "https://tessdata.projectnaptha.com/4.0.0/jpn.traineddata.gz" "$LIB/jpn.traineddata.gz"

# ONNX Runtime Web
download "https://registry.npmjs.org/onnxruntime-web/-/onnxruntime-web-$ORT.tgz" "$TMP/onnxruntime-web-$ORT.tgz"
rm -rf "$TMP/ortweb" && mkdir -p "$TMP/ortweb"
tar -xzf "$TMP/onnxruntime-web-$ORT.tgz" -C "$TMP/ortweb"
cp "$TMP/ortweb/package/dist/ort.min.js" "$LIB/ort.min.js"
cp "$TMP/ortweb/package/dist/ort-wasm-simd.wasm" "$LIB/ort-wasm-simd.wasm"
cp "$TMP/ortweb/package/dist/ort-wasm.wasm" "$LIB/ort-wasm.wasm"

# PaddleOCR dictionary + model tar
download "https://raw.githubusercontent.com/PaddlePaddle/PaddleOCR/main/ppocr/utils/dict/japan_dict.txt" "$PPOCR/japan_dict.txt"
download "https://paddleocr.bj.bcebos.com/PP-OCRv3/multilingual/japan_PP-OCRv3_rec_infer.tar" "$TMP/japan_PP-OCRv3_rec_infer.tar"
tar -xf "$TMP/japan_PP-OCRv3_rec_infer.tar" -C "$TMP"
MODEL_DIR="$(dirname "$(find "$TMP" -name inference.pdmodel -print -quit)")"
if [[ -z "$MODEL_DIR" || ! -f "$MODEL_DIR/inference.pdmodel" ]]; then
  echo "PaddleOCR inference.pdmodel was not found after extraction." >&2
  exit 1
fi

if [[ "${1:-}" == "--convert-paddle-model" ]]; then
  python3 -m pip install --upgrade pip
  python3 -m pip install paddle2onnx paddlepaddle
  paddle2onnx --model_dir "$MODEL_DIR" \
    --model_filename inference.pdmodel \
    --params_filename inference.pdiparams \
    --save_file "$PPOCR/rec_japan.onnx" \
    --opset_version 11
else
  echo "PaddleOCR model tar was downloaded, but rec_japan.onnx was not generated."
  echo "Run again with --convert-paddle-model, or convert manually with paddle2onnx."
fi

echo "Done."
