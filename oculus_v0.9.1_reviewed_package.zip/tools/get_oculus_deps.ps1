param(
  [switch]$ConvertPaddleModel
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$lib = Join-Path $root "lib"
$tmp = Join-Path $root "_download_tmp"
$core = Join-Path $lib "core"
$ppocr = Join-Path $lib "ppocr"
New-Item -ItemType Directory -Force -Path $lib,$tmp,$core,$ppocr | Out-Null

function Get-File($Url, $OutFile){
  Write-Host "GET $Url"
  Invoke-WebRequest -Uri $Url -OutFile $OutFile -UseBasicParsing
  if(!(Test-Path $OutFile) -or ((Get-Item $OutFile).Length -le 0)){ throw "download failed: $OutFile" }
}
function Expand-Tgz($Archive, $Dest){
  if(Test-Path $Dest){ Remove-Item -Recurse -Force $Dest }
  New-Item -ItemType Directory -Force -Path $Dest | Out-Null
  tar -xzf $Archive -C $Dest
}
function Copy-Required($From, $To){
  if(!(Test-Path $From)){ throw "missing extracted file: $From" }
  Copy-Item -Force $From $To
}

# ---- versions pinned for Oculus v0.9.1-review ----
$PDFJS = "3.11.174"
$TESS = "5.1.1"
$ORT = "1.18.0"
$OPENCV = "4.10.0"

# OpenCV.js
Get-File "https://docs.opencv.org/$OPENCV/opencv.js" (Join-Path $lib "opencv.js")

# PDF.js classic non-module build
Get-File "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/$PDFJS/pdf.min.js" (Join-Path $lib "pdf.min.js")
Get-File "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/$PDFJS/pdf.worker.min.js" (Join-Path $lib "pdf.worker.min.js")

# Tesseract.js + worker
$tessTgz = Join-Path $tmp "tesseract.js-$TESS.tgz"
Get-File "https://registry.npmjs.org/tesseract.js/-/tesseract.js-$TESS.tgz" $tessTgz
$tessOut = Join-Path $tmp "tesseractjs"
Expand-Tgz $tessTgz $tessOut
Copy-Required (Join-Path $tessOut "package/dist/tesseract.min.js") (Join-Path $lib "tesseract.min.js")
Copy-Required (Join-Path $tessOut "package/dist/worker.min.js") (Join-Path $lib "worker.min.js")

# Tesseract.js core files: copy every js/wasm asset so the worker can select SIMD/non-SIMD/lstm variants.
$coreTgz = Join-Path $tmp "tesseract.js-core-$TESS.tgz"
Get-File "https://registry.npmjs.org/tesseract.js-core/-/tesseract.js-core-$TESS.tgz" $coreTgz
$coreOut = Join-Path $tmp "tesseractcore"
Expand-Tgz $coreTgz $coreOut
Get-ChildItem (Join-Path $coreOut "package") -File | Where-Object { $_.Name -match '^tesseract-core.*\.(js|wasm)$' } | ForEach-Object {
  Copy-Item -Force $_.FullName (Join-Path $core $_.Name)
}

# Tesseract language data used by langPath='./lib/' and gzip:true
Get-File "https://tessdata.projectnaptha.com/4.0.0/eng.traineddata.gz" (Join-Path $lib "eng.traineddata.gz")
Get-File "https://tessdata.projectnaptha.com/4.0.0/jpn.traineddata.gz" (Join-Path $lib "jpn.traineddata.gz")

# ONNX Runtime Web for optional PaddleOCR path
$ortTgz = Join-Path $tmp "onnxruntime-web-$ORT.tgz"
Get-File "https://registry.npmjs.org/onnxruntime-web/-/onnxruntime-web-$ORT.tgz" $ortTgz
$ortOut = Join-Path $tmp "ortweb"
Expand-Tgz $ortTgz $ortOut
Copy-Required (Join-Path $ortOut "package/dist/ort.min.js") (Join-Path $lib "ort.min.js")
Copy-Required (Join-Path $ortOut "package/dist/ort-wasm-simd.wasm") (Join-Path $lib "ort-wasm-simd.wasm")
Copy-Required (Join-Path $ortOut "package/dist/ort-wasm.wasm") (Join-Path $lib "ort-wasm.wasm")

# PaddleOCR dictionary + inference model tar. The HTML needs rec_japan.onnx, so conversion is optional but recommended.
Get-File "https://raw.githubusercontent.com/PaddlePaddle/PaddleOCR/main/ppocr/utils/dict/japan_dict.txt" (Join-Path $ppocr "japan_dict.txt")
$modelTar = Join-Path $tmp "japan_PP-OCRv3_rec_infer.tar"
Get-File "https://paddleocr.bj.bcebos.com/PP-OCRv3/multilingual/japan_PP-OCRv3_rec_infer.tar" $modelTar
tar -xf $modelTar -C $tmp
$inferModel = Get-ChildItem $tmp -Recurse -Filter "inference.pdmodel" | Select-Object -First 1
if($null -eq $inferModel){ throw "PaddleOCR inference.pdmodel was not found after extraction." }
$modelDir = Split-Path -Parent $inferModel.FullName

if($ConvertPaddleModel){
  Write-Host "Installing paddle2onnx / paddlepaddle if needed. This may take time."
  python -m pip install --upgrade pip
  python -m pip install paddle2onnx paddlepaddle
  paddle2onnx --model_dir $modelDir `
    --model_filename inference.pdmodel `
    --params_filename inference.pdiparams `
    --save_file (Join-Path $ppocr "rec_japan.onnx") `
    --opset_version 11
} else {
  Write-Host "PaddleOCR model tar was downloaded, but rec_japan.onnx was not generated."
  Write-Host "Run this script again with -ConvertPaddleModel, or convert manually with paddle2onnx."
}

Write-Host ""
Write-Host "Done. Verify these minimum files exist:"
@(
  "lib/opencv.js", "lib/pdf.min.js", "lib/pdf.worker.min.js",
  "lib/tesseract.min.js", "lib/worker.min.js", "lib/core", "lib/eng.traineddata.gz", "lib/jpn.traineddata.gz",
  "lib/ort.min.js", "lib/ort-wasm-simd.wasm", "lib/ort-wasm.wasm", "lib/ppocr/japan_dict.txt"
) | ForEach-Object { Write-Host " - $_" }
if(Test-Path (Join-Path $ppocr "rec_japan.onnx")){ Write-Host " - lib/ppocr/rec_japan.onnx" } else { Write-Host " - lib/ppocr/rec_japan.onnx  (not created yet; AI will fall back to Tesseract)" }
