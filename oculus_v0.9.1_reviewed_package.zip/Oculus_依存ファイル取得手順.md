# Oculus 依存ファイル取得手順

このパッケージには、修正済み `oculus.html` と、依存ファイルを取得するスクリプトを入れています。

## Windowsで取得

PowerShellをこのフォルダで開き、まず通常取得を実行します。

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.	ools\get_oculus_deps.ps1
```

PaddleOCRのローカルAIまで使う場合は、Python環境のあるPCで次を実行します。

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.	ools\get_oculus_deps.ps1 -ConvertPaddleModel
```

`rec_japan.onnx` が無い場合でも、ツール本体はTesseractにフォールバックして動きます。

## 起動

```bat
start_oculus_server.bat
```

ブラウザで `http://127.0.0.1:8765/oculus.html` が開きます。`file://` 直開きではTesseract workerやWASMが止まりやすいため、必ずローカルサーバ経由で開いてください。

## 職場オフラインPCへ持ち込むもの

- `oculus.html`
- `lib/` フォルダ一式
- 必要なら `start_oculus_server.bat`

`_download_tmp/` は不要です。
