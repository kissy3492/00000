@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  start http://127.0.0.1:8765/oculus.html
  py -m http.server 8765 --bind 127.0.0.1
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    start http://127.0.0.1:8765/oculus.html
    python -m http.server 8765 --bind 127.0.0.1
  ) else (
    echo Python not found. Install Python or start any static local server at this folder.
    pause
  )
)
