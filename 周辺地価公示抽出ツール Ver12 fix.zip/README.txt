周辺地価公示等抽出ツール Ver.12
================================

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
■ 3分版（まず読む）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  ▶ このツールは何をするか
    地番または緯度経度を指定すると、周辺の地価公示地点を
    距離・用途地域・地積差で整理したCSVを出力します。

  ▶ 何をしないか（重要）
    × 価格の判定はしません
    × 採用標準地を決めません
    × 接道・形状等は評価できません

  ▶ 最速の使い方（3ステップ）
    1. スクリプト冒頭の設定3箇所を書き換える
         $Config_LandPriceGeoJson = "地価公示GeoJSONのパス"
         $Config_ChibanGeoJson    = "地番GeoJSONのパス"（または緯度経度を入力）
         $Config_Chiban           = "123-4"（調べたい地番）
    2. PowerShellを開き、スクリプト全体を貼り付けてEnter
    3. result.csv を開いて確認する

  ▶ データの入手先
    地価公示GeoJSON: https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-L01.html
    地番GeoJSON:     https://front.geospatial.jp/moj-chizu-shp-download/

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
■ Ver.12 の変更点（Ver.11比）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  ★ $Config_OutputAllProperties で全属性JSON出力を切り替え可能に
     デフォルト $false（出力しない）。CSVが大きくなるため通常は不要。
     GeoJSON属性の確認が必要な場合だけ $true に設定してください。

  ★ 出力列を「基本列」と「検証列」に分離
     【基本列（左側・毎回確認）】
     距離m / 条件メモ / 差分メモ / 所在地 / 価格_円m2 / 地積_m2 /
     用途地域 / 利用現況 / 調査年次
     【検証列（右側・必要時に確認）】
     標準地番号 / 調査基準日 / 用途地域_元値 / 価格_取得列 /
     用途地域_取得列 / 利用現況_取得列 / 座標取得方法 / 緯度 / 経度
     【任意列（OutputAllProperties=$trueのみ）】
     全属性JSON

  ★ 上位10件表示を基本列中心に変更

■ 本ツールの位置づけ

  ○ 周辺参考情報の整理（初動確認・違和感チェック・案件資料化）
  × 価格妥当性の判定・時価算定・個別格差評価

■ 使い方

  Step 1: このファイルをメモ帳などで開く

  Step 2: 冒頭の「★ 設定ブロック」を書き換える
  ─────────────────────────────────────
  最低限の設定例（地番モード）:

    $Config_LandPriceGeoJson = "C:\Work\L01.geojson"
    $Config_ChibanGeoJson    = "C:\Work\chiban.geojson"
    $Config_Chiban           = "123-4"
    $Config_Prefecture       = "青森"
    $Config_RadiusMeters     = 500
    $Config_TargetZoningCode = "5"
    $Config_TargetAreaM2     = 180
    $Config_OutputCsv        = "C:\Work\result.csv"

  最低限の設定例（緯度経度モード）:

    $Config_LandPriceGeoJson = "C:\Work\L01.geojson"
    $Config_Latitude         = 40.8246
    $Config_Longitude        = 140.7400
    $Config_RadiusMeters     = 500
    $Config_OutputCsv        = "C:\Work\result.csv"
  ─────────────────────────────────────

  Step 3: PowerShellウィンドウを開く

  Step 4: スクリプト全体をコピーして貼り付けてEnter

  Step 5: 地番候補が複数あれば番号を選択

  Step 6: result.csv と result_処理ログ.csv が出力される

■ 候補が多い場合のワークフロー

  ① Config_ChibanSelectMode に出力先を設定して実行
     → 候補一覧CSVが出力されて処理が停止する

  ② candidates.csv を開いて選択番号を確認

  ③ 設定を変更して再実行:
     Config_SelectedIndex    = 3     ← 確認した番号
     Config_ChibanSelectMode = ""    ← 空に戻す

■ 設定項目一覧

  Config_LandPriceGeoJson  地価公示GeoJSONのパス（必須）
  Config_ChibanGeoJson     地番GeoJSONのパス（地番モード時）
  Config_Chiban            検索する地番（地番モード時）
  Config_Latitude          中心点の緯度（緯度経度モード時）
  Config_Longitude         中心点の経度（緯度経度モード時）
  Config_Prefecture        都道府県名またはコード（座標チェック用）
  Config_RadiusMeters      抽出半径（メートル、デフォルト1000）
  Config_TargetAreaM2      対象地の地積（㎡）
  Config_TargetZoningCode  対象地の用途地域コード
  Config_AddressKeyword    地番候補の絞り込みキーワード
  Config_OutputCsv         出力CSVパス
  Config_OutputEncoding    UTF8BOM（推奨）/ SJIS
  Config_OutputExcel       Excel出力パス
                           ※ ImportExcelモジュールが必要。職場環境では
                             インストールできない場合が多いため非推奨。
                             ImportExcelがなくても処理は正常に完了し、
                             CSVが出力されます。Excel出力は任意の追加機能です。
  Config_ChibanSelectMode  候補CSV出力先（指定すると候補出力後停止）
  Config_SelectedIndex     候補選択番号直接指定
  Config_NoPrompt          $true で対話なし自動候補CSV出力

■ 出力ファイル

  result.csv         抽出結果（地価公示参考一覧）
  result_処理ログ.csv 処理サマリー・警告・詳細ログ

  ※ 処理ログに記録される情報:
    処理日時、入力地番、選択地番、対象地情報、中心座標、
    座標取得方法、地積・用途地域条件、半径、抽出件数、
    警告内容、処理ステップログ

■ 出力される列

  距離m           中心点からの直線距離
  条件メモ        距離・用途・地積差の整理
                  例: 「距離:近接(230m) / 用途:同一地域 / 地積:差18%」
  差分メモ        対象地と参考地の具体的差分
                  例: 「用途:対象=第一種住居地域 → 参考=同一 /
                         地積:対象180㎡ → 参考220㎡(+22%)」
  標準地番号      L01_002
  所在地          L01_001
  調査年次        L01_005
  調査基準日      L01_006
  価格_円m2       L01_008
  地積_m2         L01_011
  利用現況        日本語デコード済
  用途地域        デコード後（変換不能は空欄）
  用途地域_元値   GeoJSON生値（確認用）
  価格_取得列     価格の取得属性名（データ検証用）
  用途地域_取得列 用途地域の取得属性名（データ検証用）
  利用現況_取得列 利用現況の取得属性名（データ検証用）
  座標取得方法    Point/Polygon面積重心/MultiPolygon最大面積採用
  緯度 / 経度
  全属性JSON      全プロパティ（デバッグ用）

■ 用途地域コード（Config_TargetZoningCode）
  1=第一種低層住居専用  2=第二種低層住居専用
  3=第一種中高層住居専用  4=第二種中高層住居専用
  5=第一種住居  6=第二種住居  7=準住居  8=田園住居
  9=近隣商業  10=商業  11=準工業  12=工業  13=工業専用

■ 本ツールの限界（重要）

  以下は構造上解決できない限界です。出力後に人間が必ず確認してください。

  【直線距離の限界】
  距離が近くても川・線路・幹線道路・用途地域境界をまたぐ場合、
  参考性が大きく落ちます。地図上での位置関係確認は必須です。

  【GeoJSONデータ品質への依存】
  地番GeoJSONの座標・属性精度はデータ提供元に依存します。
  データがズレていれば抽出結果もズレます。本ツールは補正できません。

  【地価GeoJSON属性形式の変化】
  L01_008などの属性名は年度・版で変わる可能性があります。
  「価格_取得列」列で実際に使用した属性名を確認してください。

  【評価できない要素】（人間による別途確認が必須）
  接道状況 / 前面道路幅員 / 形状・奥行 / 高低差
  建蔽率・容積率 / 商業繁華性 / 駅距離 / 個別格差

  本ツールの位置づけ:
    ○ 参考地探索支援・一覧整理
    × 価格妥当性判定・時価算定

■ データ入手先
  地価公示GeoJSON:
    https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-L01.html
  地番GeoJSON（推奨・緯度経度変換済み）:
    https://front.geospatial.jp/moj-chizu-shp-download/

■ 座標系について
  本ツールは緯度経度（WGS84/JGD）のGeoJSONのみ対応。
  公図ビューア版（kouzuviewer.com）は公共座標系XYのため、
  QGISで変換してから使用してください。
  誤って入力するとエラーメッセージと解決方法が表示されます。

■ 重要な注意事項
  ・本ツールは「周辺参考地の探索支援・一覧整理」ツールです
  ・価格妥当性の判定には使用できません
  ・接道・前面道路・形状・高低差等は判定できません
  ・最終判断は不動産鑑定士等の専門家にご確認ください
