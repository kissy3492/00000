(function(global){
  'use strict';

  /* ============================================================
     v38-58: Step3 Input Core / IIFE Strict Phase19
     Step3の全体描画、手入力フォーム、入力データ収集/復元/クリア、入力ペイン切替、Step3固定イベント接続を担当。

     契約:
     - classic script / IIFE + explicit window export。ES Modulesは使わない。
     - 保存キー・保存形式・field.source名・入力データキーは変更しない。
     - Step3ExtensionRegistry / InputDataExtensionRegistry hookを維持する。
     - キュー、住所録、履歴、Excel貼付取込の実体は js/48_step3_queue_ui.js が担当する。
     - Step3固定ボタン/タブのイベント接続は bindEventsForStep3() が担当する。
     ============================================================ */

/* ===== v38-12 extracted from 10_core.js: renderStep3 ===== */
function renderStep3(){
  const t=getCurrentTpl();const isReply=t&&t.isReply;
  $('step3Title').textContent=isReply?'返送先を入力します':'宛先を入力します';
  $('step3Subtitle').textContent=isReply?'部署名・氏名・敬称（行）を入力してキューに追加':'入力するとすぐ右のキューに追加されます';
  $('replyBanner3') && ($('replyBanner3').style.display=isReply?'flex':'none');
  renderInputForm();renderQueue();renderAddrbook();renderHistory();renderPasteImport();
  $('abTabCount').textContent=state.addressBook.length?`(${state.addressBook.length})`:'';
  $('histTabCount').textContent=getPrintRecordCount()?`(${getPrintRecordCount()})`:'';
  $('step3Next').disabled=state.queue.length===0;
  // v28 Step2: Step3拡張UIの移行先。現時点ではStage5/6/7はまだ登録しないため既存挙動は変えない。
  if(window.Step3ExtensionRegistry && typeof window.Step3ExtensionRegistry.runRenderHooks === 'function'){
    window.Step3ExtensionRegistry.runRenderHooks();
  }
}

/* ===== v38-12 extracted from 10_core.js: renderInputForm ===== */
function renderInputForm(){
  const t=getCurrentTpl();const isReply=t&&t.isReply;
  const form=$('inputForm');
  if(isReply){
    form.innerHTML=`<div class="row r-2-1">
      <div><label>会社名</label><input type="text" id="iCompany" placeholder="株式会社○○"></div>
      <div><label>敬称</label><select id="iHonor">
        <option value="行" selected>行</option><option value="宛">宛</option><option value="御中">御中</option><option value="">（なし）</option>
      </select></div>
    </div>
    <div class="row r2"><div><label>部署名</label><input type="text" id="iDept" placeholder="採用ご担当 / 総務課 など"></div><div><label>役職名</label><input type="text" id="iTitle"></div></div>
    <div class="row"><label>氏名 / 担当者名（任意）</label><input type="text" id="iName" placeholder="採用担当 など"></div>
    <input type="hidden" id="iZip"><input type="hidden" id="iAddr"><input type="hidden" id="iAddr2"><input type="hidden" id="iName2"><input type="hidden" id="iHonor2"><input type="hidden" id="iSenderZip"><input type="hidden" id="iSenderAddr"><input type="hidden" id="iSenderCompany"><input type="hidden" id="iSenderDept"><input type="hidden" id="iSenderName"><input type="hidden" id="iSenderTel">`;
  } else {
    form.innerHTML=`<div class="row r-2-1">
      <div><label>郵便番号</label><input type="text" id="iZip" placeholder="123-4567" maxlength="8"></div>
      <div><label>敬称</label><select id="iHonor">
        <option value="様" selected>様</option><option value="御中">御中</option>
        <option value="先生">先生</option><option value="行">行</option><option value="">（なし）</option>
      </select></div>
    </div>
    <div class="row"><label>住所1</label><textarea id="iAddr" placeholder="東京都千代田区..."></textarea></div>
    <div class="row"><label>住所2・建物名（任意）</label><input type="text" id="iAddr2" placeholder="○○ビル501 など"></div>
    <div class="row r3"><div><label>会社名（任意）</label><input type="text" id="iCompany"></div><div><label>部署名（任意）</label><input type="text" id="iDept"></div><div><label>役職名（任意）</label><input type="text" id="iTitle"></div></div>
    <input type="hidden" id="iCorp">
    <div class="row r2"><div><label>氏名 / 宛名</label><input type="text" id="iName"></div><div><label>連名（任意）</label><input type="text" id="iName2"></div></div>
    <div class="row r2"><div><label>連名敬称</label><select id="iHonor2"><option value="様" selected>様</option><option value="先生">先生</option><option value="">（なし）</option></select></div><div></div></div>
    <details class="config-card" style="margin-top:10px"><summary>差出人（任意）</summary><div class="body">
      <div class="row r2"><div><label>差出人郵便番号</label><input type="text" id="iSenderZip" placeholder="030-0000" maxlength="8"></div><div><label>差出人氏名</label><input type="text" id="iSenderName"></div></div>
      <div class="row"><label>差出人住所</label><input type="text" id="iSenderAddr"></div>
      <div class="row r2"><div><label>差出人会社</label><input type="text" id="iSenderCompany"></div><div><label>差出人部署</label><input type="text" id="iSenderDept"></div></div>
      <div class="row"><label>差出人電話</label><input type="text" id="iSenderTel"></div>
    </div></details>`;
  }
  ['iZip','iSenderZip'].forEach(id=>{
    const inp=$(id);
    if(inp){
      inp.addEventListener('input',e=>{
        let v=e.target.value.replace(/[^\d-]/g,'').replace(/-/g,'');
        if(v.length>3) v=v.slice(0,3)+'-'+v.slice(3,7);
        e.target.value=v;
      });
    }
  });
  applyScreenA11y(form);
}

/* ===== v38-12 extracted from 10_core.js: getInputData ===== */
function getInputData(){
  const data = {
    zip:($('iZip')&&$('iZip').value||'').trim(),
    addr:($('iAddr')&&$('iAddr').value||'').trim(),
    addr2:($('iAddr2')&&$('iAddr2').value||'').trim(),
    company:($('iCompany')&&$('iCompany').value||'').trim(),
    dept:($('iDept')&&$('iDept').value||'').trim(),
    title:($('iTitle')&&$('iTitle').value||'').trim(),
    corp:($('iCorp')&&$('iCorp').value||'').trim(),
    name:($('iName')&&$('iName').value||'').trim(),
    honor:($('iHonor')&&$('iHonor').value||''),
    name2:($('iName2')&&$('iName2').value||'').trim(),
    honor2:($('iHonor2')&&$('iHonor2').value||''),
    sender_zip:($('iSenderZip')&&$('iSenderZip').value||'').trim(),
    sender_addr:($('iSenderAddr')&&$('iSenderAddr').value||'').trim(),
    sender_company:($('iSenderCompany')&&$('iSenderCompany').value||'').trim(),
    sender_dept:($('iSenderDept')&&$('iSenderDept').value||'').trim(),
    sender_name:($('iSenderName')&&$('iSenderName').value||'').trim(),
    sender_tel:($('iSenderTel')&&$('iSenderTel').value||'').trim()
  };
  const normalized = normalizeAddressData(data);
  // v34 Step2: 追加入力欄の値を本体関数上書きなしで合流できるよう、collect hookを実行する。
  // 現時点ではStage7既存ラッパーを残すため、hook未登録なら既存挙動と同じ結果になる。
  if(window.InputDataExtensionRegistry && typeof window.InputDataExtensionRegistry.runCollectHooks === 'function'){
    return window.InputDataExtensionRegistry.runCollectHooks(normalized);
  }
  return normalized;
}

/* ===== v38-12 extracted from 10_core.js: loadAddrToInput ===== */
function loadAddrToInput(a){
  a = normalizeAddressData(Object.assign({}, a||{}));
  const map = {
    iZip:'zip', iAddr:'addr', iAddr2:'addr2', iCompany:'company', iDept:'dept', iTitle:'title', iCorp:'corp',
    iName:'name', iHonor:'honor', iName2:'name2', iHonor2:'honor2',
    iSenderZip:'sender_zip', iSenderAddr:'sender_addr', iSenderCompany:'sender_company', iSenderDept:'sender_dept', iSenderName:'sender_name', iSenderTel:'sender_tel'
  };
  Object.entries(map).forEach(([id,k])=>{ if($(id) && a[k]!==undefined) $(id).value = String(a[k]||'').replace(/^〒/,''); });
  // v35 Step3: 追加入力欄の読込を本体関数上書きなしで合流できるよう、load hookを実行する。
  // 現時点ではStage7既存ラッパーを残すため、hook未登録なら既存挙動と同じ結果になる。
  if(window.InputDataExtensionRegistry && typeof window.InputDataExtensionRegistry.runLoadHooks === 'function'){
    window.InputDataExtensionRegistry.runLoadHooks(a);
  }
}

/* ===== v38-12 extracted from 10_core.js: clearInput ===== */
function clearInput(){
  clearInputInvalidStates($('inputForm') || document);
  ['iZip','iAddr','iAddr2','iCompany','iDept','iTitle','iCorp','iName','iName2','iSenderZip','iSenderAddr','iSenderCompany','iSenderDept','iSenderName','iSenderTel'].forEach(id=>{if($(id)) $(id).value=''});
  const t=getCurrentTpl();
  if($('iHonor')) $('iHonor').value=t&&t.isReply?'行':'様';
  if($('iHonor2')) $('iHonor2').value='様';
  // v35 Step3: 追加入力欄のクリアを本体関数上書きなしで合流できるよう、clear hookを実行する。
  // 現時点ではStage7既存ラッパーを残すため、hook未登録なら既存挙動と同じ結果になる。
  if(window.InputDataExtensionRegistry && typeof window.InputDataExtensionRegistry.runClearHooks === 'function'){
    window.InputDataExtensionRegistry.runClearHooks();
  }
}

/* ===== v38-12 extracted from 10_core.js: switchInputPane ===== */
function switchInputPane(name){
  state.activeInputPane=name;
  document.querySelectorAll('.input-tab').forEach(t=>t.classList.toggle('active',t.dataset.pane===name));
  document.querySelectorAll('.input-pane').forEach(p=>p.classList.toggle('active',p.dataset.pane===name));
  applyInputTabsA11y();
  // v28 Step2: manualペイン表示時の拡張UI移行先。Stage5/6/7のhook登録は次Step以降。
  if(name==='manual' && window.Step3ExtensionRegistry && typeof window.Step3ExtensionRegistry.runManualPaneHooks === 'function'){
    window.Step3ExtensionRegistry.runManualPaneHooks();
  }
}

/* ===== v38-31: Step3 fixed event binder ===== */
function bindEventsForStep3(){
  // ステップ3
  $('step3Back').addEventListener('click',()=>goToStep(state.uiMode==='simple'?1:2));
  $('step3Next').addEventListener('click',()=>goToStep(4));
  document.querySelectorAll('.input-tab').forEach(t=>t.addEventListener('click',()=>switchInputPane(t.dataset.pane)));
  document.querySelector('.input-tabs').addEventListener('keydown',e=>{
    const tabs=Array.from(document.querySelectorAll('.input-tab'));
    const idx=tabs.indexOf(document.activeElement);
    if(idx<0) return;
    let next=-1;
    if(e.key==='ArrowRight') next=(idx+1)%tabs.length;
    if(e.key==='ArrowLeft') next=(idx-1+tabs.length)%tabs.length;
    if(e.key==='Home') next=0;
    if(e.key==='End') next=tabs.length-1;
    if(next>=0){ e.preventDefault(); tabs[next].focus(); switchInputPane(tabs[next].dataset.pane); }
  });
  $('btnAddQueue').addEventListener('click',()=>{
    clearInputInvalidStates($('inputForm') || document);
    if(!state.selectedTplId){toast('テンプレート未選択','warn');return}
    const t=getCurrentTpl();const d=getInputData();
    // v37 step26: Stage5等の入力検証はキャプチャフェーズ乗っ取りではなく明示hookで実行する。
    if(window.InputValidationRegistry && typeof window.InputValidationRegistry.runBeforeAddQueueHooks === 'function'){
      if(!window.InputValidationRegistry.runBeforeAddQueueHooks({data:d, tpl:t, source:'manual'})) return;
    }
    if(t.isReply){
      if(!d.corp&&!d.company&&!d.dept&&!d.name){
        const msg='会社名・部署または氏名を入力してください';
        markInputFieldsInvalid(['iCompany','iDept','iName'], msg);
        toast(msg,'warn');return;
      }
    }
    else if(!d.name&&!d.company&&!d.corp){
      const msg='氏名／宛名または会社名を入力してください';
      markInputFieldsInvalid(['iName','iCompany'], msg);
      toast(msg,'warn');return;
    }
    state.queue.push({...d,tplId:state.selectedTplId});
    save();renderQueue();
    $('step3Next').disabled=state.queue.length===0;
    renderSteps();
    toast(`「${d.name||d.corp}」をキューに追加（${state.queue.length}件）`,'ok');
    clearInput();
    const first=document.querySelector('#inputForm input:not([type=hidden]),#inputForm textarea');
    if(first) first.focus();
  });
  $('btnSaveToAddrbook').addEventListener('click',async ()=>{
    clearInputInvalidStates($('inputForm') || document);
    const d=getInputData();
    if(!d.name&&!d.corp&&!d.company){
      const msg='氏名または会社名を入力';
      markInputFieldsInvalid(['iName','iCompany'], msg);
      toast(msg,'warn');return;
    }
    const dup=state.addressBook.find(a=>a.name===d.name&&a.addr===d.addr&&a.addr2===d.addr2&&(a.corp||a.company)===(d.corp||d.company));
    if(dup){
      // v37 step40: 住所録重複上書き確認をブラウザ標準confirmからDOMモーダルへ移行する。
      if(!await showAppConfirm('同じ宛先が住所録にあります。上書きしますか？','住所録の上書き',{okLabel:'上書きする',danger:true})) return;
      Object.assign(dup,d);
    }
    else state.addressBook.push({id:uid('a'),...d});
    save();renderAddrbook();
    $('abTabCount').textContent=state.addressBook.length?`(${state.addressBook.length})`:'';
    renderSteps();
    toast(`住所録に${dup?'更新':'保存'}しました`,'ok');
  });
  $('btnClearInput').addEventListener('click',clearInput);
  $('abSearch').addEventListener('input',renderAddrbook);
  $('btnClearQueue').addEventListener('click',async ()=>{
    if(!state.queue.length) return;
    // v37 step36: キュー全削除確認をブラウザ標準confirmからDOMモーダルへ移行する。
    if(await showAppConfirm(`キュー${state.queue.length}件を削除しますか？`,'キューの全削除',{okLabel:'削除する',danger:true})){
      state.queue=[];save();renderQueue();
      $('step3Next').disabled=true;renderSteps();
    }
  });
  $('btnClearHistory').addEventListener('click',async ()=>{
    const count=getPrintRecordCount();
    if(!count) return;
    // v37 step36: 試行履歴・旧履歴の全削除確認をブラウザ標準confirmからDOMモーダルへ移行する。
    if(await showAppConfirm(`試行履歴・旧履歴${count}件を削除しますか？`,'試行履歴・旧履歴の全削除',{okLabel:'削除する',danger:true})){
      state.history=[];state.printAttempts=[];save();renderHistory();
      $('histTabCount').textContent='';
    }
  });

}



  const Step3InputCoreApi = Object.freeze({
    renderStep3,
    renderInputForm,
    getInputData,
    loadAddrToInput,
    clearInput,
    switchInputPane,
    bindEventsForStep3
  });

  Object.assign(global, {
    renderStep3,
    renderInputForm,
    getInputData,
    loadAddrToInput,
    clearInput,
    switchInputPane,
    bindEventsForStep3,
    EnvelopePrintStep3InputCore: Step3InputCoreApi
  });
})(typeof window !== 'undefined' ? window : globalThis);
