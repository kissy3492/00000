(function(global){
  'use strict';

/* ============================================================
   Print Control
   v38-11: 印刷前チェック・印刷実行制御・印刷試行履歴を core から分離。
   ============================================================ */

function addPrintAttempt(item){
  // v38-11: 「印刷成功履歴」ではなく「印刷試行履歴」として記録する。
  if(!Array.isArray(state.printAttempts)) state.printAttempts=[];
  const attempt={id:uid('pa'),attemptedAt:Date.now(),historyKind:'attempt',...item};
  delete attempt.printedAt;
  state.printAttempts.push(attempt);
  if(state.printAttempts.length>500) state.printAttempts=state.printAttempts.slice(-500);
  return attempt;
}

function getPrintRecordCount(){
  // v38-11: 旧historyと現行printAttemptsを合算して、既存UIの件数表示を維持する。
  const oldCount=Array.isArray(state.history)?state.history.length:0;
  const attemptCount=Array.isArray(state.printAttempts)?state.printAttempts.length:0;
  return oldCount+attemptCount;
}

function renderFinalChecklist(){
  const t=getCurrentTpl();if(!t) return;
  const p=getCurrentPrinter();
  const corr=p?getPrinterCorrection(p.id,t.id):{rightShift:0,downShift:0,widthDiff:0,heightDiff:0};
  const stat=getTplAdjustmentSummary(t);
  const mismatch=state.queue.filter(q=>q.tplId!==state.selectedTplId);
  const validCount = state.queue.length - mismatch.length;
  const items=[
    {ok:true,label:'テンプレート',detail:`${t.name} (${t.w}×${t.h}mm)${t.isReply?' [返信用]':' [通常]'}`},
    {ok:validCount>0,label:'印刷枚数',detail:t.paperKind==='label_sheet'?`${validCount}件 / ${getEffectivePrintPageCount(t, validCount)}ページ（1ページ${labelCapacity(t)}面）`:`${state.queue.length}枚（うち現テンプレ対応:${validCount}枚）`},
    {ok:!!p,label:'プリンタ',detail:p?p.name:'未選択（補正なしで印刷されます）'},
    {ok:'info',label:'補正値',detail:hasAnyCorrection(corr)?`右${corr.rightShift}/下${corr.downShift}/横幅差${corr.widthDiff}/縦幅差${corr.heightDiff} mm`:'なし'},
    {ok:stat.bgAligned||(!getBgImage(t)),label:'背景画像での位置確認',detail:stat.bgAligned?'確認済み':(getBgImage(t)?'未確認 — ウィザード推奨':'背景画像なし（標準位置）')},
    {ok:stat.zipChecked||t.isReply||!t.fields.find(f=>f.source==='zip'),label:'郵便番号枠の確認',detail:t.isReply?'返信用のため不要':(stat.zipChecked?'確認済み':'未確認 — ウィザード推奨')},
    {ok:stat.testPrinted,label:'テスト印刷結果の確認',detail:stat.testPrinted?'結果確認済み（実印刷成功の保証ではありません）':'⚠ 未確認 — 必ずテスト印刷し、結果を確認してください'},
    {ok:mismatch.length===0,label:'キュー内テンプレート整合',detail:mismatch.length===0?'全件一致':`${mismatch.length}件不一致（スキップされます）`},
    {ok:'info',label:'背景画像は印刷されません',detail:'画面表示用のみ。本印刷には含まれません'},
    {ok:'info',label:'プリンタダイアログで確認',detail:'用紙サイズ=封筒サイズに、余白=なし に設定してください'}
  ];
  $('finalChecklist').innerHTML=`
    <h4>本印刷の確認</h4>
    ${items.map(it=>{
      const cls=it.ok===true?'ok':(it.ok===false?'ng':(it.ok==='info'?'info':'warn'));
      const icon=it.ok===true?'✓':(it.ok===false?'✕':(it.ok==='info'?'ⓘ':'⚠'));
      return `<div class="checklist-item ${cls}">
        <div class="ci-icon">${icon}</div>
        <div class="ci-text">
          <div class="ci-label">${it.label}</div>
          <div class="ci-detail">${escapeHtml(it.detail)}</div>
        </div>
      </div>`;
    }).join('')}
  `;
}

function getHardPrintIssues(){
  const issues=[];
  const t=getCurrentTpl();
  if(!t){ issues.push('テンプレートが選択されていません'); return issues; }
  const mismatch=state.queue.filter(q=>q.tplId!==state.selectedTplId);
  const validCount=state.queue.length-mismatch.length;
  const stat=getTplAdjustmentSummary(t);
  if(validCount<=0) issues.push('印刷対象がありません');
  if(mismatch.length>0) issues.push(`キューにテンプレート不一致が${mismatch.length}件あります`);
  if(!getCurrentPrinter()) issues.push('プリンタが選択されていません');
  if(!stat || !stat.testPrinted) issues.push('テスト印刷結果が未確認、またはレイアウト変更後に再確認されていません');
  return issues;
}


function getQueueTemplateGroups(){
  const groups = [];
  const by = new Map();
  state.queue.forEach(q=>{
    const id = q.tplId || '(none)';
    if(!by.has(id)) by.set(id, []);
    by.get(id).push(q);
  });
  by.forEach((items,id)=>groups.push({tplId:id, tpl:getTpl(id), items}));
  return groups;
}
function renderJobGroupSummary(){
  const groups = getQueueTemplateGroups();
  if(groups.length<=1) return '';
  return `<div class="info-banner" style="margin-bottom:12px">
    <h4>テンプレート別ジョブ分割</h4>
    <div style="font-size:12px;line-height:1.7;margin-bottom:8px">キューに複数テンプレートが混在しています。用紙を差し替えながら、グループごとに印刷してください。</div>
    <div style="display:flex;flex-direction:column;gap:6px">
      ${groups.map(g=>`<div style="display:flex;align-items:center;gap:8px;background:#fff;border:1px solid var(--line-soft);padding:7px 8px">
        <span style="flex:1">${escapeHtml(g.tpl?g.tpl.name:'(削除済テンプレート)')}：<strong>${g.items.length}件</strong></span>
        ${g.tpl?`<button class="btn sm ghost job-select" data-tpl="${escapeHtml(g.tplId)}">この用紙を選択</button>`:''}
      </div>`).join('')}
    </div>
  </div>`;
}

function renderPrintActionArea(){
  const t=getCurrentTpl();
  const validQueue=state.queue.filter(q=>q.tplId===state.selectedTplId);
  const hardIssues=getHardPrintIssues();
  const hardBlock = state.uiMode==='simple' && hardIssues.length>0;
  const issueHtml = hardIssues.length ? `
    <div class="warn-banner" style="margin-bottom:12px">
      <h4>本印刷前に解消が必要です</h4>
      <div style="font-size:12px;line-height:1.6">${hardIssues.map(x=>'・'+escapeHtml(x)).join('<br>')}</div>
      ${state.uiMode==='simple'
        ? '<div style="margin-top:8px;font-weight:600">簡単モードでは、この状態のまま本印刷できません。</div>'
        : '<div style="margin-top:8px">詳細モードのため、確認後に強行印刷できます。</div>'}
    </div>` : '';
  $('printActionArea').innerHTML=`
    ${issueHtml}
    ${renderJobGroupSummary()}
    <div class="confirm-box" style="${hardBlock?'opacity:.5':''}">
      <input type="checkbox" id="finalConfirm" ${hardBlock?'disabled':''}>
      <label for="finalConfirm" style="font-size:12px;margin:0;cursor:pointer">上記すべてを確認しました</label>
    </div>
    <button class="btn ${hardIssues.length&&state.uiMode!=='simple'?'danger':'primary'} big" id="btnPrint" style="width:100%;margin-top:10px" disabled>
      ▶ ${hardIssues.length&&state.uiMode!=='simple'?'危険を理解して印刷':'印刷を実行'}（${validQueue.length}件）
    </button>
    <div class="hint" style="margin-top:10px;font-size:11px">プリンタダイアログで用紙サイズを封筒サイズに、余白を「なし」に設定してください</div>
  `;
  $('finalConfirm').addEventListener('change',e=>{
    $('btnPrint').disabled=!e.target.checked || hardBlock;
  });
  $('btnPrint').addEventListener('click',executePrint);
  document.querySelectorAll('#printActionArea .job-select').forEach(btn=>btn.addEventListener('click',async ()=>{
    state.selectedTplId=btn.dataset.tpl;
    state.lastUsedTplId=state.selectedTplId;
    save();
    renderStep1();renderSteps();renderStep5();
    toast('印刷対象テンプレートを切り替えました','ok');
  }));
}

async function executePrint(){
  const t=getCurrentTpl();
  const valid=state.queue.filter(q=>q.tplId===state.selectedTplId);
  const hardIssues=getHardPrintIssues();
  if(state.uiMode==='simple' && hardIssues.length){
    toast('本印刷前のNG項目を解消してください','warn');
    renderPrintActionArea();
    return;
  }
  if(!valid.length){toast('印刷対象がありません','warn');return}
  if(!$('finalConfirm').checked){toast('確認チェックを入れてください','warn');return}
  if(hardIssues.length && state.uiMode!=='simple'){
    // v37 step39: 強行印刷確認をブラウザ標準confirmからDOMモーダルへ移行する。
    if(!await showAppConfirm(`⚠ 危険な状態です。\n\n・${hardIssues.join('\n・')}\n\nそれでも詳細モードとして強行印刷しますか？`,'強行印刷の確認',{okLabel:'強行印刷する',danger:true})) return;
  }
  if(valid.length!==state.queue.length){
    // v37 step39: テンプレート不一致スキップ確認をDOMモーダルへ移行する。
    if(!await showAppConfirm(`${state.queue.length}件中${valid.length}件のみ印刷します（テンプレ不一致${state.queue.length-valid.length}件をスキップ）。続行しますか？`,'一部印刷の確認',{okLabel:'続行する',danger:true})) return;
  }
  valid.forEach(q=>addPrintAttempt(Object.assign({}, q)));
  save();
  doPrint({queue:valid});
}

/* ============================================================
   印刷処理
   ============================================================ */

function doPrint(opts){
  // v37 step22: 印刷実行直前処理はdoPrintラッパーではなくRegistry hook経由で実行する。
  if(window.PrintExecutionRegistry && typeof window.PrintExecutionRegistry.runBeforePrintHooks === 'function'){
    window.PrintExecutionRegistry.runBeforePrintHooks({opts:opts||{}, queue:opts&&opts.queue, tpl:getCurrentTpl(), printer:getCurrentPrinter()});
  }
  buildPrintStack(opts.queue, opts);
  const stack=$('printStack');
  let cleaned=false;
  const cleanup=()=>{
    if(cleaned) return;
    cleaned=true;
    setTimeout(()=>{ if(stack){stack.classList.remove('printing');stack.innerHTML='';} }, 200);
  };
  window.addEventListener('afterprint', cleanup, {once:true});
  // DOM構築直後の印刷で空プレビューになるのを避けるため、描画フレームを2回待つ。
  requestAnimationFrame(()=>requestAnimationFrame(()=>{
    try{ window.print(); }
    finally{
      // Firefox等でafterprintが発火しない場合の保険。500msでは短すぎるため長めに残す。
      setTimeout(cleanup, 60000);
    }
  }));
}

  Object.assign(global, {
    addPrintAttempt,
    getPrintRecordCount,
    renderFinalChecklist,
    getHardPrintIssues,
    getQueueTemplateGroups,
    renderJobGroupSummary,
    renderPrintActionArea,
    executePrint,
    doPrint
  });
  global.EnvelopePrintControl = Object.freeze({
    addPrintAttempt,
    getPrintRecordCount,
    renderFinalChecklist,
    getHardPrintIssues,
    getQueueTemplateGroups,
    renderJobGroupSummary,
    renderPrintActionArea,
    executePrint,
    doPrint
  });
})(typeof window !== 'undefined' ? window : globalThis);
