(function(global){
  'use strict';
/* ============================================================
   v38-6: Registry Core
   FieldSource / Step3 / Step5 / PrintExecution / InputValidation / InputData / SampleData
   依存: js/05_utilities.js 読込後、js/10_core.js 読込前。
   ============================================================ */

/* ============================================================
   FieldSourceRegistry Step1
   目的：getFieldText の多重モンキーパッチ廃止に向けた土台。
   注意：Step1では既存 getFieldText の挙動を変更しない。
   次工程で getFieldText をRegistry経由へ移行するため、既存sourceを先に登録しておく。
   ============================================================ */
const FieldSourceRegistry = (function(){
  const sources = Object.create(null);
  const sourceOrder = [];
  const postProcessors = [];
  function registerSource(key, label, resolver, options){
    if(!key || typeof resolver !== 'function') return false;
    const opt = options || {};
    sources[key] = {key, label:label||key, resolver, options:opt};
    if(!sourceOrder.includes(key)) sourceOrder.push(key);
    return true;
  }
  function hasSource(key){
    return Object.prototype.hasOwnProperty.call(sources, key);
  }
  function resolve(key, field, data){
    const entry = sources[key];
    if(!entry) return {found:false, value:''};
    try{
      return {found:true, value:entry.resolver(field, data)};
    }catch(e){
      // v26: source resolver の例外で封筒全体の描画を止めないため、値は空扱いにして警告を残す。
      console.warn('FieldSourceRegistry resolver failed', key, e);
      return {found:true, value:'', error:e};
    }
  }
  function registerPostProcessor(fn){
    if(typeof fn !== 'function') return false;
    postProcessors.push(fn);
    return true;
  }
  function applyPostProcessors(field, value, data, context){
    // v37 Step6-1: 描画対象テンプレート等を後処理へ渡すためのcontext受け口を追加。
    // 既存の3引数postProcessorは追加引数を無視するため後方互換を維持する。
    let current = value;
    for(const fn of postProcessors){
      try{
        const next = fn(field, current, data, context);
        if(next !== undefined) current = next;
      }catch(e){
        console.warn('FieldSourceRegistry postProcessor failed', e);
      }
    }
    return current;
  }
  function listSources(){
    return sourceOrder.map(k=>sources[k]).filter(Boolean);
  }
  function listSourceKeys(){
    return listSources().map(s=>s.key);
  }
  function getLabel(key){
    return (sources[key] && sources[key].label) || key;
  }
  return {registerSource, hasSource, resolve, registerPostProcessor, applyPostProcessors, listSources, listSourceKeys, getLabel, _sources:sources, _sourceOrder:sourceOrder, _postProcessors:postProcessors};
})();
global.FieldSourceRegistry = FieldSourceRegistry;


/* ============================================================
   Step3ExtensionRegistry Step1
   目的：renderStep3 / switchInputPane の多重モンキーパッチ廃止に向けた土台。
   注意：Step1では既存のStage5/6/7ラッパーは停止しない。
   次工程で本体renderStep3/switchInputPaneにhook実行地点を追加するため、先に登録先だけ用意する。
   ============================================================ */
const Step3ExtensionRegistry = (function(){
  const renderHooks = [];
  const manualPaneHooks = [];
  function registerRenderHook(fn, label){
    if(typeof fn !== 'function') return false;
    if(renderHooks.some(h=>h.fn===fn)) return false;
    renderHooks.push({fn, label:label||fn.name||'anonymous'});
    return true;
  }
  function registerManualPaneHook(fn, label){
    if(typeof fn !== 'function') return false;
    if(manualPaneHooks.some(h=>h.fn===fn)) return false;
    manualPaneHooks.push({fn, label:label||fn.name||'anonymous'});
    return true;
  }
  function runHookList(list, phase){
    for(const hook of list){
      try{ hook.fn(); }
      catch(e){ console.warn('Step3ExtensionRegistry hook failed', phase, hook.label, e); }
    }
  }
  function runRenderHooks(){
    runHookList(renderHooks, 'render');
  }
  function runManualPaneHooks(){
    runHookList(manualPaneHooks, 'manualPane');
  }
  function listHooks(){
    return {
      render: renderHooks.map(h=>h.label),
      manualPane: manualPaneHooks.map(h=>h.label)
    };
  }
  return {registerRenderHook, registerManualPaneHook, runRenderHooks, runManualPaneHooks, listHooks, _renderHooks:renderHooks, _manualPaneHooks:manualPaneHooks};
})();
global.Step3ExtensionRegistry = Step3ExtensionRegistry;


/* ============================================================
   Step5ExtensionRegistry Step21
   目的：renderStep5 の後段モンキーパッチ廃止に向けた本印刷画面hook。
   Stage6のラベル開始位置UIなど、Step5の描画後に差し込む処理を登録する。
   ============================================================ */
const Step5ExtensionRegistry = (function(){
  const renderHooks = [];
  function registerRenderHook(fn, label){
    if(typeof fn !== 'function') return false;
    if(renderHooks.some(h=>h.fn===fn)) return false;
    renderHooks.push({fn, label:label||fn.name||'anonymous'});
    return true;
  }
  function runRenderHooks(context){
    for(const hook of renderHooks){
      try{ hook.fn(context||{}); }
      catch(e){ console.warn('Step5ExtensionRegistry render hook failed', hook.label, e); }
    }
  }
  function listHooks(){
    return {render: renderHooks.map(h=>h.label)};
  }
  return {registerRenderHook, runRenderHooks, listHooks, _renderHooks:renderHooks};
})();
global.Step5ExtensionRegistry = Step5ExtensionRegistry;


/* ============================================================
   PrintExecutionRegistry Step22
   目的：doPrint の後段モンキーパッチ廃止に向けた印刷実行hook。
   Stage8の印刷試行記録など、印刷実行直前の処理を登録する。
   ============================================================ */
const PrintExecutionRegistry = (function(){
  const beforePrintHooks = [];
  function registerBeforePrintHook(fn, label){
    if(typeof fn !== 'function') return false;
    if(beforePrintHooks.some(h=>h.fn===fn)) return false;
    beforePrintHooks.push({fn, label:label||fn.name||'anonymous'});
    return true;
  }
  function runBeforePrintHooks(context){
    for(const hook of beforePrintHooks){
      try{ hook.fn(context||{}); }
      catch(e){ console.warn('PrintExecutionRegistry beforePrint hook failed', hook.label, e); }
    }
  }
  function listHooks(){
    return {beforePrint: beforePrintHooks.map(h=>h.label)};
  }
  return {registerBeforePrintHook, runBeforePrintHooks, listHooks, _beforePrintHooks:beforePrintHooks};
})();
global.PrintExecutionRegistry = PrintExecutionRegistry;


/* ============================================================
   InputValidationRegistry Step26
   目的：btnAddQueue の入力検証をキャプチャフェーズ乗っ取りではなく明示hookで扱う。
   Stage5の住所・宛名チェックなど、キュー追加直前の検証処理を登録する。
   ============================================================ */
const InputValidationRegistry = (function(){
  const beforeAddQueueHooks = [];
  function registerBeforeAddQueueHook(fn, label){
    if(typeof fn !== 'function') return false;
    if(beforeAddQueueHooks.some(h=>h.fn===fn)) return false;
    beforeAddQueueHooks.push({fn, label:label||fn.name||'anonymous'});
    return true;
  }
  function runBeforeAddQueueHooks(context){
    for(const hook of beforeAddQueueHooks){
      try{
        const result = hook.fn(context||{});
        if(result === false) return false;
      }catch(e){
        console.warn('InputValidationRegistry beforeAddQueue hook failed', hook.label, e);
      }
    }
    return true;
  }
  function listHooks(){
    return {beforeAddQueue: beforeAddQueueHooks.map(h=>h.label)};
  }
  return {registerBeforeAddQueueHook, runBeforeAddQueueHooks, listHooks, _beforeAddQueueHooks:beforeAddQueueHooks};
})();
global.InputValidationRegistry = InputValidationRegistry;


/* ============================================================
   InputDataExtensionRegistry Step3
   目的：getInputData / loadAddrToInput / clearInput のモンキーパッチ廃止に向けた土台。
   Step3では本体 loadAddrToInput() / clearInput() に load / clear hook 実行地点を追加する。
   注意：Stage7既存ラッパー停止は次工程以降で行う。
   ============================================================ */
const InputDataExtensionRegistry = (function(){
  const collectHooks = [];
  const loadHooks = [];
  const clearHooks = [];
  function registerCollectHook(fn, label){
    if(typeof fn !== 'function') return false;
    if(collectHooks.some(h=>h.fn===fn)) return false;
    collectHooks.push({fn, label:label||fn.name||'anonymous'});
    return true;
  }
  function registerLoadHook(fn, label){
    if(typeof fn !== 'function') return false;
    if(loadHooks.some(h=>h.fn===fn)) return false;
    loadHooks.push({fn, label:label||fn.name||'anonymous'});
    return true;
  }
  function registerClearHook(fn, label){
    if(typeof fn !== 'function') return false;
    if(clearHooks.some(h=>h.fn===fn)) return false;
    clearHooks.push({fn, label:label||fn.name||'anonymous'});
    return true;
  }
  function runCollectHooks(data){
    const target = data || {};
    for(const hook of collectHooks){
      try{
        const extra = hook.fn(target);
        if(extra && typeof extra === 'object') Object.assign(target, extra);
      }catch(e){
        console.warn('InputDataExtensionRegistry collect hook failed', hook.label, e);
      }
    }
    return target;
  }
  function runLoadHooks(data){
    for(const hook of loadHooks){
      try{ hook.fn(data || {}); }
      catch(e){ console.warn('InputDataExtensionRegistry load hook failed', hook.label, e); }
    }
  }
  function runClearHooks(){
    for(const hook of clearHooks){
      try{ hook.fn(); }
      catch(e){ console.warn('InputDataExtensionRegistry clear hook failed', hook.label, e); }
    }
  }
  function listHooks(){
    return {
      collect: collectHooks.map(h=>h.label),
      load: loadHooks.map(h=>h.label),
      clear: clearHooks.map(h=>h.label)
    };
  }
  return {registerCollectHook, registerLoadHook, registerClearHook, runCollectHooks, runLoadHooks, runClearHooks, listHooks, _collectHooks:collectHooks, _loadHooks:loadHooks, _clearHooks:clearHooks};
})();
global.InputDataExtensionRegistry = InputDataExtensionRegistry;

function registerBuiltinFieldSources(){
  const r = FieldSourceRegistry;
  if(!r || r.hasSource('zip')) return;
  // v37 step46: 組み込みsourceのラベル・表示順をRegistry定義へ一本化する。
  // 旧来のUIプルダウン順と同じ順序で登録し、表示順を維持する。
  const defs = [
    ['zip','郵便番号',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.zip||'_______'; }],
    ['full_addr','住所1＋住所2',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.full_addr || global.joinLines([data.addr, data.addr2]) || '［住所］'; }],
    ['addr','住所1',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.addr||'［住所］'; }],
    ['addr2','住所2・建物名',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.addr2||''; }],
    ['company','会社名',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.company || ''; }],
    ['dept','部署名',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.dept || ''; }],
    ['title','役職名',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.title || ''; }],
    ['corp','会社・部署まとめ',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return global.buildOrgText(data); }],
    ['org_full','会社＋部署＋役職',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return global.buildOrgFullText(data); }],
    ['name','氏名',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.name||'［氏名］'; }],
    ['name_honor','氏名＋敬称',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return global.buildNameWithHonor(data.name||'［氏名］', data.honor); }],
    ['name2','連名',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.name2||''; }],
    ['name2_honor','連名＋敬称',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return global.buildNameWithHonor(data.name2, data.honor2||data.honor); }],
    ['sender_full','差出人まとめ',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return global.buildSenderText(data); }],
    ['sender_zip','差出人郵便番号',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.sender_zip ? '〒' + String(data.sender_zip).replace(/^〒/,'') : ''; }],
    ['sender_addr','差出人住所',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.sender_addr || ''; }],
    ['sender_company','差出人会社',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.sender_company || ''; }],
    ['sender_dept','差出人部署',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.sender_dept || ''; }],
    ['sender_name','差出人氏名',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.sender_name || ''; }],
    ['sender_tel','差出人電話',(f,data)=>{ data=global.normalizeAddressData(Object.assign({}, data||{})); return data.sender_tel ? 'TEL ' + data.sender_tel : ''; }],
    ['stamp','スタンプ',(f,data)=> f.customText || '親展'],
    ['custom','固定文字',(f,data)=> f.customText || '']
  ];
  defs.forEach(def=>r.registerSource(def[0], def[1], def[2]));
}
registerBuiltinFieldSources();

function getFieldSourceEntries(){
  const registry = global.FieldSourceRegistry || FieldSourceRegistry;
  if(registry && typeof registry.listSources === 'function'){
    const entries = registry.listSources();
    if(entries && entries.length) return entries;
  }
  return [];
}
function getFieldSourceLabel(key){
  const registry = global.FieldSourceRegistry || FieldSourceRegistry;
  if(registry && typeof registry.getLabel === 'function') return registry.getLabel(key);
  return key;
}
function sourceOptionsHtml(selected){
  // v37 step23: フィールドsourceのUI選択肢はFieldSourceRegistryを主たる参照元にする。
  const entries = getFieldSourceEntries().slice();
  if(selected && !entries.some(e=>e.key===selected)) entries.push({key:selected, label:getFieldSourceLabel(selected)});
  return entries.map(e=>`<option value="${global.escapeHtml(e.key)}" ${selected===e.key?' selected':''}>${global.escapeHtml(e.label||e.key)}</option>`).join('');
}


const SampleDataRegistry = (function(){
  const defaults = Object.create(null);
  const providers = [];
  function registerDefaults(values, label){
    if(!values || typeof values !== 'object' || Array.isArray(values)) return false;
    Object.keys(values).forEach(k=>{ defaults[k] = values[k]; });
    return true;
  }
  function registerProvider(fn, label){
    if(typeof fn !== 'function') return false;
    if(providers.some(p=>p.fn===fn)) return false;
    providers.push({fn, label:label||fn.name||'anonymous'});
    return true;
  }
  function build(tpl, base){
    // v37 step24: プレビュー用サンプルデータをRegistry経由で合流し、Stage追加sourceのサンプル不足を避ける。
    const out = Object.assign({}, base || {}, defaults);
    for(const p of providers){
      try{
        const extra = p.fn(tpl, Object.assign({}, out));
        if(extra && typeof extra === 'object' && !Array.isArray(extra)) Object.assign(out, extra);
      }catch(e){
        console.warn('SampleDataRegistry provider failed', p.label, e);
      }
    }
    return global.normalizeAddressData(out);
  }
  function listProviders(){ return providers.map(p=>p.label); }
  function listDefaultKeys(){ return Object.keys(defaults); }
  return {registerDefaults, registerProvider, build, listProviders, listDefaultKeys, _defaults:defaults, _providers:providers};
})();
global.SampleDataRegistry = SampleDataRegistry;

function registerBuiltinSampleData(){
  if(!global.SampleDataRegistry) return;
  global.SampleDataRegistry.registerDefaults({
    issue_no:'No.0001', issue_date:'令和8年5月24日', serial:'0001', amount:'金10,000円', memo:'これはプレビュー用の本文です。\n必要な文面に差し替えてください。'
  }, 'builtin extended sample defaults');
}
registerBuiltinSampleData();


  const RegistryCoreApi = Object.freeze({
    FieldSourceRegistry,
    Step3ExtensionRegistry,
    Step5ExtensionRegistry,
    PrintExecutionRegistry,
    InputValidationRegistry,
    InputDataExtensionRegistry,
    SampleDataRegistry,
    registerBuiltinFieldSources,
    getFieldSourceEntries,
    getFieldSourceLabel,
    sourceOptionsHtml,
    registerBuiltinSampleData
  });

  Object.assign(global, {
    FieldSourceRegistry,
    Step3ExtensionRegistry,
    Step5ExtensionRegistry,
    PrintExecutionRegistry,
    InputValidationRegistry,
    InputDataExtensionRegistry,
    SampleDataRegistry,
    registerBuiltinFieldSources,
    getFieldSourceEntries,
    getFieldSourceLabel,
    sourceOptionsHtml,
    registerBuiltinSampleData
  });
  global.EnvelopePrintRegistryCore = RegistryCoreApi;
})(typeof window !== 'undefined' ? window : globalThis);
