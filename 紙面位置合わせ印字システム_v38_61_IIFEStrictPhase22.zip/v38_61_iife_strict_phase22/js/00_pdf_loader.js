(function(global){
  'use strict';
  const doc = global.document;
  if(!doc || !doc.createElement || !doc.head){
    global.__pdfjsAvailable = false;
    return;
  }
  const s = doc.createElement('script');
  s.src = './pdf.min.js';
  s.onerror = ()=>{ global.__pdfjsAvailable = false; };
  s.onload = ()=>{
    if(global.pdfjsLib){
      global.pdfjsLib.GlobalWorkerOptions.workerSrc = './pdf.worker.min.js';
      global.__pdfjsAvailable = true;
    } else {
      global.__pdfjsAvailable = false;
    }
  };
  doc.head.appendChild(s);
})(window);
