(function(global){
  'use strict';
  /* ============================================================
     Bootstrap Controller / Event Binder
     v38-44: 起動委譲役を IIFE + strict 化。
     v38-37: 共通UIイベントを54_common_ui_binder.jsへ分離し、起動順序の委譲役へ寄せる。
     classic script / IIFE + explicit window export。保存キー・保存形式・field.source名は変更しない。
     ============================================================ */

function bindEvents(){
  // 共通UI: ヘルプ・データ管理・表示モード切替はCommon UI Binderへ委譲する。
  bindEventsForCommonUI();

  // ステップ1: 固定ボタンの接続はStep1 UI Controllerへ委譲する。
  bindEventsForStep1();

  // ステップ2: 固定イベントの接続はStep2 Edit UIへ委譲する。
  bindEventsForStep2();

  // ステップ3: 固定イベントの接続はStep3 Input Coreへ委譲する。
  bindEventsForStep3();

  // ステップ4: 固定イベントの接続はStep4 Test Print UIへ委譲する。
  bindEventsForStep4();

  // ステップ5: 固定イベントの接続はStep5 Final Print UIへ委譲する。
  bindEventsForStep5();
}

function selectLastUsedTemplate(){
  if(state.lastUsedTplId && getTpl(state.lastUsedTplId)) state.selectedTplId = state.lastUsedTplId;
  return state.selectedTplId || null;
}

function initializeApp(options){
  const hooks = options || {};
  (hooks.load || load)();
  (hooks.setupKeyboard || setupKeyboard)();
  (hooks.setupEscapeToCloseOverlays || setupEscapeToCloseOverlays)();
  (hooks.bindEvents || bindEvents)();
  (hooks.selectLastUsedTemplate || selectLastUsedTemplate)();
  (hooks.goToStep || goToStep)(1);
  (hooks.updateStorageStatus || updateStorageStatus)();
}

const EnvelopePrintBootstrap = Object.freeze({
  bindEvents,
  selectLastUsedTemplate,
  initializeApp
});

Object.assign(global, {
  bindEvents,
  selectLastUsedTemplate,
  initializeApp,
  EnvelopePrintBootstrap
});

if(!global.__ENVELOPE_PRINT_BOOTSTRAP_TEST_MODE){
  initializeApp();
}
})(typeof window !== 'undefined' ? window : globalThis);
