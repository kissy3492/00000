(function(global){
  'use strict';
/* ============================================================
   v38-9 Field Render
   renderNormalField / renderZipField を core から分離。
   renderEnvelopeInto やドラッグ本体は 10_core.js 側に残す。
   ============================================================ */

function renderNormalField(parent,f,sample,tpl,interactive,scale,highlightFieldId){
  const rect=f.autoFit?adjustFieldRect(f,tpl.excludeZones||[],tpl.w,tpl.h):{x:f.x,y:f.y,w:f.w,h:f.h};
  // v37 step19: Stage7の画像・印影文字はラッパーではなく本体描画で処理する。
  if(f.source==='image' || f.source==='seal_text'){
    const el=document.createElement('div');
    el.className='field' + (f.source==='image'?' stage7-image':' stage7-seal')
      +((f.id===state.selectedFieldId||f.id===highlightFieldId)&&interactive?' selected':'')
      +(tpl.locked?' locked':'');
    el.dataset.fid=f.id;
    el.style.left=(rect.x*scale)+'mm';el.style.top=(rect.y*scale)+'mm';
    el.style.width=(rect.w*scale)+'mm';el.style.height=(rect.h*scale)+'mm';
    el.style.fontSize=((f.fontSize||12)*scale)+'pt';
    el.style.fontWeight=f.bold?'700':'400';
    el.style.fontFamily="'Hiragino Mincho ProN','Yu Mincho','MS Mincho',serif";
    const c=document.createElement('div');
    c.className='field-content anchor-'+(f.anchor||'mc');
    if(f.source==='image' && f.imageData){
      const img=document.createElement('img');
      img.src=f.imageData;
      c.appendChild(img);
    }else{
      c.textContent=getFieldText(f,sample,{tpl});
    }
    el.appendChild(c);
    if(interactive && !tpl.locked){
      attachFieldDrag(el,f);
      el.addEventListener('click',e=>{
        e.stopPropagation();
        state.selectedFieldId=f.id;state.selectedZoneId=null;
        renderEnvelope();renderFieldList();
        $('envelope').focus();
      });
    }
    parent.appendChild(el);
    return;
  }
  // v37 Step6-2: 描画対象テンプレートをpostProcessorへ渡す。
  const text=getFieldText(f,sample,{tpl});
  const fit=f.autoFit?fitText(text,f,rect):{text,fontSize:f.fontSize,fit:true};
  const el=document.createElement('div');
  el.className='field'+(f.vertical?' vertical':'')
    +((f.id===state.selectedFieldId||f.id===highlightFieldId)&&interactive?' selected':'')
    +(!fit.fit&&interactive?' has-warning':'')
    +(tpl.locked?' locked':'');
  el.dataset.fid=f.id;
  el.style.left=(rect.x*scale)+'mm';el.style.top=(rect.y*scale)+'mm';
  el.style.width=(rect.w*scale)+'mm';el.style.height=(rect.h*scale)+'mm';
  el.style.fontSize=(fit.fontSize*scale)+'pt';
  el.style.fontWeight=f.bold?'700':'400';
  el.style.fontFamily="'Hiragino Mincho ProN','Yu Mincho','MS Mincho',serif";
  if(!fit.fit&&interactive){
    const w=document.createElement('div');w.className='field-warning-icon';w.textContent='!';el.appendChild(w);
  }
  const c=document.createElement('div');
  c.className='field-content anchor-'+(f.anchor||'tl');
  c.textContent=fit.text;
  if(f.vertical&&/[0-9a-zA-Z]/.test(c.textContent)) c.classList.add('with-numbers');
  el.appendChild(c);
  if(interactive && !tpl.locked){
    attachFieldDrag(el,f);
    el.addEventListener('click',e=>{
      e.stopPropagation();
      state.selectedFieldId=f.id;state.selectedZoneId=null;
      renderEnvelope();renderFieldList();
      $('envelope').focus();
    });
  }
  parent.appendChild(el);
}

function renderZipField(parent,f,data,tpl,interactive,scale,highlightFieldId,onlyZip){
  const zc=f.zipConfig||{showFrame:false,showMark:false,charSpacing:1.2,gapAfter3:1.5,digitOffsets:[]};
  const zip=(data.zip||'').replace(/[^\d]/g,'').slice(0,7).padEnd(7,'_');
  const wrap=document.createElement('div');
  wrap.className='field'+((f.id===state.selectedFieldId||f.id===highlightFieldId)&&interactive?' selected':'')
    +(tpl.locked?' locked':'');
  wrap.dataset.fid=f.id;
  wrap.style.left=(f.x*scale)+'mm';wrap.style.top=(f.y*scale)+'mm';
  wrap.style.width=(f.w*scale)+'mm';wrap.style.height=(f.h*scale)+'mm';
  wrap.style.fontSize=(f.fontSize*scale)+'pt';
  wrap.style.fontWeight=f.bold?'700':'400';
  wrap.style.fontFamily="'Hiragino Mincho ProN','Yu Mincho','MS Mincho',serif";
  let prefixW=0;
  if(zc.showMark){
    const m=document.createElement('span');m.textContent='〒';
    m.style.cssText=`position:absolute;left:0;top:50%;transform:translateY(-50%);font-size:${f.fontSize*scale}pt`;
    wrap.appendChild(m);prefixW=f.fontSize*25.4/72*0.9;
  }
  const cm=f.fontSize*25.4/72;
  const totalWidth=7*cm+6*zc.charSpacing+zc.gapAfter3+prefixW;
  const startX=prefixW+Math.max(0,(f.w-totalWidth)/2);
  let curX=startX;
  for(let i=0;i<7;i++){
    const off=(zc.digitOffsets&&zc.digitOffsets[i])||{x:0,y:0};
    const d=document.createElement('span');d.textContent=zip[i];
    d.style.cssText=`position:absolute;left:${(curX+off.x)*scale}mm;top:${off.y*scale}mm;width:${cm*scale}mm;text-align:center;font-size:${f.fontSize*scale}pt`;
    wrap.appendChild(d);
    curX+=cm+zc.charSpacing;
    if(i===2) curX+=zc.gapAfter3;
  }
  if(zc.showFrame&&interactive){
    const grid=document.createElement('div');grid.className='zip-grid';
    grid.style.cssText=`position:absolute;left:${startX*scale}mm;top:0;width:${(totalWidth-prefixW)*scale}mm;height:100%;border:1px dashed rgba(196,77,46,0.4);display:flex`;
    for(let i=0;i<7;i++){
      const s=document.createElement('div');
      s.style.cssText=`flex:1;border-right:1px dashed rgba(196,77,46,0.3)`;
      if(i===6) s.style.borderRight='none';
      grid.appendChild(s);
    }
    wrap.appendChild(grid);
  }
  if(interactive && !tpl.locked){
    attachFieldDrag(wrap,f);
    wrap.addEventListener('click',e=>{
      e.stopPropagation();
      state.selectedFieldId=f.id;state.selectedZoneId=null;
      renderEnvelope();renderFieldList();
    });
  }
  parent.appendChild(wrap);
}

  Object.assign(global, {
    renderNormalField,
    renderZipField
  });
  global.EnvelopePrintFieldRenderer = Object.freeze({
    renderNormalField,
    renderZipField
  });
})(typeof window !== 'undefined' ? window : globalThis);
