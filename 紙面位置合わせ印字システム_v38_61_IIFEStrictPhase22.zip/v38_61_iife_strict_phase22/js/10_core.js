/* ============================================================
   定数
   ============================================================ */
const APP_DISPLAY_NAME = '紙面位置合わせ印字システム';
const APP_RELEASE_LABEL = 'v38-61 iife strict phase22';
const APP_STORAGE_SCHEMA_VERSION = 19;
const APP_MODULE_API_VERSION = 'v38-61-iife-strict-phase22';
const APP_RELEASE_NOTES = [
  {step:'v37 step1-7', summary:'tpl context受け渡し・主要Registry導入・描画経路整理'},
  {step:'v37 step8-24', summary:'取込/保存/復元/サンプルデータ/主要モンキーパッチ排除'},
  {step:'v37 step25-32', summary:'イベント乗っ取り排除・復元ID安全化・fitText改善'},
  {step:'v37 step33-46', summary:'標準ダイアログ全廃・a11y第一段階・FieldSourceRegistry一本化'},
  {step:'v37 step47-63', summary:'版表示整理・保存キー現行化・保存/復元安全化・実機検証導線'},
  {step:'v37 step64-65', summary:'実機検証レポート表示/コピー統一・状態付きチェックリスト化'},
  {step:'v37 step66', summary:'Stage8専用toastラッパーを撤去し、通知経路を本体toastへ統一'},
  {step:'v37 step67', summary:'Stage8モーダル遷移を共通化し、入れ子モーダルの直接innerHTML破棄を整理'},
  {step:'v37 step68', summary:'単体HTML維持を前提に、疑似モジュール索引と分割方針を明文化'},
  {step:'v37 step69', summary:'v37凍結候補とv38構造リファクタフェーズの境界を明文化'},
  {step:'v38-1', summary:'構造棚卸し・実コード位置対応表・分割難度・依存方向を明文化'},
  {step:'v38-2', summary:'開発検証用にCSS/JSを外部ファイルへ抽出し、単体HTML再結合前提の分割試作を作成'},
  {step:'v38-3', summary:'共通ユーティリティを js/05_utilities.js へ切り出し、core本体から通知・コピー・a11y・モーダル系を分離'},
  {step:'v38-4', summary:'保存・復元系のブラウザテスト導入。sanitize・ID変換・Stage8 addon復元整合をテストページで確認可能にした'},
  {step:'v38-5', summary:'分割版を開発・配布の本流へ変更。単体HTML再結合前提を撤回し、分割構成の運用・検証方針を明文化'},
  {step:'v38-6', summary:'10_core.jsからRegistry系とStorage/Backup系を段階分離し、依存順を明示'},
  {step:'v38-7', summary:'Template/Field Modelを js/40_templates.js へ分離し、ENVELOPE_SIZES・normalizeTpl・field生成系をcoreから切り出し'},
  {step:'v38-8', summary:'Render/Layout分離の前段として、fitText・矩形調整・印字幅推定を js/42_layout_math.js へ分離'},
  {step:'v38-9', summary:'field描画関数 renderNormalField / renderZipField を js/45_render_fields.js へ分離'},
  {step:'v38-10', summary:'renderEnvelopeInto・ラベル面付け・印刷スタック描画を js/46_render_envelope.js へ分離'},
  {step:'v38-11', summary:'印刷前チェック・印刷実行制御・印刷試行履歴を js/47_print.js へ分離'},
  {step:'v38-12', summary:'ステップ進行・各Step描画・入力/一覧/貼付取込UIを js/48_steps_ui.js へ分離'},
  {step:'v38-13', summary:'位置合わせウィザードを js/49_wizard.js へ分離'},
  {step:'v38-14', summary:'10_core.jsに残る責務を棚卸しし、次の分離順序と保留判断を明文化'},
  {step:'v38-15', summary:'Address Data Formatterを js/15_address_data.js へ分離し、宛名整形・サンプルデータ・field text解決入口をcoreから切り出し'},
  {step:'v38-16', summary:'Address Data Formatterの依存順・scope export・README構成・単体テスト・verify脚本を是正'},
  {step:'v38-17', summary:'ESC閉じ・キーボード微調整などのKeyboard/Overlay制御を js/06_keyboard_overlay.js へ分離'},
  {step:'v38-18', summary:'背景画像/PDF取込・圧縮・テンプレート反映を js/43_background_assets.js へ分離'},
  {step:'v38-19', summary:'ヘルプ・バックアップ管理・疑似モジュール概要を js/52_data_management_ui.js へ分離'},
  {step:'v38-20', summary:'詳細編集キャンバスのmm換算・field/zoneドラッグ・避ける範囲作成を js/44_edit_canvas_controller.js へ分離'},
  {step:'v38-21', summary:'イベント接続 bindEvents と初期化順序 initializeApp を js/90_bootstrap.js へ分離'},
  {step:'v38-22', summary:'差出人欄・スタンプfield生成と追加操作を js/41_parts_actions.js へ分離'},
  {step:'v38-23', summary:'詳細編集画面の描画入口 renderEnvelope を js/44_edit_canvas_controller.js へ分離'},
  {step:'v38-24', summary:'調整ステータス判定 getTplAdjustmentSummary を js/53_adjustment_status.js へ分離'},
  {step:'v38-25', summary:'Stage5〜8 addonの保存キー・Registry接続・読込順・getFieldText非上書きを棚卸し、静的検証を追加'},
  {step:'v38-26', summary:'Step1テンプレート選択UIを js/48_step1_template_ui.js へ分離'},
  {step:'v38-27', summary:'Step3入力・キュー・住所録・履歴・Excel貼付取込の分離前契約を棚卸し、静的検証を追加'},
  {step:'v38-28', summary:'Step3手入力coreを js/48_step3_input_core.js へ分離し、入力フォーム・入力データ収集/復元/クリアを移動'},
  {step:'v38-29', summary:'画面表示・README・manifest・core定数の版数同期を修正し、tools/sync_version.js とverifyの版数同期検証を追加'},
  {step:'v38-30', summary:'Step1固定ボタンのevent binderを js/48_step1_template_ui.js へ移し、90_bootstrap.js のbindEventsをStep別委譲へ寄せた'},
  {step:'v38-31', summary:'Step3固定イベントのevent binderを js/48_step3_input_core.js へ移し、公開APIにStep3Input区分を追加'},
  {step:'v38-32', summary:'Step3キュー・住所録・履歴・Excel貼付取込を js/48_step3_queue_ui.js へ分離し、公開APIにStep3Queue区分を追加'},
  {step:'v38-33', summary:'Step4テスト印刷・プリンタ補正UIを js/48_step4_test_print_ui.js へ、Step5本印刷プレビューUIを js/48_step5_final_print_ui.js へ分離し、固定イベント接続もStep側へ移動'},
  {step:'v38-34', summary:'ステップ一覧描画・進行可否・ステップ遷移を js/48_step_navigation.js へ分離し、Step具体UIとの委譲境界を整理'},
  {step:'v38-35', summary:'Step2詳細編集UIを js/48_step2_edit_ui.js へ分離し、48_steps_ui.jsを残存メモだけに縮小'},
  {step:'v38-36', summary:'Step2固定イベントのevent binderを js/48_step2_edit_ui.js へ移し、90_bootstrap.js をStep別委譲に集約'},
  {step:'v38-37', summary:'ヘルプ・データ管理・表示モード切替の共通event binderを js/54_common_ui_binder.js へ分離し、90_bootstrap.js を起動委譲役へさらに縮小'},
  {step:'v38-38', summary:'履歴マーカー化していた js/48_steps_ui.js を完全退役し、tools/regenerate_inventory.js でcore残存台帳の再生成を可能にした'},
  {step:'v38-39', summary:'個別の棚卸しdocsを docs/refactor_inventory_archive.md に統合し、最新台帳と過去メモの参照先を整理した'},
  {step:'v38-40', summary:'00_pdf_loader・42_layout_math・99_audit_markerをIIFE + strict化し、Layout Mathの明示exportと検証を追加した'},
  {step:'v38-41', summary:'45_render_fields・46_render_envelope・47_printをIIFE + strict化し、描画/印刷系の明示exportと公開API索引を更新した'},
  {step:'v38-42', summary:'40_templatesをIIFE + strict化し、Template Modelの明示exportと公開API索引を更新した'},
  {step:'v38-43', summary:'20_registriesをIIFE + strict化し、Registry Coreの明示exportと公開API索引を更新した'},
  {step:'v38-44', summary:'90_bootstrapをIIFE + strict化し、起動委譲役の明示exportと互換グローバルを維持した'},
  {step:'v38-45', summary:'49_wizardをIIFE + strict化し、Wizard Controllerの明示exportとwizardState互換参照を維持した'},
  {step:'v38-46', summary:'05_utilitiesをIIFE + strict化し、共通ユーティリティの明示exportとEnvelopePrintUtilities APIを追加した'},
  {step:'v38-47', summary:'15_address_dataをIIFE + strict化し、Address Data Formatterの明示exportとEnvelopePrintAddressData APIを追加した'},
  {step:'v38-48', summary:'53_adjustment_statusをIIFE + strict Phase9として再整備し、Adjustment Statusの明示exportとEnvelopePrintAdjustmentStatus APIを追加した'},
  {step:'v38-49', summary:'54_common_ui_binderをIIFE + strict Phase10として再整備し、Common UI Binderの明示APIと概要索引の検証を強化した'},
  {step:'v38-50', summary:'41_parts_actionsをIIFE Strict Phase11として再整備し、Parts Actionsの明示API EnvelopePrintPartsActions と検証を追加した'},
  {step:'v38-51', summary:'52_data_management_uiをIIFE Strict Phase12として再整備し、Data Management UIの明示API EnvelopePrintDataManagementUI と検証を追加した'},
  {step:'v38-52', summary:'30_storage.jsをIIFE Strict Phase13として再整備し、保存仕様を維持したままEnvelopePrintStorageCore APIと検証を追加した'},
  {step:'v38-53', summary:'43_background_assets.jsをIIFE Strict Phase14として再整備し、背景画像/PDF処理のEnvelopePrintBackgroundAssets APIと検証を追加した'},
  {step:'v38-54', summary:'44_edit_canvas_controller.jsをIIFE Strict Phase15として再整備し、編集キャンバス制御のEnvelopePrintEditCanvasController APIと検証を追加した'},
  {step:'v38-55', summary:'48_step_navigation.jsをIIFE Strict Phase16として再整備し、Step NavigationのEnvelopePrintStepNavigation APIと検証を追加した'},
  {step:'v38-56', summary:'48_step1_template_ui.jsをIIFE Strict Phase17として再整備し、Step1 Template UIのEnvelopePrintStep1TemplateUI APIと検証を追加した'},
  {step:'v38-57', summary:'48_step2_edit_ui.jsをIIFE Strict Phase18として再整備し、Step2 Edit UIのEnvelopePrintStep2EditUI APIと検証を追加した'},
  {step:'v38-58', summary:'48_step3_input_core.jsをIIFE Strict Phase19として再整備し、Step3 Input CoreのEnvelopePrintStep3InputCore APIと検証を追加した'},
  {step:'v38-59', summary:'48_step3_queue_ui.jsをIIFE Strict Phase20として再整備し、Step3 Queue UIのEnvelopePrintStep3QueueUI APIと検証を追加した'},
  {step:'v38-60', summary:'48_step4_test_print_ui.jsをIIFE Strict Phase21として再整備し、Step4 Test Print UIのEnvelopePrintStep4TestPrintUI APIと検証を追加した'},
  {step:'v38-61', summary:'48_step5_final_print_ui.jsをIIFE Strict Phase22として再整備し、Step5 Final Print UIのEnvelopePrintStep5FinalPrintUI APIと検証を追加した'},
  {step:'欠番/統合', summary:'レビューのみのStepや中断可能点は成果物として統合され、ファイル化されていない場合がある'}
];
// v37 step64: step番号を履歴の代替にしないため、主要な作業範囲をAPP_RELEASE_NOTESとして明示する。
// v37 step65: 実機印刷チェックをアプリ内状態として保持し、レポートにも反映する。
// v38-5: 分割版を本流化。単体HTML前提の疑似モジュール索引は、分割後の責務対応表として維持する。
// v37 step69: v38は機能追加ではなく構造リファクタ専用フェーズとして扱い、v37と境界を切る。
const APP_ARCHITECTURE_DECISION = [
  {topic:'配布形態', decision:'分割版を本流化', reason:'8,000行級の単体HTMLではレビュー・テスト・責務分離が限界に近いため。以後はindex.html + css/jsを正とする'},
  {topic:'外部JS分割', decision:'現段階では実施しない', reason:'pdf.min.jsのような任意ライブラリと異なり、本体ロジック分割は配布物欠落時に即停止するため'},
  {topic:'v38方針', decision:'分割版を正とする', reason:'単体HTMLは必要時の派生成果物に格下げし、通常の開発・レビュー・テストは分割版で行う'},
  {topic:'現行対策', decision:'モジュール索引・Registry境界・公開APIを明文化', reason:'単一ファイルのままでも、触るべき領域と触ってはいけない領域を追えるようにするため'}
];
const APP_PSEUDO_MODULE_MAP = [
  {name:'Metadata / Constants', scope:'アプリ名・版表示・保存キー・リリースメモ', entry:'APP_DISPLAY_NAME / APP_RELEASE_LABEL / STORAGE_KEY'},
  {name:'Registry Core', scope:'FieldSource / Step3 / Step5 / PrintExecution / InputValidation / InputData / SampleData', entry:'各Registry定義'},
  {name:'Storage / Backup', scope:'保存・バックアップ・復元・sanitize・localStorage容量管理', entry:'save / load / backupNow / restoreFullBackupSafely'},
  {name:'Template / Field Model', scope:'テンプレート生成・正規化・field/source管理', entry:'normalizeTpl / buildFieldsForPreset'},
  {name:'Input / Address Book', scope:'宛先入力・住所録・Excel貼付・履歴復帰', entry:'getInputData / renderPasteImport'},
  {name:'Layout / Render', scope:'封筒/ラベル/帳票の描画、field/zip描画、ドラッグ操作', entry:'renderEnvelopeInto / renderNormalField / renderZipField'},
  {name:'Wizard', scope:'初回位置合わせウィザード、背景画像、補正導線', entry:'openWizard / renderWizard / closeWizard'},
  {name:'Print', scope:'印刷スタック生成、履歴/試行履歴、印刷前チェック', entry:'buildPrintStack / executePrint / doPrint'},
  {name:'Stage5 Addon', scope:'差出人プロファイル・スタンプライブラリ・住所録管理拡張', entry:'EnvelopePrintStage5'},
  {name:'Stage6 Addon', scope:'住所整形・郵便番号辞書・縦書き補助・ラベル開始位置', entry:'EnvelopePrintStage6'},
  {name:'Stage7 Addon', scope:'はがき裏面・名札・帳票部品・画像/印影field', entry:'EnvelopePrintStage7'},
  {name:'Stage8 Validation', scope:'実機検証記録・印刷ガイド・補正ナビ・手動チェック', entry:'EnvelopePrintStage8'}
];
// v37 step69: v37を機能凍結候補、v38を構造リファクタ専用フェーズとして分離する判断を明文化する。
const APP_V38_REFACTOR_DECISION = [
  {topic:'v37の扱い', decision:'機能凍結候補', reason:'保存・復元・印刷・a11y・検証導線の主要負債を解消済みで、これ以上の機能追加は肥大化リスクが高いため'},
  {topic:'v38の目的', decision:'構造リファクタ専用', reason:'単体HTMLのまま機能を足すのではなく、責務分離・テスト容易性・レビュー容易性を改善するため'},
  {topic:'v38でやること', decision:'分割検証・責務境界整理・テスト導入', reason:'現行機能を増やさず、壊さず、見通しを良くする作業に限定するため'},
  {topic:'v38でやらないこと', decision:'新機能追加・保存形式変更・UI全面刷新は原則禁止', reason:'リファクタと機能追加を混ぜると不具合原因を切り分けられないため'},
  {topic:'配布方針', decision:'分割版を本流にする', reason:'既存ユーザーがなく、開発継続とレビュー効率を優先するため。単体HTMLは必要時のみ派生物として扱う'}
];
const APP_V38_REFACTOR_PLAN = [
  {phase:'v38-1', scope:'構造棚卸し', output:'疑似モジュール索引と実コード位置の対応表を作る', done:'主要関数の責務・依存・呼び出し方向を説明できる'},
  {phase:'v38-2', scope:'開発用分割の試作', output:'同フォルダJS分割版を別成果物として作る', done:'単体HTML版と機能差分がないことを確認できる'},
  {phase:'v38-3', scope:'共通ユーティリティ集約', output:'escape/copy/toast/modal/storage系の重複を整理する', done:'同種関数が複数系統に分かれていない'},
  {phase:'v38-4', scope:'保存・復元テスト導入', output:'JSON復元・壊れたfield・容量超過の最小テストを作る', done:'主要データ保全処理を手作業だけに依存しない'},
  {phase:'v38-5', scope:'分割版本流化', output:'README・マニフェスト・運用方針を分割版正へ変更する', done:'単体HTML再結合前提を撤回し、分割版を基準成果物として扱える'}
];
// v38-1〜5: 構造棚卸しを経て分割版を本流化。責務境界・抽出候補・依存方向を明文化する。
const APP_V38_MODULE_INVENTORY = [
  {module:'00 Metadata', marker:'定数', owns:'アプリ名、表示版、保存キー、リリースメモ、v38判断', examples:'APP_DISPLAY_NAME / APP_RELEASE_LABEL / STORAGE_KEY', dependsOn:'なし', extractionRisk:'低', nextAction:'最初に切り出せるが、保存キー変更は別判断にする'},
  {module:'01 Utilities', marker:'共通ユーティリティ', owns:'escape、format、copy、toast、modal、a11y補助、容量推定', examples:'escapeHtml / copyTextToClipboard / showAppConfirm / applyScreenA11y', dependsOn:'00 Metadata', extractionRisk:'中', nextAction:'v38-3で最優先に集約対象。DOM依存関数と純粋関数を分ける'},
  {module:'02 Registry Core', marker:'Registry', owns:'source解決、Step拡張、入力拡張、印刷hook、サンプルデータ', examples:'FieldSourceRegistry / Step3ExtensionRegistry / InputValidationRegistry', dependsOn:'01 Utilities', extractionRisk:'中', nextAction:'分割時はStorageやRenderより先に読み込ませる'},
  {module:'03 Storage Backup', marker:'保存・バックアップ', owns:'localStorage保存、復元、sanitize、ロールバック、旧キー掃除、容量表示', examples:'save / load / sanitizeSnapshotForLoad / restoreFullBackupSafely', dependsOn:'00 Metadata, 01 Utilities, 02 Registry Core', extractionRisk:'高', nextAction:'v38-4でテスト導入後に切り出す。先に動かすとデータ保全リスクが高い'},
  {module:'04 Template Field Model', marker:'テンプレート・フィールド', owns:'テンプレート生成、field生成、source初期配置、郵便番号設定', examples:'initialTemplates / normalizeTpl / buildFieldsForPreset', dependsOn:'01 Utilities, 02 Registry Core', extractionRisk:'中', nextAction:'v38-7でモデル定義を js/40_templates.js へ分離済み'},
  {module:'05 Input AddressBook', marker:'宛先入力・住所録', owns:'宛先入力、住所録、Excel貼付、履歴復帰、入力検証', examples:'getInputData / loadAddrToInput / renderPasteImport / doImportPaste', dependsOn:'01 Utilities, 02 Registry Core, 03 Storage Backup', extractionRisk:'分離済', nextAction:'v38-28で手入力core、v38-32でキュー・住所録・履歴・貼付取込を分離済み'},
  {module:'06 Layout Render', marker:'描画・ドラッグ', owns:'封筒/ラベル/帳票描画、field描画、fitText、ドラッグ、タッチ操作', examples:'renderEnvelopeInto / renderNormalField / renderZipField / attachFieldDrag', dependsOn:'01 Utilities, 02 Registry Core, 04 Template Field Model', extractionRisk:'高', nextAction:'v38-8〜10でfitText・field描画・envelope描画を分離、v38-20でドラッグ操作を js/44_edit_canvas_controller.js へ分離済み'},
  {module:'07 Wizard', marker:'位置合わせウィザード', owns:'背景画像、初回補正、ウィザード状態、beforeunload保護', examples:'openWizard / renderWizard / closeWizard / hasActiveWizardDraft', dependsOn:'03 Storage Backup, 04 Template Field Model, 06 Layout Render', extractionRisk:'分離済', nextAction:'v38-13で js/49_wizard.js へ分離済み。今後はWizard内の背景処理とプリンタ補正依存を精査'},
  {module:'08 Print', marker:'印刷', owns:'印刷スタック、ラベル面付け、印刷試行履歴、cleanup、印刷前チェック', examples:'buildPrintStack / buildLabelSheetStack / executePrint / doPrint', dependsOn:'03 Storage Backup, 06 Layout Render, 02 Registry Core', extractionRisk:'高', nextAction:'v38-10で印刷スタック描画を分離、v38-11で印刷前チェック・実行制御を分離済み。実機印刷挙動は別途検証する'},
  {module:'09 Stage5 Addon', marker:'Stage5', owns:'差出人プロファイル、スタンプライブラリ、住所録管理、住所入力補助', examples:'showSenderProfileModal / showStampLibraryModal / renderValidationPanel', dependsOn:'01 Utilities, 02 Registry Core, 05 Input AddressBook', extractionRisk:'中', nextAction:'addon保存キーを保ったまま単独ファイル候補にする'},
  {module:'10 Stage6 Addon', marker:'Stage6', owns:'郵便番号辞書、住所整形、縦書き住所postProcessor、ラベル開始位置UI', examples:'normalizeZip6 / importZipText / renderZipAssistModal', dependsOn:'01 Utilities, 02 Registry Core, 04 Template Field Model', extractionRisk:'中', nextAction:'FieldSourceRegistry/Step5ExtensionRegistryを境界にする'},
  {module:'11 Stage7 Addon', marker:'Stage7', owns:'帳票・証明書・名札・画像/印影・サンプルデータ', examples:'registerExtendedSources / addImageFieldFromPicker / buildReceiptFields', dependsOn:'01 Utilities, 02 Registry Core, 04 Template Field Model, 06 Layout Render', extractionRisk:'高', nextAction:'画像DataURL容量とRender依存が強いので後段'},
  {module:'12 Stage8 Validation', marker:'Stage8', owns:'検証記録、印刷ガイド、補正ナビ、手動チェック進捗、レポート', examples:'showValidationModal / showPrintGuideModal / buildManualPrintVerificationReport', dependsOn:'01 Utilities, 02 Registry Core, 03 Storage Backup, 08 Print', extractionRisk:'中', nextAction:'保存形式を変えずにUIだけ分離しやすい'},
  {module:'13 Bootstrap', marker:'初期化', owns:'load、bindEvents、setupKeyboard、a11y適用、beforeunload', examples:'initializeApp / bindEvents / selectLastUsedTemplate', dependsOn:'全モジュール', extractionRisk:'分離済', nextAction:'v38-21で js/90_bootstrap.js へ分離済み。起動順検証をverifyに維持する'}
];
const APP_V38_REFACTOR_GATES = [
  {gate:'機能追加禁止', rule:'v38では新機能を原則追加しない。追加が必要な場合はv37凍結版へ戻って判断する'},
  {gate:'保存形式固定', rule:'APP_STORAGE_SCHEMA_VERSION と保存キーは、テスト導入前に変更しない'},
  {gate:'モンキーパッチ禁止', rule:'window上の既存関数差し替えではなく、Registryまたは明示的な本体hookで扱う'},
  {gate:'標準ダイアログ禁止', rule:'alert/confirm/promptを復活させない'},
  {gate:'分割版を本流とする確認', rule:'以後の修正・テスト・レビューは分割版を基準に行う。単体HTMLは必要時だけ別途生成する'},
  {gate:'実機印刷保留', rule:'印刷ロジック変更は実機検証チェックリストを通すまで行わない'}
];
// v38-14: 10_core.jsに残る責務を棚卸しし、次の分離単位を明文化する。
const APP_V38_CORE_RESIDUAL_INVENTORY = [
  {area:'State / Bootstrap', owns:'state/transientBg、初期化順序、bindEvents、初期goToStep', examples:'state / transientBg / initializeApp / bindEvents / goToStep(1)', risk:'一部分離済', next:'v38-21でbindEventsと初期化順序を js/90_bootstrap.js へ分離済み。state/transientBg本体は保存・復元・Wizard共有のためcoreに残す'},
  {area:'Address Data Formatter', owns:'宛名・差出人データ整形、サンプルデータ、field text解決入口', examples:'joinLines / normalizeAddressData / defaultDataForTemplate / getFieldText / getSampleData', risk:'低〜中', next:'v38-15でjs/15_address_data.jsへ分離済み。RegistryとTemplateへの参照だけを境界にしている'},
  {area:'Parts Actions', owns:'差出人欄追加・スタンプ追加の本体アクション', examples:'createSenderFields / createStampField / addSenderBlockToCurrentTpl / addStampToCurrentTpl', risk:'分離済', next:'v38-22で js/41_parts_actions.js へ分離済み。Stage5スタンプライブラリ委譲も同ファイルで維持'},
  {area:'Background Assets', owns:'背景画像/PDF読込、圧縮、テンプレートへの背景設定', examples:'compressImageDataUrl / loadBackgroundFileInto / loadBackgroundPDF / setBackgroundOnTpl', risk:'分離済', next:'v38-18で js/43_background_assets.js へ分離済み。transientBg本体はstate/bootstrap側に残す'},
  {area:'Edit Canvas Controller', owns:'詳細編集画面のrenderEnvelope、field/zoneドラッグ、避ける範囲作成', examples:'renderEnvelope / attachFieldDrag / attachZoneDrag / startAddZone / getMMperPx', risk:'分離済', next:'v38-20でmm換算・ドラッグ・避ける範囲作成を分離し、v38-23でrenderEnvelope本体も js/44_edit_canvas_controller.js へ分離済み'},
  {area:'Global Overlay / Keyboard', owns:'ESC、キーボード微調整、モーダル閉じ制御', examples:'closeTopOverlayByEscape / setupEscapeToCloseOverlays / setupKeyboard', risk:'分離済', next:'v38-17で js/06_keyboard_overlay.js へ分離済み。Wizard/Modal/Step2編集とは実行時参照で接続'},
  {area:'Help / Data Management', owns:'ヘルプ、バックアップ管理、旧キー掃除UI、開発メモ表示', examples:'showHelp / showDataMgmt / getModuleOverview', risk:'分離済', next:'v38-19で js/52_data_management_ui.js へ分離済み。Storage API呼び出しUIとしてcore外へ移した'},
  {area:'Adjustment Status', owns:'背景位置合わせ・郵便番号確認・レイアウト確認・テスト印刷確認・プリンタ補正状態の集約判定', examples:'getTplAdjustmentSummary', risk:'分離済', next:'v38-24で js/53_adjustment_status.js へ分離済み。state本体はcoreに残し、判定関数だけを分離'},
  {area:'Step UI Controllers', owns:'Step1/2/3/4/5の具体UIと固定イベント接続、ステップ進行', examples:'renderStep1 / renderStep2 / renderStep3 / renderStep4 / renderStep5 / bindEventsForStep* / goToStep', risk:'分離済', next:'v38-26〜33でStep1、Step3、Step4、Step5を分離し、v38-34でステップ進行、v38-35でStep2詳細編集UIを分離済み。v38-38で48_steps_ui.jsは完全退役'}
];
const APP_V38_CORE_NEXT_EXTRACTION_ORDER = [
  {order:1, target:'js/15_address_data.js', reason:'v38-15で完了。宛名整形・サンプルデータ・field text解決入口をcoreから分離済み'},
  {order:2, target:'js/43_background_assets.js', reason:'v38-18で完了。背景画像/PDF処理をcoreから分離済み'},
  {order:3, target:'js/06_keyboard_overlay.js', reason:'v38-17で完了。ESC/キーボード制御を一箇所へ集約し、モーダル遷移・a11y検証をしやすくした'},
  {order:4, target:'js/52_data_management_ui.js', reason:'v38-19で完了。ヘルプ/バックアップ管理UIと疑似モジュール概要をcoreから分離済み'},
  {order:5, target:'js/44_edit_canvas_controller.js', reason:'v38-20でmm換算・ドラッグ・避ける範囲作成を分離し、v38-23でrenderEnvelope本体も分離済み'},
  {order:6, target:'js/90_bootstrap.js', reason:'v38-21で完了。bindEventsと初期化順序をcoreから分離済み'},
  {order:7, target:'js/41_parts_actions.js', reason:'v38-22で完了。差出人欄・スタンプfield生成と追加操作をcoreから分離済み'},
  {order:8, target:'js/53_adjustment_status.js', reason:'v38-24で完了。調整ステータス判定をcoreから分離済み'}
];
// v37 step55: 実装前提で完全新規システムとして扱うため、旧envelope_print_system系キー互換を撤去する。
// 旧版データを読みに行かず、保存先・バックアップ先・addon保存先を現行キー体系に統一する。
const STORAGE_KEY = 'paper_position_print_system_v37';
const BACKUP_KEY = 'paper_position_print_system_v37_backups';
const MAX_BACKUPS = 3;
const ANCHOR_KEYS = ['tl','tc','tr','ml','mc','mr','bl','bc','br'];
const ANCHOR_LABELS = {tl:'左上',tc:'上中央',tr:'右上',ml:'左中央',mc:'中央',mr:'右中央',bl:'左下',bc:'下中央',br:'右下'};
const STAMP_PRESETS = ['親展','重要','請求書在中','書類在中','納品書在中','折曲厳禁','水濡注意','料金後納郵便','料金別納郵便','速達','簡易書留'];

/* ============================================================
   v38-6: Registry系は js/20_registries.js へ分離済み。
   ============================================================ */


/* v38-18: 背景画像/PDF取込・圧縮は js/43_background_assets.js へ分離済み。 */
// localStorage 容量警告閾値（UTF-16換算の概算バイト）
const STORAGE_WARN_BYTES = 4 * 1024 * 1024; // 4MB
const STORAGE_HARD_LIMIT = 4.5 * 1024 * 1024;

const STEPS_SIMPLE = [
  {n:1,title:'封筒を選ぶ',desc:'TEMPLATE'},
  {n:3,title:'宛先を入力',desc:'ADDRESS'},
  {n:4,title:'テスト印刷',desc:'TEST'},
  {n:5,title:'本印刷',desc:'PRINT'}
];
const STEPS_ADVANCED = [
  {n:1,title:'封筒を選ぶ',desc:'TEMPLATE'},
  {n:2,title:'詳細編集',desc:'EDIT'},
  {n:3,title:'宛先を入力',desc:'ADDRESS'},
  {n:4,title:'テスト印刷',desc:'TEST'},
  {n:5,title:'本印刷',desc:'PRINT'}
];

/* ============================================================
   v38-7: Template/Field Model は js/40_templates.js へ分離済み。
   ============================================================ */

/* ============================================================
   状態
   ============================================================ */
let state = {
  templates:[],queue:[],addressBook:[],history:[],printAttempts:[],
  printerProfiles:[],
  selectedTplId:null,selectedFieldId:null,selectedZoneId:null,
  selectedPrinterId:null,
  mode:'edit',zoom:1,
  lastUsedTplId:null,
  currentStep:1,
  activeInputPane:'manual',
  uiMode:'simple',
  lastSavedAt:null
};
let transientBg = {}; // 保存しない背景画像（テンプレIDをキー）

/* ============================================================
   v38-3: 共通ユーティリティは js/05_utilities.js へ分離済み。
   このファイルはcore業務ロジック・保存・描画・印刷を担当する。
   ============================================================ */

/* ============================================================
   v38-15: 宛名・差出人データ整形は js/15_address_data.js へ分離済み。
   ============================================================ */

/* ============================================================
   v38-6: SampleDataRegistry は js/20_registries.js へ分離済み。
   ============================================================ */

/* ============================================================
   v38-22: Parts Actions は js/41_parts_actions.js へ分離済み。
   ============================================================ */

/* ============================================================
   v38-6: Storage / Backup / Restore 系は js/30_storage.js へ分離済み。
   ============================================================ */

/* v38-18: compressImageDataUrl は js/43_background_assets.js へ分離済み。 */

/* v38-15: getFieldText は js/15_address_data.js へ分離済み。 */


/* ============================================================
   v38-24: 調整ステータス判定は js/53_adjustment_status.js へ分離済み。
   ============================================================ */
/* ============================================================
   ステップ管理
   ============================================================ */
/* v38-38: 旧Step/UI集約ファイル js/48_steps_ui.js は完全退役済み。 */
/* v38-15: getSampleData は js/15_address_data.js へ分離済み。 */


/* ============================================================
   v38-23: 詳細編集用レンダリング renderEnvelope は js/44_edit_canvas_controller.js へ分離済み。
   ============================================================ */

/* ============================================================
   背景画像読込（圧縮あり）
   ============================================================ */
/* v38-18: loadBackgroundFileInto / PDF / image / setBackgroundOnTpl は js/43_background_assets.js へ分離済み。 */
/* v38-13: 位置合わせウィザード関数群は js/49_wizard.js へ分離済み。 */

/* v38-17: ESC/Keyboard制御は js/06_keyboard_overlay.js へ分離済み。 */

/* ============================================================
   v38-19: ヘルプ・データ管理UIは js/52_data_management_ui.js へ分離済み。
   ============================================================ */

/* ============================================================
   v38-22: 差出人欄・スタンプ追加アクションは js/41_parts_actions.js へ分離済み。
   ============================================================ */
/* v38-19: getModuleOverview() は js/52_data_management_ui.js へ分離済み。 */

/* ============================================================
   v38-21: イベントバインドと初期化は js/90_bootstrap.js へ分離済み。
   ============================================================ */




/* ============================================================
   内部モジュール公開（デバッグ・段階的分割の足場）
   ============================================================ */
const EnvelopePrintModules = Object.freeze({
  version:APP_MODULE_API_VERSION,
  displayName:APP_DISPLAY_NAME,
  releaseLabel:APP_RELEASE_LABEL,
  releaseNotes:APP_RELEASE_NOTES,
  architectureDecision:APP_ARCHITECTURE_DECISION,
  pseudoModuleMap:APP_PSEUDO_MODULE_MAP,
  v38RefactorDecision:APP_V38_REFACTOR_DECISION,
  v38RefactorPlan:APP_V38_REFACTOR_PLAN,
  v38ModuleInventory:APP_V38_MODULE_INVENTORY,
  v38RefactorGates:APP_V38_REFACTOR_GATES,
  v38CoreResidualInventory:APP_V38_CORE_RESIDUAL_INVENTORY,
  v38CoreNextExtractionOrder:APP_V38_CORE_NEXT_EXTRACTION_ORDER,
  storageKey:STORAGE_KEY,
  backupKey:BACKUP_KEY,
  storageSchemaVersion:APP_STORAGE_SCHEMA_VERSION,
  overview:getModuleOverview,
  DataManagementUI:EnvelopePrintDataManagementUI,
  Core:{uid, toast, escapeHtml, formatBytes, estimateStorageBytes, estimateDataUrlBytes},
  Utilities:EnvelopePrintUtilities,
  StorageCore:EnvelopePrintStorageCore,
  Storage:{dataSnapshot, save, backupNow, load, getStorageUsage},
  Template:{ENVELOPE_SIZES, normalizeTpl, markLayoutChanged, defaultLabelConfig, getLabelConfig, labelCapacity, getEffectivePrintPageCount, buildExcludeZonesForPreset, initialTemplates, buildFieldsForPreset, buildFieldsForSize},
  BackgroundAssets:EnvelopePrintBackgroundAssets,
  RegistryCore:EnvelopePrintRegistryCore,
  StepNavigation:EnvelopePrintStepNavigation,
  Step1TemplateUI:EnvelopePrintStep1TemplateUI,
  Step2Edit:EnvelopePrintStep2EditUI,
  AddressData:EnvelopePrintAddressData,
  Data:{normalizeAddressData, buildOrgText, buildSenderText, getInputData},
  Step3Input:EnvelopePrintStep3InputCore,
  Step3Queue:EnvelopePrintStep3QueueUI,
  Step4TestPrint:EnvelopePrintStep4TestPrintUI,
  Step5FinalPrint:EnvelopePrintStep5FinalPrintUI,
  CommonUI:EnvelopePrintCommonUI,
  FieldSources:{registry:FieldSourceRegistry},
  Step3Extensions:{registry:Step3ExtensionRegistry},
  InputDataExtensions:{registry:InputDataExtensionRegistry},
  Layout:{overlap, adjustFieldRect, approxChar, estimatePrintCharUnits, wrapTextByPrintUnits, fitText, renderEnvelope, renderEnvelopeInto, renderNormalField, renderZipField, renderLabelCellInto, buildLabelSheetStack, buildPrintStack},
  EditCanvasController:EnvelopePrintEditCanvasController,
  AdjustmentStatus:EnvelopePrintAdjustmentStatus,
  Adjustment:{getTplAdjustmentSummary},
  Wizard:EnvelopePrintWizard,
  Print:{addPrintAttempt, getPrintRecordCount, renderFinalChecklist, getHardPrintIssues, renderPrintActionArea, executePrint, buildPrintStack, doPrint},
  Parts:EnvelopePrintPartsActions,
  EditCanvas:EnvelopePrintEditCanvasController,
  Jobs:{getQueueTemplateGroups, renderJobGroupSummary},
  Paper:{buildFieldsForPreset, buildPostcardFields, buildLabelSheetFields, buildFormOverlayFields},
  TestHooks:Object.freeze({
    sanitizeSnapshotForLoad,
    sanitizeSnapshotForRestore,
    sanitizeStage8AddonForRestore,
    normalizeRestoreField,
    normalizeRestoreTemplateFields,
    normalizeRestoreTemplateIds,
    normalizeRestorePrinterIds,
    normalizeRestoreSafeId,
    isRestoreSafeIdString,
    addonStorageKeys,
    joinLines,
    buildOrgText,
    buildOrgFullText,
    buildNameWithHonor,
    buildSenderText,
    normalizeAddressData,
    defaultDataForTemplate,
    getFieldText,
    getSampleData
  }),
  Extensions:{}
});
window.EnvelopePrintModules = EnvelopePrintModules;

/* ============================================================
   v38-21: 初期化実行は js/90_bootstrap.js の initializeApp() へ分離済み。
   ============================================================ */
