(function(global){
  'use strict';
/* ============================================================
   v38-50: Parts Actions Controller / IIFE Strict Phase11
   差出人欄・スタンプfieldの生成と、現在テンプレートへの追加操作を担当。

   契約:
   - classic script前提。ES Modulesは使わない。
   - 保存形式・保存キー・field.source名は変更しない。
   - state / save / renderFieldList / renderEnvelope / renderZipConfig は実行時参照。
   - Stage5が有効な場合のスタンプ追加委譲は従来どおり handleAddStampClick() で行う。
   ============================================================ */

  function createSenderFields(tpl){
    const w = tpl.w, h = tpl.h;
    const vertical = !(tpl.fields && tpl.fields.some(f=>f.vertical===false && ['addr','full_addr','name_honor'].includes(f.source)));
    if(vertical){
      return [
        {id:uid('f'),label:'差出人住所',x:8,y:Math.max(20,h-100),w:13,h:75,fontSize:8,vertical:true,bold:false,source:'sender_addr',anchor:'tr',autoFit:true},
        {id:uid('f'),label:'差出人名',x:23,y:Math.max(28,h-95),w:12,h:65,fontSize:9,vertical:true,bold:false,source:'sender_name',anchor:'tc',autoFit:true}
      ];
    }
    return [
      {id:uid('f'),label:'差出人まとめ',x:8,y:Math.max(5,h-30),w:Math.max(60,w-16),h:24,fontSize:8,vertical:false,bold:false,source:'sender_full',anchor:'bl',autoFit:true}
    ];
  }

  function createStampField(tpl, text){
    const w = tpl.w, h = tpl.h;
    return {id:uid('f'),label:text||'スタンプ',x:Math.max(5,w-38),y:Math.max(5,Math.round(h*0.08)),w:30,h:12,fontSize:12,vertical:false,bold:true,source:'stamp',customText:text||'親展',anchor:'mc',autoFit:true};
  }

  function refreshPartsActionUi(tpl){
    if(typeof markLayoutChanged === 'function') markLayoutChanged(tpl);
    if(typeof save === 'function') save();
    if(typeof renderFieldList === 'function') renderFieldList();
    if(typeof renderEnvelope === 'function') renderEnvelope();
    if(typeof renderZipConfig === 'function') renderZipConfig();
    const badge = typeof $ === 'function' ? $('fldBadge') : null;
    if(badge) badge.textContent = tpl.fields.length;
  }

  function addSenderBlockToCurrentTpl(){
    const t=getCurrentTpl();
    if(!t){toast('テンプレート未選択','warn');return}
    if(t.locked){toast('ロック中は追加できません','warn');return}
    const fields=createSenderFields(t);
    t.fields.push(...fields);
    refreshPartsActionUi(t);
    toast('差出人欄を追加しました','ok');
  }

  async function addStampToCurrentTpl(){
    const t=getCurrentTpl();
    if(!t){toast('テンプレート未選択','warn');return}
    if(t.locked){toast('ロック中は追加できません','warn');return}
    // v37 step42: スタンプ文字入力をブラウザ標準promptからDOM入力モーダルへ移行する。
    const text=await showAppPrompt('追加するスタンプ文字を入力してください', '親展', 'スタンプ追加', {okLabel:'追加する'});
    if(text===null) return;
    t.fields.push(createStampField(t, text.trim()||'親展'));
    refreshPartsActionUi(t);
    toast('スタンプを追加しました','ok');
  }

  async function handleAddStampClick(){
    // v37 step25: Stage5がある場合もキャプチャフェーズで本体イベントを潰さず、明示分岐でスタンプライブラリへ委譲する。
    const stage5 = global.EnvelopePrintStage5;
    if(stage5 && typeof stage5.showStampLibraryModal === 'function'){
      stage5.showStampLibraryModal();
      return;
    }
    await addStampToCurrentTpl();
  }

  const PartsActionsApi = Object.freeze({
    createSenderFields,
    createStampField,
    refreshPartsActionUi,
    addSenderBlockToCurrentTpl,
    addStampToCurrentTpl,
    handleAddStampClick
  });

  Object.assign(global, {
    createSenderFields,
    createStampField,
    refreshPartsActionUi,
    addSenderBlockToCurrentTpl,
    addStampToCurrentTpl,
    handleAddStampClick,
    EnvelopePrintPartsActions: PartsActionsApi
  });
})(typeof window !== 'undefined' ? window : globalThis);
