/* ============================================================
   Keyboard / Overlay Controller
   v38-17: ESC閉じ・キーボード微調整をcoreから分離。

   契約:
   - classic script前提。ES Modulesは使わない。
   - closeAccessibleModal / showAppConfirm 等は js/05_utilities.js 由来。
   - wizardState / closeWizard / state / getCurrentTpl 等は実行時参照。
   - このモジュールは保存形式・印刷ロジックを変更しない。
   ============================================================ */
(function(global){
  'use strict';

  async function closeTopOverlayByEscape(){
    // v37 step17: ESCキーでDOM上のモーダル/ウィザードを閉じる。ブラウザ標準confirm/alert/promptには介入しない。
    const overlays = Array.from(document.querySelectorAll('.modal-overlay'));
    const top = overlays.length ? overlays[overlays.length - 1] : null;
    // v37 step42: showAppAlert/showAppConfirm/showAppPromptはPromise解決が必要なため、ウィザードより先に既存ボタン経由で閉じる。
    if(top && top.dataset && top.dataset.appConfirm){
      const cancel = top.querySelector('[data-app-confirm-cancel]');
      if(cancel) cancel.click();
      else top.remove();
      return true;
    }
    if(top && top.dataset && top.dataset.appAlert){
      const close = top.querySelector('[data-app-alert-close]');
      if(close) close.click();
      else top.remove();
      return true;
    }
    if(top && top.dataset && top.dataset.appPrompt){
      const cancel = top.querySelector('[data-app-prompt-cancel]');
      if(cancel) cancel.click();
      else top.remove();
      return true;
    }
    if(top && top.dataset && top.dataset.legacyModal){
      closeAccessibleModal(top);
      return true;
    }
    const wizard = document.querySelector('.wizard-overlay');
    if(wizard && wizardState){
      // v37 step38: ESCでのウィザード中止確認もDOMモーダルへ移行する。
      if(await showAppConfirm('ウィザードを中止しますか？\n（未保存の調整内容は破棄されます）','ウィザードの中止',{okLabel:'中止する',danger:true})) closeWizard();
      return true;
    }
    if(!top) return false;
    const host = top.parentElement && top.parentElement.id === 'modalContainer' ? top.parentElement : null;
    if(host){ closeAccessibleModal(top); host.innerHTML = ''; }
    else closeAccessibleModal(top);
    return true;
  }

  function setupEscapeToCloseOverlays(){
    document.addEventListener('keydown', async e=>{
      if(e.key !== 'Escape') return;
      if(await closeTopOverlayByEscape()){
        e.preventDefault();
        e.stopPropagation();
      }
    });
  }

  function setupKeyboard(){
    document.addEventListener('keydown',e=>{
      const tag=(e.target.tagName||'').toLowerCase();
      if(['input','textarea','select'].includes(tag)) return;
      if(state.currentStep!==2) return;
      if(!state.selectedFieldId&&!state.selectedZoneId) return;
      if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)) return;
      const t=getCurrentTpl();if(!t||t.locked) return;
      e.preventDefault();
      let target=state.selectedFieldId
        ?t.fields.find(f=>f.id===state.selectedFieldId)
        :(t.excludeZones||[]).find(z=>z.id===state.selectedZoneId);
      if(!target) return;
      const step=e.shiftKey?5:0.5;
      const isResize=e.ctrlKey||e.metaKey;
      let dx=0,dy=0;
      if(e.key==='ArrowLeft') dx=-step;
      if(e.key==='ArrowRight') dx=step;
      if(e.key==='ArrowUp') dy=-step;
      if(e.key==='ArrowDown') dy=step;
      if(isResize){target.w=Math.max(5,target.w+dx);target.h=Math.max(5,target.h+dy)}
      else {target.x=Math.max(0,target.x+dx);target.y=Math.max(0,target.y+dy)}
      markLayoutChanged(t);renderEnvelope();renderFieldList();renderZoneList();save();
    });
  }

  Object.assign(global, {
    closeTopOverlayByEscape,
    setupEscapeToCloseOverlays,
    setupKeyboard
  });
})(typeof window !== 'undefined' ? window : globalThis);
