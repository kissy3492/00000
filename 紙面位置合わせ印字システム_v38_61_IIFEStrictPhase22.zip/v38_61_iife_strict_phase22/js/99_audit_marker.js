(function(){
  'use strict';
  /*
    Stage18 緊急棚卸し修正版
    - Stage8検証記録のsave無限再帰を解消
    - Stage8 toast種別不一致を修正
    - Stage7 CSS/JSへidを付与
    - Stage5 esc二重エスケープを修正
    - ベースバックアップへStage5/6/7/8アドオンlocalStorageを統合
    - save()をデバウンスし、キー連打時のlocalStorage連続書込を抑制
    - doPrint()をafterprint/requestAnimationFrame方式へ変更

    v38-40:
    - 退役せず、監査用の履歴コメントをIIFE + strictの無害なno-op scriptとして維持する。
  */
})();
