(function(global){
  'use strict';
/* ============================================================
   v38-40 Layout Math / Text Fit
   - Render本体から独立しやすい純粋寄り関数を分離
   - DOM描画・ドラッグ処理とは分離済み
   - v38-40でIIFE + strict + 明示export化
   ============================================================ */
const MIN_FONT_PT = 8;

/* ============================================================
   自動調整
   ============================================================ */
function overlap(a,b){return !(a.x+a.w<=b.x||b.x+b.w<=a.x||a.y+a.h<=b.y||b.y+b.h<=a.y)}
function adjustFieldRect(fld,zones,envW,envH){
  let rect={x:fld.x,y:fld.y,w:fld.w,h:fld.h};
  if(rect.x+rect.w>envW) rect.w=Math.max(5,envW-rect.x);
  if(rect.y+rect.h>envH) rect.h=Math.max(5,envH-rect.y);
  const anchor=fld.anchor||'tl';const ah=anchor[1],av=anchor[0];
  for(const z of zones){
    if(!overlap(rect,z)) continue;
    const options=[];
    if(av!=='t'&&z.y+z.h<=rect.y+rect.h){
      const newY=z.y+z.h;
      if(newY<rect.y+rect.h) options.push({score:(newY-rect.y),apply:()=>{const nh=rect.y+rect.h-newY;rect.y=newY;rect.h=nh}});
    }
    if(av!=='b'&&z.y>=rect.y){
      const nh=z.y-rect.y;
      if(nh>0&&nh<rect.h) options.push({score:(rect.h-nh),apply:()=>{rect.h=nh}});
    }
    if(ah!=='l'&&z.x+z.w<=rect.x+rect.w){
      const newX=z.x+z.w;
      if(newX<rect.x+rect.w) options.push({score:(newX-rect.x),apply:()=>{const nw=rect.x+rect.w-newX;rect.x=newX;rect.w=nw}});
    }
    if(ah!=='r'&&z.x>=rect.x){
      const nw=z.x-rect.x;
      if(nw>0&&nw<rect.w) options.push({score:(rect.w-nw),apply:()=>{rect.w=nw}});
    }
    if(options.length){options.sort((a,b)=>a.score-b.score);options[0].apply()}
  }
  return rect;
}
function approxChar(pt){return pt*25.4/72}
function estimatePrintCharUnits(ch, vertical){
  // v37 step32: fitTextの折返しは全角1文字固定ではなく、半角英数字を概算0.55字として扱う。
  if(!ch) return 0;
  if(vertical) return 1; // 縦書きは列内の字数計算を優先し、過剰詰込みを避ける。
  const code = ch.codePointAt(0);
  if(ch==='\t') return 2;
  if(/\s/.test(ch)) return 0.5;
  if(code <= 0x007F) return 0.55;
  if(code >= 0xFF61 && code <= 0xFF9F) return 0.55; // 半角カナ
  if(code >= 0x2000 && code <= 0x206F) return 0.5; // 一般句読点
  return 1;
}
function wrapTextByPrintUnits(line, maxPrintUnits, vertical){
  // v37 step14: UTF-16 code unit単位のsliceでサロゲートペアを分断しない。
  // v37 step32: 半角・全角の概算幅を考慮して、不必要な折返し/縮小を減らす。
  const units = Array.from(line == null ? '' : String(line));
  const out = [];
  const limit = Math.max(1, Number(maxPrintUnits) || 1);
  let current = '', used = 0;
  for(const ch of units){
    const w = Math.max(0.25, estimatePrintCharUnits(ch, vertical));
    if(current && used + w > limit){
      out.push(current);
      current = ch;
      used = w;
    }else{
      current += ch;
      used += w;
    }
  }
  if(current || !out.length) out.push(current);
  return out;
}
function fitText(text,fld,rect){
  if(!text) return {text:'',fontSize:fld.fontSize,fit:true};
  const vertical=fld.vertical;let size=fld.fontSize;
  const logical=String(text).split('\n');
  while(size>=MIN_FONT_PT){
    const cm=approxChar(size);const lh=cm*1.2;
    const cpl=vertical?Math.max(1,Math.floor(rect.h/cm)):Math.max(1,Math.floor(rect.w/cm));
    const maxL=vertical?Math.max(1,Math.floor(rect.w/lh)):Math.max(1,Math.floor(rect.h/lh));
    const wrapped=[];
    for(const ll of logical){
      if(!ll){wrapped.push('');continue}
      wrapped.push(...wrapTextByPrintUnits(ll,cpl,vertical));
    }
    if(wrapped.length<=maxL) return {text:wrapped.join('\n'),fontSize:size,fit:true};
    size-=0.5;
  }
  const cm=approxChar(MIN_FONT_PT);
  const cpl=vertical?Math.max(1,Math.floor(rect.h/cm)):Math.max(1,Math.floor(rect.w/cm));
  const wrapped=[];
  for(const ll of logical){
    if(!ll){wrapped.push('');continue}
    wrapped.push(...wrapTextByPrintUnits(ll,cpl,vertical));
  }
  return {text:wrapped.join('\n'),fontSize:MIN_FONT_PT,fit:false};
}


  Object.assign(global, {
    overlap,
    adjustFieldRect,
    approxChar,
    estimatePrintCharUnits,
    wrapTextByPrintUnits,
    fitText
  });
  global.EnvelopePrintLayoutMath = Object.freeze({
    overlap,
    adjustFieldRect,
    approxChar,
    estimatePrintCharUnits,
    wrapTextByPrintUnits,
    fitText
  });
})(window);
