(function(global){
  'use strict';

/* ============================================================
   v38-19: Help / Data Management UI Controller
   - showHelp(): 使い方・開発メモ・構造メモ表示
   - showDataMgmt(): バックアップ管理・手動復元・旧キー掃除UI
   - getModuleOverview(): EnvelopePrintModules.overview 用の疑似モジュール一覧

   classic script / IIFE + explicit window export.
   保存キー・保存形式・field.source名は変更しない。
   ============================================================ */

function showHelp(){
  const modal=document.createElement('div');modal.className='modal-overlay';
  modal.innerHTML=`<div class="modal-box" style="min-width:540px">
    <h3>使い方</h3>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">通常の使い方（簡単モード）</h4>
    <ol style="font-size:12px;line-height:1.8;margin-left:18px">
      <li><strong>封筒を選ぶ</strong> — お気に入りや既存テンプレートから選択、または「＋新しく作る」で初回位置合わせウィザード起動</li>
      <li><strong>宛先を入力</strong> — 新規入力／住所録／履歴／Excel貼付から</li>
      <li><strong>テスト印刷</strong> — 試し刷り＆プリンタ補正を「見たまま」入力</li>
      <li><strong>本印刷</strong> — チェックリスト確認後に一括印刷</li>
    </ol>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">初回位置合わせウィザード（8ステップ）</h4>
    <p style="font-size:12px">新規封筒では、サイズ→封筒画像→背景合わせ→郵便番号→宛名→テスト印刷→プリンタ補正→保存の順で位置合わせ。一度作れば次回からは選ぶだけです</p>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">詳細モード</h4>
    <p style="font-size:12px">フィールド追加・削除、サイズ変更、避ける範囲編集等の「テンプレートを壊す可能性のある操作」が可能です</p>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">段階6：住所整形・郵便番号辞書・縦書き表記・ラベル開始位置</h4>
    <p style="font-size:12px">詳細モードで「差出人欄セット」「スタンプ」を追加できます。さらに、はがき・ラベル・帳票追記・窓付き封筒用の用紙プリセットを追加し、ラベル面付け印刷とキューのテンプレート別分割に対応しています</p>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">住所録のExcel貼付</h4>
    <p style="font-size:12px">Excelで住所表を選択→Ctrl+C→「Excel貼付」タブのテキストエリアにCtrl+V。タブ区切りを自動解析し、列の意味を推定してプレビュー表示。確認後にまとめて取込</p>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">バックアップ</h4>
    <p style="font-size:12px">自動で3世代バックアップ。「バックアップ」ボタンから世代復元・JSONテキストコピー・貼付け復元が可能</p>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">開発メモ</h4>
    <p style="font-size:12px">step番号だけでは履歴を追い切れないため、主要な改修範囲を以下に整理しています。</p>
    <ul style="font-size:11px;line-height:1.7;margin-left:18px">${APP_RELEASE_NOTES.map(n=>`<li><strong>${escapeHtml(n.step)}</strong> — ${escapeHtml(n.summary)}</li>`).join('')}</ul>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">構造メモ</h4>
    <p style="font-size:12px">v38-5以降は分割版を本流とします。単体HTMLは必要時の派生成果物とし、通常の修正・レビュー・テストはindex.html + css/js構成を基準にします。</p>
    <ul style="font-size:11px;line-height:1.7;margin-left:18px">${APP_ARCHITECTURE_DECISION.map(n=>`<li><strong>${escapeHtml(n.topic)}</strong> — ${escapeHtml(n.decision)}。${escapeHtml(n.reason)}</li>`).join('')}</ul>
    <details style="font-size:11px;margin-top:8px"><summary>疑似モジュール索引</summary><ul style="line-height:1.7;margin-left:18px">${APP_PSEUDO_MODULE_MAP.map(m=>`<li><strong>${escapeHtml(m.name)}</strong> — ${escapeHtml(m.scope)} <span class="muted">入口: ${escapeHtml(m.entry)}</span></li>`).join('')}</ul></details>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">v38リファクタ判断</h4>
    <p style="font-size:12px">v37は機能凍結候補とし、v38は新機能追加ではなく構造整理専用フェーズとして扱います。</p>
    <ul style="font-size:11px;line-height:1.7;margin-left:18px">${APP_V38_REFACTOR_DECISION.map(n=>`<li><strong>${escapeHtml(n.topic)}</strong> — ${escapeHtml(n.decision)}。${escapeHtml(n.reason)}</li>`).join('')}</ul>
    <details style="font-size:11px;margin-top:8px"><summary>v38段階計画</summary><ol style="line-height:1.7;margin-left:18px">${APP_V38_REFACTOR_PLAN.map(p=>`<li><strong>${escapeHtml(p.phase)}</strong> — ${escapeHtml(p.scope)} / 成果: ${escapeHtml(p.output)} / 完了条件: ${escapeHtml(p.done)}</li>`).join('')}</ol></details>
    <details style="font-size:11px;margin-top:8px"><summary>v38-1 構造棚卸し・実コード対応表</summary><table><thead><tr><th>領域</th><th>責務</th><th>入口</th><th>依存</th><th>抽出難度</th></tr></thead><tbody>${APP_V38_MODULE_INVENTORY.map(m=>`<tr><td><strong>${escapeHtml(m.module)}</strong><br><span class="muted">${escapeHtml(m.marker)}</span></td><td>${escapeHtml(m.owns)}</td><td><code>${escapeHtml(m.examples)}</code><br><span class="muted">${escapeHtml(m.nextAction)}</span></td><td>${escapeHtml(m.dependsOn)}</td><td>${escapeHtml(m.extractionRisk)}</td></tr>`).join('')}</tbody></table></details>
    <details style="font-size:11px;margin-top:8px"><summary>v38リファクタのゲート条件</summary><ul style="line-height:1.7;margin-left:18px">${APP_V38_REFACTOR_GATES.map(g=>`<li><strong>${escapeHtml(g.gate)}</strong> — ${escapeHtml(g.rule)}</li>`).join('')}</ul></details>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">PDF.jsの導入（任意）</h4>
    <p style="font-size:12px"><code>pdf.min.js</code> と <code>pdf.worker.min.js</code> をこのHTMLと同フォルダに置けばPDF取込が可能。JPG/PNGなら追加不要</p>
    <div class="actions"><button class="btn primary" id="helpClose">閉じる</button></div>
  </div>`;
  document.body.appendChild(modal);
  applyLegacyModalA11y(modal,{title:'使い方', initialFocus:'#helpClose'});
  modal.querySelector('#helpClose').addEventListener('click',()=>closeAccessibleModal(modal));
  modal.addEventListener('click',e=>{if(e.target===modal) closeAccessibleModal(modal)});
}

function showDataMgmt(){
  const backups=getBackups();
  const u=getStorageUsage();
  const obsoleteEntries=getObsoleteStorageEntries();
  const obsoleteBytes=obsoleteEntries.reduce((sum,e)=>sum+(e.bytes||0),0);
  const lastSave=state.lastSavedAt?fmtDate(state.lastSavedAt):'未保存';
  const modal=document.createElement('div');modal.className='modal-overlay';
  modal.innerHTML=`<div class="modal-box" style="min-width:560px">
    <h3>バックアップ管理</h3>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;background:var(--paper-2);padding:10px;font-size:11px;margin-bottom:14px">
      <div>テンプレート：<strong>${state.templates.length}件</strong></div>
      <div>住所録：<strong>${state.addressBook.length}件</strong></div>
      <div>試行履歴：<strong>${getPrintRecordCount()}件</strong></div>
      <div>プリンタ：<strong>${state.printerProfiles.length}件</strong></div>
      <div>保存容量：<strong style="color:${u>STORAGE_WARN_BYTES?'var(--warn)':'inherit'}">${formatBytes(u)}</strong></div>
      <div>最終保存：<strong>${lastSave}</strong></div>
      <div>旧開発キー：<strong style="color:${obsoleteBytes?'var(--warn)':'inherit'}">${obsoleteEntries.length?`${obsoleteEntries.length}件 / ${formatBytes(obsoleteBytes)}`:'なし'}</strong></div>
    </div>
    ${obsoleteEntries.length?`<div style="background:#fff7ed;border:1px solid rgba(180,95,6,.28);padding:10px;margin-bottom:12px;font-size:12px">
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
        <strong>旧開発キーが残っています</strong>
        <span style="color:#666">旧 envelope_print_system 系キーは現在読まないため、容量圧迫だけが残ります。</span>
        <button class="btn sm ghost" id="dmCleanOldKeys" style="margin-left:auto;border-color:var(--warn);color:var(--warn)">旧キーを削除</button>
      </div>
      <details style="margin-top:6px"><summary>対象キーを表示</summary>
        <ul style="margin:6px 0 0 18px;line-height:1.7">${obsoleteEntries.map(e=>`<li><code>${escapeHtml(e.key)}</code> — ${formatBytes(e.bytes||0)}</li>`).join('')}</ul>
      </details>
    </div>`:''}
    <h4 class="serif" style="font-size:13px;margin:14px 0 6px">バックアップ世代（最大3世代）</h4>
    <div style="display:flex;flex-direction:column;gap:6px;font-size:12px">
      ${backups.length?backups.map((b,i)=>`
        <div style="display:flex;align-items:center;gap:8px;background:#fff;padding:8px;border:1px solid var(--line-soft)">
          <span>世代${i+1}: ${fmtDate(b.savedAt)} (テンプレ${(b.templates||[]).length}件/住所録${(b.addressBook||[]).length}件)</span>
          <span style="flex:1"></span>
          <button class="btn sm ghost" data-restore="${i}">復元</button>
        </div>`).join(''):'<div class="empty-state" style="padding:14px">バックアップなし</div>'}
    </div>
    <div style="margin-top:8px"><button class="btn sm" id="dmBackupNow">今すぐバックアップ</button></div>
    <h4 class="serif" style="font-size:13px;margin:18px 0 6px">手動バックアップ（コピーして保存）</h4>
    <p style="font-size:11px;color:#666">このテキストをコピーしてメモ帳等に保存しておけば、別ブラウザ・別PCでも復元できます</p>
    <textarea class="backup-textarea" id="dmText" readonly>${escapeHtml(JSON.stringify(dataSnapshotForBackup(),null,2))}</textarea>
    <div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap">
      <button class="btn sm" id="dmCopy">📋 全文コピー</button>
      <button class="btn sm" id="dmShowLoad">📥 テキストから復元</button>
      ${state.uiMode==='advanced'?'<button class="btn sm ghost" style="margin-left:auto;border-color:var(--warn);color:var(--warn)" id="dmReset">🗑 全データリセット</button>':''}
    </div>
    <div id="dmLoadArea" style="display:none;margin-top:10px">
      <p style="font-size:11px;color:#666">保存したテキストを貼り付けて「読込実行」（現在のデータは自動バックアップされます）</p>
      <textarea class="backup-textarea" id="dmLoadText" placeholder='{"templates":[...]}'></textarea>
      <div style="margin-top:6px"><button class="btn sm primary" id="dmDoLoad">読込実行</button></div>
    </div>
    <div class="actions"><button class="btn ghost" id="dmClose">閉じる</button></div>
  </div>`;
  document.body.appendChild(modal);
  applyLegacyModalA11y(modal,{title:'バックアップ管理', initialFocus:'#dmClose'});
  modal.querySelector('#dmClose').addEventListener('click',()=>closeAccessibleModal(modal));
  modal.addEventListener('click',e=>{if(e.target===modal) closeAccessibleModal(modal)});
  modal.querySelector('#dmBackupNow').addEventListener('click',()=>{
    if(backupNow()){closeAccessibleModal(modal);showDataMgmt();toast('バックアップしました','ok')}
  });
  const cleanOldKeysBtn=modal.querySelector('#dmCleanOldKeys');
  if(cleanOldKeysBtn) cleanOldKeysBtn.addEventListener('click',async ()=>{
    const entries=getObsoleteStorageEntries();
    const bytes=entries.reduce((sum,e)=>sum+(e.bytes||0),0);
    if(!entries.length){toast('削除対象の旧キーはありません','ok');return}
    if(!(await showAppConfirm(`旧開発キー${entries.length}件（約${formatBytes(bytes)}）を削除しますか？\n現在の保存キー paper_position_print_system_v37 系は削除しません。`,'旧開発キーの削除',{okLabel:'削除する',danger:true}))) return;
    const result=removeObsoleteStorageKeys();
    const retry=retrySaveAfterObsoleteKeyCleanup(result);
    updateStorageStatus();
    closeAccessibleModal(modal);
    showDataMgmt();
    if(result.failed.length){
      const extra = retry.attempted && !retry.ok ? '。保存再試行にも失敗しました' : (retry.attempted && retry.ok ? '。保存状態は回復しました' : '');
      toast(`旧キー${result.count}件を削除しました。一部削除失敗: ${result.failed.length}件${extra}`,'warn');
    }else if(retry.attempted && retry.ok){
      toast(`旧キー${result.count}件（約${formatBytes(result.bytes)}）を削除し、保存状態も回復しました`,'ok');
    }else if(retry.attempted && !retry.ok){
      toast(`旧キー${result.count}件（約${formatBytes(result.bytes)}）を削除しましたが、保存再試行に失敗しました`,'warn');
    }else{
      toast(`旧キー${result.count}件（約${formatBytes(result.bytes)}）を削除しました`,'ok');
    }
  });
  modal.querySelector('#dmCopy').addEventListener('click',async()=>{
    const textarea=modal.querySelector('#dmText');
    const text=textarea ? textarea.value : '';
    await copyTextToClipboard(text,{successMessage:'クリップボードにコピーしました', fallbackElement:textarea, fallbackMessage:'テキストを選択しました（Ctrl+Cでコピー）'});
  });
  modal.querySelector('#dmShowLoad').addEventListener('click',()=>{
    const area=modal.querySelector('#dmLoadArea');
    area.style.display=area.style.display==='none'?'block':'none';
  });
  modal.querySelector('#dmDoLoad').addEventListener('click',async ()=>{
    const text=modal.querySelector('#dmLoadText').value.trim();
    if(!text) return;
    try{
      const d=JSON.parse(text);
      if(!d||typeof d!=='object') throw new Error('invalid');
      // v37 step41: 復元系の高リスク確認もDOMモーダルへ移行する。
      if(!(await showAppConfirm(`復元すると現在のデータは上書きされます（自動バックアップは作成されます）。続けますか？\n\nテンプレ${(d.templates||[]).length}件 / 住所録${(d.addressBook||[]).length}件`,'バックアップJSONからの復元',{okLabel:'復元する',danger:true}))) return;
      if(!backupNow() && !(await showAppConfirm('自動バックアップに失敗しました。このまま復元を続行しますか？','自動バックアップ失敗',{okLabel:'復元を続行',danger:true}))) return;
      if(await restoreFullBackupSafely(d,'読込完了')) closeAccessibleModal(modal);
    }catch(e){toast('テキストが正しくありません','warn')}
  });
  const rb=modal.querySelector('#dmReset');
  if(rb) rb.addEventListener('click',async ()=>{
    // v37 step41: 全データ初期化確認をブラウザ標準confirmからDOMモーダルへ移行する。
    if(await showAppConfirm('全データを初期状態に戻しますか？\n（自動バックアップは作成されます）','全データリセット',{okLabel:'リセットする',danger:true})){
      if(!backupNow() && !(await showAppConfirm('自動バックアップに失敗しました。このままリセットしますか？','自動バックアップ失敗',{okLabel:'リセットを続行',danger:true}))) return;
      localStorage.removeItem(STORAGE_KEY);
      clearAddonStorage();
      transientBg={};
      state={templates:[],queue:[],addressBook:[],history:[],printAttempts:[],
        printerProfiles:[],
        selectedTplId:null,selectedFieldId:null,selectedZoneId:null,selectedPrinterId:null,
        mode:'edit',zoom:1,lastUsedTplId:null,
        currentStep:1,activeInputPane:'manual',uiMode:state.uiMode,lastSavedAt:null};
      closeAccessibleModal(modal); requestReloadAfterDataRestore('リセット完了');
    }
  });
  modal.querySelectorAll('[data-restore]').forEach(btn=>{
    btn.addEventListener('click',async ()=>{
      const idx=+btn.dataset.restore;const b=backups[idx];
      // v37 step41: 世代バックアップ復元確認をブラウザ標準confirmからDOMモーダルへ移行する。
      if(b && await showAppConfirm(`世代${idx+1}（${fmtDate(b.savedAt)}）に復元しますか？\n（現在の状態は自動バックアップされます）`,'世代バックアップの復元',{okLabel:'復元する',danger:true})){
        if(!backupNow() && !(await showAppConfirm('自動バックアップに失敗しました。このまま復元しますか？','自動バックアップ失敗',{okLabel:'復元を続行',danger:true}))) return;
        if(await restoreFullBackupSafely(b,'復元しました')) closeAccessibleModal(modal);
      }
    });
  });
}




function getModuleOverview(){
  return {
    Metadata:['APP_DISPLAY_NAME','APP_RELEASE_LABEL','APP_STORAGE_SCHEMA_VERSION','APP_MODULE_API_VERSION','STORAGE_KEY','BACKUP_KEY'],
    Architecture:['APP_RELEASE_NOTES','APP_ARCHITECTURE_DECISION','APP_PSEUDO_MODULE_MAP'],
    DataManagementUI:['EnvelopePrintDataManagementUI','showHelp','showDataMgmt','getModuleOverview'],
    Core:['uid','toast','escapeHtml','formatBytes','estimateStorageBytes','estimateDataUrlBytes'],
    Utilities:['EnvelopePrintUtilities','$','uid','toast','announceA11y','escapeHtml','formatBytes','fmtDate','showAppAlert','showAppConfirm','showAppPrompt','copyTextToClipboard','applyScreenA11y','applyLegacyModalA11y','closeAccessibleModal'],
    Storage:['dataSnapshot','save','backupNow','load','getStorageUsage'],
    StorageCore:['EnvelopePrintStorageCore','dataSnapshot','dataSnapshotForBackup','save','backupNow','restoreFullBackupSafely','load','getStorageUsage','getBackups','clearAddonStorage','removeObsoleteStorageKeys','retrySaveAfterObsoleteKeyCleanup','sanitizeSnapshotForLoad','sanitizeSnapshotForRestore'],
    Template:['ENVELOPE_SIZES','normalizeTpl','markLayoutChanged','defaultLabelConfig','getLabelConfig','labelCapacity','getEffectivePrintPageCount','buildExcludeZonesForPreset','initialTemplates','buildFieldsForPreset','buildFieldsForSize'],
    BackgroundAssets:['EnvelopePrintBackgroundAssets','BG_MAX_LONG_EDGE','BG_JPEG_QUALITY','compressImageDataUrl','loadBackgroundFileInto','fileToDataURL','loadBackgroundPDF','loadBackgroundImage','setBackgroundOnTpl'],
    RegistryCore:['FieldSourceRegistry','Step3ExtensionRegistry','Step5ExtensionRegistry','PrintExecutionRegistry','InputValidationRegistry','InputDataExtensionRegistry','SampleDataRegistry','registerBuiltinFieldSources','getFieldSourceEntries','getFieldSourceLabel','sourceOptionsHtml','registerBuiltinSampleData'],
    StepNavigation:['EnvelopePrintStepNavigation','getActiveSteps','stepIndex','renderSteps','getStepStatus','canSkipTo','canGoToStep','goToStep'],
    Step1TemplateUI:['EnvelopePrintStep1TemplateUI','bindEventsForStep1','renderStep1','handleTplCardClick','showUnadjustedGuide','duplicateTpl'],
    Step2Edit:['EnvelopePrintStep2EditUI','renderStep2','renderFieldList','renderZipConfig','renderZoneList','renderBgUI','bindEventsForStep2'],
    AddressData:['EnvelopePrintAddressData','joinLines','buildOrgText','buildOrgFullText','buildNameWithHonor','buildSenderText','normalizeAddressData','defaultDataForTemplate','getFieldText','getSampleData'],
    Data:['normalizeAddressData','buildOrgText','buildSenderText'],
    Step3Input:['EnvelopePrintStep3InputCore','renderStep3','renderInputForm','getInputData','loadAddrToInput','clearInput','switchInputPane','bindEventsForStep3'],
    Step3Queue:['EnvelopePrintStep3QueueUI','renderQueue','cloneQueueItemFromRecord','renderAddrbook','renderHistory','addToHistory','renderPasteImport','analyzePastedData','renderPastePreview','doImportPaste'],
    Step4TestPrint:['EnvelopePrintStep4TestPrintUI','renderStep4','renderPrinterProfileSection','updateStep4Summary','bindEventsForStep4'],
    Step5FinalPrint:['EnvelopePrintStep5FinalPrintUI','renderStep5','bindEventsForStep5'],
    CommonUI:['EnvelopePrintCommonUI','bindEventsForCommonUI'],
    Layout:['overlap','adjustFieldRect','approxChar','estimatePrintCharUnits','wrapTextByPrintUnits','fitText','renderEnvelopeInto','renderNormalField','renderZipField','renderLabelCellInto','buildLabelSheetStack','buildPrintStack'],
    EditCanvasController:['EnvelopePrintEditCanvasController','renderEnvelope','getMMperPxOf','getMMperPx','getDragPoint','isPrimaryDragStart','preventDragDefault','addDragDocumentListeners','removeDragDocumentListeners','attachFieldDrag','attachZoneDrag','startAddZone','startEnvelopeZoneDraft','attachEnvelopeZoneDraftHandler','getEditCanvasControllerState'],
    AdjustmentStatus:['EnvelopePrintAdjustmentStatus','getTplAdjustmentSummary'],
    Adjustment:['getTplAdjustmentSummary'],
    Wizard:['EnvelopePrintWizard','openWizard','renderWizard','wizardNext','closeWizard','commitWizardDraft'],
    Print:['addPrintAttempt','getPrintRecordCount','renderFinalChecklist','getHardPrintIssues','renderPrintActionArea','executePrint','buildPrintStack','doPrint'],
    Parts:['EnvelopePrintPartsActions','createSenderFields','createStampField','refreshPartsActionUi','addSenderBlockToCurrentTpl','addStampToCurrentTpl','handleAddStampClick'],
    Jobs:['getQueueTemplateGroups','renderJobGroupSummary','getEffectivePrintPageCount'],
    Paper:['buildFieldsForPreset','buildPostcardFields','buildLabelSheetFields','buildFormOverlayFields','defaultLabelConfig','getLabelConfig','labelCapacity','buildWindowEnvelopeFields','buildWindowDocumentFields']
  };
}


const DataManagementUiApi = Object.freeze({
  showHelp,
  showDataMgmt,
  getModuleOverview
});

Object.assign(global, {
  showHelp,
  showDataMgmt,
  getModuleOverview,
  EnvelopePrintDataManagementUI: DataManagementUiApi
});
})(typeof window !== 'undefined' ? window : globalThis);
