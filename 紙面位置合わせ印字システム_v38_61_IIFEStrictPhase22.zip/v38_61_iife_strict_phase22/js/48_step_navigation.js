(function(global){
  'use strict';

/* ============================================================
   v38-34: Step Navigation Controller
   - ステップ一覧描画、進行可否、ステップ遷移を担当する。
   - Step1/3/4/5具体UIとStep2詳細編集UIは各UIファイルへ委譲する。

   classic script / IIFE + explicit window export / Phase16 explicit API.
   保存キー・保存形式・field.source名は変更しない。
   ============================================================ */

/* ===== v38-12 extracted from 10_core.js: getActiveSteps ===== */
function getActiveSteps(){return state.uiMode==='simple'?STEPS_SIMPLE:STEPS_ADVANCED}

/* ===== v38-12 extracted from 10_core.js: stepIndex ===== */
function stepIndex(n){return getActiveSteps().findIndex(s=>s.n===n)}


/* ===== v38-12 extracted from 10_core.js: renderSteps ===== */
function renderSteps(){
  const list=$('stepList');list.innerHTML='';
  const steps=getActiveSteps();
  steps.forEach((s,i)=>{
    const el=document.createElement('div');
    const isDisabled=!canGoToStep(s.n);
    el.className='step-item'+(s.n===state.currentStep?' active':'')
      +(canSkipTo(s.n)&&stepIndex(s.n)<stepIndex(state.currentStep)?' done':'')
      +(isDisabled?' disabled':'');
    el.innerHTML=`<div class="step-num"><span>${stepIndex(s.n)+1}</span></div>
      <div class="step-title">${s.title}</div>
      <div class="step-desc">${s.desc}</div>
      <div class="step-status">${getStepStatus(s.n)}</div>`;
    if(!isDisabled) el.addEventListener('click',()=>goToStep(s.n));
    else el.addEventListener('click',()=>toast('前のステップを完了してください','warn'));
    list.appendChild(el);
    if(i<steps.length-1){const div=document.createElement('div');div.className='step-divider';list.appendChild(div)}
  });
  $('sbSummary').textContent=`テンプレ${state.templates.length} / 住所録${state.addressBook.length} / 試行履歴${getPrintRecordCount()}`;
  const pdf=window.__pdfjsAvailable;
  $('sbPdfStatus').innerHTML=pdf===undefined?''
    :(pdf?'<span style="color:var(--ok)">● PDF読込ON</span>'
         :'<span style="color:#aaa">○ PDF読込OFF（画像のみ）</span>');
  updateStorageStatus();
}

/* ===== v38-12 extracted from 10_core.js: getStepStatus ===== */
function getStepStatus(n){
  if(n===1){const t=getCurrentTpl();return t?`「${t.name.slice(0,12)}」`:'未選択'}
  if(n===2){const t=getCurrentTpl();return t?`${t.w}×${t.h}mm`:''}
  if(n===3) return state.queue.length?`${state.queue.length}件キュー`:'';
  if(n===4){const p=getCurrentPrinter();return p?`補正:${p.name.slice(0,8)}`:'未補正'}
  if(n===5) return state.queue.length?`${state.queue.length}件を印刷`:'';
  return '';
}

/* ===== v38-12 extracted from 10_core.js: canSkipTo ===== */
function canSkipTo(n){
  if(n===1) return true;
  if(n===2||n===3) return !!state.selectedTplId;
  if(n===4||n===5) return !!state.selectedTplId&&state.queue.length>0;
  return false;
}

/* ===== v38-12 extracted from 10_core.js: canGoToStep ===== */
function canGoToStep(n){
  if(state.uiMode==='simple'&&n===2) return false;
  return canSkipTo(n);
}

/* ===== v38-12 extracted from 10_core.js: goToStep ===== */
function goToStep(n){
  if(!canGoToStep(n)){toast('前のステップを完了してください','warn');return}
  state.currentStep=n;
  document.querySelectorAll('.step-content').forEach(c=>c.classList.toggle('active',+c.dataset.step===n));
  renderSteps();
  if(n===1) renderStep1();
  if(n===2) renderStep2();
  if(n===3) renderStep3();
  if(n===4) renderStep4();
  if(n===5) renderStep5();
  applyScreenA11y(document);
  document.querySelector('.main').scrollTop=0;
}


  const StepNavigationApi = Object.freeze({
    getActiveSteps,
    stepIndex,
    renderSteps,
    getStepStatus,
    canSkipTo,
    canGoToStep,
    goToStep
  });

  Object.assign(global, {
    getActiveSteps,
    stepIndex,
    renderSteps,
    getStepStatus,
    canSkipTo,
    canGoToStep,
    goToStep,
    EnvelopePrintStepNavigation: StepNavigationApi
  });
})(typeof window !== 'undefined' ? window : globalThis);
