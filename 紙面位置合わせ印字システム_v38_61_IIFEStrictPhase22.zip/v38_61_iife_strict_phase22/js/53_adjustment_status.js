(function(global){
  'use strict';
/* ============================================================
   v38-48: Adjustment Status / IIFE Strict Phase9
   テンプレートの位置合わせ・郵便番号確認・レイアウト確認・テスト印刷確認・プリンタ補正状態を判定する。

   契約:
   - classic script / IIFE + explicit window export。
   - 保存キー・保存形式・field.source名は変更しない。
   - state / getBgImage() / getPrinterCorrection() / hasAnyCorrection() は実行時参照。
   ============================================================ */

  function getTplAdjustmentSummary(tpl){
    if(!tpl) return null;
    const s = tpl.adjustmentStatus || {};
    const lc = s.lastLayoutChangedAt || 0;
    const hasBg = !!global.getBgImage(tpl);
    // bgAligned: bgAlignedAtがあり、それ以降にレイアウト変更されていない
    const bgAligned = !!(s.bgAlignedAt && s.bgAlignedAt >= lc);
    // zipChecked
    const zipChecked = !!(s.zipCheckedAt && s.zipCheckedAt >= lc);
    // layoutChecked
    const layoutChecked = !!(s.layoutCheckedAt && s.layoutCheckedAt >= lc);
    // testPrinted: 互換名。実印刷成功ではなく、testPrintedAt=テスト印刷結果をユーザが確認した時刻。
    const testPrinted = !!(s.testPrintedAt && s.testPrintedAt >= lc);
    // プリンタ補正済み（オプション）
    let printerCalibrated = false;
    const appState = global.state || {};
    if(appState.selectedPrinterId){
      const c = global.getPrinterCorrection(appState.selectedPrinterId, tpl.id);
      // 補正値が入っている or printerCheckedAtがあれば済み
      printerCalibrated = global.hasAnyCorrection(c) || !!(s.printerCheckedAt && s.printerCheckedAt >= lc);
    }
    return {bgAligned, zipChecked, layoutChecked, testPrinted, printerCalibrated, hasBg};
  }

  const AdjustmentStatusApi = Object.freeze({
    getTplAdjustmentSummary
  });

  Object.assign(global, {
    getTplAdjustmentSummary,
    EnvelopePrintAdjustmentStatus: AdjustmentStatusApi
  });
})(typeof window !== 'undefined' ? window : globalThis);
