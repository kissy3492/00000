(function(global){
  'use strict';

/* ============================================================
   v38-7 Template / Field Model
   - 用紙サイズ定義
   - テンプレート正規化
   - 標準テンプレート生成
   - field自動生成
   注意: Stage7追加kind(postcard_back/name_badge/form_receipt)は後段Stage7読込後に解決される。
   ============================================================ */

const ENVELOPE_SIZES = {
  '角形':[
    {n:'角0号',w:287,h:382,note:'B4在中'},
    {n:'角1号',w:270,h:382,note:'B4在中'},
    {n:'角2号',w:240,h:332,note:'A4在中（最頻出）',favorite:true},
    {n:'角形A4',w:228,h:312,note:'A4ぴったり'},
    {n:'角3号',w:216,h:277,note:'B5在中'},
    {n:'角4号',w:197,h:267,note:'B5在中'},
    {n:'角5号',w:190,h:240,note:'A5在中'},
    {n:'角6号',w:162,h:229,note:'A5在中'},
    {n:'角7号',w:142,h:205,note:'B6在中'},
    {n:'角8号',w:119,h:197,note:'給料袋等'}
  ],
  '長形':[
    {n:'長1号',w:142,h:332,note:'B4三つ折'},
    {n:'長2号',w:119,h:277,note:'B5二つ折'},
    {n:'長3号',w:120,h:235,note:'A4三つ折（最頻出）',favorite:true},
    {n:'長30号',w:92,h:235,note:'A4四つ折'},
    {n:'長4号',w:90,h:205,note:'B5三つ折',favorite:true},
    {n:'長40号',w:90,h:225,note:'A4四つ折'},
    {n:'長5号',w:90,h:185,note:'A5二つ折'},
    {n:'長6号',w:110,h:220,note:''},
    {n:'長8号',w:119,h:197,note:''}
  ],
  '窓付き':[
    {n:'長3号 窓付き封筒',w:120,h:235,note:'A4三つ折・窓付き封筒',favorite:true,kind:'window_envelope'},
    {n:'洋形長3号 窓付き封筒',w:235,h:120,note:'横型窓付き封筒',kind:'window_envelope'},
    {n:'A4 三つ折り窓位置確認用',w:210,h:297,note:'窓付き封筒に入れる文書側へ宛名印字',kind:'window_document'}
  ],
  '洋形':[
    {n:'洋形0号',w:235,h:120,note:'A4三つ折・横'},
    {n:'洋形1号',w:176,h:120,note:''},
    {n:'洋形2号',w:162,h:114,note:'A5二つ折'},
    {n:'洋形3号',w:148,h:98,note:'B5三つ折'},
    {n:'洋形4号',w:235,h:105,note:'A4三つ折'},
    {n:'洋形5号',w:217,h:95,note:''},
    {n:'洋形6号',w:190,h:98,note:'B5四つ折'},
    {n:'洋形7号',w:165,h:92,note:''},
    {n:'洋形長3号',w:235,h:120,note:'',favorite:true},
    {n:'洋形長4号',w:220,h:105,note:''}
  ],
  'その他':[
    {n:'はがき',w:100,h:148,note:'郵政規格',kind:'postcard'},
    {n:'往復はがき',w:200,h:148,note:'',kind:'postcard'},
    {n:'B5サイズ封筒',w:182,h:257,note:'',kind:'envelope'},
    {n:'A4サイズ封筒',w:210,h:297,note:'',kind:'envelope'}
  ],
  'はがき・カード':[
    {n:'郵便はがき 縦',w:100,h:148,note:'通常はがき・宛名面',favorite:true,kind:'postcard'},
    {n:'郵便はがき 横',w:148,h:100,note:'横向きカード',kind:'card'},
    {n:'案内カード A6',w:105,h:148,note:'A6カード・招待状',kind:'card'},
    {n:'名刺サイズカード',w:91,h:55,note:'名札・小カード',kind:'card'}
  ],
  'ラベル':[
    {n:'A4ラベル 12面',w:210,h:297,note:'12面ラベルシート（面付けは印字位置合わせ用途）',kind:'label_sheet'},
    {n:'A4ラベル 24面',w:210,h:297,note:'24面ラベルシート（面付けは次段階強化）',kind:'label_sheet'},
    {n:'単票ラベル 70×42',w:70,h:42,note:'単票ラベル・管理票',kind:'label'}
  ],
  '帳票・追記':[
    {n:'A4帳票追記',w:210,h:297,note:'既存様式に文字だけ追記',favorite:true,kind:'form_overlay'},
    {n:'B5帳票追記',w:182,h:257,note:'B5既存様式に追記',kind:'form_overlay'},
    {n:'賞状・証明書 A4横',w:297,h:210,note:'氏名・日付の中央印字',kind:'certificate'}
  ]
};

/* ============================================================
   テンプレート構造の正規化
   ============================================================ */
function normalizeTpl(t){
  if(!t.id) t.id = uid('tpl');
  if(!t.name) t.name = '無名';
  if(typeof t.w !== 'number') t.w = 240;
  if(typeof t.h !== 'number') t.h = 332;
  if(!Array.isArray(t.fields)) t.fields = [];
  if(!t.excludeZones) t.excludeZones = [];
  if(t.pinned===undefined) t.pinned = false;
  if(t.isReply===undefined) t.isReply = false;
  if(t.bgOpacity===undefined) t.bgOpacity = 0.85;
  if(t.isPreset===undefined) t.isPreset = false;
  if(t.presetNote===undefined) t.presetNote = '';
  if(t.locked===undefined) t.locked = false;
  if(t.createdAt===undefined) t.createdAt = Date.now();
  if(!t.paperKind) t.paperKind = t.kind || 'envelope';
  if(t.paperKind==='label_sheet' && !t.labelConfig) t.labelConfig = defaultLabelConfig(t.name);
  if(!t.bgAdjust) t.bgAdjust = {offsetX:0,offsetY:0,scaleX:100,scaleY:100,rotation:0};
  // 旧 verified を isPreset に移行
  if(t.verified !== undefined){
    if(t.verified && !t.isPreset) t.isPreset = true;
    delete t.verified;
  }
  // adjustmentStatus を日時ベースに正規化
  if(!t.adjustmentStatus || typeof t.adjustmentStatus !== 'object'
     || t.adjustmentStatus.bgAlignedAt === undefined){
    const old = t.adjustmentStatus || {};
    t.adjustmentStatus = {
      bgAlignedAt: old.bgAligned ? Date.now() : null,
      zipCheckedAt: old.zipChecked ? Date.now() : null,
      layoutCheckedAt: old.layoutChecked ? Date.now() : null,
      testPrintedAt: old.testInWizard ? Date.now() : null,
      printerCheckedAt: null,
      lastLayoutChangedAt: t.createdAt || Date.now()
    };
  }
  t.fields.forEach(f=>{
    if(!f.id) f.id = uid('f');
    if(!f.anchor) f.anchor = f.vertical?'tr':'tl';
    if(f.autoFit===undefined) f.autoFit = true;
    if(f.source==='zip' && !f.zipConfig){
      f.zipConfig = {showFrame:false,showMark:false,charSpacing:1.2,gapAfter3:1.5,digitOffsets:[]};
    }
  });
  return t;
}

// レイアウト変更時に呼び出す（直接state.templatesのオブジェクトに対して）
function markLayoutChanged(tpl){
  if(!tpl) return;
  if(!tpl.adjustmentStatus) tpl.adjustmentStatus = {};
  tpl.adjustmentStatus.lastLayoutChangedAt = Date.now();
}

/* ============================================================
   用紙・ラベル設定ヘルパー（段階4）
   ============================================================ */
function defaultLabelConfig(name){
  const n = String(name||'');
  if(n.includes('24')){
    return {cols:2, rows:12, marginX:14, marginY:8, gapX:0, gapY:0, labelW:91, labelH:23.4};
  }
  // 一般的なA4 12面に近い初期値。実用品は背景画像で合わせる前提。
  return {cols:2, rows:6, marginX:10, marginY:21, gapX:0, gapY:0, labelW:95, labelH:42.3};
}
function getLabelConfig(tpl){
  if(!tpl) return defaultLabelConfig('');
  if(!tpl.labelConfig) tpl.labelConfig = defaultLabelConfig(tpl.name);
  const d = defaultLabelConfig(tpl.name);
  return Object.assign({}, d, tpl.labelConfig||{});
}
function labelCapacity(tpl){
  const c=getLabelConfig(tpl);
  return Math.max(1,(parseInt(c.cols)||1)*(parseInt(c.rows)||1));
}
function getEffectivePrintPageCount(tpl, itemCount){
  if(!tpl) return 0;
  if(tpl.paperKind==='label_sheet'){
    // v37 step21: ラベル開始位置を本体のページ数計算へ統合する。
    const cap = labelCapacity(tpl);
    const start = Math.max(1, Math.min(cap, +(tpl.labelStartIndex || 1)));
    const offset = start - 1;
    return Math.ceil((offset + (itemCount||0)) / cap);
  }
  return itemCount||0;
}
function buildExcludeZonesForPreset(size){
  const kind=size&&size.kind;
  if(kind==='window_envelope'){
    const landscape = size.w > size.h;
    return [landscape
      ? {id:uid('z'),x:45,y:34,w:90,h:38,label:'窓位置（印字禁止）'}
      : {id:uid('z'),x:18,y:78,w:85,h:45,label:'窓位置（印字禁止）'}
    ];
  }
  if(kind==='window_document'){
    return [{id:uid('z'),x:20,y:85,w:95,h:45,label:'窓から見える範囲'}];
  }
  return [];
}

/* ============================================================
   標準テンプレート（位置プリセット）
   ============================================================ */
function tplKaku2(){
  return normalizeTpl({
    id:uid('tpl'),name:'角2号 標準（縦書き）',w:240,h:332,
    fields:[
      {id:uid('f'),label:'郵便番号',x:175,y:13,w:54,h:8,fontSize:13,vertical:false,bold:false,
        source:'zip',anchor:'mc',autoFit:true,
        zipConfig:{showFrame:false,showMark:false,charSpacing:1.5,gapAfter3:2,digitOffsets:[]}},
      {id:uid('f'),label:'住所',x:148,y:34,w:35,h:230,fontSize:15,vertical:true,bold:false,source:'addr',anchor:'tr',autoFit:true},
      {id:uid('f'),label:'会社・部署',x:112,y:48,w:30,h:215,fontSize:14,vertical:true,bold:false,source:'corp',anchor:'tr',autoFit:true},
      {id:uid('f'),label:'氏名',x:78,y:75,w:30,h:230,fontSize:28,vertical:true,bold:true,source:'name_honor',anchor:'tc',autoFit:true}
    ],
    excludeZones:[],pinned:true,isReply:false,bgOpacity:0.85,
    isPreset:true,presetNote:'標準位置プリセット（実封筒で要確認）'
  });
}
function tplNaga3(){
  return normalizeTpl({
    id:uid('tpl'),name:'長3号 標準（縦書き）',w:120,h:235,
    fields:[
      {id:uid('f'),label:'郵便番号',x:60,y:9,w:50,h:7,fontSize:11,vertical:false,bold:false,
        source:'zip',anchor:'mc',autoFit:true,
        zipConfig:{showFrame:false,showMark:false,charSpacing:1.2,gapAfter3:1.5,digitOffsets:[]}},
      {id:uid('f'),label:'住所',x:78,y:23,w:22,h:160,fontSize:11,vertical:true,bold:false,source:'addr',anchor:'tr',autoFit:true},
      {id:uid('f'),label:'会社・部署',x:55,y:35,w:18,h:150,fontSize:10,vertical:true,bold:false,source:'corp',anchor:'tr',autoFit:true},
      {id:uid('f'),label:'氏名',x:32,y:55,w:22,h:160,fontSize:18,vertical:true,bold:true,source:'name_honor',anchor:'tc',autoFit:true}
    ],
    excludeZones:[],pinned:true,isReply:false,bgOpacity:0.85,
    isPreset:true,presetNote:'標準位置プリセット（実封筒で要確認）'
  });
}
function tplNaga4(){
  return normalizeTpl({
    id:uid('tpl'),name:'長4号 標準（縦書き）',w:90,h:205,
    fields:[
      {id:uid('f'),label:'郵便番号',x:34,y:8,w:48,h:7,fontSize:10,vertical:false,bold:false,
        source:'zip',anchor:'mc',autoFit:true,
        zipConfig:{showFrame:false,showMark:false,charSpacing:1.0,gapAfter3:1.2,digitOffsets:[]}},
      {id:uid('f'),label:'住所',x:60,y:20,w:18,h:140,fontSize:10,vertical:true,bold:false,source:'addr',anchor:'tr',autoFit:true},
      {id:uid('f'),label:'会社・部署',x:42,y:30,w:14,h:130,fontSize:9,vertical:true,bold:false,source:'corp',anchor:'tr',autoFit:true},
      {id:uid('f'),label:'氏名',x:22,y:45,w:18,h:140,fontSize:15,vertical:true,bold:true,source:'name_honor',anchor:'tc',autoFit:true}
    ],
    excludeZones:[],pinned:true,isReply:false,bgOpacity:0.85,
    isPreset:true,presetNote:'標準位置プリセット（実封筒で要確認）'
  });
}
function tplYouNaga3(){
  return normalizeTpl({
    id:uid('tpl'),name:'洋形長3号 標準（横書き）',w:235,h:120,
    fields:[
      {id:uid('f'),label:'郵便番号',x:15,y:10,w:55,h:8,fontSize:12,vertical:false,bold:false,
        source:'zip',anchor:'ml',autoFit:true,
        zipConfig:{showFrame:false,showMark:false,charSpacing:1.2,gapAfter3:2,digitOffsets:[]}},
      {id:uid('f'),label:'住所',x:18,y:22,w:200,h:14,fontSize:11,vertical:false,bold:false,source:'addr',anchor:'tl',autoFit:true},
      {id:uid('f'),label:'会社・部署',x:18,y:42,w:200,h:8,fontSize:11,vertical:false,bold:false,source:'corp',anchor:'tl',autoFit:true},
      {id:uid('f'),label:'氏名',x:35,y:70,w:165,h:25,fontSize:20,vertical:false,bold:true,source:'name_honor',anchor:'mc',autoFit:true}
    ],
    excludeZones:[],pinned:true,isReply:false,bgOpacity:0.85,
    isPreset:true,presetNote:'標準位置プリセット（実封筒で要確認）'
  });
}
function tplReplyNaga3(){
  return normalizeTpl({
    id:uid('tpl'),name:'返信用 長3号（縦書き）',w:120,h:235,
    fields:[
      {id:uid('f'),label:'会社・部署',x:75,y:30,w:22,h:160,fontSize:14,vertical:true,bold:false,source:'corp',anchor:'tr',autoFit:true},
      {id:uid('f'),label:'氏名＋行',x:38,y:40,w:30,h:170,fontSize:24,vertical:true,bold:true,source:'name_honor',anchor:'tc',autoFit:true}
    ],
    excludeZones:[],pinned:true,isReply:true,bgOpacity:0.85,
    isPreset:true,presetNote:'標準位置プリセット（実封筒で要確認）'
  });
}
function initialTemplates(){
  return [tplKaku2(),tplNaga3(),tplNaga4(),tplYouNaga3(),tplReplyNaga3()];
}

/* ============================================================
   フィールド自動生成
   ============================================================ */
function buildFieldsForPreset(size, vertical, isReply){
  const kind = size && size.kind ? size.kind : 'envelope';
  if(isReply) return buildReplyFields(size.w,size.h,vertical);
  if(kind==='postcard') return buildPostcardFields(size.w,size.h,vertical);
  if(kind==='card') return buildCardFields(size.w,size.h,vertical);
  if(kind==='label_sheet') return buildLabelSheetFields(size.w,size.h);
  if(kind==='window_envelope') return buildWindowEnvelopeFields(size.w,size.h,vertical);
  if(kind==='window_document') return buildWindowDocumentFields(size.w,size.h);
  if(kind==='label') return buildSingleLabelFields(size.w,size.h);
  if(kind==='form_overlay') return buildFormOverlayFields(size.w,size.h);
  if(kind==='certificate') return buildCertificateFields(size.w,size.h);
  // v37 step20: Stage7追加用紙プリセットも本体関数で処理し、buildFieldsForPresetの後段ラッパーを不要にする。
  if(kind==='postcard_back') return buildPostcardBackFields(size.w,size.h);
  if(kind==='name_badge') return buildNameBadgeFields(size.w,size.h);
  if(kind==='form_receipt') return buildReceiptFields(size.w,size.h);
  return buildFieldsForSize(size.w,size.h,vertical,isReply);
}
function buildFieldsForSize(w,h,vertical,isReply){
  if(isReply) return buildReplyFields(w,h,vertical);
  if(vertical) return buildVerticalFields(w,h);
  return buildHorizontalFields(w,h);
}
function buildVerticalFields(w,h){
  const baseScale = w/240;
  const zipPt = Math.max(10,Math.round(13*Math.min(baseScale,1.2)));
  const addrPt = Math.max(10,Math.round(15*Math.min(baseScale,1.2)));
  const corpPt = Math.max(10,Math.round(14*Math.min(baseScale,1.2)));
  const namePt = Math.max(16,Math.round(26*Math.min(baseScale,1.2)));
  return [
    {id:uid('f'),label:'郵便番号',x:Math.max(0,w-64),y:12,w:Math.min(50,w-14),h:8,fontSize:zipPt,vertical:false,bold:false,
      source:'zip',anchor:'mc',autoFit:true,
      zipConfig:{showFrame:false,showMark:false,charSpacing:1.2,gapAfter3:1.5,digitOffsets:[]}},
    {id:uid('f'),label:'住所',x:Math.round(w*0.62),y:30,w:Math.max(15,Math.round(w*0.15)),h:Math.max(80,h-50),fontSize:addrPt,vertical:true,bold:false,source:'addr',anchor:'tr',autoFit:true},
    {id:uid('f'),label:'会社・部署',x:Math.round(w*0.42),y:45,w:Math.max(13,Math.round(w*0.13)),h:Math.max(80,h-65),fontSize:corpPt,vertical:true,bold:false,source:'corp',anchor:'tr',autoFit:true},
    {id:uid('f'),label:'氏名',x:Math.round(w*0.3),y:Math.round(h*0.25),w:Math.max(20,Math.round(w*0.2)),h:Math.round(h*0.6),fontSize:namePt,vertical:true,bold:true,source:'name_honor',anchor:'tc',autoFit:true}
  ];
}
function buildHorizontalFields(w,h){
  const baseScale = w/235;
  const zipPt = Math.max(10,Math.round(11*Math.min(baseScale,1.2)));
  const addrPt = Math.max(9,Math.round(11*Math.min(baseScale,1.2)));
  const corpPt = Math.max(9,Math.round(11*Math.min(baseScale,1.2)));
  const namePt = Math.max(14,Math.round(18*Math.min(baseScale,1.2)));
  return [
    {id:uid('f'),label:'郵便番号',x:12,y:8,w:Math.min(50,w-24),h:8,fontSize:zipPt,vertical:false,bold:false,
      source:'zip',anchor:'ml',autoFit:true,
      zipConfig:{showFrame:false,showMark:false,charSpacing:1.2,gapAfter3:1.5,digitOffsets:[]}},
    {id:uid('f'),label:'住所',x:14,y:20,w:Math.max(50,w-26),h:Math.min(h*0.25,18),fontSize:addrPt,vertical:false,bold:false,source:'addr',anchor:'tl',autoFit:true},
    {id:uid('f'),label:'会社・部署',x:14,y:Math.round(h*0.5),w:Math.max(50,w-26),h:8,fontSize:corpPt,vertical:false,bold:false,source:'corp',anchor:'tl',autoFit:true},
    {id:uid('f'),label:'氏名',x:Math.round(w*0.1),y:Math.round(h*0.6),w:Math.round(w*0.8),h:Math.round(h*0.25),fontSize:namePt,vertical:false,bold:true,source:'name_honor',anchor:'mc',autoFit:true}
  ];
}

function buildPostcardFields(w,h,vertical){
  if(vertical){
    return [
      {id:uid('f'),label:'郵便番号',x:43,y:8,w:48,h:7,fontSize:11,vertical:false,bold:false,source:'zip',anchor:'mc',autoFit:true,zipConfig:{showFrame:false,showMark:false,charSpacing:1.0,gapAfter3:1.2,digitOffsets:[]}},
      {id:uid('f'),label:'住所',x:63,y:25,w:18,h:85,fontSize:10,vertical:true,bold:false,source:'full_addr',anchor:'tr',autoFit:true},
      {id:uid('f'),label:'会社・部署',x:45,y:35,w:14,h:80,fontSize:9,vertical:true,bold:false,source:'org_full',anchor:'tr',autoFit:true},
      {id:uid('f'),label:'氏名',x:23,y:45,w:18,h:85,fontSize:16,vertical:true,bold:true,source:'name_honor',anchor:'tc',autoFit:true},
      {id:uid('f'),label:'差出人',x:6,y:92,w:16,h:48,fontSize:7,vertical:true,bold:false,source:'sender_full',anchor:'br',autoFit:true}
    ];
  }
  return buildHorizontalFields(w,h);
}
function buildCardFields(w,h,vertical){
  return [
    {id:uid('f'),label:'タイトル',x:10,y:8,w:w-20,h:14,fontSize:16,vertical:false,bold:true,source:'custom',customText:'タイトル',anchor:'mc',autoFit:true},
    {id:uid('f'),label:'氏名',x:10,y:h*0.42,w:w-20,h:18,fontSize:18,vertical:false,bold:true,source:'name_honor',anchor:'mc',autoFit:true},
    {id:uid('f'),label:'補足',x:10,y:h-22,w:w-20,h:12,fontSize:10,vertical:false,bold:false,source:'custom',customText:'補足文字',anchor:'mc',autoFit:true}
  ];
}
function buildLabelSheetFields(w,h){
  // ラベル1面目の中だけを設計する。印刷時に面付けエンジンが各セルへ複製する。
  return [
    {id:uid('f'),label:'ラベル 郵便番号',x:4,y:3,w:52,h:6,fontSize:8,vertical:false,bold:false,source:'zip',anchor:'ml',autoFit:true,zipConfig:{showFrame:false,showMark:false,charSpacing:1,gapAfter3:1.2,digitOffsets:[]}},
    {id:uid('f'),label:'ラベル 住所',x:4,y:10,w:82,h:12,fontSize:7.5,vertical:false,bold:false,source:'full_addr',anchor:'tl',autoFit:true},
    {id:uid('f'),label:'ラベル 会社部署',x:4,y:23,w:82,h:6,fontSize:7.5,vertical:false,bold:false,source:'org_full',anchor:'tl',autoFit:true},
    {id:uid('f'),label:'ラベル 宛名',x:4,y:30,w:82,h:10,fontSize:10,vertical:false,bold:true,source:'name_honor',anchor:'ml',autoFit:true}
  ];
}
function buildWindowEnvelopeFields(w,h,vertical){
  if(w>h){
    return [
      {id:uid('f'),label:'窓外 郵便番号',x:150,y:12,w:55,h:8,fontSize:10,vertical:false,bold:false,source:'zip',anchor:'ml',autoFit:true,zipConfig:{showFrame:false,showMark:false,charSpacing:1,gapAfter3:1.2,digitOffsets:[]}},
      {id:uid('f'),label:'窓外 スタンプ',x:178,y:30,w:38,h:14,fontSize:11,vertical:false,bold:true,source:'stamp',customText:'親展',anchor:'mc',autoFit:true},
      {id:uid('f'),label:'差出人',x:150,y:82,w:70,h:26,fontSize:8,vertical:false,bold:false,source:'sender_full',anchor:'bl',autoFit:true}
    ];
  }
  return [
    {id:uid('f'),label:'窓外 郵便番号',x:59,y:12,w:50,h:7,fontSize:10,vertical:false,bold:false,source:'zip',anchor:'mc',autoFit:true,zipConfig:{showFrame:false,showMark:false,charSpacing:1,gapAfter3:1.2,digitOffsets:[]}},
    {id:uid('f'),label:'窓外 スタンプ',x:75,y:26,w:32,h:12,fontSize:10,vertical:false,bold:true,source:'stamp',customText:'親展',anchor:'mc',autoFit:true},
    {id:uid('f'),label:'差出人',x:7,y:175,w:26,h:45,fontSize:7,vertical:true,bold:false,source:'sender_full',anchor:'br',autoFit:true}
  ];
}
function buildWindowDocumentFields(w,h){
  // A4文書側に印字して、窓付き封筒から見える位置に宛名を置くための初期配置。
  return [
    {id:uid('f'),label:'窓内 郵便番号',x:25,y:90,w:55,h:8,fontSize:10,vertical:false,bold:false,source:'zip',anchor:'ml',autoFit:true,zipConfig:{showFrame:false,showMark:false,charSpacing:1,gapAfter3:1.2,digitOffsets:[]}},
    {id:uid('f'),label:'窓内 住所',x:25,y:101,w:90,h:12,fontSize:9,vertical:false,bold:false,source:'full_addr',anchor:'tl',autoFit:true},
    {id:uid('f'),label:'窓内 会社部署',x:25,y:116,w:90,h:8,fontSize:9,vertical:false,bold:false,source:'org_full',anchor:'tl',autoFit:true},
    {id:uid('f'),label:'窓内 宛名',x:30,y:127,w:80,h:11,fontSize:12,vertical:false,bold:true,source:'name_honor',anchor:'ml',autoFit:true}
  ];
}
function buildSingleLabelFields(w,h){
  return [
    {id:uid('f'),label:'コード/番号',x:4,y:3,w:w-8,h:7,fontSize:8,vertical:false,bold:false,source:'custom',customText:'管理番号',anchor:'tl',autoFit:true},
    {id:uid('f'),label:'名称',x:4,y:12,w:w-8,h:12,fontSize:11,vertical:false,bold:true,source:'name',anchor:'ml',autoFit:true},
    {id:uid('f'),label:'備考',x:4,y:28,w:w-8,h:10,fontSize:8,vertical:false,bold:false,source:'custom',customText:'備考',anchor:'tl',autoFit:true}
  ];
}
function buildFormOverlayFields(w,h){
  return [
    {id:uid('f'),label:'受付番号',x:25,y:22,w:45,h:8,fontSize:10,vertical:false,bold:false,source:'custom',customText:'受付番号',anchor:'ml',autoFit:true},
    {id:uid('f'),label:'日付',x:w-70,y:22,w:45,h:8,fontSize:10,vertical:false,bold:false,source:'custom',customText:'令和　年　月　日',anchor:'ml',autoFit:true},
    {id:uid('f'),label:'氏名',x:50,y:70,w:100,h:12,fontSize:12,vertical:false,bold:true,source:'name',anchor:'ml',autoFit:true},
    {id:uid('f'),label:'備考',x:30,y:h-55,w:w-60,h:20,fontSize:9,vertical:false,bold:false,source:'custom',customText:'追記欄',anchor:'tl',autoFit:true}
  ];
}
function buildCertificateFields(w,h){
  return [
    {id:uid('f'),label:'証書タイトル',x:30,y:28,w:w-60,h:18,fontSize:22,vertical:false,bold:true,source:'custom',customText:'証　書',anchor:'mc',autoFit:true},
    {id:uid('f'),label:'氏名',x:45,y:80,w:w-90,h:22,fontSize:24,vertical:false,bold:true,source:'name_honor',anchor:'mc',autoFit:true},
    {id:uid('f'),label:'本文',x:45,y:115,w:w-90,h:40,fontSize:12,vertical:false,bold:false,source:'custom',customText:'上記の者であることを証明します。',anchor:'mc',autoFit:true},
    {id:uid('f'),label:'発行者',x:w-95,y:h-45,w:75,h:18,fontSize:11,vertical:false,bold:false,source:'sender_full',anchor:'ml',autoFit:true}
  ];
}

function buildReplyFields(w,h,vertical){
  const baseScale = vertical?w/240:w/235;
  if(vertical){
    return [
      {id:uid('f'),label:'会社・部署',x:Math.round(w*0.55),y:Math.round(h*0.15),w:Math.round(w*0.15),h:Math.round(h*0.5),
        fontSize:Math.max(12,Math.round(16*Math.min(baseScale,1.2))),vertical:true,bold:false,source:'corp',anchor:'tr',autoFit:true},
      {id:uid('f'),label:'氏名＋行',x:Math.round(w*0.25),y:Math.round(h*0.2),w:Math.round(w*0.25),h:Math.round(h*0.65),
        fontSize:Math.max(20,Math.round(32*Math.min(baseScale,1.2))),vertical:true,bold:true,source:'name_honor',anchor:'tc',autoFit:true}
    ];
  } else {
    return [
      {id:uid('f'),label:'会社・部署',x:Math.round(w*0.1),y:Math.round(h*0.3),w:Math.round(w*0.8),h:Math.round(h*0.15),
        fontSize:Math.max(10,Math.round(13*Math.min(baseScale,1.2))),vertical:false,bold:false,source:'corp',anchor:'mc',autoFit:true},
      {id:uid('f'),label:'氏名＋行',x:Math.round(w*0.1),y:Math.round(h*0.5),w:Math.round(w*0.8),h:Math.round(h*0.3),
        fontSize:Math.max(16,Math.round(22*Math.min(baseScale,1.2))),vertical:false,bold:true,source:'name_honor',anchor:'mc',autoFit:true}
    ];
  }
}



  const TemplateModelApi = Object.freeze({
    ENVELOPE_SIZES,
    normalizeTpl,
    markLayoutChanged,
    defaultLabelConfig,
    getLabelConfig,
    labelCapacity,
    getEffectivePrintPageCount,
    buildExcludeZonesForPreset,
    tplKaku2,
    tplNaga3,
    tplNaga4,
    tplYouNaga3,
    tplReplyNaga3,
    initialTemplates,
    buildFieldsForPreset,
    buildFieldsForSize,
    buildVerticalFields,
    buildHorizontalFields,
    buildPostcardFields,
    buildCardFields,
    buildLabelSheetFields,
    buildWindowEnvelopeFields,
    buildWindowDocumentFields,
    buildSingleLabelFields,
    buildFormOverlayFields,
    buildCertificateFields,
    buildReplyFields
  });
  Object.assign(global, {
    ENVELOPE_SIZES,
    normalizeTpl,
    markLayoutChanged,
    defaultLabelConfig,
    getLabelConfig,
    labelCapacity,
    getEffectivePrintPageCount,
    buildExcludeZonesForPreset,
    tplKaku2,
    tplNaga3,
    tplNaga4,
    tplYouNaga3,
    tplReplyNaga3,
    initialTemplates,
    buildFieldsForPreset,
    buildFieldsForSize,
    buildVerticalFields,
    buildHorizontalFields,
    buildPostcardFields,
    buildCardFields,
    buildLabelSheetFields,
    buildWindowEnvelopeFields,
    buildWindowDocumentFields,
    buildSingleLabelFields,
    buildFormOverlayFields,
    buildCertificateFields,
    buildReplyFields
  });
  global.EnvelopePrintTemplateModel = TemplateModelApi;
})(typeof window !== 'undefined' ? window : globalThis);
