(function(global){
  'use strict';

/* ============================================================
   v38-35: Step2 Edit UI Controller
   Step2詳細編集画面、field一覧、郵便番号詳細、避ける範囲一覧、背景UIを担当。

   契約:
   - classic script / IIFE + explicit window export。ES Modulesは使わない。
   - 保存キー・保存形式・field.source名は変更しない。
   - renderEnvelope / markLayoutChanged / save / getCurrentTpl 等は実行時参照。
   - ステップ進行は js/48_step_navigation.js、Step1/3/4/5具体UIは各Step専用ファイルが担当する。
   ============================================================ */
/* ============================================================
   v38-12: Step / UI Controller
   目的：ステップ進行、各Step描画、入力/一覧/貼付取込UIをcoreから分離する。
   注意：イベント束ね(bindEvents)とドラッグ/ウィザード本体は依存が強いためcore側に残す。
   ============================================================ */

/* ============================================================
   v38-34: ステップ進行・サイドバー描画は js/48_step_navigation.js へ分離済み。
   ============================================================ */

/* ============================================================
   v38-26: Step1テンプレート選択UIは js/48_step1_template_ui.js へ分離済み。
   ============================================================ */


/* ============================================================
   封筒レンダリング（汎用）
   印刷時：print-layer に補正を適用
   編集時：補正なし
   ============================================================ */



/* ===== v38-12 extracted from 10_core.js: renderStep2 ===== */
function renderStep2(){
  const t=getCurrentTpl();if(!t){goToStep(1);return}
  $('step2Title').textContent=`「${t.name}」の詳細編集`;
  $('basicBadge').textContent=`${t.w}×${t.h}mm`;
  $('fldBadge').textContent=t.fields.length;
  $('zoneBadge').textContent=(t.excludeZones||[]).length;
  const bg=getBgImage(t);
  $('bgBadge').textContent=bg?'取込済':'未取込';
  $('tName').value=t.name;$('tW').value=t.w;$('tH').value=t.h;
  $('tIsReply').checked=!!t.isReply;
  $('tLocked').checked=!!t.locked;
  $('bgOpacity').value=Math.round((t.bgOpacity??0.85)*100);
  $('bgOpacityVal').textContent=$('bgOpacity').value+'%';
  $('replyBanner').style.display=t.isReply?'flex':'none';
  $('lockBanner').style.display=t.locked?'flex':'none';
  $('pdfNotice').textContent=window.__pdfjsAvailable
    ?'PDF取込が利用できます'
    :'PDF取込を使うには pdf.min.js と pdf.worker.min.js を同フォルダに置いてください';
  const ba=t.bgAdjust||{offsetX:0,offsetY:0,scaleX:100,scaleY:100,rotation:0};
  $('bgOffX').value=ba.offsetX;
  $('bgOffY').value=ba.offsetY;
  $('bgScaleX').value=ba.scaleX;
  $('bgScaleY').value=ba.scaleY;
  $('bgRotation').value=ba.rotation||0;
  $('bgSizeInfo').textContent=bg?`画像容量: ${formatBytes(bg.bytes||0)}${t.bgPersist?' / 保存中':' / 一時'}`:'';
  renderBgUI();renderFieldList();renderZoneList();renderZipConfig();renderEnvelope();
}


/* ===== v38-12 extracted from 10_core.js: renderFieldList ===== */
function renderFieldList(){
  const t=getCurrentTpl();if(!t) return;
  const list=$('fieldList');list.innerHTML='';
  if(t.locked){
    list.innerHTML='<div class="empty-state" style="padding:14px">🔒 ロック中：上部の「ロックを解除して編集」から解除してください</div>';
    return;
  }
  t.fields.forEach(f=>{
    const el=document.createElement('details');
    el.className='field-mini';el.open=f.id===state.selectedFieldId;
    el.innerHTML=`<summary class="ttl" style="cursor:pointer;list-style:none">
      <span>${escapeHtml(f.label)}</span>
      <span class="pill" style="margin-left:auto">${escapeHtml(getFieldSourceLabel(f.source))}</span>
      <button class="del" data-fid="${f.id}" style="background:none;border:none;cursor:pointer;font-size:14px;color:#888">×</button>
    </summary>
    <div style="margin-top:8px">
      <div class="row r4">
        <div><label>左から</label><input type="number" step="0.5" data-fid="${f.id}" data-k="x" value="${f.x}" style="font-size:11px;padding:4px"></div>
        <div><label>上から</label><input type="number" step="0.5" data-fid="${f.id}" data-k="y" value="${f.y}" style="font-size:11px;padding:4px"></div>
        <div><label>幅</label><input type="number" step="0.5" data-fid="${f.id}" data-k="w" value="${f.w}" style="font-size:11px;padding:4px"></div>
        <div><label>高さ</label><input type="number" step="0.5" data-fid="${f.id}" data-k="h" value="${f.h}" style="font-size:11px;padding:4px"></div>
      </div>
      <div class="row r3">
        <div><label>文字大きさ(pt)</label><input type="number" step="0.5" data-fid="${f.id}" data-k="fontSize" value="${f.fontSize}" style="font-size:11px;padding:4px"></div>
        <div><label>方向</label><select data-fid="${f.id}" data-k="vertical" style="font-size:11px;padding:4px"><option value="false"${!f.vertical?' selected':''}>横書き</option><option value="true"${f.vertical?' selected':''}>縦書き</option></select></div>
        <div><label>項目種類</label><select data-fid="${f.id}" data-k="source" style="font-size:11px;padding:4px">
          ${sourceOptionsHtml(f.source)}
        </select></div>
      </div>
      <div class="row r2">
        <div><label>表示名</label><input type="text" data-fid="${f.id}" data-k="label" value="${escapeHtml(f.label)}" style="font-size:11px;padding:4px"></div>
        <div><label>位置揃え</label><div class="anchor-grid" data-fid="${f.id}">${ANCHOR_KEYS.map(k=>`<button data-anchor="${k}" class="${f.anchor===k?'active':''}" title="${ANCHOR_LABELS[k]}"></button>`).join('')}</div></div>
      </div>
      <div style="display:flex;gap:10px;margin-top:6px">
        <label class="checkbox-row"><input type="checkbox" data-fid="${f.id}" data-k="bold" ${f.bold?'checked':''}> 太字</label>
        <label class="checkbox-row"><input type="checkbox" data-fid="${f.id}" data-k="autoFit" ${f.autoFit?'checked':''}> 自動調整</label>
      </div>
      ${['custom','stamp'].includes(f.source)?`<div class="row" style="margin-top:6px"><label>${f.source==='stamp'?'スタンプ文字':'固定テキスト'}</label><input type="text" data-fid="${f.id}" data-k="customText" value="${escapeHtml(f.customText||'')}" style="font-size:11px;padding:4px" list="stampPresetList"></div>`:''}
    </div>`;
    list.appendChild(el);
  });
  list.querySelectorAll('input,select').forEach(inp=>{
    inp.addEventListener('input',e=>{
      const fid=e.target.dataset.fid;if(!fid) return;
      const k=e.target.dataset.k;if(!k) return;
      const fld=t.fields.find(x=>x.id===fid);if(!fld) return;
      let v=e.target.value;
      if(['x','y','w','h','fontSize'].includes(k)) v=parseFloat(v)||0;
      if(k==='vertical') v=v==='true';
      if(['bold','autoFit'].includes(k)) v=e.target.checked;
      fld[k]=v;
      if(k==='source'&&v==='zip'&&!fld.zipConfig){
        fld.zipConfig={showFrame:false,showMark:false,charSpacing:1.2,gapAfter3:1.5,digitOffsets:[]};
      }
      if(k==='source'&&v==='stamp'&&!fld.customText){
        fld.customText='親展';
      }
      markLayoutChanged(t);renderEnvelope();save();renderZipConfig();
    });
  });
  list.querySelectorAll('.anchor-grid button').forEach(btn=>{
    btn.addEventListener('click',e=>{
      e.preventDefault();
      const fid=btn.parentElement.dataset.fid;
      const fld=t.fields.find(x=>x.id===fid);if(!fld) return;
      fld.anchor=btn.dataset.anchor;
      btn.parentElement.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b===btn));
      markLayoutChanged(t);renderEnvelope();save();
    });
  });
  list.querySelectorAll('.del').forEach(btn=>{
    btn.addEventListener('click',async e=>{
      e.stopPropagation();e.preventDefault();
      // v37 step37: フィールド削除確認をブラウザ標準confirmからDOMモーダルへ移行する。
      if(!await showAppConfirm('このフィールドを削除しますか？','フィールドの削除',{okLabel:'削除する',danger:true})) return;
      const fid=btn.dataset.fid;
      t.fields=t.fields.filter(f=>f.id!==fid);
      markLayoutChanged(t);save();renderFieldList();renderEnvelope();renderZipConfig();
      $('fldBadge').textContent=t.fields.length;
    });
  });
  applyScreenA11y(list);
}


/* ===== v38-12 extracted from 10_core.js: renderZipConfig ===== */
function renderZipConfig(){
  const t=getCurrentTpl();if(!t) return;
  const zipFields=t.fields.filter(f=>f.source==='zip');
  const body=$('zipConfigBody');
  if(!zipFields.length){
    body.innerHTML='<div class="empty-state" style="padding:14px">郵便番号フィールドがあると詳細設定が表示されます</div>';
    $('zipBadge').textContent='—';return;
  }
  $('zipBadge').textContent=`${zipFields.length}件`;
  body.innerHTML='';
  if(t.locked){
    body.innerHTML='<div class="empty-state" style="padding:14px">🔒 ロック中</div>';
    return;
  }
  zipFields.forEach((f,idx)=>{
    if(!f.zipConfig) f.zipConfig={showFrame:false,showMark:false,charSpacing:1.2,gapAfter3:1.5,digitOffsets:[]};
    const zc=f.zipConfig;
    if(!Array.isArray(zc.digitOffsets)) zc.digitOffsets=[];
    while(zc.digitOffsets.length<7) zc.digitOffsets.push({x:0,y:0});
    const wrap=document.createElement('div');
    wrap.className='field-mini';
    wrap.innerHTML=`<div class="ttl"><span>${escapeHtml(f.label)}（${idx+1}）</span></div>
      <div style="display:flex;gap:10px;margin-bottom:6px;flex-wrap:wrap">
        <label class="checkbox-row"><input type="checkbox" data-zk="showMark" data-fid="${f.id}" ${zc.showMark?'checked':''}> 〒記号を表示</label>
        <label class="checkbox-row"><input type="checkbox" data-zk="showFrame" data-fid="${f.id}" ${zc.showFrame?'checked':''}> 枠線を表示</label>
      </div>
      <div class="row r2">
        <div><label>文字間隔(mm)</label><input type="number" step="0.1" data-zk="charSpacing" data-fid="${f.id}" value="${zc.charSpacing}" style="font-size:11px;padding:4px"></div>
        <div><label>3桁目後の隙間(mm)</label><input type="number" step="0.1" data-zk="gapAfter3" data-fid="${f.id}" value="${zc.gapAfter3}" style="font-size:11px;padding:4px"></div>
      </div>
      <details style="margin-top:8px">
        <summary style="cursor:pointer;font-size:11px;font-weight:600">▸ 1桁ごとの個別位置調整</summary>
        <div class="zip-digit-table">
          <div></div>
          ${Array.from({length:7},(_,i)=>`<div class="hdr">${i+1}桁</div>`).join('')}
          <div class="hdr">右</div>
          ${Array.from({length:7},(_,i)=>`<div><input type="number" step="0.1" data-zk="digitX" data-fid="${f.id}" data-idx="${i}" value="${zc.digitOffsets[i].x}"></div>`).join('')}
          <div class="hdr">下</div>
          ${Array.from({length:7},(_,i)=>`<div><input type="number" step="0.1" data-zk="digitY" data-fid="${f.id}" data-idx="${i}" value="${zc.digitOffsets[i].y}"></div>`).join('')}
        </div>
      </details>`;
    body.appendChild(wrap);
  });
  body.querySelectorAll('input').forEach(inp=>{
    inp.addEventListener('input',e=>{
      const fid=e.target.dataset.fid;
      const fld=t.fields.find(x=>x.id===fid);if(!fld) return;
      const k=e.target.dataset.zk;const zc=fld.zipConfig;
      if(k==='showMark'||k==='showFrame') zc[k]=e.target.checked;
      else if(k==='charSpacing'||k==='gapAfter3') zc[k]=parseFloat(e.target.value)||0;
      else if(k==='digitX'||k==='digitY'){
        const idx=+e.target.dataset.idx;
        if(!zc.digitOffsets[idx]) zc.digitOffsets[idx]={x:0,y:0};
        zc.digitOffsets[idx][k==='digitX'?'x':'y']=parseFloat(e.target.value)||0;
      }
      markLayoutChanged(t);renderEnvelope();save();
    });
  });
}


/* ===== v38-12 extracted from 10_core.js: renderZoneList ===== */
function renderZoneList(){
  const t=getCurrentTpl();if(!t) return;
  const list=$('zoneList');list.innerHTML='';
  if(t.locked){
    list.innerHTML='<div class="empty-state" style="padding:14px">🔒 ロック中</div>';
    return;
  }
  (t.excludeZones||[]).forEach((z,idx)=>{
    const el=document.createElement('div');
    el.className='field-mini';el.style.borderLeft='3px solid var(--warn)';
    el.innerHTML=`<div class="ttl">
      <span style="color:var(--warn)">▣</span><span>避ける範囲 ${idx+1}</span>
      <input type="text" data-zid="${z.id}" data-k="label" value="${escapeHtml(z.label||'')}" placeholder="メモ（任意）" style="flex:1;margin-left:6px;padding:3px 6px;font-size:11px">
      <button class="del" data-zid="${z.id}" style="background:none;border:none;cursor:pointer;font-size:14px;color:#888">×</button>
    </div>
    <div class="row r4">
      <div><label>左から</label><input type="number" step="0.5" data-zid="${z.id}" data-k="x" value="${z.x}" style="font-size:11px;padding:4px"></div>
      <div><label>上から</label><input type="number" step="0.5" data-zid="${z.id}" data-k="y" value="${z.y}" style="font-size:11px;padding:4px"></div>
      <div><label>幅</label><input type="number" step="0.5" data-zid="${z.id}" data-k="w" value="${z.w}" style="font-size:11px;padding:4px"></div>
      <div><label>高さ</label><input type="number" step="0.5" data-zid="${z.id}" data-k="h" value="${z.h}" style="font-size:11px;padding:4px"></div>
    </div>`;
    list.appendChild(el);
  });
  list.querySelectorAll('input').forEach(inp=>{
    inp.addEventListener('input',e=>{
      const z=(t.excludeZones||[]).find(x=>x.id===e.target.dataset.zid);if(!z) return;
      const k=e.target.dataset.k;let v=e.target.value;
      if(['x','y','w','h'].includes(k)) v=parseFloat(v)||0;
      z[k]=v;markLayoutChanged(t);save();renderEnvelope();
    });
  });
  list.querySelectorAll('.del').forEach(btn=>{
    btn.addEventListener('click',async e=>{
      e.stopPropagation();
      // v37 step37: 避ける範囲削除確認をブラウザ標準confirmからDOMモーダルへ移行する。
      if(!await showAppConfirm('この避ける範囲を削除しますか？','避ける範囲の削除',{okLabel:'削除する',danger:true})) return;
      const zid=btn.dataset.zid;
      t.excludeZones=(t.excludeZones||[]).filter(z=>z.id!==zid);
      if(state.selectedZoneId===zid) state.selectedZoneId=null;
      markLayoutChanged(t);save();renderZoneList();renderEnvelope();
      $('zoneBadge').textContent=(t.excludeZones||[]).length;
    });
  });
}


/* ===== v38-12 extracted from 10_core.js: renderBgUI ===== */
function renderBgUI(){
  const t=getCurrentTpl();if(!t) return;
  const bg=getBgImage(t);
  if(bg){
    $('bgDot').classList.add('on');
    $('bgInfo').textContent=`取込済（${escapeHtml(bg.name||'画像')}）${t.bgPersist?' [保存中]':' [一時]'}`;
    $('bgBadge').textContent='取込済';
  } else {
    $('bgDot').classList.remove('on');
    $('bgInfo').textContent='画像/PDFを取り込んで位置合わせ';
    $('bgBadge').textContent='未取込';
  }
  $('bgPersist').checked=!!t.bgPersist;
}


/* ===== v38-36: Step2 fixed event binder ===== */
function bindEventsForStep2(){
  $('btnReWizard').addEventListener('click',()=>{
    if(getCurrentTpl()) openWizard(getCurrentTpl(),'edit');
  });
  $('btnUnlock').addEventListener('click',async ()=>{
    const t=getCurrentTpl();if(!t||!t.locked) return;
    // v37 step38: 詳細編集のロック解除確認をDOMモーダルへ移行する。
    if(await showAppConfirm(`「${t.name}」のロックを解除して編集可能にしますか？`,'ロック解除の確認',{okLabel:'解除する'})){
      t.locked=false;save();renderStep2();
    }
  });
  $('step2Back').addEventListener('click',()=>goToStep(1));
  $('step2Next').addEventListener('click',()=>goToStep(3));
  $('tName').addEventListener('input',e=>{const t=getCurrentTpl();if(!t||t.locked) return;t.name=e.target.value;$('step2Title').textContent=`「${t.name}」の詳細編集`;save();renderSteps()});
  $('tW').addEventListener('input',e=>{const t=getCurrentTpl();if(!t||t.locked) return;t.w=parseFloat(e.target.value)||0;$('basicBadge').textContent=`${t.w}×${t.h}mm`;markLayoutChanged(t);save();renderEnvelope()});
  $('tH').addEventListener('input',e=>{const t=getCurrentTpl();if(!t||t.locked) return;t.h=parseFloat(e.target.value)||0;$('basicBadge').textContent=`${t.w}×${t.h}mm`;markLayoutChanged(t);save();renderEnvelope()});
  $('tIsReply').addEventListener('change',async e=>{
    const t=getCurrentTpl();if(!t||t.locked) return;
    const wasReply=!!t.isReply;t.isReply=e.target.checked;
    $('replyBanner').style.display=t.isReply?'flex':'none';
    if(wasReply!==t.isReply){
      // v37 step38: 標準レイアウト再生成確認をDOMモーダルへ移行する。
      if(await showAppConfirm(`フィールドを${t.isReply?'返信用':'通常'}の標準レイアウトに再生成しますか？`,'標準レイアウト再生成',{okLabel:'再生成する',danger:true})){
        const isV=t.fields[0]?t.fields[0].vertical:true;
        t.fields=buildFieldsForSize(t.w,t.h,isV,t.isReply);
      }
    }
    markLayoutChanged(t);save();renderStep2();
  });
  $('tLocked').addEventListener('change',e=>{
    const t=getCurrentTpl();if(!t) return;
    t.locked=e.target.checked;save();renderStep2();
  });
  $('btnAddField').addEventListener('click',()=>{
    const t=getCurrentTpl();if(!t||t.locked) return;
    t.fields.push({id:uid('f'),label:'新規',x:20,y:20,w:80,h:20,fontSize:14,vertical:false,bold:false,source:'custom',customText:'サンプル',anchor:'tl',autoFit:true});
    markLayoutChanged(t);save();renderFieldList();renderEnvelope();
    $('fldBadge').textContent=t.fields.length;
  });
  $('btnAddSenderBlock').addEventListener('click',addSenderBlockToCurrentTpl);
  $('btnAddStamp').addEventListener('click',handleAddStampClick);
  $('btnAddZone').addEventListener('click',startAddZone);
  $('btnLoadBg').addEventListener('click',()=>$('fileBg').click());
  $('fileBg').addEventListener('change',async e=>{
    const f=e.target.files[0];if(f){
      await loadBackgroundFileInto(f, getCurrentTpl(), {onLoaded:()=>{renderBgUI();renderEnvelope();renderStep2()}});
    }
    e.target.value='';
  });
  $('btnClearBg').addEventListener('click',()=>{
    const t=getCurrentTpl();if(!t) return;
    delete t.bgImage;delete t.bgSourceName;delete t.bgBytes;delete transientBg[t.id];
    markLayoutChanged(t);save();renderBgUI();renderEnvelope();renderStep2();
  });
  $('bgPersist').addEventListener('change',e=>{
    const t=getCurrentTpl();if(!t) return;
    t.bgPersist=e.target.checked;
    if(t.bgPersist&&transientBg[t.id]){t.bgImage=transientBg[t.id].dataUrl;t.bgSourceName=transientBg[t.id].name;t.bgBytes=transientBg[t.id].bytes;delete transientBg[t.id]}
    if(!t.bgPersist&&t.bgImage){transientBg[t.id]={dataUrl:t.bgImage,name:t.bgSourceName,bytes:t.bgBytes};delete t.bgImage;delete t.bgSourceName;delete t.bgBytes}
    save();renderBgUI();
  });
  $('bgOpacity').addEventListener('input',e=>{
    const t=getCurrentTpl();if(!t) return;
    t.bgOpacity=e.target.value/100;
    $('bgOpacityVal').textContent=e.target.value+'%';
    save();renderEnvelope();
  });
  ['bgOffX','bgOffY','bgScaleX','bgScaleY','bgRotation'].forEach(id=>{
    $(id).addEventListener('input',e=>{
      const t=getCurrentTpl();if(!t) return;
      if(!t.bgAdjust) t.bgAdjust={offsetX:0,offsetY:0,scaleX:100,scaleY:100,rotation:0};
      const v=parseFloat(e.target.value)||0;
      if(id==='bgOffX') t.bgAdjust.offsetX=v;
      if(id==='bgOffY') t.bgAdjust.offsetY=v;
      if(id==='bgScaleX') t.bgAdjust.scaleX=v;
      if(id==='bgScaleY') t.bgAdjust.scaleY=v;
      if(id==='bgRotation') t.bgAdjust.rotation=v;
      save();renderEnvelope();
    });
  });
  $('btnBgReset').addEventListener('click',()=>{
    const t=getCurrentTpl();if(!t) return;
    t.bgAdjust={offsetX:0,offsetY:0,scaleX:100,scaleY:100,rotation:0};
    save();renderStep2();
  });
  document.querySelectorAll('.mode-toggle button').forEach(b=>{
    b.addEventListener('click',()=>{
      document.querySelectorAll('.mode-toggle button').forEach(x=>x.classList.remove('active'));
      b.classList.add('active');
      state.mode=b.dataset.mode;
      if(state.mode==='preview'){state.selectedFieldId=null;state.selectedZoneId=null}
      renderEnvelope();
    });
  });
  $('btnZoomIn').addEventListener('click',()=>{state.zoom=Math.min(2,state.zoom+0.1);$('zoomLabel').textContent=Math.round(state.zoom*100)+'%';renderEnvelope()});
  $('btnZoomOut').addEventListener('click',()=>{state.zoom=Math.max(0.3,state.zoom-0.1);$('zoomLabel').textContent=Math.round(state.zoom*100)+'%';renderEnvelope()});
  $('envelope').addEventListener('click',e=>{
    if(e.target.id==='envelope'){state.selectedFieldId=null;state.selectedZoneId=null;renderEnvelope()}
  });
  attachEnvelopeZoneDraftHandler($('envelope'));
}


const Step2EditUiApi = Object.freeze({
  renderStep2,
  renderFieldList,
  renderZipConfig,
  renderZoneList,
  renderBgUI,
  bindEventsForStep2
});

Object.assign(global, {
  renderStep2,
  renderFieldList,
  renderZipConfig,
  renderZoneList,
  renderBgUI,
  bindEventsForStep2,
  EnvelopePrintStep2EditUI: Step2EditUiApi
});
})(typeof window !== 'undefined' ? window : globalThis);
