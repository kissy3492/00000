(function(global){
  'use strict';

/* ============================================================
   v38-18: Background Assets Controller
   背景画像/PDF取込、画像圧縮、テンプレートへの背景反映を担当。

   契約:
   - classic script前提。ES Modulesは使わない。
   - 保存形式・保存キー・field.source名は変更しない。
   - state / transientBg / save / markLayoutChanged は実行時参照。
   - PDF読込は従来どおり pdf.min.js / pdf.worker.min.js がある場合だけ有効。
   ============================================================ */
  const BG_MAX_LONG_EDGE = 1600;
  const BG_JPEG_QUALITY = 0.8;

  async function compressImageDataUrl(srcUrl, maxEdge, quality){
    return new Promise((resolve, reject)=>{
      const img = new Image();
      img.onload = ()=>{
        let {width, height} = img;
        if(width > maxEdge || height > maxEdge){
          if(width >= height){
            height = Math.round(height * maxEdge / width);
            width = maxEdge;
          } else {
            width = Math.round(width * maxEdge / height);
            height = maxEdge;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
        const compressed = canvas.toDataURL('image/jpeg', quality);
        resolve({
          dataUrl: compressed,
          width,
          height,
          bytes: estimateDataUrlBytes(compressed)
        });
      };
      img.onerror = reject;
      img.src = srcUrl;
    });
  }

  async function loadBackgroundFileInto(file, tpl, opts={}){
    if(!file){
      if(typeof toast === 'function') toast('ファイルが選択されていません','warn');
      return;
    }
    const type = String(file.type || '').toLowerCase();
    const name = String(file.name || '');
    const isPdf = type === 'application/pdf' || /\.pdf$/i.test(name);
    const isImage = type.startsWith('image/') || /\.(png|jpe?g|gif|webp|bmp)$/i.test(name);

    if(isPdf){
      if(!global.__pdfjsAvailable || !global.pdfjsLib){
        if(typeof toast === 'function') toast('PDF読込機能が無効です。同フォルダにpdf.min.jsを置いてください','warn');
        return;
      }
      await loadBackgroundPDF(file, tpl, opts);
    } else if(isImage) {
      await loadBackgroundImage(file, tpl, opts);
    } else {
      if(typeof toast === 'function') toast('対応形式：画像 または PDF','warn');
    }
  }

  function fileToDataURL(file){
    return new Promise((resolve, reject)=>{
      const reader = new FileReader();
      reader.onload = ()=>resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  async function loadBackgroundPDF(file, tpl, opts={}){
    try{
      if(typeof toast === 'function') toast('PDF読込中…');
      const ab = await file.arrayBuffer();
      const pdf = await global.pdfjsLib.getDocument({data:ab}).promise;
      const page = await pdf.getPage(1);
      const vp = page.getViewport({scale:200/72});
      const canvas = document.createElement('canvas');
      canvas.width = vp.width;
      canvas.height = vp.height;
      await page.render({canvasContext:canvas.getContext('2d'), viewport:vp}).promise;
      const rawUrl = canvas.toDataURL('image/jpeg', 0.9);
      const compressed = await compressImageDataUrl(rawUrl, BG_MAX_LONG_EDGE, BG_JPEG_QUALITY);
      setBackgroundOnTpl(tpl, compressed.dataUrl, file.name, compressed.bytes);
      if(typeof save === 'function') save();
      if(typeof toast === 'function') toast(`PDF取込完了（${formatBytes(compressed.bytes)}）`,'ok');
      if(opts.onLoaded) opts.onLoaded();
    }catch(e){
      console.error(e);
      if(typeof toast === 'function') toast('PDF読込エラー','warn');
    }
  }

  async function loadBackgroundImage(file, tpl, opts={}){
    try{
      const url = await fileToDataURL(file);
      const compressed = await compressImageDataUrl(url, BG_MAX_LONG_EDGE, BG_JPEG_QUALITY);
      setBackgroundOnTpl(tpl, compressed.dataUrl, file.name, compressed.bytes);
      if(typeof save === 'function') save();
      if(typeof toast === 'function') toast(`画像取込完了（${formatBytes(compressed.bytes)}）`,'ok');
      if(opts.onLoaded) opts.onLoaded();
    }catch(e){
      console.error(e);
      if(typeof toast === 'function') toast('画像読込エラー','warn');
    }
  }

  function setBackgroundOnTpl(tpl, dataUrl, name, bytes){
    if(!tpl) return false;
    if(tpl.bgPersist){
      tpl.bgImage = dataUrl;
      tpl.bgSourceName = name;
      tpl.bgBytes = bytes;
    } else {
      transientBg[tpl.id] = {dataUrl, name, bytes};
    }
    // 背景画像変更もレイアウト変更扱い（テスト印刷をやり直す必要がある）
    if(typeof markLayoutChanged === 'function') markLayoutChanged(tpl);
    return true;
  }

  const BackgroundAssetsApi = Object.freeze({
    BG_MAX_LONG_EDGE,
    BG_JPEG_QUALITY,
    compressImageDataUrl,
    loadBackgroundFileInto,
    fileToDataURL,
    loadBackgroundPDF,
    loadBackgroundImage,
    setBackgroundOnTpl
  });

  Object.assign(global, {
    BG_MAX_LONG_EDGE,
    BG_JPEG_QUALITY,
    compressImageDataUrl,
    loadBackgroundFileInto,
    fileToDataURL,
    loadBackgroundPDF,
    loadBackgroundImage,
    setBackgroundOnTpl,
    EnvelopePrintBackgroundAssets: BackgroundAssetsApi
  });
})(typeof window !== 'undefined' ? window : globalThis);
