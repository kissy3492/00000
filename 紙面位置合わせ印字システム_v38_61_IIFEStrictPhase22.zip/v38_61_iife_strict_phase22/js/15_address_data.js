(function(global){
  'use strict';
/* ============================================================
   v38-47: Address Data Formatter / IIFE Strict Phase8
   宛名・差出人データ整形、サンプルデータ、field text解決入口を担当。

   契約:
   - このモジュールが返す文字列はHTMLではなくプレーンテキスト。
   - DOMへ挿入する側が escapeHtml()/textContent 等でHTML安全性を担保する。
   - 既存互換のため、公開関数は window へ明示 export する。
   - Registry系は実行時参照。読み込み順は address_data → registries を正とする。
   - 保存キー・保存形式・field.source名は変更しない。
   ============================================================ */

  function joinLines(parts){
    return parts.map(v=>(v||'').trim()).filter(Boolean).join('\n');
  }

  function buildOrgText(data){
    // corpは「会社・部署まとめ」欄の明示値として扱うため、存在すれば優先する。
    data = data || {};
    const explicit = (data.corp||'').trim();
    if(explicit) return explicit;
    return joinLines([data.company, data.dept, data.title]);
  }

  function buildOrgFullText(data){
    // company/dept/titleの構造化入力を優先する。空の場合だけcorpへfallbackする。
    // buildOrgTextとは優先順位が異なるため、Registryのsource別に使い分ける。
    data = data || {};
    return joinLines([data.company, data.dept, data.title]) || (data.corp||'');
  }

  function buildNameWithHonor(name, honor){
    return (name||'').trim() ? (name.trim() + (honor ? ' ' + honor : '')) : '';
  }

  function buildSenderText(data){
    data = data || {};
    return joinLines([
      data.sender_zip ? '〒' + String(data.sender_zip).replace(/^〒/,'') : '',
      data.sender_addr,
      data.sender_company,
      data.sender_dept,
      data.sender_name,
      data.sender_tel ? 'TEL ' + data.sender_tel : ''
    ]);
  }

  function normalizeAddressData(data){
    data = data || {};
    if(!data.company && data.corp) data.company = data.corp;
    if(!data.corp) data.corp = buildOrgText(data);
    if(!data.full_addr) data.full_addr = joinLines([data.addr, data.addr2]);
    return data;
  }

  function defaultDataForTemplate(tpl){
    return tpl && tpl.isReply ? {
      zip:'', addr:'', addr2:'', full_addr:'', company:'株式会社サンプル', dept:'営業部', title:'', corp:'株式会社サンプル\n営業部',
      name:'採用ご担当', honor:'行', name2:'', honor2:'様',
      sender_zip:'', sender_addr:'', sender_company:'', sender_dept:'', sender_name:'', sender_tel:''
    } : {
      zip:'123-4567', addr:'東京都千代田区丸の内一丁目二番三号', addr2:'サンプルビル501', full_addr:'東京都千代田区丸の内一丁目二番三号\nサンプルビル501',
      company:'株式会社サンプル', dept:'営業部', title:'課長', corp:'株式会社サンプル\n営業部',
      name:'山田 太郎', honor:'様', name2:'佐藤 花子', honor2:'様',
      sender_zip:'030-0000', sender_addr:'青森県青森市サンプル一丁目1番1号', sender_company:'差出人サンプル', sender_dept:'総務係', sender_name:'森谷', sender_tel:'017-000-0000'
    };
  }

  function getFieldText(f,data,context){
    // field.sourceの解決入口。値解決はFieldSourceRegistryへ委譲する。
    data = normalizeAddressData(Object.assign({}, data||{}));
    const registry = global.FieldSourceRegistry || null;
    if(registry && typeof registry.resolve === 'function'){
      const resolved = registry.resolve(f && f.source, f, data);
      if(resolved && resolved.found){
        const value = resolved.value == null ? '' : resolved.value;
        return (typeof registry.applyPostProcessors === 'function')
          ? registry.applyPostProcessors(f, value, data, context)
          : value;
      }
    }
    return '';
  }

  function getSampleData(tpl){
    const base = defaultDataForTemplate(tpl);
    if(global.SampleDataRegistry && typeof global.SampleDataRegistry.build === 'function'){
      return global.SampleDataRegistry.build(tpl, base);
    }
    return base;
  }

  const AddressDataApi = Object.freeze({
    joinLines,
    buildOrgText,
    buildOrgFullText,
    buildNameWithHonor,
    buildSenderText,
    normalizeAddressData,
    defaultDataForTemplate,
    getFieldText,
    getSampleData
  });

  Object.assign(global, {
    joinLines,
    buildOrgText,
    buildOrgFullText,
    buildNameWithHonor,
    buildSenderText,
    normalizeAddressData,
    defaultDataForTemplate,
    getFieldText,
    getSampleData,
    EnvelopePrintAddressData: AddressDataApi
  });
})(typeof window !== 'undefined' ? window : globalThis);
