(function(global){
  'use strict';
/* ============================================================
   v38-10 Envelope / Canvas Render
   renderEnvelopeInto と印刷スタック描画を core から分離。
   ドラッグ操作・画面状態更新は引き続き 10_core.js 側に残す。
   ============================================================ */

function renderEnvelopeInto(env, tpl, sample, opts={}){
  const isEdit = opts.editable !== false;
  const scale = opts.scale || 1;
  const showBg = opts.showBg !== false;
  const showZones = opts.showZones !== false;
  const interactive = opts.interactive === true;
  const applyCorrection = opts.applyCorrection === true; // 印刷時のみtrue

  // envelope本体は物理サイズ固定
  env.style.width=(tpl.w*scale)+'mm';
  env.style.height=(tpl.h*scale)+'mm';
  env.style.transform=''; // 本体には絶対transform適用しない
  if(isEdit) env.classList.add('edit-mode'); else env.classList.remove('edit-mode');
  const bg=getBgImage(tpl);
  env.classList.toggle('has-bg',isEdit&&!!bg);
  env.innerHTML='';

  // 背景画像（編集時のみ表示。印刷時は出さない）
  if(showBg && bg && !applyCorrection){
    const img=document.createElement('img');
    img.className='envelope-bg';img.src=bg.data;
    const ba = tpl.bgAdjust || {offsetX:0,offsetY:0,scaleX:100,scaleY:100,rotation:0};
    img.style.left=(ba.offsetX*scale)+'mm';
    img.style.top=(ba.offsetY*scale)+'mm';
    img.style.width=(tpl.w*ba.scaleX/100*scale)+'mm';
    img.style.height=(tpl.h*ba.scaleY/100*scale)+'mm';
    img.style.opacity=(tpl.bgOpacity??0.85);
    if(ba.rotation) img.style.transform=`rotate(${ba.rotation}deg)`;
    img.draggable=false;
    env.appendChild(img);
  }

  // print-layer：補正対象
  const printLayer = document.createElement('div');
  printLayer.className = 'print-layer';
  if(applyCorrection && opts.transform){
    const transforms = [];
    if(opts.transform.offsetX || opts.transform.offsetY){
      transforms.push(`translate(${opts.transform.offsetX}mm, ${opts.transform.offsetY}mm)`);
    }
    if(opts.transform.scaleX !== 1 || opts.transform.scaleY !== 1){
      transforms.push(`scale(${opts.transform.scaleX}, ${opts.transform.scaleY})`);
    }
    if(transforms.length) printLayer.style.transform = transforms.join(' ');
  }
  env.appendChild(printLayer);

  // 避ける範囲（編集時のみ）
  if(showZones){
    (tpl.excludeZones||[]).forEach(z=>{
      const el=document.createElement('div');
      el.className='exclude-zone'+(z.id===state.selectedZoneId?' selected':'');
      el.style.left=(z.x*scale)+'mm';el.style.top=(z.y*scale)+'mm';
      el.style.width=(z.w*scale)+'mm';el.style.height=(z.h*scale)+'mm';
      el.innerHTML=`<span class="label">避ける: ${escapeHtml(z.label||'#'+((tpl.excludeZones||[]).indexOf(z)+1))}</span>${interactive?'<span class="resize-corner"></span>':''}`;
      if(interactive && !tpl.locked){
        el.addEventListener('click',e=>{
          e.stopPropagation();
          state.selectedZoneId=z.id;state.selectedFieldId=null;
          renderEnvelope();
        });
        attachZoneDrag(el,z);
      }
      printLayer.appendChild(el);
    });
  }

  tpl.fields.forEach(f=>{
    if(f.source==='zip'){
      renderZipField(printLayer, f, sample, tpl, interactive, scale, opts.highlightFieldId, opts.onlyZip);
      return;
    }
    if(opts.onlyZip) return;
    renderNormalField(printLayer, f, sample, tpl, interactive, scale, opts.highlightFieldId);
  });
}

function renderLabelCellInto(layer, tpl, data, originX, originY, cfg){
  const skipMemo = f => String(f.label||'').includes('面付けメモ');
  (tpl.fields||[]).filter(f=>!skipMemo(f)).forEach(f=>{
    const nf = Object.assign({}, f, {
      x: originX + (f.x||0),
      y: originY + (f.y||0),
      w: Math.min(f.w||cfg.labelW, Math.max(2, cfg.labelW-(f.x||0))),
      h: Math.min(f.h||cfg.labelH, Math.max(2, cfg.labelH-(f.y||0)))
    });
    // v26: 既存描画関数のシグネチャに合わせ、座標補正済みfield・実データ・テンプレートを渡す。
    // rect/text を直接渡す旧実装は sample/tpl/scale の位置がずれ、ラベル面付けを破壊していた。
    if(nf.source==='zip') renderZipField(layer, nf, data, tpl, false, 1, false, false);
    else renderNormalField(layer, nf, data, tpl, false, 1, false);
  });
}
function buildLabelSheetStack(tpl, targetQueue, transform){
  const stack=$('printStack');
  const cfg=getLabelConfig(tpl);
  const cap=labelCapacity(tpl);
  // v37 step21: Stage6のラベル開始位置処理を本体へ統合し、buildLabelSheetStackラッパーを不要にする。
  const start=Math.max(1, Math.min(cap, +(tpl.labelStartIndex || 1)));
  const offset=start-1;
  const totalSlots=offset+(targetQueue?targetQueue.length:0);
  const pages=Math.max(1, Math.ceil(totalSlots/cap));
  for(let page=0;page<pages;page++){
    const env=document.createElement('div');
    env.className='envelope';
    env.style.width=tpl.w+'mm';env.style.height=tpl.h+'mm';env.style.position='relative';
    const printLayer=document.createElement('div');
    printLayer.className='print-layer';
    const transforms=[];
    if(transform.offsetX||transform.offsetY) transforms.push(`translate(${transform.offsetX}mm, ${transform.offsetY}mm)`);
    if(transform.scaleX!==1||transform.scaleY!==1) transforms.push(`scale(${transform.scaleX}, ${transform.scaleY})`);
    if(transforms.length) printLayer.style.transform=transforms.join(' ');
    env.appendChild(printLayer);
    for(let slot=0;slot<cap;slot++){
      const globalSlot=page*cap+slot;
      const qi=globalSlot-offset;
      if(qi<0 || qi>=targetQueue.length) continue;
      const q=targetQueue[qi];
      const col=slot % cfg.cols;
      const row=Math.floor(slot / cfg.cols);
      const x=cfg.marginX + col*(cfg.labelW+cfg.gapX);
      const y=cfg.marginY + row*(cfg.labelH+cfg.gapY);
      renderLabelCellInto(printLayer,tpl,normalizeAddressData(Object.assign({},q)),x,y,cfg);
    }
    stack.appendChild(env);
  }
}
function buildPrintStack(targetQueue, opts={}){
  const t = opts.sourceTpl || getCurrentTpl();
  if(!t) return;
  const stack=$('printStack');
  stack.classList.add('printing');stack.innerHTML='';
  const p=getCurrentPrinter();
  const corr=(t&&p)?getPrinterCorrection(p.id, t.id):{rightShift:0,downShift:0,widthDiff:0,heightDiff:0};
  const transform = correctionToTransform(corr, t.w, t.h);

  if(t.paperKind==='label_sheet' && !opts.testCross){
    buildLabelSheetStack(t, targetQueue, transform);
    return;
  }

  if(opts.testCross){
    const env=document.createElement('div');env.className='envelope';
    env.style.width=t.w+'mm';env.style.height=t.h+'mm';env.style.position='relative';
    const printLayer=document.createElement('div');
    printLayer.className='print-layer';
    const transforms=[];
    if(transform.offsetX||transform.offsetY) transforms.push(`translate(${transform.offsetX}mm, ${transform.offsetY}mm)`);
    if(transform.scaleX!==1||transform.scaleY!==1) transforms.push(`scale(${transform.scaleX}, ${transform.scaleY})`);
    if(transforms.length) printLayer.style.transform=transforms.join(' ');
    env.appendChild(printLayer);
    [[5,5],[t.w-5,5],[5,t.h-5],[t.w-5,t.h-5]].forEach(([cx,cy])=>{
      const v=document.createElement('div');
      v.style.cssText=`position:absolute;left:${cx-0.1}mm;top:${cy-5}mm;width:0.2mm;height:10mm;background:#000`;
      printLayer.appendChild(v);
      const h=document.createElement('div');
      h.style.cssText=`position:absolute;left:${cx-5}mm;top:${cy-0.1}mm;width:10mm;height:0.2mm;background:#000`;
      printLayer.appendChild(h);
      const label=document.createElement('div');
      label.className='test-marker';
      label.style.cssText=`left:${cx+2}mm;top:${cy+2}mm;position:absolute`;
      label.textContent=`(${cx},${cy})`;
      printLayer.appendChild(label);
    });
    const cx=t.w/2,cy=t.h/2;
    const v=document.createElement('div');
    v.style.cssText=`position:absolute;left:${cx-0.1}mm;top:${cy-5}mm;width:0.2mm;height:10mm;background:#000`;
    printLayer.appendChild(v);
    const hl=document.createElement('div');
    hl.style.cssText=`position:absolute;left:${cx-5}mm;top:${cy-0.1}mm;width:10mm;height:0.2mm;background:#000`;
    printLayer.appendChild(hl);
    for(let x=10;x<t.w;x+=10){
      const tick=document.createElement('div');
      tick.style.cssText=`position:absolute;left:${x-0.05}mm;top:0;width:0.1mm;height:3mm;background:#888`;
      printLayer.appendChild(tick);
      if(x%50===0){
        const lbl=document.createElement('div');lbl.className='test-marker';
        lbl.style.cssText=`left:${x+1}mm;top:1mm;position:absolute`;
        lbl.textContent=x;printLayer.appendChild(lbl);
      }
    }
    for(let y=10;y<t.h;y+=10){
      const tick=document.createElement('div');
      tick.style.cssText=`position:absolute;left:0;top:${y-0.05}mm;width:3mm;height:0.1mm;background:#888`;
      printLayer.appendChild(tick);
      if(y%50===0){
        const lbl=document.createElement('div');lbl.className='test-marker';
        lbl.style.cssText=`left:1mm;top:${y+1}mm;position:absolute`;
        lbl.textContent=y;printLayer.appendChild(lbl);
      }
    }
    const info=document.createElement('div');info.className='test-marker';
    info.style.cssText=`left:5mm;top:${t.h/2}mm;font-size:9pt;position:absolute`;
    info.textContent=`${t.name} / ${p?p.name:'未設定'} / 右${corr.rightShift} 下${corr.downShift} 横幅${corr.widthDiff} 縦幅${corr.heightDiff}`;
    printLayer.appendChild(info);
    stack.appendChild(env);
    return;
  }
  targetQueue.forEach(q=>{
    const env=document.createElement('div');env.className='envelope';
    env.style.width=t.w+'mm';env.style.height=t.h+'mm';env.style.position='relative';
    const data=normalizeAddressData(Object.assign({}, q));
    renderEnvelopeInto(env, t, data, {
      editable:false, scale:1, interactive:false,
      showBg:false, showZones:false,
      applyCorrection:true, transform,
      onlyZip:opts.onlyZip
    });
    stack.appendChild(env);
  });
}

  Object.assign(global, {
    renderEnvelopeInto,
    renderLabelCellInto,
    buildLabelSheetStack,
    buildPrintStack
  });
  global.EnvelopePrintEnvelopeRenderer = Object.freeze({
    renderEnvelopeInto,
    renderLabelCellInto,
    buildLabelSheetStack,
    buildPrintStack
  });
})(typeof window !== 'undefined' ? window : globalThis);
