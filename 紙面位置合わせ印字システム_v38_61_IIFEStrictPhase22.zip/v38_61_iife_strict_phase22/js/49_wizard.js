(function(global){
  'use strict';
/* ============================================================
   v38-13: Wizard Controller
   位置合わせウィザードを 10_core.js から分離。
   v38-45: IIFE + strict 化し、公開入口を window へ明示export。
   保存形式・beforeunload保護・印刷ロジックは変更しない。
   ============================================================ */

/* ============================================================
   位置合わせウィザード（v8）
   mode: 'new' = サイズ選択から / 'edit' = 既存テンプレ再調整
   ============================================================ */
let wizardState = null;

Object.defineProperty(global, 'wizardState', {
  configurable: true,
  get(){ return wizardState; },
  set(value){ wizardState = value; }
});

function makeWizardSnapshot(){
  return {
    state: JSON.parse(JSON.stringify(state)),
    transientBg: JSON.parse(JSON.stringify(transientBg||{}))
  };
}
function restoreWizardSnapshot(snap){
  if(!snap) return;
  state = JSON.parse(JSON.stringify(snap.state));
  transientBg = JSON.parse(JSON.stringify(snap.transientBg||{}));
  if(Array.isArray(state.templates)) state.templates.forEach(normalizeTpl);
  if(Array.isArray(state.printerProfiles)) state.printerProfiles.forEach(p=>{if(!p.perTpl) p.perTpl={}});
}

const WZ_STEPS_NEW = [
  {n:1, title:'封筒サイズ'},
  {n:2, title:'封筒画像'},
  {n:3, title:'背景合わせ'},
  {n:4, title:'郵便番号'},
  {n:5, title:'宛名'},
  {n:6, title:'テスト印刷'},
  {n:7, title:'プリンタ補正'},
  {n:8, title:'保存'}
];
const WZ_STEPS_EDIT = [
  {n:2, title:'封筒画像'},
  {n:3, title:'背景合わせ'},
  {n:4, title:'郵便番号'},
  {n:5, title:'宛名'},
  {n:6, title:'テスト印刷'},
  {n:7, title:'プリンタ補正'},
  {n:8, title:'保存'}
];

function getWzSteps(){return wizardState.mode==='new'?WZ_STEPS_NEW:WZ_STEPS_EDIT}

async function openWizard(tpl, mode='edit', isReply=false){
  if(mode==='new'){
    wizardState = {
      mode:'new', isReply,
      _snapshot: makeWizardSnapshot(),
      step:1,
      selectedSize:null,
      vertical:true,
      tpl:null,
      stepAmt:1, zipStepAmt:1, layoutStepAmt:1,
      selectedFieldInWz:null,
      testDone:false
    };
  } else {
    const snap = makeWizardSnapshot();
    if(!tpl) tpl = getCurrentTpl();
    if(!tpl){toast('テンプレートが選択されていません','warn');return}
    // ロックされていれば解除を促す
    if(tpl.locked){
      // v37 step38: ウィザード編集前のロック解除確認をDOMモーダルへ移行する。
      if(!await showAppConfirm(`「${tpl.name}」はロックされています。\nウィザードで編集するにはロック解除が必要です。解除しますか？`,'ロック解除の確認',{okLabel:'解除する'})) return;
      tpl.locked = false;
    }
    const draftTpl = normalizeTpl(JSON.parse(JSON.stringify(tpl)));
    wizardState = {
      mode:'edit',
      originalTplId: tpl.id,
      _snapshot: snap,
      step:2,
      tpl: draftTpl, isReply:draftTpl.isReply,
      stepAmt:1, zipStepAmt:1, layoutStepAmt:1,
      selectedFieldInWz:null,
      testDone:false
    };
  }
  renderWizard();
}

function closeWizard(committed=false){
  const snap = wizardState && wizardState._snapshot;
  if(!committed && snap){
    restoreWizardSnapshot(snap);
    toast('ウィザードの変更を破棄しました','warn');
  }
  $('wizardContainer').innerHTML='';
  wizardState=null;
  renderStep1();renderSteps();
  if(state.currentStep===2) renderStep2();
  if(state.currentStep===3) renderStep3();
  if(state.currentStep===4) renderStep4();
  if(state.currentStep===5) renderStep5();
}

function renderWizard(){
  const cont=$('wizardContainer');
  const steps=getWzSteps();
  const curIdx=steps.findIndex(s=>s.n===wizardState.step);
  cont.innerHTML=`
    <div class="wizard-overlay">
      <div class="wizard-box">
        <div class="wizard-header">
          <div class="wz-title">位置合わせウィザード${wizardState.mode==='new'?'（新規作成）':'（再調整）'}</div>
          <button class="wz-close" id="wzAbort">中止</button>
        </div>
        <div class="wizard-progress">
          ${steps.map((s,i)=>`<div class="wz-step ${s.n===wizardState.step?'active':''}${i<curIdx?' done':''}">
            <span class="wz-num"><span>${i+1}</span></span>${s.title}
          </div>`).join('')}
        </div>
        <div class="wizard-body" id="wzBody"></div>
        <div class="wizard-footer" id="wzFooter"></div>
      </div>
    </div>
  `;
  cont.querySelector('#wzAbort').addEventListener('click',async ()=>{
    // v37 step38: ウィザード中止確認をブラウザ標準confirmからDOMモーダルへ移行する。
    if(await showAppConfirm('ウィザードを中止しますか？\n（未保存の調整内容は破棄されます）','ウィザードの中止',{okLabel:'中止する',danger:true})){
      closeWizard();
    }
  });
  renderWizardStep();
}

function renderWizardStep(){
  const body=$('wzBody');const footer=$('wzFooter');
  const s=wizardState.step;
  if(s===1) renderWzStep1(body,footer);
  else if(s===2) renderWzStep2(body,footer);
  else if(s===3) renderWzStep3(body,footer);
  else if(s===4) renderWzStep4(body,footer);
  else if(s===5) renderWzStep5(body,footer);
  else if(s===6) renderWzStep6(body,footer);
  else if(s===7) renderWzStep7(body,footer);
  else if(s===8) renderWzStep8(body,footer);
}

function wzFooter(footer, opts){
  footer.innerHTML=`
    <button class="btn ghost" id="wzPrev">${opts.prevLabel||'← 戻る'}</button>
    <div style="font-size:11px;color:#666;text-align:center;flex:1">${opts.hint||''}</div>
    <button class="btn primary" id="wzNext" ${opts.nextDisabled?'disabled':''}>${opts.nextLabel||'次へ →'}</button>
  `;
  footer.querySelector('#wzPrev').addEventListener('click', opts.onPrev||wizardPrev);
  footer.querySelector('#wzNext').addEventListener('click', opts.onNext||wizardNext);
}
async function wizardPrev(){
  const steps=getWzSteps();
  const idx=steps.findIndex(s=>s.n===wizardState.step);
  if(idx<=0){
    // v37 step38: 先頭ステップから戻る場合の中止確認をDOMモーダルへ移行する。
    if(await showAppConfirm('ウィザードを中止しますか？','ウィザードの中止',{okLabel:'中止する',danger:true})) closeWizard();
    return;
  }
  wizardState.step=steps[idx-1].n;
  renderWizard();
}
function wizardNext(){
  const steps=getWzSteps();
  const idx=steps.findIndex(s=>s.n===wizardState.step);
  if(idx>=steps.length-1) return;
  wizardState.step=steps[idx+1].n;
  renderWizard();
}

/* ----- Step1: サイズ選択（newのみ） ----- */
function renderWzStep1(body, footer){
  let cat = Object.keys(ENVELOPE_SIZES)[0];
  function render(){
    body.innerHTML=`
      <h3 class="serif" style="font-size:18px;margin-bottom:6px">用紙・封筒サイズを選んでください</h3>
      <p style="font-size:12px;color:#666;margin-bottom:14px">封筒・はがき・ラベル・帳票追記の土台になる用紙です。後でサイズ変更すると位置がズレるため、最初に正確に選んでください</p>
      <div class="size-cats">
        ${Object.keys(ENVELOPE_SIZES).map(c=>`<div class="size-cat ${c===cat?'active':''}" data-cat="${escapeHtml(c)}">${escapeHtml(c)}</div>`).join('')}
      </div>
      <div class="wizard-grid" id="wzSizes"></div>
      <div style="margin-top:18px;display:flex;gap:14px;align-items:center;flex-wrap:wrap">
        <label class="serif" style="font-size:13px">書き方：</label>
        <button class="btn ${wizardState.vertical?'primary':'ghost'} sm" id="vBtn">縦書き</button>
        <button class="btn ${!wizardState.vertical?'primary':'ghost'} sm" id="hBtn">横書き</button>
        ${wizardState.isReply?'<span class="pill reply" style="margin-left:8px">返信用封筒モード</span>':''}
      </div>
      <div style="margin-top:14px;padding:10px;background:var(--paper-2);font-size:12px">
        ${wizardState.selectedSize?`<strong>選択中:</strong> ${escapeHtml(wizardState.selectedSize.n)} (${wizardState.selectedSize.w}×${wizardState.selectedSize.h}mm) / ${wizardState.vertical?'縦書き':'横書き'}${wizardState.selectedSize.kind?` / ${escapeHtml(wizardState.selectedSize.kind)}`:''}`:'<span style="color:#888">封筒サイズを選んでください</span>'}
      </div>
    `;
    body.querySelectorAll('.size-cat').forEach(c=>{
      c.addEventListener('click',()=>{cat=c.dataset.cat;render()});
    });
    body.querySelector('#vBtn').addEventListener('click',()=>{wizardState.vertical=true;render()});
    body.querySelector('#hBtn').addEventListener('click',()=>{wizardState.vertical=false;render()});
    const grid=body.querySelector('#wzSizes');
    ENVELOPE_SIZES[cat].forEach(s=>{
      const b=document.createElement('button');
      b.className=(wizardState.selectedSize&&wizardState.selectedSize.n===s.n)?'selected':'';
      b.innerHTML=`${s.favorite?'<span class="star-mark">★</span>':''}<span class="nm">${s.n}</span><span class="sz">${s.w}×${s.h}</span>${s.note?`<span class="note">${escapeHtml(s.note)}</span>`:''}`;
      b.addEventListener('click',()=>{wizardState.selectedSize=s;render();updateFooter()});
      grid.appendChild(b);
    });
    updateFooter();
  }
  function updateFooter(){
    wzFooter(footer,{
      nextDisabled:!wizardState.selectedSize,
      hint:wizardState.selectedSize?'次：封筒画像を取り込みます':'',
      onPrev:async ()=>{if(await showAppConfirm('ウィザードを中止しますか？','ウィザードの中止',{okLabel:'中止する',danger:true})) closeWizard()},
      onNext:()=>{
        const sz=wizardState.selectedSize;
        const t=normalizeTpl({
          id:uid('tpl'),
          name:`${sz.n}${wizardState.isReply?'（返信用）':''}（${wizardState.vertical?'縦':'横'}）`,
          w:sz.w,h:sz.h,
          paperKind:sz.kind||'envelope',
          labelConfig:(sz.kind==='label_sheet'?defaultLabelConfig(sz.n):undefined),
          fields:buildFieldsForPreset(sz,wizardState.vertical,wizardState.isReply),
          excludeZones:buildExcludeZonesForPreset(sz),pinned:false,isReply:wizardState.isReply,
          bgOpacity:0.85,isPreset:false,locked:false
        });
        // 段階3：ここでは本データへ追加しない。最後の保存ステップまで draftTpl として保持する。
        wizardState.tpl=t;
        wizardState.step=2;
        renderWizard();
      }
    });
  }
  render();
}

/* ----- Step2: 封筒画像取込 ----- */
function renderWzStep2(body, footer){
  const t=wizardState.tpl;
  function render(){
    const bg=getBgImage(t);
    body.innerHTML=`
      <h3 class="serif" style="font-size:18px;margin-bottom:6px">封筒画像を取り込みます</h3>
      <p style="font-size:12px;color:#666;margin-bottom:14px">実際の封筒をスキャナで取り込んだ画像（JPG/PNG${window.__pdfjsAvailable?'/PDF':''}）を選んでください。次のステップで封筒枠に合わせます</p>
      <div style="background:#fff;border:1px solid var(--line-soft);padding:18px;margin-bottom:14px">
        <div class="bg-status">
          <span class="dot ${bg?'on':''}"></span>
          <span>${bg?`取込済：${escapeHtml(bg.name||'画像')} (${formatBytes(bg.bytes||0)})`:'画像未取込'}</span>
        </div>
        <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">
          <button class="btn" id="wzBgLoad">${bg?'別の画像に差し替える':'画像を選ぶ'}</button>
          ${bg?'<button class="btn ghost sm" id="wzBgClear">削除</button>':''}
        </div>
        <input type="file" id="wzBgFile" accept="image/*${window.__pdfjsAvailable?',application/pdf':''}" style="display:none">
        <label class="checkbox-row" style="margin-top:10px">
          <input type="checkbox" id="wzBgPersist" ${t.bgPersist?'checked':''}>
          <span>背景画像を保存（次回も自動表示、容量大）</span>
        </label>
        <div class="hint" style="margin-top:6px">
          ${window.__pdfjsAvailable?'JPG/PNG/PDFが取込めます':'JPG/PNG画像のみ取込めます（PDFは pdf.min.js が必要）'}<br>
          画像は自動圧縮されます（最大${window.BG_MAX_LONG_EDGE || 1600}px、JPEG品質${Math.round((window.BG_JPEG_QUALITY || 0.8)*100)}%）
        </div>
      </div>
      ${bg?`
      <div style="text-align:center;margin-bottom:8px;font-size:11px;color:#666">画像プレビュー</div>
      <div style="display:flex;justify-content:center">
        <div id="wzBgPreviewWrap" style="background:repeating-linear-gradient(45deg,#e8e0cc 0 2px,#ece5d2 2px 12px);padding:14px;border:1px solid var(--line-soft)">
          <img src="${bg.data}" style="display:block;max-width:400px;max-height:300px;background:#fff;border:1px solid #d0c8b0">
        </div>
      </div>`:''}
      <p style="font-size:11px;color:#999;margin-top:14px">※ 画像なしでも次へ進めますが、その場合は実物との位置合わせができません。標準テンプレート位置のままになります。</p>
    `;
    body.querySelector('#wzBgLoad').addEventListener('click',()=>body.querySelector('#wzBgFile').click());
    body.querySelector('#wzBgFile').addEventListener('change',async e=>{
      const f=e.target.files[0];if(!f) return;
      await loadBackgroundFileInto(f,t,{onLoaded:()=>render()});
      e.target.value='';
    });
    const clr=body.querySelector('#wzBgClear');
    if(clr) clr.addEventListener('click',()=>{
      delete t.bgImage;delete t.bgSourceName;delete t.bgBytes;delete transientBg[t.id];
      markLayoutChanged(t);save();render();
    });
    body.querySelector('#wzBgPersist').addEventListener('change',e=>{
      t.bgPersist=e.target.checked;
      if(t.bgPersist&&transientBg[t.id]){
        t.bgImage=transientBg[t.id].dataUrl;
        t.bgSourceName=transientBg[t.id].name;
        t.bgBytes=transientBg[t.id].bytes;
        delete transientBg[t.id];
      }
      if(!t.bgPersist&&t.bgImage){
        transientBg[t.id]={dataUrl:t.bgImage,name:t.bgSourceName,bytes:t.bgBytes};
        delete t.bgImage;delete t.bgSourceName;delete t.bgBytes;
      }
      save();
    });
    wzFooter(footer,{
      hint:getBgImage(t)?'次：背景画像を封筒枠に合わせます':'画像なしで次へ進む場合は、宛名位置の調整のみ可能になります'
    });
  }
  render();
}

/* ----- Step3: 背景位置合わせ ----- */
function renderWzStep3(body, footer){
  const t=wizardState.tpl;
  const bg=getBgImage(t);
  if(!bg){
    body.innerHTML=`
      <h3 class="serif" style="font-size:18px;margin-bottom:6px">背景画像の位置合わせ</h3>
      <div class="info-banner"><h4>背景画像なし</h4>背景画像が取り込まれていないため、このステップはスキップします。標準テンプレートの位置を使います。</div>
    `;
    wzFooter(footer,{hint:'次へ進んでください'});
    return;
  }
  function render(){
    const ba=t.bgAdjust||{offsetX:0,offsetY:0,scaleX:100,scaleY:100,rotation:0};
    body.innerHTML=`
      <h3 class="serif" style="font-size:18px;margin-bottom:6px">背景画像を封筒枠に合わせます</h3>
      <p style="font-size:12px;color:#666;margin-bottom:14px">背景画像の位置・大きさを、グレーの罫線で示された封筒枠に合わせてください。封筒サイズ自体は変わりません</p>
      <div class="wz-layout">
        <div>
          <div class="preview-area" style="max-height:60vh;padding:14px">
            <div class="envelope edit-mode has-bg" id="wzEnv"></div>
          </div>
        </div>
        <div class="wz-controls">
          <div class="wz-card">
            <h5>背景を動かす</h5>
            <div class="adjust-pad">
              <button style="visibility:hidden"></button>
              <button data-adj="0,-1">↑</button>
              <button style="visibility:hidden"></button>
              <button data-adj="-1,0">←</button>
              <button class="center"></button>
              <button data-adj="1,0">→</button>
              <button style="visibility:hidden"></button>
              <button data-adj="0,1">↓</button>
              <button style="visibility:hidden"></button>
            </div>
            <div class="step-amount">
              <button data-st="0.5" class="${wizardState.stepAmt===0.5?'active':''}">0.5mm</button>
              <button data-st="1" class="${wizardState.stepAmt===1?'active':''}">1mm</button>
              <button data-st="5" class="${wizardState.stepAmt===5?'active':''}">5mm</button>
            </div>
            <div class="row r2" style="margin-top:8px">
              <div><label>X位置(mm)</label><input type="number" step="0.5" id="wzBgX" value="${ba.offsetX}"></div>
              <div><label>Y位置(mm)</label><input type="number" step="0.5" id="wzBgY" value="${ba.offsetY}"></div>
            </div>
          </div>
          <div class="wz-card">
            <h5>背景の大きさ・回転</h5>
            <div class="row r2">
              <div><label>横倍率(%)</label><input type="number" step="0.5" id="wzBgSX" value="${ba.scaleX}"></div>
              <div><label>縦倍率(%)</label><input type="number" step="0.5" id="wzBgSY" value="${ba.scaleY}"></div>
            </div>
            <div class="row" style="margin-top:6px">
              <label>回転(度)</label><input type="number" step="0.5" id="wzBgRot" value="${ba.rotation||0}">
            </div>
            <div style="display:flex;gap:4px;margin-top:6px">
              <button class="btn sm ghost" id="wzBgSizeM" style="flex:1">－ 小さく</button>
              <button class="btn sm ghost" id="wzBgSizeP" style="flex:1">＋ 大きく</button>
            </div>
          </div>
          <div class="wz-card">
            <h5>背景の濃さ</h5>
            <input type="range" min="10" max="100" value="${Math.round((t.bgOpacity??0.85)*100)}" class="opacity-slider" id="wzBgOp">
            <div style="text-align:center;font-size:11px" id="wzBgOpV">${Math.round((t.bgOpacity??0.85)*100)}%</div>
          </div>
          <button class="btn ghost sm" id="wzBgReset">背景補正をリセット</button>
        </div>
      </div>
    `;
    renderWzBgPreview();
    body.querySelectorAll('.step-amount button').forEach(b=>{
      b.addEventListener('click',()=>{wizardState.stepAmt=parseFloat(b.dataset.st);render()});
    });
    body.querySelectorAll('[data-adj]').forEach(b=>{
      if(getComputedStyle(b).visibility==='hidden') return;
      b.addEventListener('click',()=>{
        const [dx,dy]=b.dataset.adj.split(',').map(Number);
        t.bgAdjust.offsetX=Math.round((t.bgAdjust.offsetX+dx*wizardState.stepAmt)*10)/10;
        t.bgAdjust.offsetY=Math.round((t.bgAdjust.offsetY+dy*wizardState.stepAmt)*10)/10;
        save();render();
      });
    });
    body.querySelector('#wzBgX').addEventListener('input',e=>{t.bgAdjust.offsetX=parseFloat(e.target.value)||0;save();renderWzBgPreview()});
    body.querySelector('#wzBgY').addEventListener('input',e=>{t.bgAdjust.offsetY=parseFloat(e.target.value)||0;save();renderWzBgPreview()});
    body.querySelector('#wzBgSX').addEventListener('input',e=>{t.bgAdjust.scaleX=parseFloat(e.target.value)||100;save();renderWzBgPreview()});
    body.querySelector('#wzBgSY').addEventListener('input',e=>{t.bgAdjust.scaleY=parseFloat(e.target.value)||100;save();renderWzBgPreview()});
    body.querySelector('#wzBgRot').addEventListener('input',e=>{t.bgAdjust.rotation=parseFloat(e.target.value)||0;save();renderWzBgPreview()});
    body.querySelector('#wzBgSizeM').addEventListener('click',()=>{
      t.bgAdjust.scaleX=Math.round((t.bgAdjust.scaleX-0.5)*10)/10;
      t.bgAdjust.scaleY=Math.round((t.bgAdjust.scaleY-0.5)*10)/10;
      save();render();
    });
    body.querySelector('#wzBgSizeP').addEventListener('click',()=>{
      t.bgAdjust.scaleX=Math.round((t.bgAdjust.scaleX+0.5)*10)/10;
      t.bgAdjust.scaleY=Math.round((t.bgAdjust.scaleY+0.5)*10)/10;
      save();render();
    });
    body.querySelector('#wzBgOp').addEventListener('input',e=>{
      t.bgOpacity=e.target.value/100;
      body.querySelector('#wzBgOpV').textContent=e.target.value+'%';
      save();renderWzBgPreview();
    });
    body.querySelector('#wzBgReset').addEventListener('click',()=>{
      t.bgAdjust={offsetX:0,offsetY:0,scaleX:100,scaleY:100,rotation:0};
      save();render();
    });
    wzFooter(footer,{
      hint:'封筒の輪郭がグレー罫線と合うように調整',
      nextLabel:'背景合わせ完了 →',
      onNext:()=>{
        if(!t.adjustmentStatus) t.adjustmentStatus={};
        t.adjustmentStatus.bgAlignedAt=Date.now();
        save();wizardNext();
      }
    });
  }
  function renderWzBgPreview(){
    const env=body.querySelector('#wzEnv');
    if(!env) return;
    // renderEnvelopeInto を流用し、本編集画面と完全一致させる
    // 適切なスケールを計算（mm基準、1mm=3.7795px相当）
    const maxW=500;
    const scale=Math.min(maxW/(t.w*3.7795), 1.5);
    renderEnvelopeInto(env, t, getSampleData(t), {
      editable:true, scale:scale, interactive:false,
      showBg:true, showZones:false
    });
  }
  render();
}

/* ----- Step4: 郵便番号位置合わせ ----- */
function renderWzStep4(body, footer){
  const t=wizardState.tpl;
  const zipField=t.fields.find(f=>f.source==='zip');
  if(!zipField){
    body.innerHTML=`
      <h3 class="serif" style="font-size:18px;margin-bottom:6px">郵便番号枠を合わせます</h3>
      <div class="info-banner"><h4>郵便番号フィールドなし</h4>${t.isReply?'返信用封筒のため郵便番号は不要です。':'郵便番号フィールドが存在しません。'}スキップします</div>
    `;
    wzFooter(footer,{
      onNext:()=>{
        if(!t.adjustmentStatus) t.adjustmentStatus={};
        t.adjustmentStatus.zipCheckedAt=Date.now();
        save();wizardNext();
      }
    });
    return;
  }
  function render(){
    const zc=zipField.zipConfig||{showFrame:false,showMark:false,charSpacing:1.2,gapAfter3:1.5,digitOffsets:[]};
    if(!wizardState.zipStepAmt) wizardState.zipStepAmt=1;
    body.innerHTML=`
      <h3 class="serif" style="font-size:18px;margin-bottom:6px">郵便番号枠を合わせます</h3>
      <p style="font-size:12px;color:#666;margin-bottom:14px">郵便番号の表示位置を、実際の封筒の郵便番号枠に合わせてください。プレビューだけでなく、必ず<strong>郵便番号だけテスト印刷</strong>して実物に重ねて確認してください</p>
      <div class="wz-layout">
        <div>
          <div class="preview-area" style="max-height:60vh;padding:14px">
            <div class="envelope edit-mode${getBgImage(t)?' has-bg':''}" id="wzEnv"></div>
          </div>
        </div>
        <div class="wz-controls">
          <div class="wz-card">
            <h5>郵便番号を動かす</h5>
            <div class="adjust-pad">
              <button style="visibility:hidden"></button>
              <button data-adj="0,-1">↑</button>
              <button style="visibility:hidden"></button>
              <button data-adj="-1,0">←</button>
              <button class="center"></button>
              <button data-adj="1,0">→</button>
              <button style="visibility:hidden"></button>
              <button data-adj="0,1">↓</button>
              <button style="visibility:hidden"></button>
            </div>
            <div class="step-amount">
              <button data-st="0.5" class="${wizardState.zipStepAmt===0.5?'active':''}">0.5mm</button>
              <button data-st="1" class="${wizardState.zipStepAmt===1?'active':''}">1mm</button>
              <button data-st="5" class="${wizardState.zipStepAmt===5?'active':''}">5mm</button>
            </div>
            <div class="row r2" style="margin-top:8px">
              <div><label>X位置(mm)</label><input type="number" step="0.5" id="wzZipX" value="${zipField.x}"></div>
              <div><label>Y位置(mm)</label><input type="number" step="0.5" id="wzZipY" value="${zipField.y}"></div>
            </div>
            <div class="row r2" style="margin-top:4px">
              <div><label>枠の幅(mm)</label><input type="number" step="0.5" id="wzZipW" value="${zipField.w}"></div>
              <div><label>文字大きさ(pt)</label><input type="number" step="0.5" id="wzZipFs" value="${zipField.fontSize}"></div>
            </div>
          </div>
          <div class="wz-card">
            <h5>表示</h5>
            <label class="checkbox-row"><input type="checkbox" id="wzZipMark" ${zc.showMark?'checked':''}> 〒記号を付ける</label>
            <label class="checkbox-row" style="margin-top:6px"><input type="checkbox" id="wzZipFrame" ${zc.showFrame?'checked':''}> 枠ガイドを表示（参考）</label>
          </div>
          <div class="wz-card">
            <h5>文字間隔</h5>
            <div class="row r2">
              <div><label>文字間隔(mm)</label><input type="number" step="0.1" id="wzZipSpace" value="${zc.charSpacing}"></div>
              <div><label>3桁目後(mm)</label><input type="number" step="0.1" id="wzZipGap" value="${zc.gapAfter3}"></div>
            </div>
          </div>
          <button class="btn primary" id="wzZipTest">📄 郵便番号だけテスト印刷</button>
        </div>
      </div>
    `;
    renderWzZipPreview();
    body.querySelectorAll('.step-amount button').forEach(b=>{
      b.addEventListener('click',()=>{wizardState.zipStepAmt=parseFloat(b.dataset.st);render()});
    });
    body.querySelectorAll('[data-adj]').forEach(b=>{
      if(getComputedStyle(b).visibility==='hidden') return;
      b.addEventListener('click',()=>{
        const [dx,dy]=b.dataset.adj.split(',').map(Number);
        zipField.x=Math.max(0,Math.round((zipField.x+dx*wizardState.zipStepAmt)*10)/10);
        zipField.y=Math.max(0,Math.round((zipField.y+dy*wizardState.zipStepAmt)*10)/10);
        markLayoutChanged(t);save();render();
      });
    });
    body.querySelector('#wzZipX').addEventListener('input',e=>{zipField.x=parseFloat(e.target.value)||0;markLayoutChanged(t);save();renderWzZipPreview()});
    body.querySelector('#wzZipY').addEventListener('input',e=>{zipField.y=parseFloat(e.target.value)||0;markLayoutChanged(t);save();renderWzZipPreview()});
    body.querySelector('#wzZipW').addEventListener('input',e=>{zipField.w=parseFloat(e.target.value)||1;markLayoutChanged(t);save();renderWzZipPreview()});
    body.querySelector('#wzZipFs').addEventListener('input',e=>{zipField.fontSize=parseFloat(e.target.value)||10;markLayoutChanged(t);save();renderWzZipPreview()});
    body.querySelector('#wzZipMark').addEventListener('change',e=>{zipField.zipConfig.showMark=e.target.checked;markLayoutChanged(t);save();renderWzZipPreview()});
    body.querySelector('#wzZipFrame').addEventListener('change',e=>{zipField.zipConfig.showFrame=e.target.checked;save();renderWzZipPreview()});
    body.querySelector('#wzZipSpace').addEventListener('input',e=>{zipField.zipConfig.charSpacing=parseFloat(e.target.value)||0;markLayoutChanged(t);save();renderWzZipPreview()});
    body.querySelector('#wzZipGap').addEventListener('input',e=>{zipField.zipConfig.gapAfter3=parseFloat(e.target.value)||0;markLayoutChanged(t);save();renderWzZipPreview()});
    body.querySelector('#wzZipTest').addEventListener('click',()=>{
      doPrint({queue:[{zip:'1234567'}], onlyZip:true, sourceTpl:t});
    });
    wzFooter(footer,{
      hint:'郵便番号が枠内に収まるように調整',
      nextLabel:'郵便番号OK →',
      onNext:()=>{
        if(!t.adjustmentStatus) t.adjustmentStatus={};
        t.adjustmentStatus.zipCheckedAt=Date.now();
        save();wizardNext();
      }
    });
  }
  function renderWzZipPreview(){
    const env=body.querySelector('#wzEnv');
    if(!env) return;
    const maxW=500;
    const scale=Math.min(maxW/(t.w*3.7795), 1.5);
    renderEnvelopeInto(env, t, getSampleData(t), {
      editable:true, scale:scale, interactive:false,
      showBg:true, showZones:false,
      highlightFieldId: zipField.id
    });
  }
  render();
}

/* ----- Step5: 宛名位置合わせ ----- */
function renderWzStep5(body, footer){
  const t=wizardState.tpl;
  const adjustables=t.fields.filter(f=>f.source!=='zip');
  if(!adjustables.length){
    body.innerHTML=`<div class="info-banner"><h4>調整対象なし</h4>郵便番号以外のフィールドがありません。スキップします</div>`;
    wzFooter(footer,{
      onNext:()=>{
        if(!t.adjustmentStatus) t.adjustmentStatus={};
        t.adjustmentStatus.layoutCheckedAt=Date.now();
        save();wizardNext();
      }
    });
    return;
  }
  function render(){
    if(!wizardState.layoutStepAmt) wizardState.layoutStepAmt=1;
    if(!wizardState.selectedFieldInWz||!adjustables.find(f=>f.id===wizardState.selectedFieldInWz)){
      wizardState.selectedFieldInWz=adjustables[0].id;
    }
    const sel=adjustables.find(f=>f.id===wizardState.selectedFieldInWz);
    body.innerHTML=`
      <h3 class="serif" style="font-size:18px;margin-bottom:6px">${t.isReply?'部署名・氏名':'住所・会社名・宛名'}の位置を合わせます</h3>
      <p style="font-size:12px;color:#666;margin-bottom:14px">調整したい項目を選び、矢印ボタンで位置を動かしてください。背景画像と比べて、印字位置を決めます</p>
      <div class="wz-layout">
        <div>
          <div class="preview-area" style="max-height:60vh;padding:14px">
            <div class="envelope edit-mode${getBgImage(t)?' has-bg':''}" id="wzEnv"></div>
          </div>
        </div>
        <div class="wz-controls">
          <div class="wz-card">
            <h5>調整する項目</h5>
            <select id="wzFieldSel" style="width:100%">
              ${adjustables.map(f=>`<option value="${f.id}" ${f.id===sel.id?'selected':''}>${escapeHtml(f.label)}（${escapeHtml(getFieldSourceLabel(f.source))}）</option>`).join('')}
            </select>
          </div>
          <div class="wz-card">
            <h5>位置を動かす</h5>
            <div class="adjust-pad">
              <button style="visibility:hidden"></button>
              <button data-adj="0,-1">↑</button>
              <button style="visibility:hidden"></button>
              <button data-adj="-1,0">←</button>
              <button class="center"></button>
              <button data-adj="1,0">→</button>
              <button style="visibility:hidden"></button>
              <button data-adj="0,1">↓</button>
              <button style="visibility:hidden"></button>
            </div>
            <div class="step-amount">
              <button data-st="0.5" class="${wizardState.layoutStepAmt===0.5?'active':''}">0.5mm</button>
              <button data-st="1" class="${wizardState.layoutStepAmt===1?'active':''}">1mm</button>
              <button data-st="5" class="${wizardState.layoutStepAmt===5?'active':''}">5mm</button>
            </div>
            <div class="row r2" style="margin-top:8px">
              <div><label>X位置</label><input type="number" step="0.5" id="wzFldX" value="${sel.x}"></div>
              <div><label>Y位置</label><input type="number" step="0.5" id="wzFldY" value="${sel.y}"></div>
            </div>
            <div class="row r2" style="margin-top:4px">
              <div><label>幅</label><input type="number" step="0.5" id="wzFldW" value="${sel.w}"></div>
              <div><label>高さ</label><input type="number" step="0.5" id="wzFldH" value="${sel.h}"></div>
            </div>
          </div>
          <div class="wz-card">
            <h5>文字の大きさ</h5>
            <div class="row r2">
              <div><label>サイズ(pt)</label><input type="number" step="0.5" id="wzFldFs" value="${sel.fontSize}"></div>
              <div style="display:flex;flex-direction:column;justify-content:flex-end">
                <label class="checkbox-row" style="margin-bottom:4px"><input type="checkbox" id="wzFldBold" ${sel.bold?'checked':''}>太字</label>
              </div>
            </div>
            <div style="display:flex;gap:4px;margin-top:6px">
              <button class="btn sm ghost" id="wzFldFsM" style="flex:1">－ 小</button>
              <button class="btn sm ghost" id="wzFldFsP" style="flex:1">＋ 大</button>
            </div>
          </div>
        </div>
      </div>
    `;
    renderWzFldPreview();
    body.querySelector('#wzFieldSel').addEventListener('change',e=>{
      wizardState.selectedFieldInWz=e.target.value;render();
    });
    body.querySelectorAll('.step-amount button').forEach(b=>{
      b.addEventListener('click',()=>{wizardState.layoutStepAmt=parseFloat(b.dataset.st);render()});
    });
    body.querySelectorAll('[data-adj]').forEach(b=>{
      if(getComputedStyle(b).visibility==='hidden') return;
      b.addEventListener('click',()=>{
        const [dx,dy]=b.dataset.adj.split(',').map(Number);
        sel.x=Math.max(0,Math.round((sel.x+dx*wizardState.layoutStepAmt)*10)/10);
        sel.y=Math.max(0,Math.round((sel.y+dy*wizardState.layoutStepAmt)*10)/10);
        markLayoutChanged(t);save();render();
      });
    });
    body.querySelector('#wzFldX').addEventListener('input',e=>{sel.x=parseFloat(e.target.value)||0;markLayoutChanged(t);save();renderWzFldPreview()});
    body.querySelector('#wzFldY').addEventListener('input',e=>{sel.y=parseFloat(e.target.value)||0;markLayoutChanged(t);save();renderWzFldPreview()});
    body.querySelector('#wzFldW').addEventListener('input',e=>{sel.w=parseFloat(e.target.value)||1;markLayoutChanged(t);save();renderWzFldPreview()});
    body.querySelector('#wzFldH').addEventListener('input',e=>{sel.h=parseFloat(e.target.value)||1;markLayoutChanged(t);save();renderWzFldPreview()});
    body.querySelector('#wzFldFs').addEventListener('input',e=>{sel.fontSize=parseFloat(e.target.value)||10;markLayoutChanged(t);save();renderWzFldPreview()});
    body.querySelector('#wzFldBold').addEventListener('change',e=>{sel.bold=e.target.checked;markLayoutChanged(t);save();renderWzFldPreview()});
    body.querySelector('#wzFldFsM').addEventListener('click',()=>{sel.fontSize=Math.max(6,sel.fontSize-1);markLayoutChanged(t);save();render()});
    body.querySelector('#wzFldFsP').addEventListener('click',()=>{sel.fontSize=sel.fontSize+1;markLayoutChanged(t);save();render()});
    wzFooter(footer,{
      hint:'各項目を背景画像に合わせて配置',
      nextLabel:'宛名OK →',
      onNext:()=>{
        if(!t.adjustmentStatus) t.adjustmentStatus={};
        t.adjustmentStatus.layoutCheckedAt=Date.now();
        save();wizardNext();
      }
    });
  }
  function renderWzFldPreview(){
    const env=body.querySelector('#wzEnv');
    if(!env) return;
    const maxW=500;
    const scale=Math.min(maxW/(t.w*3.7795), 1.5);
    renderEnvelopeInto(env, t, getSampleData(t), {
      editable:true, scale:scale, interactive:false,
      showBg:true, showZones:true,
      highlightFieldId: wizardState.selectedFieldInWz
    });
  }
  render();
}

/* ----- Step6: テスト印刷 ----- */
function renderWzStep6(body, footer){
  const t=wizardState.tpl;
  body.innerHTML=`
    <h3 class="serif" style="font-size:18px;margin-bottom:6px">テスト印刷で位置を確認します</h3>
    <p style="font-size:12px;color:#666;margin-bottom:14px">用紙（コピー用紙でOK）またはハガキ大の紙で試し刷りし、実際の封筒に重ねて印字位置を確認してください</p>
    <div style="background:#fff;border:1px solid var(--line-soft);padding:18px;margin-bottom:14px">
      <h5 class="serif" style="font-size:13px;margin-bottom:8px">テスト印刷</h5>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn primary" id="wzTestSample">サンプル宛先で1枚</button>
        <button class="btn ghost" id="wzTestCross">十字マーク・罫線テスト</button>
      </div>
      <div class="hint" style="margin-top:8px">十字マーク版なら定規でズレを正確に測れます。次のプリンタ補正に役立ちます</div>
    </div>
    <div style="padding:14px;background:var(--paper-2);border:1px solid var(--line-soft)">
      <label class="checkbox-row" style="font-size:13px"><input type="checkbox" id="wzTestDone" ${wizardState.testDone?'checked':''}><span>テスト印刷の結果を確認しました（次へ進める）</span></label>
      <div class="hint" style="margin-top:4px">※ 位置がズレていた場合は前のステップに戻って調整するか、次のプリンタ補正で吸収してください</div>
    </div>
  `;
  body.querySelector('#wzTestSample').addEventListener('click',()=>{
    doPrint({queue:[Object.assign({}, getSampleData(t))], sourceTpl:t});
  });
  body.querySelector('#wzTestCross').addEventListener('click',()=>{
    doPrint({queue:[], testCross:true, sourceTpl:t});
  });
  function updateFooter(){
    wzFooter(footer,{
      hint:'テスト印刷の結果確認後にチェックして次へ',
      nextDisabled:!wizardState.testDone,
      onNext:()=>{
        if(!t.adjustmentStatus) t.adjustmentStatus={};
        // v37 step15: testPrintedAtは実印刷成功ではなく、ユーザによるテスト印刷結果確認の時刻として扱う。
        t.adjustmentStatus.testPrintedAt=Date.now();
        save();wizardNext();
      }
    });
  }
  body.querySelector('#wzTestDone').addEventListener('change',e=>{
    wizardState.testDone=e.target.checked;
    updateFooter();
  });
  updateFooter();
}

/* ----- Step7: プリンタ補正（見たまま入力） ----- */
function renderWzStep7(body, footer){
  const t=wizardState.tpl;
  function render(){
    body.innerHTML=`
      <h3 class="serif" style="font-size:18px;margin-bottom:6px">プリンタの印字ズレを補正します</h3>
      <p style="font-size:12px;color:#666;margin-bottom:14px">テスト印刷を実封筒に重ねて、ズレ量を実測してください。「見たまま」入力できます。<br>プリンタごとに別々の補正値が保存されます（職場・自宅で別プリンタを使う場合に便利）</p>
      <div style="background:#fff;border:1px solid var(--line-soft);padding:18px">
        ${renderPrinterCalibForm(t)}
      </div>
      <div style="margin-top:14px;font-size:11px;color:#888;line-height:1.6">
        ※ 補正不要な場合は空欄（0）のまま次へ進めます<br>
        ※ プリンタは複数登録できます（後から「バックアップ管理」でも編集可能）
      </div>
    `;
    bindPrinterCalibForm(t);
    wzFooter(footer,{
      hint:'入力後、次へ進む',
      onNext:()=>{
        if(!t.adjustmentStatus) t.adjustmentStatus={};
        t.adjustmentStatus.printerCheckedAt=Date.now();
        save();wizardNext();
      }
    });
  }
  render();
}

function renderPrinterCalibForm(t){
  const sel=state.selectedPrinterId;
  const corr=sel?getPrinterCorrection(sel, t.id):{rightShift:0,downShift:0,widthDiff:0,heightDiff:0};
  return `
    <div class="row" style="margin-bottom:10px">
      <label>使用プリンタを選択</label>
      <select id="wzPrinterSel">
        <option value="">— プリンタを選択 —</option>
        ${state.printerProfiles.map(p=>`<option value="${p.id}"${p.id===sel?' selected':''}>${escapeHtml(p.name)}</option>`).join('')}
      </select>
    </div>
    <div style="display:flex;gap:6px;margin-bottom:14px">
      <button class="btn sm" id="wzAddPrinter">＋ プリンタ新規登録</button>
      ${sel?'<button class="btn sm ghost" id="wzRemovePrinter">このプリンタを削除</button>':''}
    </div>
    ${sel?`
    <div class="printer-input-helper">
      <h5>このプリンタ × このテンプレートの補正値</h5>
      <p style="font-size:11px;color:#666;margin-bottom:10px">テスト印刷を実封筒に重ねて測ったズレを「見たまま」入力します。<strong>負の値も入力可</strong>（例：左に2mmズレた → 右ズレに -2）</p>
      <div class="ph-row">
        <label>印字が右に何mmズレた？</label>
        <input type="number" step="0.5" id="corrRS" value="${corr.rightShift}">
        <span class="unit">mm</span>
      </div>
      <div class="ph-row">
        <label>印字が下に何mmズレた？</label>
        <input type="number" step="0.5" id="corrDS" value="${corr.downShift}">
        <span class="unit">mm</span>
      </div>
      <div class="ph-row">
        <label>印字の横幅が本来より何mm広い？</label>
        <input type="number" step="0.5" id="corrWD" value="${corr.widthDiff}">
        <span class="unit">mm</span>
      </div>
      <div class="ph-row">
        <label>印字の縦幅が本来より何mm広い？</label>
        <input type="number" step="0.5" id="corrHD" value="${corr.heightDiff}">
        <span class="unit">mm</span>
      </div>
    </div>
    `:'<p style="font-size:11px;color:#888;padding:10px;background:var(--paper-2)">プリンタを登録すると補正値を入力できます。<br>登録不要ならこのまま次へ進めます（補正なしで印刷）</p>'}
  `;
}

function bindPrinterCalibForm(t){
  const sp=document.querySelector('#wzPrinterSel');
  if(sp) sp.addEventListener('change',e=>{
    state.selectedPrinterId=e.target.value||null;
    save();
    // ウィザードStep7なら再描画
    if(wizardState && wizardState.step===7) renderWzStep7($('wzBody'),$('wzFooter'));
    // ステップ4内なら別の再描画
    else renderPrinterProfileSection&&renderPrinterProfileSection();
  });
  const add=document.querySelector('#wzAddPrinter');
  if(add) add.addEventListener('click',async ()=>{
    // v37 step42: プリンタ名入力をブラウザ標準promptからDOM入力モーダルへ移行する。
    const name=await showAppPrompt('プリンタ名（例：オフィス1F EPSON）', '', 'プリンタ補正プロファイルの追加', {okLabel:'追加する'});
    if(!name||!name.trim()) return;
    const p={id:uid('p'),name:name.trim(),perTpl:{}};
    state.printerProfiles.push(p);
    state.selectedPrinterId=p.id;
    save();
    if(wizardState && wizardState.step===7) renderWzStep7($('wzBody'),$('wzFooter'));
    else renderPrinterProfileSection&&renderPrinterProfileSection();
  });
  const rm=document.querySelector('#wzRemovePrinter');
  if(rm) rm.addEventListener('click',async ()=>{
    const p=getCurrentPrinter();
    // v37 step37: プリンタ削除確認をブラウザ標準confirmからDOMモーダルへ移行する。
    if(p && await showAppConfirm(`プリンタ「${p.name}」を削除しますか？\n（すべてのテンプレートに対する補正値も失われます）`,'プリンタ補正プロファイルの削除',{okLabel:'削除する',danger:true})){
      state.printerProfiles=state.printerProfiles.filter(x=>x.id!==p.id);
      state.selectedPrinterId=null;
      save();
      if(wizardState && wizardState.step===7) renderWzStep7($('wzBody'),$('wzFooter'));
      else renderPrinterProfileSection&&renderPrinterProfileSection();
    }
  });
  ['corrRS','corrDS','corrWD','corrHD'].forEach(id=>{
    const inp=document.querySelector('#'+id);
    if(inp) inp.addEventListener('input',()=>{
      if(!state.selectedPrinterId) return;
      const c={
        rightShift:parseFloat(document.querySelector('#corrRS').value)||0,
        downShift:parseFloat(document.querySelector('#corrDS').value)||0,
        widthDiff:parseFloat(document.querySelector('#corrWD').value)||0,
        heightDiff:parseFloat(document.querySelector('#corrHD').value)||0
      };
      setPrinterCorrection(state.selectedPrinterId, t.id, c);
      // 補正変更もtestPrinted/printerCheckedをリセット
      if(t.adjustmentStatus){
        t.adjustmentStatus.testPrintedAt = null;
      }
      save();
      // ステップ4のサマリーも更新
      if(typeof updateStep4Summary==='function') updateStep4Summary();
    });
  });
}


function commitWizardDraft(){
  if(!wizardState || !wizardState.tpl) return null;
  const draft = normalizeTpl(JSON.parse(JSON.stringify(wizardState.tpl)));
  if(wizardState.mode==='new'){
    if(!state.templates.some(t=>t.id===draft.id)) state.templates.push(draft);
  }else{
    const id = wizardState.originalTplId || draft.id;
    draft.id = id;
    const idx = state.templates.findIndex(t=>t.id===id);
    if(idx>=0) state.templates[idx] = draft;
    else state.templates.push(draft);
  }
  state.selectedTplId = draft.id;
  state.lastUsedTplId = draft.id;
  return draft;
}

/* ----- Step8: 保存 ----- */
function renderWzStep8(body, footer){
  const t=wizardState.tpl;
  const stat=getTplAdjustmentSummary(t);
  body.innerHTML=`
    <h3 class="serif" style="font-size:18px;margin-bottom:6px">調整完了</h3>
    <p style="font-size:12px;color:#666;margin-bottom:14px">調整内容を確認して保存します</p>
    <div style="background:#fff;border:1px solid var(--line-soft);padding:18px;margin-bottom:14px">
      <div class="row"><label>テンプレート名</label><input type="text" id="wzFinalName" value="${escapeHtml(t.name)}"></div>
      <label class="checkbox-row" style="margin-top:10px"><input type="checkbox" id="wzPin" ${t.pinned?'checked':''}><span>★ お気に入りに追加（最初のページの上部に表示）</span></label>
      <label class="checkbox-row" style="margin-top:6px"><input type="checkbox" id="wzLock" ${t.locked?'checked':''}><span>🔒 ロックする（誤操作防止。再編集時はロック解除が必要）</span></label>
    </div>
    <div style="background:var(--paper-2);padding:14px;font-size:12px">
      <strong>調整内容サマリー</strong>
      <div style="margin-top:8px;display:flex;flex-direction:column;gap:5px">
        <div>📐 封筒サイズ：${t.w} × ${t.h} mm ${t.isReply?'<span class="pill reply">返信用</span>':'<span class="pill">通常</span>'}</div>
        <div>🖼 背景画像：${getBgImage(t)?`取込済 (${formatBytes(getBgImage(t).bytes||0)})`:'未取込'}</div>
        <div>${stat.bgAligned?'✓':'○'} 背景の位置合わせ：${stat.bgAligned?'調整済':'未調整'}</div>
        <div>${stat.zipChecked?'✓':'○'} 郵便番号枠：${stat.zipChecked?'調整済':'未調整'}</div>
        <div>${stat.layoutChecked?'✓':'○'} 宛名の位置：${stat.layoutChecked?'調整済':'未調整'}</div>
        <div>${stat.testPrinted?'✓':'○'} テスト印刷結果：${stat.testPrinted?'確認済':'未確認'}</div>
        <div>🖨 プリンタ：${state.selectedPrinterId?escapeHtml(getCurrentPrinter().name):'未選択'}</div>
      </div>
    </div>
  `;
  body.querySelector('#wzFinalName').addEventListener('input',e=>{t.name=e.target.value});
  body.querySelector('#wzPin').addEventListener('change',e=>{t.pinned=e.target.checked});
  body.querySelector('#wzLock').addEventListener('change',e=>{t.locked=e.target.checked});
  wzFooter(footer,{
    nextLabel:'✓ 保存して完了',
    onNext:()=>{
      const committed = commitWizardDraft();
      save(true);
      toast(`「${committed?committed.name:t.name}」の調整を保存しました`,'ok');
      closeWizard(true);
    }
  });
}
/* ============================================================
   ステップ2：詳細編集（詳細モード専用）
   ============================================================ */
/* v38-12: Step/UI描画関数群は js/48_steps_ui.js へ分離済み。 */

Object.assign(global, {
  makeWizardSnapshot,
  restoreWizardSnapshot,
  getWzSteps,
  openWizard,
  closeWizard,
  renderWizard,
  renderWizardStep,
  wzFooter,
  wizardNext,
  renderWzStep1,
  renderWzStep2,
  renderWzStep3,
  renderWzStep4,
  renderWzStep5,
  renderWzStep6,
  renderWzStep7,
  renderPrinterCalibForm,
  bindPrinterCalibForm,
  commitWizardDraft,
  renderWzStep8
});

global.EnvelopePrintWizard = Object.freeze({
  makeWizardSnapshot,
  restoreWizardSnapshot,
  getWzSteps,
  openWizard,
  closeWizard,
  renderWizard,
  renderWizardStep,
  wzFooter,
  wizardNext,
  commitWizardDraft,
  get state(){ return wizardState; }
});
})(typeof window !== 'undefined' ? window : globalThis);
