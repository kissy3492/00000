(function(){
  'use strict';
  const ADDON_KEY = 'paper_position_print_system_v37_stage8_validation';
  const MAX_RECORDS = 120;
  const DEFAULT_BROWSER = 'Edge / Chrome 推奨（印刷倍率100%、余白なし）';

  function el(id){ return document.getElementById(id); }
  function safe(s){ return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function now(){ return Date.now(); }
  function fmt(ts){ try{ return ts ? new Date(ts).toLocaleString('ja-JP') : '—'; }catch(e){ return '—'; } }
  function deepClone(x){ return JSON.parse(JSON.stringify(x)); }
  function currentTpl(){ try{return getCurrentTpl ? getCurrentTpl() : null;}catch(e){return null;} }
  function currentPrinter(){ try{return getCurrentPrinter ? getCurrentPrinter() : null;}catch(e){return null;} }
  function qValid(){ const t=currentTpl(); if(!t || !state || !Array.isArray(state.queue)) return []; return state.queue.filter(q=>q.tplId===t.id); }
  function currentProfileKey(tplId, printerId){ return `${tplId || 'none'}::${printerId || 'none'}`; }

  function loadStore(){
    try{
      const raw = localStorage.getItem(ADDON_KEY);
      if(raw){
        const d = JSON.parse(raw);
        if(!Array.isArray(d.records)) d.records = [];
        if(!d.profiles || typeof d.profiles !== 'object') d.profiles = {};
        if(!d.manualProgress || typeof d.manualProgress !== 'object') d.manualProgress = {};
        if(!d.settings || typeof d.settings !== 'object') d.settings = {};
        return d;
      }
    }catch(e){ console.warn('Stage8 validation store load failed', e); try{ toast('実機検証記録の読込に失敗しました','warn'); }catch(_e){} }
    return {version:1, records:[], profiles:{}, manualProgress:{}, settings:{createdAt:now(), updatedAt:null}};
  }
  let store = loadStore();
  function saveStore(){
    store.settings.updatedAt = now();
    try{
      localStorage.setItem(ADDON_KEY, JSON.stringify(store));
      return true;
    }catch(e){
      // v37 step9: 実機検証記録の保存失敗を黙殺せず、処理全体を落とさない。
      console.warn('Stage8 validation store save failed', e);
      try{ if(typeof toast === 'function') toast('実機検証記録の保存に失敗しました','warn'); }catch(_e){}
      return false;
    }
  }

  function getProfile(tplId, printerId){
    const key = currentProfileKey(tplId, printerId);
    if(!store.profiles[key]){
      store.profiles[key] = {
        tplId, printerId,
        feedDirection:'', envelopeFace:'', browser:DEFAULT_BROWSER,
        paperSizeNote:'', marginNote:'余白なし / 倍率100%', scaleNote:'100%',
        trayNote:'', memo:'', updatedAt:null
      };
    }
    return store.profiles[key];
  }
  function latestRecordsFor(tplId, printerId, limit=20){
    return (store.records || []).filter(r=>r.tplId===tplId && (!printerId || r.printerId===printerId)).sort((a,b)=>b.createdAt-a.createdAt).slice(0,limit);
  }
  function latestOkRecord(tplId, printerId){
    return latestRecordsFor(tplId, printerId, 80).find(r=>r.result==='ok');
  }
  function summarizeValidation(tpl, printer){
    if(!tpl) return {level:'ng', text:'テンプレート未選択', detail:'先に用紙テンプレートを選択してください'};
    const pid = printer ? printer.id : null;
    const rec = latestOkRecord(tpl.id, pid);
    const profile = getProfile(tpl.id, pid);
    if(rec){
      return {level:'ok', text:'実機検証記録あり', detail:`最終OK: ${fmt(rec.createdAt)} / ${rec.media || '用紙未記録'} / ${rec.feedDirection || profile.feedDirection || '給紙方向未記録'}`};
    }
    const any = latestRecordsFor(tpl.id, pid, 1)[0];
    if(any){ return {level:'warn', text:'OK記録なし', detail:`最新記録: ${fmt(any.createdAt)} / 結果=${resultLabel(any.result)}。本印刷前にOK記録を推奨`}; }
    return {level:'warn', text:'実機検証記録なし', detail:'テスト印刷後に検証記録を残すと、次回の給紙方向・補正判断が安定します'};
  }
  function resultLabel(v){ return ({ok:'OK', adjust:'要補正', ng:'NG'}[v] || v || '未記録'); }

  function closeStage8HostForTransition(host){
    // v37 step67: Stage8モーダル間の遷移では、直接innerHTMLを破棄せずa11y後片付けを通す。
    const h = host || el('modalContainer');
    if(!h) return;
    const current = h.querySelector && h.querySelector('.modal-overlay');
    if(current && window.closeAccessibleModal) closeAccessibleModal(current,{suppressFocusRestore:true});
    h.innerHTML = '';
  }

  function modal(title, bodyHtml, actionsHtml=''){
    const host = el('modalContainer') || document.body;
    closeStage8HostForTransition(host);
    host.innerHTML = `<div class="modal-overlay" data-stage8-modal="1"><div class="modal-box" style="min-width:min(920px,96vw);max-width:96vw"><h3>${safe(title)}</h3>${bodyHtml}<div class="actions">${actionsHtml}<button class="btn ghost" data-stage8-close>閉じる</button></div></div></div>`;
    const overlay = host.querySelector('.modal-overlay');
    if(overlay && window.applyLegacyModalA11y) applyLegacyModalA11y(overlay,{title:title||'検証記録', initialFocus:'[data-stage8-close]'});
    host.querySelectorAll('[data-stage8-close]').forEach(b=>b.addEventListener('click',()=>{ if(overlay) closeAccessibleModal(overlay); host.innerHTML=''; }));
    return host;
  }

  function injectTopButtons(){
    const bar = document.querySelector('.topbar .spacer');
    if(!bar || el('btnStage8Validation')) return;
    const wrap = document.createElement('div');
    wrap.style.display='flex'; wrap.style.gap='6px'; wrap.style.alignItems='center';
    wrap.innerHTML = `
      <button class="stage8-top-btn" id="btnStage8Validation">検証記録</button>
      <button class="stage8-top-btn" id="btnStage8PrinterGuide">印刷ガイド</button>
      <button class="stage8-top-btn" id="btnStage8FixNavi">補正ナビ</button>`;
    bar.after(wrap);
    el('btnStage8Validation').addEventListener('click', showValidationModal);
    el('btnStage8PrinterGuide').addEventListener('click', showPrinterGuideModal);
    el('btnStage8FixNavi').addEventListener('click', showFixNaviModal);
  }

  function showValidationModal(){
    const t = currentTpl();
    const p = currentPrinter();
    const profile = getProfile(t && t.id, p && p.id);
    const recs = t ? latestRecordsFor(t.id, p && p.id, 30) : [];
    const stat = summarizeValidation(t,p);
    const body = `
      <div class="stage8-${stat.level==='ok'?'ok':'warn'}"><b>${safe(stat.text)}</b><br>${safe(stat.detail)}</div>
      <div class="stage8-grid">
        <div class="stage8-card">
          <h4>今回のテスト結果を記録</h4>
          <div class="row r2"><div><label>テンプレート</label><input type="text" value="${safe(t?t.name:'未選択')}" disabled></div><div><label>プリンタ</label><input type="text" value="${safe(p?p.name:'未選択')}" disabled></div></div>
          <div class="row r2"><div><label>用紙・封筒</label><input type="text" id="s8Media" placeholder="例：長3 白封筒 / A4 12面ラベル"></div><div><label>結果</label><select id="s8Result"><option value="ok">OK：本印刷可</option><option value="adjust">要補正：ズレあり</option><option value="ng">NG：原因確認</option></select></div></div>
          <div class="row r2"><div><label>給紙方向</label><input type="text" id="s8Feed" value="${safe(profile.feedDirection)}" placeholder="例：〒枠を奥側、表面上向き"></div><div><label>封筒の向き・面</label><input type="text" id="s8Face" value="${safe(profile.envelopeFace)}" placeholder="例：表面上 / フラップ左"></div></div>
          <fieldset class="stage8-fieldset"><legend>ズレ実測値</legend>
            <div class="row r4"><div><label>右ズレ(mm)</label><input type="number" step="0.1" id="s8Right" value="0"></div><div><label>下ズレ(mm)</label><input type="number" step="0.1" id="s8Down" value="0"></div><div><label>横幅差(mm)</label><input type="number" step="0.1" id="s8Width" value="0"></div><div><label>縦幅差(mm)</label><input type="number" step="0.1" id="s8Height" value="0"></div></div>
          </fieldset>
          <div class="row"><label>メモ</label><textarea id="s8Memo" placeholder="例：封筒を逆向きにすると郵便番号が下に3mmズレる。Edgeで倍率100%。"></textarea></div>
          <div class="stage8-actions"><button class="btn primary" id="s8SaveRecord">検証記録を保存</button><button class="btn ghost" id="s8SaveAndApplyProfile">給紙メモにも反映</button></div>
        </div>
        <div class="stage8-card">
          <h4>検証サマリー</h4>
          ${renderRecordKpi(t && t.id, p && p.id)}
          <div class="stage8-note">OK記録は「このテンプレート＋このプリンタ」の組み合わせで保持します。用紙・封筒の向きが変わる場合は別途メモしてください。</div>
          <h4 style="margin-top:14px">最近の記録</h4>
          ${renderRecords(recs)}
        </div>
      </div>`;
    const host = modal('実機検証記録', body, '<button class="btn ghost" id="s8ExportRecords">記録JSONを表示</button>');
    const commitValidationRecord = (alsoProfile)=>{
      const rec = {
        id:'vr_'+Math.random().toString(36).slice(2,9), createdAt:now(),
        tplId:t&&t.id, tplName:t&&t.name, printerId:p&&p.id, printerName:p&&p.name,
        media:val('s8Media'), result:val('s8Result'), feedDirection:val('s8Feed'), envelopeFace:val('s8Face'),
        rightShift:num('s8Right'), downShift:num('s8Down'), widthDiff:num('s8Width'), heightDiff:num('s8Height'), memo:val('s8Memo')
      };
      store.records.unshift(rec); store.records = store.records.slice(0, MAX_RECORDS);
      if(alsoProfile){
        profile.feedDirection = rec.feedDirection; profile.envelopeFace = rec.envelopeFace; profile.updatedAt = now();
      }
      // OKならテンプレート側の最終検証時刻も軽く更新する。既存構造を壊さないためStage8専用プロパティにする。
      if(t && rec.result==='ok'){
        if(!t.stage8) t.stage8 = {};
        t.stage8.lastValidationOkAt = rec.createdAt;
        try{
          if(window.EnvelopePrintModules && window.EnvelopePrintModules.Storage && typeof window.EnvelopePrintModules.Storage.save === 'function') window.EnvelopePrintModules.Storage.save(true);
          else if(window.save && window.save !== commitValidationRecord) window.save(true);
        }catch(e){ console.warn('base save failed after validation record', e); }
      }
      saveStore(); toast('検証記録を保存しました', 'ok'); showValidationModal();
    };
    const b1 = el('s8SaveRecord'); if(b1) b1.addEventListener('click',()=>commitValidationRecord(false));
    const b2 = el('s8SaveAndApplyProfile'); if(b2) b2.addEventListener('click',()=>commitValidationRecord(true));
    const be = el('s8ExportRecords'); if(be) be.addEventListener('click', showRecordExportModal);
  }
  function val(id){ const x=el(id); return x ? x.value.trim() : ''; }
  function num(id){ const n = Number(val(id)); return Number.isFinite(n) ? n : 0; }
  function renderRecordKpi(tplId, printerId){
    const a = latestRecordsFor(tplId, printerId, 999);
    const ok = a.filter(r=>r.result==='ok').length, adj=a.filter(r=>r.result==='adjust').length, ng=a.filter(r=>r.result==='ng').length;
    return `<div class="stage8-kpi"><div><b>${a.length}</b>全記録</div><div><b>${ok}</b>OK</div><div><b>${adj}</b>要補正</div><div><b>${ng}</b>NG</div></div>`;
  }
  function renderRecords(records){
    if(!records || !records.length) return '<div class="empty-state" style="padding:18px">検証記録はまだありません</div>';
    return `<div class="stage8-record-list">${records.map(r=>`<div class="stage8-record ${r.result==='ok'?'ok':'warn'}"><div class="title">${safe(resultLabel(r.result))} / ${safe(r.media||'用紙未記録')}</div><div class="meta">${safe(fmt(r.createdAt))}<br>給紙: ${safe(r.feedDirection||'未記録')} / 向き: ${safe(r.envelopeFace||'未記録')}<br>ズレ: 右${safe(r.rightShift)}mm・下${safe(r.downShift)}mm・横幅差${safe(r.widthDiff)}mm・縦幅差${safe(r.heightDiff)}mm<br>${safe(r.memo||'')}</div></div>`).join('')}</div>`;
  }

  function showRecordExportModal(){
    modal('検証記録JSON', `<p>検証記録を退避する場合は、下のJSONをコピーしてください。</p><textarea class="backup-textarea" readonly>${safe(JSON.stringify(store,null,2))}</textarea>`, '<button class="btn" id="s8CopyRecords">コピー</button>');
    const b=el('s8CopyRecords'); if(b) b.addEventListener('click',()=>copyText(JSON.stringify(store,null,2)));
  }

  function showPrinterGuideModal(){
    const t=currentTpl(), p=currentPrinter();
    const profile = getProfile(t&&t.id, p&&p.id);
    const stat = summarizeValidation(t,p);
    const body = `
      <div class="stage8-banner"><b>対象：</b>${safe(t?t.name:'テンプレート未選択')} / ${safe(p?p.name:'プリンタ未選択')}</div>
      <div class="stage8-grid">
        <div class="stage8-card">
          <h4>プリンタ・給紙メモ</h4>
          <div class="row"><label>推奨ブラウザ・印刷倍率</label><input type="text" id="s8Browser" value="${safe(profile.browser||DEFAULT_BROWSER)}"></div>
          <div class="row"><label>用紙サイズ設定</label><input type="text" id="s8PaperSize" value="${safe(profile.paperSizeNote)}" placeholder="例：長形3号 / ユーザー定義 120×235mm"></div>
          <div class="row"><label>余白・倍率</label><input type="text" id="s8Margin" value="${safe(profile.marginNote||'余白なし / 倍率100%')}"></div>
          <div class="row"><label>給紙方向</label><input type="text" id="s8GuideFeed" value="${safe(profile.feedDirection)}" placeholder="例：〒枠を奥、表面上向き"></div>
          <div class="row"><label>トレイ・差し込み口</label><input type="text" id="s8Tray" value="${safe(profile.trayNote)}" placeholder="例：手差しトレイ / 中央寄せ"></div>
          <div class="row"><label>メモ</label><textarea id="s8GuideMemo">${safe(profile.memo||'')}</textarea></div>
          <button class="btn primary" id="s8SaveGuide">この設定メモを保存</button>
        </div>
        <div class="stage8-card">
          <h4>本印刷前の推奨確認</h4>
          ${renderGuideChecklist(stat, profile)}
          <h4 style="margin-top:12px">手動検証チェックリスト</h4>
          ${renderManualPrintVerificationChecklist(t,p,profile,stat)}
          <div class="stage8-actions"><button class="btn ghost" id="s8OpenValidationFromGuide">検証記録を開く</button><button class="btn ghost" id="s8OpenNaviFromGuide">補正ナビを開く</button><button class="btn ghost" id="s8OpenManualChecklistFromGuide">手動チェックを開く</button></div>
        </div>
      </div>`;
    modal('印刷ガイド・給紙方向メモ', body);
    const bs=el('s8SaveGuide'); if(bs) bs.addEventListener('click',()=>{
      profile.browser=val('s8Browser'); profile.paperSizeNote=val('s8PaperSize'); profile.marginNote=val('s8Margin'); profile.feedDirection=val('s8GuideFeed'); profile.trayNote=val('s8Tray'); profile.memo=val('s8GuideMemo'); profile.updatedAt=now(); saveStore(); toast('印刷ガイドを保存しました', 'ok'); showPrinterGuideModal();
    });
    const bv=el('s8OpenValidationFromGuide'); if(bv) bv.addEventListener('click', showValidationModal);
    const bn=el('s8OpenNaviFromGuide'); if(bn) bn.addEventListener('click', showFixNaviModal);
    const bm=el('s8OpenManualChecklistFromGuide'); if(bm) bm.addEventListener('click', showManualPrintChecklistModal);
  }
  function manualChecklistDefinitions(t, p, profile, stat){
    // v37 step65: 実機印刷チェックリストを状態付きUIとして扱うため、項目定義を一元化する。
    const kind = t ? (t.paperKind || 'envelope') : 'unknown';
    const media = t ? `${t.name}（${t.w}×${t.h}mm）` : 'テンプレート未選択';
    const printer = p ? p.name : 'プリンタ未選択';
    const defs = [
      {id:'target', section:'基本', label:'対象確認', detail:`テンプレート：${media} / プリンタ：${printer}`},
      {id:'dialog', section:'基本', label:'印刷ダイアログ', detail:`用紙サイズ=${(profile&&profile.paperSizeNote)||'実機で確認'}、余白/倍率=${(profile&&profile.marginNote)||'余白なし・100%'}、ブラウザ=${(profile&&profile.browser)||DEFAULT_BROWSER}`},
      {id:'feed', section:'基本', label:'給紙方向', detail:(profile&&profile.feedDirection) ? profile.feedDirection : '表裏・上下・フラップ方向・トレイ位置をテスト印刷時に記録'},
      {id:'test_one', section:'基本', label:'テスト印刷', detail:'まず1件だけ印刷し、普通紙・不要封筒・余りラベルで位置を確認'},
      {id:'zip_name', section:'基本', label:'郵便番号/宛名', detail:'郵便番号枠、住所、氏名、会社名、差出人が枠内に収まり、端切れしないことを確認'},
      {id:'reproducibility', section:'基本', label:'再現性', detail:'同じ設定で再印刷してズレが再現するか確認。1回だけの偶然で補正しない'},
      {id:'validation_record', section:'基本', label:'記録', detail:`結果確認状態：${stat&&stat.text?stat.text:'未確認'}。検証記録に用紙、向き、ズレ実測値、補正値、メモを残す`}
    ];
    if(kind==='label_sheet') defs.push({id:'label_sheet', section:'用紙別', label:'ラベル固有', detail:'開始面、列数、行数、横/縦ピッチ、最終面のズレを確認'});
    if(kind==='window_envelope' || kind==='window_document') defs.push({id:'window', section:'用紙別', label:'窓付き固有', detail:'窓から宛名が切れず、三つ折り/差し込み向きで隠れないことを確認'});
    if(kind==='form_overlay' || kind==='certificate') defs.push({id:'form_overlay', section:'用紙別', label:'帳票/証明書固有', detail:'既存罫線・枠・押印欄と印字位置が重ならないことを確認'});
    return defs;
  }

  function manualProgressKey(tplId, printerId){ return currentProfileKey(tplId, printerId); }
  function getManualPrintProgress(tplId, printerId){
    if(!store.manualProgress || typeof store.manualProgress !== 'object') store.manualProgress = {};
    const key = manualProgressKey(tplId, printerId);
    if(!store.manualProgress[key]) store.manualProgress[key] = {tplId:tplId||null, printerId:printerId||null, updatedAt:null, items:{}};
    if(!store.manualProgress[key].items || typeof store.manualProgress[key].items !== 'object') store.manualProgress[key].items = {};
    return store.manualProgress[key];
  }
  function setManualPrintProgressItem(tplId, printerId, itemId, checked){
    const progress = getManualPrintProgress(tplId, printerId);
    progress.items[itemId] = !!checked;
    progress.updatedAt = now();
    return saveStore();
  }
  function clearManualPrintProgress(tplId, printerId){
    if(!store.manualProgress || typeof store.manualProgress !== 'object') return true;
    delete store.manualProgress[manualProgressKey(tplId, printerId)];
    return saveStore();
  }
  function manualProgressSummary(defs, progress){
    const total = defs.length;
    const done = defs.filter(d=>progress && progress.items && progress.items[d.id]).length;
    return {total, done, text:`${done}/${total}件完了`};
  }

  function renderManualPrintVerificationChecklist(t, p, profile, stat){
    // v37 step65: Markdown風の擬似チェックではなく、アプリ内で状態を持つチェックボックスUIにする。
    const defs = manualChecklistDefinitions(t,p,profile,stat);
    const progress = getManualPrintProgress(t&&t.id, p&&p.id);
    const rows = defs.map(d=>{
      const checked = progress.items && progress.items[d.id];
      const cid = `s8ManualCheck_${d.id}`;
      return `<tr><th><label for="${safe(cid)}" class="checkline"><input type="checkbox" id="${safe(cid)}" data-manual-check="${safe(d.id)}" ${checked?'checked':''}> ${safe(d.label)}</label></th><td><b>${safe(d.section)}</b>：${safe(d.detail)}</td></tr>`;
    }).join('');
    const summary = manualProgressSummary(defs, progress);
    const updated = progress.updatedAt ? ` / 最終更新 ${fmt(progress.updatedAt)}` : '';
    return `<div class="stage8-note" id="s8ManualProgressSummary">チェック進捗：${safe(summary.text)}${safe(updated)}</div><table class="stage8-table" aria-label="実機印刷手動検証チェックリスト"><thead><tr><th>確認項目</th><th>見るポイント</th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  function renderManualPrintFailureChecklist(){
    // v37 step53: 失敗時にどこから疑うかを固定化し、場当たり的なフィールド移動を防ぐ。
    const rows = [
      ['全体が同じ方向にズレる', 'フィールド個別移動ではなく、プリンタ補正の右ズレ/下ズレを先に疑う'],
      ['全体が拡大・縮小される', 'ブラウザ印刷倍率、用紙サイズ、余白設定、横幅差/縦幅差を確認'],
      ['郵便番号だけズレる', '郵便番号フィールド、桁間、3桁後の空き、〒マーク設定だけを確認'],
      ['住所・氏名だけ崩れる', 'フィールド幅、高さ、文字サイズ、自動縮小、縦書き変換を確認'],
      ['端が切れる', 'プリンタ非印字領域、余白なし設定、用紙向き、print-layer補正の過大値を確認'],
      ['ラベルで後半ほどズレる', 'ラベル幅/高さではなく横ピッチ/縦ピッチ、開始面、用紙の実寸を確認'],
      ['窓から外れる', '中身の紙の折り位置、封筒への差し込み向き、窓枠サイズを先に確認']
    ];
    return `<table class="stage8-table" aria-label="印刷失敗時の切り分け表"><thead><tr><th>症状</th><th>最初に疑う箇所</th></tr></thead><tbody>${rows.map(([a,b])=>`<tr><th>${safe(a)}</th><td>${safe(b)}</td></tr>`).join('')}</tbody></table>`;
  }

  function buildManualPrintVerificationReport(t, p, profile, stat){
    // v37 step63: 実機印刷で確認した内容を外部メモへ退避しやすいよう、手動検証レポートを生成する。
    // v37 step65: アプリ内チェック状態を[x]/[ ]へ反映し、レポート本文とUI状態を一致させる。
    const MANUAL_REPORT_RECENT_LIMIT = 5;
    const latest = t ? latestRecordsFor(t.id, p && p.id, MANUAL_REPORT_RECENT_LIMIT) : [];
    const kind = t ? (t.paperKind || 'envelope') : 'unknown';
    const defs = manualChecklistDefinitions(t,p,profile,stat);
    const progress = getManualPrintProgress(t&&t.id, p&&p.id);
    const summary = manualProgressSummary(defs, progress);
    const lines = [
      '# 実機印刷検証レポート',
      '',
      `作成日時: ${fmt(now())}`,
      `テンプレート: ${t ? t.name : '未選択'}`,
      `用紙種別: ${kind}`,
      `用紙サイズ: ${t ? `${t.w}×${t.h}mm` : '未選択'}`,
      `プリンタ: ${p ? p.name : '未選択'}`,
      `推奨ブラウザ/倍率: ${(profile && profile.browser) || DEFAULT_BROWSER} / ${(profile && profile.marginNote) || '余白なし・倍率100%'}`,
      `給紙方向: ${(profile && profile.feedDirection) || '未記録'}`,
      `トレイ: ${(profile && profile.trayNote) || '未記録'}`,
      `検証状態: ${stat && stat.text ? stat.text : '未確認'} - ${stat && stat.detail ? stat.detail : ''}`,
      `チェック進捗: ${summary.text}${progress.updatedAt ? ` / 最終更新 ${fmt(progress.updatedAt)}` : ''}`,
      '',
      '## チェック結果'
    ];
    defs.forEach(d=>{
      const mark = progress.items && progress.items[d.id] ? 'x' : ' ';
      lines.push(`- [${mark}] ${d.label}: ${d.detail}`);
    });
    lines.push('', `## 最近の検証記録（最大${MANUAL_REPORT_RECENT_LIMIT}件）`);
    if(latest.length){
      latest.forEach((r,i)=>{
        lines.push(`${i+1}. ${fmt(r.createdAt)} / ${resultLabel(r.result)} / ${r.media || '用紙未記録'} / 右${r.rightShift||0}mm 下${r.downShift||0}mm / ${r.memo || ''}`);
      });
    }else{
      lines.push('なし');
    }
    lines.push('', '## メモ', '- ');
    return lines.join('\n');
  }

  function updateManualChecklistReport(t,p,profile,stat,reportText){
    if(reportText) reportText.value = buildManualPrintVerificationReport(t,p,profile,stat);
    const summaryEl = el('s8ManualProgressSummary');
    if(summaryEl){
      const defs = manualChecklistDefinitions(t,p,profile,stat);
      const progress = getManualPrintProgress(t&&t.id, p&&p.id);
      const summary = manualProgressSummary(defs, progress);
      const updated = progress.updatedAt ? ` / 最終更新 ${fmt(progress.updatedAt)}` : '';
      summaryEl.textContent = `チェック進捗：${summary.text}${updated}`;
    }
  }

  function bindManualChecklistHandlers(t,p,profile,stat,reportText){
    document.querySelectorAll('[data-manual-check]').forEach(chk=>{
      chk.addEventListener('change',()=>{
        setManualPrintProgressItem(t&&t.id, p&&p.id, chk.dataset.manualCheck, chk.checked);
        updateManualChecklistReport(t,p,profile,stat,reportText);
        toast('手動チェック状態を保存しました', 'ok');
      });
    });
  }

  function showManualPrintChecklistModal(){
    const t=currentTpl(), p=currentPrinter();
    const profile = getProfile(t&&t.id, p&&p.id);
    const stat = summarizeValidation(t,p);
    const report = buildManualPrintVerificationReport(t,p,profile,stat);
    const body = `
      <div class="stage8-banner">このチェックリストは、実機印刷前後に人間が確認するためのものです。チェック状態はテンプレート＋プリンタ単位で保存され、レポートにも反映されます。</div>
      <div class="stage8-grid">
        <div class="stage8-card"><h4>実機印刷 手動検証チェックリスト</h4>${renderManualPrintVerificationChecklist(t,p,profile,stat)}</div>
        <div class="stage8-card"><h4>失敗時の切り分け</h4>${renderManualPrintFailureChecklist()}<div class="stage8-warn">補正やフィールド移動を行った後は、テスト印刷結果確認をリセットし、再テストしてください。</div></div>
      </div>
      <div class="stage8-card" style="margin-top:12px"><h4>実機検証レポート</h4><p class="stage8-note">印刷結果を確認したら、このレポートをコピーして検証記録・作業メモ・Teams等へ貼り付けてください。チェック状態はこのレポートに反映されます。</p><textarea class="backup-textarea" id="s8ManualReportText" readonly></textarea></div>`;
    const host = modal('実機印刷 手動検証チェックリスト', body, '<button class="btn" id="s8CopyManualReport">レポートをコピー</button><button class="btn ghost" id="s8ResetManualProgress">チェックをリセット</button><button class="btn ghost" id="s8ManualOpenValidation">検証記録を開く</button>');
    const reportText=el('s8ManualReportText'); if(reportText) reportText.value=report;
    bindManualChecklistHandlers(t,p,profile,stat,reportText);
    const bc=el('s8CopyManualReport'); if(bc) bc.addEventListener('click',()=>copyText(reportText?reportText.value:buildManualPrintVerificationReport(t,p,profile,stat),{fallbackElement:reportText}));
    const br=el('s8ResetManualProgress'); if(br) br.addEventListener('click',async ()=>{
      if(!await showAppConfirm('このテンプレートとプリンタの手動チェック状態をリセットしますか？','手動チェックのリセット',{okLabel:'リセットする',danger:true})) return;
      clearManualPrintProgress(t&&t.id, p&&p.id);
      showManualPrintChecklistModal();
    });
    const bv=el('s8ManualOpenValidation'); if(bv) bv.addEventListener('click',()=>{ showValidationModal(); });
  }

  function renderGuideChecklist(stat, profile){
    const lines = [
      ['用紙サイズ', profile.paperSizeNote ? profile.paperSizeNote : '未記録。プリンタダイアログで封筒/用紙サイズを確認'],
      ['余白・倍率', profile.marginNote || '余白なし、倍率100%'],
      ['給紙方向', profile.feedDirection || '未記録。テスト印刷結果確認後に記録推奨'],
      ['トレイ', profile.trayNote || '未記録'],
      ['実機検証', stat.detail]
    ];
    return `<table class="stage8-table"><tbody>${lines.map(([a,b])=>`<tr><th>${safe(a)}</th><td>${safe(b)}</td></tr>`).join('')}</tbody></table>`;
  }

  function showFixNaviModal(){
    const body = `
      <div class="stage8-banner">印刷結果の症状を選ぶと、どこを直すべきかを切り分けます。ここでは設定変更はせず、修正手順を案内します。</div>
      <div class="stage8-grid">
        <div class="stage8-card"><h4>症状を選択</h4>
          ${check('pos_all','全体が右/左/上/下に同じ量だけズレる')}
          ${check('scale','印字全体が拡大・縮小される')}
          ${check('zip','郵便番号だけ枠からズレる')}
          ${check('field','住所や氏名だけ位置がおかしい')}
          ${check('clip','端が切れる、印字が欠ける')}
          ${check('label','ラベル面の途中からズレが増える')}
          ${check('window','窓付き封筒で窓から外れる')}
          <button class="btn primary" id="s8BuildNavi" style="margin-top:10px;width:100%">対処手順を表示</button>
        </div>
        <div class="stage8-card"><h4>対処手順</h4><div id="s8NaviResult"><div class="empty-state" style="padding:18px">症状を選んでください</div></div></div>
      </div>`;
    modal('失敗時の補正ナビ', body);
    const b=el('s8BuildNavi'); if(b) b.addEventListener('click',()=>{ const r=el('s8NaviResult'); if(r) r.innerHTML = buildNaviResult(); });
  }
  function check(id,label){ return `<label class="checkbox-row"><input type="checkbox" id="s8_${id}"><span>${safe(label)}</span></label>`; }
  function checked(id){ const x=el('s8_'+id); return !!(x && x.checked); }
  function buildNaviResult(){
    const items=[];
    if(checked('pos_all')) items.push(['全体ズレ','プリンタ補正の「右ズレ」「下ズレ」を使う。テンプレート上のフィールドを動かす前に、十字マーク・罫線テストで全体ズレか確認する。']);
    if(checked('scale')) items.push(['拡大縮小','ブラウザ印刷倍率が100%か確認。まだズレる場合だけ、プリンタ補正の横幅差・縦幅差を記録する。']);
    if(checked('zip')) items.push(['郵便番号だけズレ','郵便番号フィールドまたは郵便番号詳細設定だけを動かす。住所・宛名全体やプリンタ補正を変えない。']);
    if(checked('field')) items.push(['住所・氏名だけズレ','該当フィールドの位置・幅・文字サイズを修正。変更後はテスト印刷済み状態をリセットし、再テストする。']);
    if(checked('clip')) items.push(['端切れ','プリンタの非印字領域または余白設定を疑う。余白なし設定、用紙サイズ、封筒の向きを確認。print-layer補正を大きくしすぎていないか確認。']);
    if(checked('label')) items.push(['ラベル面ズレ','面付けの列数・行数・ラベル幅/高さ・横/縦ピッチ・開始面を確認。1面目だけでなく最終面もテストする。']);
    if(checked('window')) items.push(['窓付き封筒','封筒ではなく中身の紙側に印字しているか確認。三つ折り位置、窓位置、差し込み向きを先に確認。']);
    if(!items.length) return '<div class="empty-state" style="padding:18px">症状が選択されていません</div>';
    return items.map(([h,d],i)=>`<div class="stage8-stepbox"><strong>${i+1}. ${safe(h)}</strong><div class="stage8-note">${safe(d)}</div></div>`).join('') + '<div class="stage8-warn">修正後は、必ずテスト印刷をやり直し、結果確認と検証記録を残してください。</div>';
  }

  function patchFinalChecklist(){
    // v37 step22: renderFinalChecklistの直接上書きを廃止し、Step5ExtensionRegistryへ登録する。
    if(window.Step5ExtensionRegistry && typeof window.Step5ExtensionRegistry.registerRenderHook === 'function'){
      window.Step5ExtensionRegistry.registerRenderHook(function stage8FinalChecklistHook(){
        try{ appendValidationToFinal(); }catch(e){ console.warn('Stage8 final append failed', e); }
      }, 'Stage8 final validation panel');
    }
  }
  function appendValidationToFinal(){
    const box = el('finalChecklist'); if(!box) return;
    const t=currentTpl(), p=currentPrinter();
    const stat = summarizeValidation(t,p);
    const div = document.createElement('div');
    div.className = stat.level==='ok' ? 'checklist-item ok' : 'checklist-item warn';
    div.innerHTML = `<div class="ci-icon">${stat.level==='ok'?'✓':'!'}</div><div class="ci-text"><div class="ci-label">実機検証記録</div><div class="ci-detail">${safe(stat.text)}：${safe(stat.detail)}</div><div class="stage8-actions"><button class="btn ghost sm" id="s8FinalValidation">検証記録</button><button class="btn ghost sm" id="s8FinalGuide">印刷ガイド</button><button class="btn ghost sm" id="s8FinalManualChecklist">手動チェック</button><button class="btn ghost sm" id="s8FinalNavi">補正ナビ</button></div></div>`;
    box.appendChild(div);
    const a=el('s8FinalValidation'); if(a) a.addEventListener('click', showValidationModal);
    const b=el('s8FinalGuide'); if(b) b.addEventListener('click', showPrinterGuideModal);
    const m=el('s8FinalManualChecklist'); if(m) m.addEventListener('click', showManualPrintChecklistModal);
    const c=el('s8FinalNavi'); if(c) c.addEventListener('click', showFixNaviModal);
  }

  function patchPrint(){
    // v37 step22: doPrintの直接上書きを廃止し、印刷実行hookで試行情報を記録する。
    if(window.PrintExecutionRegistry && typeof window.PrintExecutionRegistry.registerBeforePrintHook === 'function'){
      window.PrintExecutionRegistry.registerBeforePrintHook(function stage8PrintAttemptHook(context){
        try{
          const opts = (context && context.opts) || {};
          const t=(context&&context.tpl)||currentTpl(), p=(context&&context.printer)||currentPrinter();
          store.lastPrintAttempt = {createdAt:now(), tplId:t&&t.id, tplName:t&&t.name, printerId:p&&p.id, printerName:p&&p.name, count:(opts&&opts.queue&&opts.queue.length)||0, mode:state&&state.uiMode};
          saveStore();
        }catch(e){ console.warn('Stage8 print attempt record failed', e); }
      }, 'Stage8 print attempt record');
    }
  }

  function patchStep4(){
    const box = document.querySelector('.step-content[data-step="4"] .print-summary');
    if(!box || el('stage8Step4Panel')) return;
    const panel = document.createElement('div');
    panel.id='stage8Step4Panel';
    panel.style.marginTop='12px';
    panel.innerHTML = `<button class="btn ghost sm" id="s8Step4Record" style="width:100%;margin-bottom:6px">テスト結果を記録</button><button class="btn ghost sm" id="s8Step4Guide" style="width:100%">給紙メモを見る</button>`;
    box.appendChild(panel);
    el('s8Step4Record').addEventListener('click', showValidationModal);
    el('s8Step4Guide').addEventListener('click', showPrinterGuideModal);
  }

  function copyText(txt, options){
    const opt = options || {};
    if(window.copyTextToClipboard){
      window.copyTextToClipboard(txt,{successMessage:'コピーしました', fallbackMessage:'テキストを選択しました（Ctrl+Cでコピー）', fallbackElement:opt.fallbackElement});
      return;
    }
    toast('コピー機能を利用できません。テキストを手動で選択してください', 'warn');
  }
  // v37 step66: Stage8専用通知ラッパーを撤去し、通知は本体toastへ統一する。

  function initStage8(){
    injectTopButtons(); patchFinalChecklist(); patchPrint(); patchStep4();
    const mods = window.EnvelopePrintModules || (window.EnvelopePrintModules = {Extensions:{}});
    if(!mods.Extensions) mods.Extensions = {};
    mods.Extensions.Stage8 = {showValidationModal, showPrinterGuideModal, showManualPrintChecklistModal, showFixNaviModal, store, summarizeValidation, latestRecordsFor};
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', initStage8); else initStage8();
})();
