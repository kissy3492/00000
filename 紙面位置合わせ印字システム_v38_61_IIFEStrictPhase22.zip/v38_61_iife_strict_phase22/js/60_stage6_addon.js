(function(){
  'use strict';
  const ADDON_KEY = 'paper_position_print_system_v37_stage6';
  const ZIP_RE = /\d{3}-?\d{4}/;
  let addon = loadStage6();

  function loadStage6(){
    try{
      const raw = localStorage.getItem(ADDON_KEY);
      if(raw){
        const d = JSON.parse(raw);
        if(!d.zipDict || typeof d.zipDict !== 'object') d.zipDict = {};
        if(!d.settings || typeof d.settings !== 'object') d.settings = {};
        return d;
      }
    }catch(e){ console.warn('Stage6 addon load failed', e); try{ toast('郵便番号辞書データの読込に失敗しました','warn'); }catch(_e){} }
    return {zipDict:{}, settings:{}, savedAt:null};
  }
  function saveStage6(){
    addon.savedAt = Date.now();
    try{
      localStorage.setItem(ADDON_KEY, JSON.stringify(addon));
      return true;
    }catch(e){
      // v37 step9: Stage6拡張データの保存失敗を黙殺せず、処理全体を落とさない。
      console.warn('Stage6 addon save failed', e);
      try{ if(typeof toast === 'function') toast('郵便番号辞書・住所補助データの保存に失敗しました','warn'); }catch(_e){}
      return false;
    }
  }
  function byId(id){ return document.getElementById(id); }
  function esc(s){
    if(window.escapeHtml) return escapeHtml(s==null?'':s);
    return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }
  function half(s){ return String(s||'').replace(/[！-～]/g,ch=>String.fromCharCode(ch.charCodeAt(0)-0xFEE0)).replace(/　/g,' '); }
  function fullDigits(s){ return String(s||'').replace(/[0-9]/g,d=>'０１２３４５６７８９'[+d]); }
  function normalizeZip6(v){
    let s = half(v).replace(/[〒\s]/g,'').replace(/[^0-9-]/g,'').replace(/-/g,'');
    if(s.length>7) s=s.slice(0,7);
    return s.length>3 ? s.slice(0,3)+'-'+s.slice(3) : s;
  }
  const JP_DIGITS = ['〇','一','二','三','四','五','六','七','八','九'];
  function digitStringToKanji(s){ return String(s||'').replace(/[0-9０-９]/g,ch=>JP_DIGITS[+half(ch)]||ch); }
  function normalizeText(s){ return half(s).replace(/[ \t]+/g,' ').replace(/[‐‑‒–—―ー−]/g,'-').trim(); }
  function normalizeAddressLoose(s){
    return normalizeText(s)
      .replace(/(\d+)\s*丁目/g,'$1丁目')
      .replace(/(\d+)\s*番地?/g,'$1番')
      .replace(/(\d+)\s*号/g,'$1号')
      .replace(/\s*,\s*/g,' ');
  }
  function formalizeJapaneseAddress(s){
    let v = normalizeAddressLoose(s);
    // 末尾付近の 1-2-3 / 1-2 を、任意の候補として「丁目・番・号」型へ寄せる。
    v = v.replace(/(\d+)-([0-9]+)-([0-9]+)(?![0-9])/g, '$1丁目$2番$3号');
    v = v.replace(/(\d+)-([0-9]+)(?![0-9])/g, '$1番$2号');
    return v;
  }
  function toVerticalAddress(s, mode){
    let v = String(s||'');
    if(mode==='wide') return fullDigits(normalizeAddressLoose(v)).replace(/-/g,'－');
    if(mode==='kanji') return digitStringToKanji(normalizeAddressLoose(v)).replace(/-/g,'ー');
    if(mode==='formal') return digitStringToKanji(formalizeJapaneseAddress(v));
    return v;
  }
  function getTpl(){ try{ return window.getCurrentTpl ? getCurrentTpl() : null; }catch(e){ return null; } }
  function getInput(){ try{ return window.getInputData ? getInputData() : {}; }catch(e){ return {}; } }
  function setVal(id,v){ const el=byId(id); if(el) el.value = v==null?'':String(v); }

  function parseZipDictionaryText(text){
    const out = {};
    String(text||'').split(/\r?\n/).forEach(line=>{
      const raw = line.trim();
      if(!raw) return;
      const cells = raw.includes('\t') ? raw.split('\t') : raw.split(',');
      const zidx = cells.findIndex(c=>ZIP_RE.test(half(c)));
      if(zidx < 0) return;
      const zip = normalizeZip6((half(cells[zidx]).match(ZIP_RE)||[''])[0]);
      let addr = '';
      // 日本郵便のCSVをExcelから貼り付けた場合：郵便番号は3列目、住所は7〜9列目に来ることが多い。
      if(cells.length >= 9 && zidx === 2){
        addr = [cells[6],cells[7],cells[8]].filter(Boolean).join('');
      }else{
        addr = cells.slice(zidx+1).join('').trim() || cells.filter((_,i)=>i!==zidx).slice(-3).join('');
      }
      addr = normalizeAddressLoose(addr.replace(/^"|"$/g,''));
      if(!zip || zip.length < 8 || !addr) return;
      if(!out[zip]) out[zip] = [];
      if(!out[zip].includes(addr)) out[zip].push(addr);
    });
    return out;
  }
  function lookupZip(zip){ return addon.zipDict[normalizeZip6(zip)] || []; }
  function importZipText(text, merge=true){
    const parsed = parseZipDictionaryText(text);
    let count = 0;
    if(!merge) addon.zipDict = {};
    Object.entries(parsed).forEach(([zip,addrs])=>{
      if(!addon.zipDict[zip]) addon.zipDict[zip]=[];
      addrs.forEach(a=>{ if(!addon.zipDict[zip].includes(a)){ addon.zipDict[zip].push(a); count++; } });
    });
    saveStage6();
    return {zipCount:Object.keys(parsed).length, addrCount:count};
  }
  function dictCount(){ return Object.values(addon.zipDict).reduce((a,b)=>a+(Array.isArray(b)?b.length:0),0); }

  function suggestHonor(data, tpl){
    data = data || {};
    if(tpl && tpl.isReply) return '行';
    if((data.company || data.corp || data.dept) && !data.name) return '御中';
    if(data.name) return '様';
    return data.honor || '様';
  }
  function applySuggestedHonor(){
    const tpl = getTpl(); const d = getInput(); const h = suggestHonor(d,tpl);
    if(byId('iHonor')) byId('iHonor').value = h;
    if(window.toast) toast(`敬称を「${h}」にしました`,'ok');
    renderAddressAssistPanel();
  }
  function applyZipSuggestion(addr){
    if(!addr) return;
    const a1 = byId('iAddr');
    if(a1) a1.value = addr;
    if(window.toast) toast('郵便番号辞書の住所を反映しました','ok');
    renderAddressAssistPanel();
  }
  function normalizeCurrentInput(){
    const d = getInput();
    setVal('iZip', normalizeZip6(d.zip));
    setVal('iSenderZip', normalizeZip6(d.sender_zip));
    setVal('iAddr', normalizeAddressLoose(d.addr));
    setVal('iAddr2', normalizeAddressLoose(d.addr2));
    ['iCompany','iDept','iTitle','iName','iName2','iSenderAddr','iSenderCompany','iSenderDept','iSenderName','iSenderTel'].forEach(id=>{
      const el=byId(id); if(el) el.value = normalizeText(el.value);
    });
    applySuggestedHonor();
    if(window.toast) toast('住所・宛名を整形しました','ok');
    renderAddressAssistPanel();
  }
  function applyVerticalPreviewToAddress(mode){
    const a1 = byId('iAddr'); if(!a1) return;
    a1.value = toVerticalAddress(a1.value, mode);
    if(window.toast) toast('住所1へ縦書き向け表記を反映しました','ok');
    renderAddressAssistPanel();
  }
  function currentAddressPreview(){
    const d=getInput();
    const raw = [d.addr,d.addr2].filter(Boolean).join('\n');
    return {
      normal: normalizeAddressLoose(raw),
      wide: toVerticalAddress(raw,'wide'),
      kanji: toVerticalAddress(raw,'kanji'),
      formal: toVerticalAddress(raw,'formal')
    };
  }

  function renderAddressAssistPanel(){
    const panel = byId('stage6AddressAssistPanel');
    if(!panel) return;
    const tpl = getTpl(); const d = getInput();
    const zip = normalizeZip6(d.zip);
    const found = zip ? lookupZip(zip) : [];
    const honor = suggestHonor(d,tpl);
    const pv = currentAddressPreview();
    panel.innerHTML = `<div class="ttl">住所・宛名補助</div>
      <div class="stage6-mini">郵便番号辞書、敬称推定、住所整形、縦書き向け表記をここで確認します。</div>
      <div class="stage6-actions" style="margin-top:8px">
        <button class="btn sm" id="stage6NormalizeNow">住所・宛名を整形</button>
        <button class="btn sm ghost" id="stage6SuggestHonor">敬称を推定（${esc(honor)}）</button>
        <button class="btn sm ghost" id="stage6OpenAssist">住所補助を開く</button>
      </div>
      <div style="margin-top:8px">
        <span class="stage6-chip ${zip&&found.length?'ok':'warn'}">郵便番号辞書：${esc(zip||'未入力')} / ${found.length}件候補</span>
        <span class="stage6-chip">辞書登録：${Object.keys(addon.zipDict).length}郵便番号 / ${dictCount()}住所</span>
      </div>
      ${found.length ? `<div class="stage6-panel ok"><div class="ttl">住所候補</div>${found.slice(0,3).map(a=>`<div class="stage6-actions" style="justify-content:space-between;border-top:1px dashed var(--line-soft);padding:4px 0"><span>${esc(a)}</span><button class="btn sm ghost" data-stage6-apply-addr="${esc(a)}">反映</button></div>`).join('')}</div>` : ''}
      <details style="margin-top:8px"><summary style="cursor:pointer;font-size:11px">縦書き向け表記プレビュー</summary>
        <div class="stage6-preview">${esc(pv.formal || pv.kanji || pv.normal || '住所未入力')}</div>
        <div class="stage6-actions" style="margin-top:6px">
          <button class="btn sm ghost" id="stage6ApplyWide">全角数字</button>
          <button class="btn sm ghost" id="stage6ApplyKanji">漢数字</button>
          <button class="btn sm ghost" id="stage6ApplyFormal">丁目番号候補</button>
        </div>
      </details>`;
    byId('stage6NormalizeNow')?.addEventListener('click', normalizeCurrentInput);
    byId('stage6SuggestHonor')?.addEventListener('click', applySuggestedHonor);
    byId('stage6OpenAssist')?.addEventListener('click', showAddressAssistModal);
    byId('stage6ApplyWide')?.addEventListener('click',()=>applyVerticalPreviewToAddress('wide'));
    byId('stage6ApplyKanji')?.addEventListener('click',()=>applyVerticalPreviewToAddress('kanji'));
    byId('stage6ApplyFormal')?.addEventListener('click',()=>applyVerticalPreviewToAddress('formal'));
    panel.querySelectorAll('[data-stage6-apply-addr]').forEach(b=>b.addEventListener('click',()=>applyZipSuggestion(b.dataset.stage6ApplyAddr)));
  }

  function injectStep3Stage6(){
    const manual = document.querySelector('.input-pane[data-pane="manual"]');
    if(!manual) return;
    if(!byId('stage6AddressAssistPanel')){
      const box = document.createElement('div');
      box.id = 'stage6AddressAssistPanel';
      box.className = 'stage6-panel';
      manual.appendChild(box);
    }
    const form = byId('inputForm');
    if(form){
      form.querySelectorAll('input,textarea,select').forEach(el=>{
        el.removeEventListener('input', renderAddressAssistPanel);
        el.removeEventListener('change', renderAddressAssistPanel);
        el.addEventListener('input', renderAddressAssistPanel);
        el.addEventListener('change', renderAddressAssistPanel);
      });
    }
    renderAddressAssistPanel();
  }

  function showAddressAssistModal(){
    const d = getInput(); const zip = normalizeZip6(d.zip); const found = zip ? lookupZip(zip) : [];
    const pv = currentAddressPreview();
    const modal = document.createElement('div'); modal.className='modal-overlay';
    modal.innerHTML = `<div class="modal-box" style="min-width:780px">
      <h3>住所補助・郵便番号辞書</h3>
      <p>CSVファイルは読み込みません。郵便番号辞書は、Excel等からコピーした表をここへ貼り付けて登録します。</p>
      <div class="stage6-modal-tabs"><button class="active" data-s6tab="lookup">検索・整形</button><button data-s6tab="dict">辞書取込</button><button data-s6tab="settings">印字設定</button></div>
      <div id="stage6ModalBody"></div>
      <div class="actions"><button class="btn ghost" id="stage6Close">閉じる</button></div>
    </div>`;
    document.body.appendChild(modal);
    applyLegacyModalA11y(modal,{title:'住所補助・郵便番号辞書', initialFocus:'#stage6Close'});
    function renderTab(tab){
      modal.querySelectorAll('[data-s6tab]').forEach(b=>b.classList.toggle('active',b.dataset.s6tab===tab));
      const body = modal.querySelector('#stage6ModalBody');
      if(tab==='lookup'){
        body.innerHTML = `<div class="stage6-grid2"><div class="stage6-card"><h4>現在の郵便番号</h4>
          <div class="stage6-actions"><input type="text" id="s6LookupZip" value="${esc(zip)}" style="max-width:160px"><button class="btn sm" id="s6LookupBtn">検索</button></div>
          <div id="s6LookupResult" style="margin-top:8px"></div></div>
          <div class="stage6-card"><h4>住所整形プレビュー</h4><div class="stage6-preview">${esc(pv.formal || pv.kanji || pv.normal || '住所未入力')}</div>
          <div class="stage6-actions" style="margin-top:8px"><button class="btn sm" id="s6NormAll">入力欄を整形</button><button class="btn sm ghost" id="s6Honor">敬称推定</button></div></div></div>`;
        const doLookup=()=>{
          const list = lookupZip(byId('s6LookupZip').value);
          const r=byId('s6LookupResult');
          r.innerHTML = list.length ? `<table class="stage6-table"><tbody>${list.map(a=>`<tr><td>${esc(a)}</td><td style="width:80px"><button class="btn sm ghost" data-apply="${esc(a)}">反映</button></td></tr>`).join('')}</tbody></table>` : '<div class="stage6-panel warn">候補はありません。辞書を取り込むか、郵便番号を確認してください。</div>';
          r.querySelectorAll('[data-apply]').forEach(b=>b.addEventListener('click',()=>{ applyZipSuggestion(b.dataset.apply); closeAccessibleModal(modal); }));
        };
        byId('s6LookupBtn').addEventListener('click',doLookup); doLookup();
        byId('s6NormAll').addEventListener('click',()=>{ normalizeCurrentInput(); closeAccessibleModal(modal); });
        byId('s6Honor').addEventListener('click',()=>{ applySuggestedHonor(); closeAccessibleModal(modal); });
      }else if(tab==='dict'){
        body.innerHTML = `<div class="stage6-card"><h4>郵便番号辞書の貼り付け取込</h4>
          <p class="stage6-mini">対応例：<br>123-4567　青森県青森市○○<br>または、郵便番号列と住所列を含むExcel表の貼り付け。日本郵便のCSVをExcelで開いてコピーした形式にも一部対応します。</p>
          <textarea id="s6DictText" class="stage6-textarea" placeholder="030-0861\t青森県青森市長島...\n0300862\t青森県青森市古川..."></textarea>
          <div class="stage6-actions" style="margin-top:8px"><button class="btn primary" id="s6ImportMerge">追加取込</button><button class="btn ghost" id="s6ImportReplace">全置換</button><button class="btn danger" id="s6ClearDict">辞書を削除</button></div>
          <div class="stage6-panel"><div class="ttl">現在の登録数</div>${Object.keys(addon.zipDict).length}郵便番号 / ${dictCount()}住所</div></div>`;
        byId('s6ImportMerge').addEventListener('click',()=>{ const r=importZipText(byId('s6DictText').value,true); showAppAlert(`追加しました：${r.zipCount}郵便番号 / 新規${r.addrCount}住所`); closeAccessibleModal(modal); renderAddressAssistPanel(); });
        byId('s6ImportReplace').addEventListener('click',async()=>{ if(await showAppConfirm('既存辞書を置き換えますか？','郵便番号辞書の全置換',{okLabel:'置き換える',danger:true})){ const r=importZipText(byId('s6DictText').value,false); showAppAlert(`置き換えました：${r.zipCount}郵便番号 / ${r.addrCount}住所`); closeAccessibleModal(modal); renderAddressAssistPanel(); }});
        byId('s6ClearDict').addEventListener('click',async()=>{ if(await showAppConfirm('郵便番号辞書を削除しますか？','郵便番号辞書の削除',{okLabel:'削除する',danger:true})){ addon.zipDict={}; saveStage6(); closeAccessibleModal(modal); renderAddressAssistPanel(); }});
      }else{
        const tpl = getTpl(); const mode = (tpl && tpl.stage6 && tpl.stage6.verticalAddressMode) || 'none';
        body.innerHTML = `<div class="stage6-card"><h4>現在テンプレートの印字設定</h4>
          <div class="row"><label>縦書き住所の数字表記</label><select id="s6VerticalMode"><option value="none">そのまま</option><option value="wide">全角数字・全角ハイフン</option><option value="kanji">数字を漢数字化</option><option value="formal">丁目・番・号候補＋漢数字</option></select></div>
          <div class="stage6-mini">この設定は、縦書きの住所フィールドを印字するときだけ反映されます。住所を直接書き換えるのではなく、印字時の表示を調整します。</div>
          <div class="stage6-actions" style="margin-top:8px"><button class="btn primary" id="s6SaveTplSetting">保存</button></div></div>`;
        byId('s6VerticalMode').value = mode;
        byId('s6SaveTplSetting').addEventListener('click',()=>{
          const t=getTpl(); if(!t){ showAppAlert('テンプレートが選択されていません'); return; }
          if(!t.stage6) t.stage6={};
          t.stage6.verticalAddressMode = byId('s6VerticalMode').value;
          if(window.markLayoutChanged) markLayoutChanged(t);
          if(window.save) save();
          if(window.renderEnvelope) renderEnvelope();
          if(window.toast) toast('印字設定を保存しました','ok');
          closeAccessibleModal(modal);
        });
      }
      // v37 step49: Stage6独自タブをtablist/tabpanelとして同期し、動的フォームのlabel紐付けも補完する。
      applyCustomTabbarA11y(modal.querySelector('.stage6-modal-tabs'), {tabAttr:'s6tab', panel:body, label:'住所補助・郵便番号辞書の切替'});
      applyLabelForA11y(body);
      applyTableA11y(body);
    }
    modal.querySelectorAll('[data-s6tab]').forEach(b=>b.addEventListener('click',()=>renderTab(b.dataset.s6tab)));
    byId('stage6Close').addEventListener('click',()=>closeAccessibleModal(modal));
    modal.addEventListener('click',e=>{ if(e.target===modal) closeAccessibleModal(modal); });
    renderTab('lookup');
  }

  // Step3: getFieldTextを上書きせず、Registryの後処理として縦書き住所変換を登録する。
  // 理由：Stage6/Stage7の多重モンキーパッチを解消する移行途中で、住所変換だけを共通経路へ移すため。
  function applyStage6VerticalAddressPostProcess(f, text, data, context){
    let out = text;
    try{
      // v37 Step6-1: context.tpl が渡された場合は描画対象テンプレートを優先。
      // 未移行経路では従来どおり getTpl() にフォールバックする。
      const tpl = (context && context.tpl) ? context.tpl : getTpl();
      const mode = (tpl && tpl.stage6 && tpl.stage6.verticalAddressMode) || 'none';
      if(mode !== 'none' && f && f.vertical && ['addr','addr2','full_addr'].includes(f.source)){
        out = toVerticalAddress(out == null ? '' : String(out), mode);
      }
    }catch(e){
      console.warn('Stage6 vertical address postProcess failed', e);
    }
    return out;
  }
  if(window.FieldSourceRegistry && typeof window.FieldSourceRegistry.registerPostProcessor === 'function'){
    window.FieldSourceRegistry.registerPostProcessor(applyStage6VerticalAddressPostProcess);
  }else{
    // Step5: getFieldTextのモンキーパッチ廃止方針により、ここでは上書きしない。
    // FieldSourceRegistryが無い場合は縦書き後処理を有効化できないため、警告だけ出す。
    console.warn('FieldSourceRegistry is unavailable; Stage6 vertical address postProcess was not registered.');
  }

  // ラベル開始位置。A4ラベルの余り紙を使う実務向け。
  // v37 step21: buildLabelSheetStackの開始位置処理は本体へ統合済み。ここではUI注入だけを担当する。
  function injectLabelStartControl(){
    const area = byId('printActionArea'); const tpl = getTpl();
    if(!area || !tpl || tpl.paperKind!=='label_sheet' || byId('stage6LabelStartBox')) return;
    const cfg = getLabelConfig(tpl); const cap = labelCapacity(tpl);
    const cur = Math.max(1, Math.min(cap, +(tpl.labelStartIndex||1)));
    const box = document.createElement('div');
    box.id='stage6LabelStartBox'; box.className='stage6-label-start';
    box.innerHTML = `<h4 class="serif" style="font-size:13px;margin-bottom:6px">ラベル開始位置</h4>
      <div class="stage6-mini">使いかけのラベル紙を使う場合、最初に印刷する面を指定できます。</div>
      <div class="stage6-actions" style="margin-top:6px"><label style="margin:0">開始面</label><input type="number" id="stage6LabelStartInput" min="1" max="${cap}" value="${cur}" style="width:80px"><button class="btn sm" id="stage6SaveLabelStart">設定</button></div>
      <div class="slots">${Array.from({length:Math.min(cap,24)},(_,i)=>`<button data-slot="${i+1}" class="${i+1===cur?'active':''}">${i+1}</button>`).join('')}</div>`;
    area.insertBefore(box, area.firstChild);
    function saveStart(v){
      tpl.labelStartIndex = Math.max(1, Math.min(cap, +v || 1));
      if(window.save) save();
      if(window.renderStep5) renderStep5();
      if(window.toast) toast(`ラベル開始位置を${tpl.labelStartIndex}面目にしました`,'ok');
    }
    byId('stage6SaveLabelStart').addEventListener('click',()=>saveStart(byId('stage6LabelStartInput').value));
    box.querySelectorAll('[data-slot]').forEach(b=>b.addEventListener('click',()=>saveStart(b.dataset.slot)));
  }

  function addTopbar(){
    const topbar = document.querySelector('.topbar'); const ref = byId('btnHelp');
    if(!topbar || byId('stage6AssistBtn')) return;
    const btn = document.createElement('button'); btn.className='stage6-top-btn'; btn.id='stage6AssistBtn'; btn.textContent='住所補助';
    topbar.insertBefore(btn, ref);
    btn.addEventListener('click', showAddressAssistModal);
  }
  function patchStage6(){
    if(window.__stage6Patched) return; window.__stage6Patched = true;
    const step3Ext = window.Step3ExtensionRegistry;
    if(step3Ext && typeof step3Ext.registerRenderHook === 'function'){
      // v30 Step4: Stage6もrenderStep3を上書きせず、Step3ExtensionRegistry経由で住所補助UIを注入する。
      step3Ext.registerRenderHook(injectStep3Stage6, 'Stage6.injectStep3Stage6.render');
    }else{
      console.warn('Step3ExtensionRegistry is not available. Stage6 render hook was not registered.');
    }
    if(step3Ext && typeof step3Ext.registerManualPaneHook === 'function'){
      // v30 Step4: manualタブ復帰時もRegistry経由で住所補助UIを再注入する。
      step3Ext.registerManualPaneHook(injectStep3Stage6, 'Stage6.injectStep3Stage6.manual');
    }
    const step5Ext = window.Step5ExtensionRegistry;
    if(step5Ext && typeof step5Ext.registerRenderHook === 'function'){
      // v37 step21: renderStep5を上書きせず、Registry経由でラベル開始位置UIを注入する。
      step5Ext.registerRenderHook(injectLabelStartControl, 'Stage6.injectLabelStartControl.render');
    }else{
      console.warn('Step5ExtensionRegistry is not available. Stage6 Step5 hook was not registered.');
    }
    addTopbar();
    setTimeout(()=>{ injectStep3Stage6(); injectLabelStartControl(); },0);
  }
  window.Stage6 = {
    normalizeZip: normalizeZip6,
    normalizeAddress: normalizeAddressLoose,
    formalizeJapaneseAddress,
    toVerticalAddress,
    importZipText,
    lookupZip,
    showAddressAssistModal,
    renderAddressAssistPanel
  };
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', patchStage6); else patchStage6();
})();
