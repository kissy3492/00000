(function(global){
  'use strict';
/* ============================================================
   v38-6: Storage / Backup / Restore
   保存・復元・sanitize・バックアップ・容量管理を core から分離。
   依存: js/05_utilities.js / js/20_registries.js 読込後。
   注意: state / transientBg / normalizeTpl 等は js/10_core.js 側のグローバル束縛を実行時に参照する。
   ============================================================ */

/* ============================================================
   永続化＋バックアップ
   ============================================================ */

function addonStorageKeys(){
  return {
    stage5:'paper_position_print_system_v37_stage5_addons',
    stage6:'paper_position_print_system_v37_stage6',
    stage7:'paper_position_print_system_v37_stage7_addon',
    stage8:'paper_position_print_system_v37_stage8_validation'
  };
}
let __addonSnapshotWarnings = [];
function isInvalidAddonSnapshotValue(value){
  // 破損マーカーは正規データとして復元しない。破損データで上書きする事故を防ぐ。
  return !!(value && typeof value === 'object' && value.__error === 'parse_failed');
}
function getAddonStorageSnapshot(){
  const out={};
  __addonSnapshotWarnings = [];
  Object.entries(addonStorageKeys()).forEach(([name,key])=>{
    try{
      const raw=localStorage.getItem(key);
      if(raw) out[name]=JSON.parse(raw);
    }catch(e){
      // parse失敗データはバックアップに含めない。復元時に破損マーカーで上書きしないため。
      __addonSnapshotWarnings.push({name, key, reason:'parse_failed'});
      console.warn('addon snapshot skipped because parse failed', name, e);
    }
  });
  return out;
}
function captureAddonRawStorage(){
  const raw={};
  Object.entries(addonStorageKeys()).forEach(([name,key])=>{
    try{ raw[name]=localStorage.getItem(key); }
    catch(e){ raw[name]=null; console.warn('addon raw capture failed', name, e); }
  });
  return raw;
}
function restoreAddonRawStorage(raw){
  const result={ok:true,failed:[]};
  const keys=addonStorageKeys();
  Object.entries(keys).forEach(([name,key])=>{
    try{
      if(!raw || raw[name] === null || raw[name] === undefined) localStorage.removeItem(key);
      else localStorage.setItem(key, raw[name]);
    }catch(e){
      result.ok=false;
      result.failed.push(name);
      console.warn('addon raw rollback failed', name, e);
    }
  });
  return result;
}
function rollbackAddonStorageAfterRestoreFailure(addonRollback, reason){
  // v37 step60: 復元失敗時のアドオン巻き戻しも成功/失敗を確認し、中途半端なaddon状態を見逃さない。
  const result = restoreAddonRawStorage(addonRollback);
  if(!result.ok){
    const names = result.failed.join(', ');
    console.warn('addon rollback failed after restore failure', reason, result.failed);
    notifyStorageFailure(`復元に失敗し、アドオンデータの巻き戻しにも失敗しました：${names}。手動バックアップで退避してください`);
  }
  return result;
}
function sanitizeStage8AddonForRestore(addon, restoreContext){
  // v37 step31: 復元時に本体側で安全化したtplId/printerIdをStage8検証記録にも反映する。
  if(!isRestorePlainObject(addon)) return addon;
  const out = JSON.parse(JSON.stringify(addon));
  const tplMap = (restoreContext && restoreContext.__restoreTplIdMap) || Object.create(null);
  const tplIds = (restoreContext && restoreContext.__restoreTplIds) || Object.create(null);
  const printerMap = (restoreContext && restoreContext.__restorePrinterIdMap) || Object.create(null);
  const printerIds = (restoreContext && restoreContext.__restorePrinterIds) || Object.create(null);
  const remapTplId = v=>{
    if(v === null || v === undefined || v === 'none' || v === '') return null;
    if(typeof v !== 'string') return null;
    if(Object.prototype.hasOwnProperty.call(tplMap, v)) return tplMap[v];
    return tplIds[v] ? v : null;
  };
  const remapPrinterId = v=>{
    if(v === null || v === undefined || v === 'none' || v === '') return null;
    if(typeof v !== 'string') return null;
    if(Object.prototype.hasOwnProperty.call(printerMap, v)) return printerMap[v];
    return printerIds[v] ? v : null;
  };
  const profileKey = (tplId, printerId)=>`${tplId || 'none'}::${printerId || 'none'}`;
  if(Array.isArray(out.records)){
    out.records = out.records.filter(isRestorePlainObject).map(r=>{
      r.id = normalizeRestoreSafeId(r.id, 'vr');
      r.tplId = remapTplId(r.tplId);
      r.printerId = remapPrinterId(r.printerId);
      r.tplName = normalizeRestoreString(r.tplName, '');
      r.printerName = normalizeRestoreString(r.printerName, '');
      return r;
    }).slice(0, 120);
  }else{
    out.records = [];
  }
  if(isRestorePlainObject(out.lastPrintAttempt)){
    out.lastPrintAttempt.tplId = remapTplId(out.lastPrintAttempt.tplId);
    out.lastPrintAttempt.printerId = remapPrinterId(out.lastPrintAttempt.printerId);
  }else if(out.lastPrintAttempt !== undefined){
    delete out.lastPrintAttempt;
  }
  const rawProfiles = isRestorePlainObject(out.profiles) ? out.profiles : {};
  const profiles = {};
  Object.keys(rawProfiles).forEach(k=>{
    const p = rawProfiles[k];
    if(!isRestorePlainObject(p)) return;
    const parts = String(k).split('::');
    const rawTplId = p.tplId !== undefined ? p.tplId : (parts[0] === 'none' ? null : parts[0]);
    const rawPrinterId = p.printerId !== undefined ? p.printerId : (parts[1] === 'none' ? null : parts[1]);
    const tplId = remapTplId(rawTplId);
    const printerId = remapPrinterId(rawPrinterId);
    const nk = profileKey(tplId, printerId);
    if(!profiles[nk]) profiles[nk] = Object.assign({}, p, {tplId, printerId});
  });
  out.profiles = profiles;
  const rawManual = isRestorePlainObject(out.manualProgress) ? out.manualProgress : {};
  const manualProgress = {};
  Object.keys(rawManual).forEach(k=>{
    const p = rawManual[k];
    if(!isRestorePlainObject(p)) return;
    const parts = String(k).split('::');
    const rawTplId = p.tplId !== undefined ? p.tplId : (parts[0] === 'none' ? null : parts[0]);
    const rawPrinterId = p.printerId !== undefined ? p.printerId : (parts[1] === 'none' ? null : parts[1]);
    const tplId = remapTplId(rawTplId);
    const printerId = remapPrinterId(rawPrinterId);
    const items = isRestorePlainObject(p.items) ? p.items : {};
    const cleanItems = {};
    Object.keys(items).forEach(id=>{
      if(/^[A-Za-z0-9_-]{1,80}$/.test(id)) cleanItems[id] = !!items[id];
    });
    const nk = profileKey(tplId, printerId);
    manualProgress[nk] = {tplId, printerId, updatedAt:Number(p.updatedAt)||null, items:cleanItems};
  });
  out.manualProgress = manualProgress;
  if(!isRestorePlainObject(out.settings)) out.settings = {};
  return out;
}
function sanitizeAddonForRestore(name, value, restoreContext){
  if(name === 'stage8') return sanitizeStage8AddonForRestore(value, restoreContext);
  return value;
}
function restoreAddonStorageSnapshot(addons, restoreContext){
  const result={ok:true,failed:[],skipped:[]};
  if(!addons || typeof addons !== 'object') return result;
  const keys=addonStorageKeys();
  Object.entries(keys).forEach(([name,key])=>{
    if(addons[name] === undefined) return;
    if(isInvalidAddonSnapshotValue(addons[name])){
      result.skipped.push(name);
      console.warn('addon restore skipped invalid snapshot value', name);
      return;
    }
    try{
      const value = sanitizeAddonForRestore(name, addons[name], restoreContext);
      localStorage.setItem(key, JSON.stringify(value));
    }
    catch(e){
      result.ok=false;
      result.failed.push(name);
      console.warn('addon restore failed', name, e);
    }
  });
  return result;
}
function clearAddonStorage(){
  Object.values(addonStorageKeys()).forEach(key=>{
    try{ localStorage.removeItem(key); }
    catch(e){ console.warn('addon storage clear failed', key, e); }
  });
}

function notifyStorageFailure(message, error){
  // 保存失敗をサイレントにしない。保存済み表示の誤表示を防ぐため、ここでは lastSavedAt を更新しない。
  // v37 step57: 保存失敗が未解消のままページ離脱しないよう、beforeunloadで参照するフラグを立てる。
  __lastSaveFailed = true;
  __lastSaveFailureMessage = message || '保存に失敗しました';
  if(error) console.warn(message, error);
  try{ toast(message, 'warn'); }catch(e){ console.warn('toast failed during storage failure', e); }
  updateStorageStatus();
}

function dataSnapshot(options){
  const opt = options || {};
  const stripBg = !!opt.stripPersistedBackgrounds;
  const tpls=state.templates.map(t=>{
    const c={...t};
    // v37 step12: バックアップ容量退避時だけ、ライブ状態を壊さずsnapshot上の背景を除外できるようにする。
    if(stripBg){ c.bgPersist=false; delete c.bgImage; delete c.bgSourceName; delete c.bgBytes; }
    else if(!c.bgPersist){delete c.bgImage;delete c.bgSourceName;delete c.bgBytes}
    return c;
  });
  return {version:APP_STORAGE_SCHEMA_VERSION,savedAt:Date.now(),templates:tpls,queue:state.queue,addressBook:state.addressBook,
    history:state.history,printAttempts:state.printAttempts,printerProfiles:state.printerProfiles,
    lastUsedTplId:state.lastUsedTplId,selectedPrinterId:state.selectedPrinterId};
}
function dataSnapshotForBackup(options){
  // 通常保存ではアドオンを重複保存しない。バックアップ時だけ統合する。
  const snap = dataSnapshot(options);
  snap.addons = getAddonStorageSnapshot();
  return snap;
}
let __saveDebounceTimer = null;
let __savePending = false;
let __lastSaveFailed = false;
let __lastSaveFailureMessage = '';
function hasPendingSave(){
  return !!__savePending;
}
function hasUnresolvedSaveFailure(){
  return !!__lastSaveFailed;
}
function flushPendingSave(){
  if(__saveDebounceTimer){
    clearTimeout(__saveDebounceTimer);
    __saveDebounceTimer = null;
    return save(true);
  }
  return true;
}
function detachPersistedBackgroundsForSave(){
  // v37 step11: 保存容量対策で背景を一時解除する前に、失敗時ロールバック用の情報を保持する。
  const removed = [];
  state.templates.forEach(t=>{
    if(t.bgPersist && t.bgImage){
      const id = t.id;
      removed.push({
        tpl:t,
        id,
        bgPersist:t.bgPersist,
        bgImage:t.bgImage,
        bgSourceName:t.bgSourceName,
        bgBytes:t.bgBytes,
        hadBgSourceName:Object.prototype.hasOwnProperty.call(t,'bgSourceName'),
        hadBgBytes:Object.prototype.hasOwnProperty.call(t,'bgBytes'),
        hadTransient:Object.prototype.hasOwnProperty.call(transientBg,id),
        transient:transientBg[id]
      });
      transientBg[id] = {dataUrl:t.bgImage, name:t.bgSourceName, bytes:estimateDataUrlBytes(t.bgImage)};
      t.bgPersist = false;
      delete t.bgImage; delete t.bgSourceName; delete t.bgBytes;
    }
  });
  return removed;
}
function restorePersistedBackgroundsAfterSaveFailure(removed){
  // v37 step11: 背景解除後の再保存に失敗した場合、メモリ上のテンプレート状態も元に戻す。
  if(!removed || !removed.length) return;
  removed.forEach(r=>{
    const t = r.tpl;
    if(!t) return;
    t.bgPersist = r.bgPersist;
    t.bgImage = r.bgImage;
    if(r.hadBgSourceName) t.bgSourceName = r.bgSourceName; else delete t.bgSourceName;
    if(r.hadBgBytes) t.bgBytes = r.bgBytes; else delete t.bgBytes;
    if(r.hadTransient) transientBg[r.id] = r.transient; else delete transientBg[r.id];
  });
}
function save(force=false){
  // 位置合わせウィザード中はドラフト編集中として扱い、途中状態を永続保存しない。
  // 完了時だけ save(true) で保存する。
  if(typeof wizardState !== 'undefined' && wizardState && !force){
    return false;
  }
  // キー操作などの連続保存でlocalStorageを書き潰さないため、通常保存は短時間デバウンスする。
  // save(false) は「保存予約」であり、保存完了ではない。完了判定が必要な箇所では save(true) を使う。
  if(!force){
    clearTimeout(__saveDebounceTimer);
    __savePending = true;
    __saveDebounceTimer = setTimeout(()=>save(true), 250);
    return true;
  }
  clearTimeout(__saveDebounceTimer);
  __saveDebounceTimer = null;
  __savePending = false;

  let saved = false;
  let detachedForSave = null;
  try{
    let data = JSON.stringify(dataSnapshot());
    if(estimateStorageBytes(data, STORAGE_KEY) > STORAGE_HARD_LIMIT){
      // 容量超過：背景保存を全部解除して再試行する。再試行失敗時は解除前の状態へ戻す。
      detachedForSave = detachPersistedBackgroundsForSave();
      const removed = detachedForSave.length;
      if(removed){
        const retryData = JSON.stringify(dataSnapshot());
        if(estimateStorageBytes(retryData, STORAGE_KEY) > STORAGE_HARD_LIMIT){
          restorePersistedBackgroundsAfterSaveFailure(detachedForSave);
          detachedForSave = null;
          notifyStorageFailure('背景保存を解除しても保存容量を超過しています。手動バックアップで退避してください');
          return false;
        }
        try{
          localStorage.setItem(STORAGE_KEY, retryData);
          saved = true;
          detachedForSave = null;
          toast(`容量超過のため背景保存を${removed}件解除しました`,'warn');
        }catch(e){
          restorePersistedBackgroundsAfterSaveFailure(detachedForSave);
          detachedForSave = null;
          throw e;
        }
      } else {
        notifyStorageFailure('保存容量超過。一部データが保存できません');
        return false;
      }
    } else {
      localStorage.setItem(STORAGE_KEY, data);
      saved = true;
    }
  }
  catch(e){
    if(detachedForSave){
      restorePersistedBackgroundsAfterSaveFailure(detachedForSave);
      detachedForSave = null;
    }
    if(e && (e.name==='QuotaExceededError'||/quota/i.test(String(e.message)))){
      // 緊急退避：背景保存を全解除して再試行。再試行失敗時は解除前の状態へ戻す。
      const emergencyDetached = detachPersistedBackgroundsForSave();
      const removed = emergencyDetached.length;
      if(!removed){
        notifyStorageFailure('保存に失敗しました。バックアップ画面でデータを退避してください', e);
        return false;
      }
      try{
        const retryData = JSON.stringify(dataSnapshot());
        if(estimateStorageBytes(retryData, STORAGE_KEY) > STORAGE_HARD_LIMIT){
          restorePersistedBackgroundsAfterSaveFailure(emergencyDetached);
          notifyStorageFailure('背景保存を解除しても保存容量を超過しています。手動バックアップで退避してください', e);
          return false;
        }
        localStorage.setItem(STORAGE_KEY, retryData);
        saved = true;
        toast(`容量超過のため背景保存を${removed}件解除しました`,'warn');
      }catch(e2){
        restorePersistedBackgroundsAfterSaveFailure(emergencyDetached);
        notifyStorageFailure('保存に失敗しました。バックアップ画面でデータを退避してください', e2);
        return false;
      }
    } else {
      notifyStorageFailure('保存に失敗しました。バックアップ画面でデータを退避してください', e);
      return false;
    }
  }
  if(saved){
    __lastSaveFailed = false;
    __lastSaveFailureMessage = '';
    state.lastSavedAt=Date.now();
    updateStorageStatus();
    return true;
  }
  return false;
}
function getStorageUsageExcludingKey(excludedKey){
  try{
    let total=0;
    for(let k in localStorage){
      if(Object.prototype.hasOwnProperty.call(localStorage,k) && k!==excludedKey){
        total += estimateStorageBytes(localStorage[k], k);
      }
    }
    return total;
  }catch(e){
    console.warn('storage usage estimate failed', e);
    return 0;
  }
}
function writeBackupArrayWithTrim(arr){
  // v37 step12: バックアップ自身がlocalStorageを圧迫しないよう、古い世代を容量に応じて落としてから保存する。
  const baseUsage = getStorageUsageExcludingKey(BACKUP_KEY);
  const work = Array.isArray(arr) ? arr.slice() : [];
  let normalRemoved = 0;
  let capacityRemoved = 0;
  while(work.length > MAX_BACKUPS){ work.shift(); normalRemoved++; }
  while(work.length){
    const json = JSON.stringify(work);
    const projected = baseUsage + estimateStorageBytes(json, BACKUP_KEY);
    if(projected > STORAGE_HARD_LIMIT && work.length > 1){
      work.shift();
      capacityRemoved++;
      continue;
    }
    if(projected > STORAGE_HARD_LIMIT){
      return {ok:false, normalRemoved, capacityRemoved, reason:'backup_too_large'};
    }
    try{
      localStorage.setItem(BACKUP_KEY, json);
      return {ok:true, normalRemoved, capacityRemoved, count:work.length};
    }catch(e){
      if(work.length > 1){
        work.shift();
        capacityRemoved++;
        continue;
      }
      return {ok:false, normalRemoved, capacityRemoved, error:e};
    }
  }
  return {ok:false, normalRemoved, capacityRemoved, reason:'empty_backup_array'};
}
function countPersistedBackgroundsInSnapshot(snap){
  return snap && Array.isArray(snap.templates) ? snap.templates.filter(t=>t && t.bgImage).length : 0;
}
function backupNow(){
  try{
    const raw=localStorage.getItem(BACKUP_KEY);
    const arr=raw?JSON.parse(raw):[];

    const snap=dataSnapshotForBackup();
    const warnings = (__addonSnapshotWarnings||[]).slice();
    arr.push(snap);

    let result = writeBackupArrayWithTrim(arr);
    let strippedBackgrounds = 0;
    if(!result.ok && countPersistedBackgroundsInSnapshot(snap)){
      // v37 step12: フルバックアップが容量上限を超える場合のみ、バックアップ内の背景画像を除外して再試行する。
      const leanSnap = dataSnapshotForBackup({stripPersistedBackgrounds:true});
      strippedBackgrounds = countPersistedBackgroundsInSnapshot(snap);
      const leanArr = arr.slice(0, Math.max(0, arr.length - 1));
      leanArr.push(leanSnap);
      result = writeBackupArrayWithTrim(leanArr);
    }

    if(!result.ok){
      console.warn('backup failed because backup data is too large', result);
      try{ toast('バックアップ容量が大きすぎるため保存できません。手動コピーで退避してください','warn'); }catch(_e){}
      return false;
    }
    if(result.capacityRemoved){
      try{ toast(`容量確保のため古いバックアップを${result.capacityRemoved}件削除しました`,'warn'); }catch(_e){}
    }
    if(strippedBackgrounds){
      try{ toast(`容量確保のためバックアップ内の背景画像を${strippedBackgrounds}件除外しました`,'warn'); }catch(_e){}
    }
    if(warnings.length){
      try{ toast(`一部アドオンデータは破損のためバックアップ対象外です：${warnings.map(w=>w.name).join(', ')}`,'warn'); }catch(_e){}
      console.warn('addon snapshot warnings', warnings);
    }
    return true;
  }catch(e){
    console.error('backup failed', e);
    try{ toast('バックアップに失敗しました。保存容量を確認してください','warn'); }catch(_e){}
    return false;
  }
}
function requestReloadAfterDataRestore(message){
  // アドオンは起動時にlocalStorageをメモリへ読み込むため、復元後は再読込してメモリ不整合を防ぐ。
  try{ toast((message||'復元しました') + '。反映のため再読み込みします','ok'); }catch(e){}
  setTimeout(()=>{ location.reload(); }, 700);
}
function cloneStateForRestoreRollback(){
  // 復元失敗時に画面上のメモリ状態だけが差し替わる事故を防ぐための退避。
  return JSON.parse(JSON.stringify(state));
}
function restoreStateFromRollbackSnapshot(snapshot){
  state = snapshot;
  if(Array.isArray(state.templates)) state.templates.forEach(normalizeTpl);
  renderAll();
}
function persistRollbackStateAfterRestoreFailure(reason){
  // v37 step56: 復元失敗時にメモリ上のロールバックだけで終わらせず、元データの再保存結果も確認する。
  const ok = save(true);
  if(!ok){
    console.warn('restore rollback save failed', reason);
    notifyStorageFailure('復元に失敗し、元データの再保存にも失敗しました。手動バックアップで退避してください');
    return false;
  }
  return true;
}
function isRestorePlainObject(v){
  return !!v && typeof v === 'object' && !Array.isArray(v);
}
function cloneRestoreArray(d, key, fallback, required){
  // v37 step16: 復元JSONをstateへ直接流し込まず、型検証と複製を通してから適用する。
  const v = d[key];
  if(v === undefined || v === null){
    if(required) throw new Error('invalid backup field: '+key);
    return fallback;
  }
  if(!Array.isArray(v)) throw new Error('invalid backup field: '+key);
  v.forEach((item, i)=>{
    if(!isRestorePlainObject(item)) throw new Error('invalid backup field: '+key+'['+i+']');
  });
  return JSON.parse(JSON.stringify(v));
}
function normalizeRestoreId(v){
  return (typeof v === 'string' && v) ? v : null;
}
function isRestoreSafeIdString(v){
  return typeof v === 'string' && /^[A-Za-z0-9_-]{1,80}$/.test(v);
}
function normalizeRestoreSafeId(v, prefix){
  // v37 step28: 復元JSON由来の内部IDがHTML属性を壊さないよう、安全なID形式に制限する。
  const s = normalizeRestoreString(v, '').trim();
  return isRestoreSafeIdString(s) ? s : uid(prefix || 'id');
}
function normalizeRestoreTemplateIds(next){
  // v37 step29: template.idを安全ID化する場合は、参照側のtplIdも同じ対応表で変換して参照切れを防ぐ。
  if(!next || !Array.isArray(next.templates)) return next;
  const idMap = Object.create(null);
  const used = Object.create(null);
  next.templates.forEach(t=>{
    const oldId = typeof t.id === 'string' ? t.id : '';
    let newId = (isRestoreSafeIdString(oldId) && !used[oldId]) ? oldId : uid('tpl');
    while(used[newId]) newId = uid('tpl');
    used[newId] = true;
    t.id = newId;
    if(oldId && !Object.prototype.hasOwnProperty.call(idMap, oldId)) idMap[oldId] = newId;
  });
  const remapTplId = v=>{
    if(typeof v !== 'string' || !v) return null;
    if(Object.prototype.hasOwnProperty.call(idMap, v)) return idMap[v];
    return isRestoreSafeIdString(v) ? v : null;
  };
  next.lastUsedTplId = remapTplId(next.lastUsedTplId);
  ['queue','history','printAttempts'].forEach(key=>{
    if(!Array.isArray(next[key])) return;
    next[key].forEach(item=>{
      if(isRestorePlainObject(item)) item.tplId = remapTplId(item.tplId);
    });
  });
  if(Array.isArray(next.printerProfiles)){
    next.printerProfiles.forEach(p=>{
      if(!isRestorePlainObject(p)) return;
      const rawPerTpl = isRestorePlainObject(p.perTpl) ? p.perTpl : {};
      const perTpl = {};
      Object.keys(rawPerTpl).forEach(k=>{
        const nk = remapTplId(k);
        if(nk) perTpl[nk] = rawPerTpl[k];
      });
      p.perTpl = perTpl;
    });
  }
  // v37 step31: addon内ID変換にも同じ対応表を使うため、復元コンテキストに保持する。stateへは反映しない。
  next.__restoreTplIdMap = idMap;
  next.__restoreTplIds = used;
  return next;
}
function normalizeRestorePrinterIds(next){
  // v37 step30: printerProfile.idを安全ID化する場合は、selectedPrinterIdも同じ対応表で変換して参照切れを防ぐ。
  if(!next || !Array.isArray(next.printerProfiles)) return next;
  const idMap = Object.create(null);
  const used = Object.create(null);
  next.printerProfiles.forEach(p=>{
    if(!isRestorePlainObject(p)) return;
    const oldId = typeof p.id === 'string' ? p.id : '';
    let newId = (isRestoreSafeIdString(oldId) && !used[oldId]) ? oldId : uid('p');
    while(used[newId]) newId = uid('p');
    used[newId] = true;
    p.id = newId;
    p.name = normalizeRestoreString(p.name, 'プリンタ');
    if(!isRestorePlainObject(p.perTpl)) p.perTpl = {};
    if(oldId && !Object.prototype.hasOwnProperty.call(idMap, oldId)) idMap[oldId] = newId;
  });
  const remapPrinterId = v=>{
    if(typeof v !== 'string' || !v) return null;
    if(Object.prototype.hasOwnProperty.call(idMap, v)) return idMap[v];
    return used[v] ? v : null;
  };
  next.selectedPrinterId = remapPrinterId(next.selectedPrinterId);
  // v37 step31: addon内ID変換にも同じ対応表を使うため、復元コンテキストに保持する。stateへは反映しない。
  next.__restorePrinterIdMap = idMap;
  next.__restorePrinterIds = used;
  return next;
}
function normalizeRestoreString(v, fallback){
  // v37 step27: 復元fieldの文字列項目を安全に文字列化する。
  if(v === undefined || v === null) return fallback == null ? '' : String(fallback);
  return String(v);
}
function normalizeRestoreNumber(v, fallback, min, max){
  // v37 step27: 復元fieldの座標・サイズ等を有限数値へ補正する。
  let n = (typeof v === 'number') ? v : parseFloat(v);
  if(!Number.isFinite(n)) n = fallback;
  if(min !== undefined && n < min) n = min;
  if(max !== undefined && n > max) n = max;
  return n;
}
function normalizeRestoreBool(v, fallback){
  // v37 step27: 文字列化された真偽値も既存バックアップ互換として受ける。
  if(v === undefined || v === null) return !!fallback;
  if(typeof v === 'boolean') return v;
  if(typeof v === 'string'){
    const s = v.toLowerCase().trim();
    if(['true','1','yes','on'].includes(s)) return true;
    if(['false','0','no','off'].includes(s)) return false;
  }
  return !!v;
}
function normalizeRestoreSource(v){
  const key = normalizeRestoreString(v, 'custom').trim() || 'custom';
  try{
    const registry = window.FieldSourceRegistry || FieldSourceRegistry;
    if(registry && typeof registry.hasSource === 'function' && registry.hasSource(key)) return key;
  }catch(e){ console.warn('restore source registry check failed', e); }
  return 'custom';
}
function normalizeRestoreZipConfig(v){
  // v37 step27: 郵便番号fieldの詳細設定を描画可能な範囲に補正する。
  const base = {showFrame:false,showMark:false,charSpacing:1.2,gapAfter3:1.5,digitOffsets:[]};
  const raw = isRestorePlainObject(v) ? v : {};
  const out = {
    showFrame: normalizeRestoreBool(raw.showFrame, base.showFrame),
    showMark: normalizeRestoreBool(raw.showMark, base.showMark),
    charSpacing: normalizeRestoreNumber(raw.charSpacing, base.charSpacing, 0, 10),
    gapAfter3: normalizeRestoreNumber(raw.gapAfter3, base.gapAfter3, 0, 20),
    digitOffsets: []
  };
  if(Array.isArray(raw.digitOffsets)){
    out.digitOffsets = raw.digitOffsets.slice(0, 7).map(o=>{
      const item = isRestorePlainObject(o) ? o : {};
      return {x:normalizeRestoreNumber(item.x, 0, -20, 20), y:normalizeRestoreNumber(item.y, 0, -20, 20)};
    });
  }
  return out;
}
function normalizeRestoreField(raw, tpl){
  // v37 step27: 復元時だけfield単位を安全側へ補正し、壊れたJSONがCSS/描画へ直接流れないようにする。
  const src = isRestorePlainObject(raw) ? raw : {};
  const f = JSON.parse(JSON.stringify(src));
  const source = normalizeRestoreSource(f.source);
  f.id = normalizeRestoreSafeId(f.id, 'f');
  f.source = source;
  f.label = normalizeRestoreString(f.label, getFieldSourceLabel(source) || '項目');
  f.customText = normalizeRestoreString(f.customText, '');
  f.x = normalizeRestoreNumber(f.x, 20, -500, 1000);
  f.y = normalizeRestoreNumber(f.y, 20, -500, 1000);
  f.w = normalizeRestoreNumber(f.w, 50, 1, 1000);
  f.h = normalizeRestoreNumber(f.h, 12, 1, 1000);
  f.fontSize = normalizeRestoreNumber(f.fontSize, 12, 6, 72);
  f.vertical = normalizeRestoreBool(f.vertical, false);
  f.bold = normalizeRestoreBool(f.bold, false);
  f.autoFit = normalizeRestoreBool(f.autoFit, true);
  f.anchor = ANCHOR_KEYS.includes(f.anchor) ? f.anchor : (f.vertical ? 'tr' : 'tl');
  if(f.source === 'zip') f.zipConfig = normalizeRestoreZipConfig(f.zipConfig);
  else if(f.zipConfig !== undefined && !isRestorePlainObject(f.zipConfig)) delete f.zipConfig;
  if(f.source === 'image'){
    if(typeof f.imageData !== 'string') delete f.imageData;
    f.imageBytes = normalizeRestoreNumber(f.imageBytes, f.imageData ? estimateDataUrlBytes(f.imageData) : 0, 0, Number.MAX_SAFE_INTEGER);
  }else if(f.imageData !== undefined && typeof f.imageData !== 'string'){
    delete f.imageData;
  }
  return f;
}
function normalizeRestoreTemplateFields(tpl){
  // v37 step27: 復元経路に限定してfields配列の中身を正規化する。通常起動時の既存localStorage読込には適用しない。
  if(!tpl) return tpl;
  if(!Array.isArray(tpl.fields)) tpl.fields = [];
  tpl.fields = tpl.fields.map(f=>normalizeRestoreField(f, tpl));
  return tpl;
}
function sanitizeSnapshotForRestore(d){
  if(!isRestorePlainObject(d)) throw new Error('invalid backup data');
  if(d.addons !== undefined && d.addons !== null && !isRestorePlainObject(d.addons)){
    throw new Error('invalid backup field: addons');
  }
  const next = {
    templates: cloneRestoreArray(d, 'templates', [], true),
    queue: cloneRestoreArray(d, 'queue', [], false),
    addressBook: cloneRestoreArray(d, 'addressBook', [], false),
    history: cloneRestoreArray(d, 'history', [], false),
    printAttempts: cloneRestoreArray(d, 'printAttempts', [], false),
    printerProfiles: cloneRestoreArray(d, 'printerProfiles', [], false),
    lastUsedTplId: normalizeRestoreId(d.lastUsedTplId),
    selectedPrinterId: normalizeRestoreId(d.selectedPrinterId)
  };
  normalizeRestoreTemplateIds(next);
  normalizeRestorePrinterIds(next);
  next.templates.forEach(normalizeTpl);
  // v37 step27: 復元時のみfield内部の型・範囲を補正する。
  next.templates.forEach(normalizeRestoreTemplateFields);
  return next;
}
function cloneLoadArray(d, key, fallback){
  // v37 step62: 通常起動時localStorage読込は、壊れた配列要素を丸ごとstateへ流し込まず、有効なplain objectだけを通す。
  const v = d && d[key];
  if(!Array.isArray(v)) return fallback;
  const out = [];
  v.forEach((item, i)=>{
    if(isRestorePlainObject(item)) out.push(JSON.parse(JSON.stringify(item)));
    else console.warn('invalid local storage item skipped', key+'['+i+']');
  });
  return out;
}
function sanitizeSnapshotForLoad(d){
  // v37 step62: 復元時だけでなく通常起動時にも軽量sanitizeを通し、手編集・破損localStorageへの耐性を上げる。
  if(!isRestorePlainObject(d)) throw new Error('invalid saved data');
  const next = {
    templates: cloneLoadArray(d, 'templates', [], false),
    queue: cloneLoadArray(d, 'queue', [], false),
    addressBook: cloneLoadArray(d, 'addressBook', [], false),
    history: cloneLoadArray(d, 'history', [], false),
    printAttempts: cloneLoadArray(d, 'printAttempts', [], false),
    printerProfiles: cloneLoadArray(d, 'printerProfiles', [], false),
    lastUsedTplId: normalizeRestoreId(d.lastUsedTplId),
    selectedPrinterId: normalizeRestoreId(d.selectedPrinterId)
  };
  if(!next.templates.length) next.templates = initialTemplates();
  normalizeRestoreTemplateIds(next);
  normalizeRestorePrinterIds(next);
  next.templates.forEach(normalizeTpl);
  next.templates.forEach(normalizeRestoreTemplateFields);
  return next;
}
function applySanitizedSnapshotToState(next){
  state.templates = next.templates;
  state.queue = next.queue;
  state.addressBook = next.addressBook;
  state.history = next.history;
  state.printAttempts = next.printAttempts;
  state.printerProfiles = next.printerProfiles;
  state.lastUsedTplId = next.lastUsedTplId;
  state.selectedPrinterId = next.selectedPrinterId;
  return next;
}
function applySnapshotToState(d){
  const next = sanitizeSnapshotForRestore(d);
  return applySanitizedSnapshotToState(next);
}
async function restoreFullBackupSafely(d, message){
  const stateRollback = cloneStateForRestoreRollback();
  const addonRollback = captureAddonRawStorage();
  let restoreMainSaved = false;
  try{
    const restoreContext = applySnapshotToState(d);
    const addonResult = d.addons ? restoreAddonStorageSnapshot(d.addons, restoreContext) : {ok:true,failed:[],skipped:[]};
    if(!addonResult.ok){
      const addonRollbackResult = rollbackAddonStorageAfterRestoreFailure(addonRollback, 'addon restore failed');
      restoreStateFromRollbackSnapshot(stateRollback);
      toast(
        addonRollbackResult.ok
          ? `復元に失敗しました。書き戻せないアドオンデータがあります：${addonResult.failed.join(', ')}`
          : `復元に失敗し、アドオンデータの巻き戻しにも失敗しました：${addonRollbackResult.failed.join(', ')}`,
        'warn'
      );
      return false;
    }
    if(!save(true)){
      const addonRollbackResult = rollbackAddonStorageAfterRestoreFailure(addonRollback, 'restore save failed');
      restoreStateFromRollbackSnapshot(stateRollback);
      const rollbackSaved = persistRollbackStateAfterRestoreFailure('restore save failed');
      toast(
        !addonRollbackResult.ok
          ? `復元に失敗し、アドオンデータの巻き戻しにも失敗しました：${addonRollbackResult.failed.join(', ')}`
          : (rollbackSaved ? '復元に失敗しました。保存容量を確認してください' : '復元に失敗し、元データの再保存にも失敗しました。手動バックアップで退避してください'),
        'warn'
      );
      return false;
    }
    restoreMainSaved = true;
    if(addonResult.skipped && addonResult.skipped.length){
      // v37 step43: 復元完了後の破損アドオン除外通知もDOMモーダルで表示し、読み終わってからリロード予約へ進む。
      await showAppAlert(`復元は完了しましたが、破損マーカーを含むアドオンデータは復元対象から除外しました。\n対象：${addonResult.skipped.join(', ')}`, '復元時の一部除外');
    }
    requestReloadAfterDataRestore(message||'復元しました');
    return true;
  }catch(e){
    if(restoreMainSaved){
      // v37 step56: 復元データの保存後に通知・リロード予約だけ失敗した場合は、成功済みの復元を巻き戻さない。
      console.warn('post-restore follow-up failed', e);
      try{ requestReloadAfterDataRestore(message||'復元しました'); }catch(e2){ console.warn('post-restore reload request failed', e2); }
      return true;
    }
    const addonRollbackResult = rollbackAddonStorageAfterRestoreFailure(addonRollback, 'restore exception rollback');
    restoreStateFromRollbackSnapshot(stateRollback);
    const rollbackSaved = persistRollbackStateAfterRestoreFailure('restore exception rollback');
    toast(
      !addonRollbackResult.ok
        ? `復元に失敗し、アドオンデータの巻き戻しにも失敗しました：${addonRollbackResult.failed.join(', ')}`
        : (rollbackSaved ? '復元に失敗しました。バックアップデータを確認してください' : '復元に失敗し、元データの再保存にも失敗しました。手動バックアップで退避してください'),
      'warn'
    );
    console.warn('restore failed and rolled back', e);
    return false;
  }
}
function getBackups(){
  try{
    const raw=localStorage.getItem(BACKUP_KEY);
    if(raw) return JSON.parse(raw);
    // v37 step55: 旧バックアップキー互換は撤去。完全新規システムとして現行BACKUP_KEYのみ参照する。
    return [];
  }
  catch(e){ console.warn('backup list load failed', e); return[]; }
}
function hasActiveWizardDraft(){
  // v37 step58: 位置合わせウィザード中のドラフトは通常保存対象外なので、ページ離脱前に保護する。
  return typeof wizardState !== 'undefined' && !!wizardState;
}
function shouldBlockUnloadForSaveFailure(){
  // v37 step57: 離脱直前のflushが失敗した場合、または直近の保存失敗が未解消の場合は離脱を抑止する。
  // v37 step58: ウィザード中の未保存ドラフトも離脱抑止対象に含める。
  // ブラウザは独自文言を表示しないことが多いが、returnValue設定により標準の離脱確認を出せる。
  return hasUnresolvedSaveFailure() || hasActiveWizardDraft();
}
if(global && typeof global.addEventListener === 'function'){
  global.addEventListener('beforeunload',(e)=>{
    // デバウンス保存の予約だけで未書込の変更を残さない。
    let flushOk = true;
    if(hasPendingSave()) flushOk = flushPendingSave();
    if(!flushOk || shouldBlockUnloadForSaveFailure()){
      const message = hasActiveWizardDraft()
        ? '位置合わせウィザードの未保存の調整内容があります。ページを閉じると破棄されます。'
        : '保存できていない変更があります。ページを閉じる前に手動バックアップを確認してください。';
      e.preventDefault();
      e.returnValue = message;
      return message;
    }
  });
}
function load(){
  try{
    const raw=localStorage.getItem(STORAGE_KEY);
    if(!raw){
      // v37 step55: 旧キー移行は行わず、現行キーにデータがなければ完全新規として初期化する。
      state.templates=initialTemplates();
      return;
    }
    const d=JSON.parse(raw);
    const next=sanitizeSnapshotForLoad(d);
    applySanitizedSnapshotToState(next);
    state.lastSavedAt=d.savedAt||null;
  }catch(e){
    console.error('load失敗',e);
    toast('データ読み込みに失敗。バックアップから復元できます','warn');
    state.templates=initialTemplates();
    state.queue=[];
    state.addressBook=[];
    state.history=[];
    state.printAttempts=[];
    state.printerProfiles=[];
    state.lastUsedTplId=null;
    state.selectedPrinterId=null;
  }
}
function getStorageUsage(){
  try{
    let total=0;
    for(let k in localStorage){
      if(Object.prototype.hasOwnProperty.call(localStorage,k)){
        total += estimateStorageBytes(localStorage[k], k);
      }
    }
    return total;
  }catch(e){
    // v37 step62: 容量計算に失敗した場合も黙殺せず、容量表示の信頼性低下をログに残す。
    console.warn('storage usage calculation failed', e);
    return 0;
  }
}
function isObsoleteStorageKey(key){
  // v37 step55: 完全新規システム化後、旧envelope_print_system系キーは読込対象ではなく容量圧迫要因として扱う。
  const k = String(key || '');
  return /^envelope_print_system/.test(k);
}
function getObsoleteStorageEntries(){
  try{
    const entries=[];
    for(let i=0;i<localStorage.length;i++){
      const key=localStorage.key(i);
      if(!isObsoleteStorageKey(key)) continue;
      const value=localStorage.getItem(key);
      entries.push({key, bytes:estimateStorageBytes(value, key)});
    }
    return entries.sort((a,b)=>a.key.localeCompare(b.key));
  }catch(e){
    console.warn('obsolete storage key scan failed', e);
    return [];
  }
}
function getObsoleteStorageUsage(){
  return getObsoleteStorageEntries().reduce((sum,e)=>sum+(e.bytes||0),0);
}
function removeObsoleteStorageKeys(){
  // v37 step55: 旧キー掃除は現行paper_position_print_system_v37系キーを削除しない。
  const entries=getObsoleteStorageEntries();
  const result={count:0, bytes:0, failed:[]};
  entries.forEach(e=>{
    try{
      localStorage.removeItem(e.key);
      result.count++;
      result.bytes += e.bytes || 0;
    }catch(err){
      console.warn('obsolete storage key remove failed', e.key, err);
      result.failed.push(e.key);
    }
  });
  return result;
}
function retrySaveAfterObsoleteKeyCleanup(cleanupResult){
  // v37 step60: 旧キー削除で容量が空いた直後に保存を再試行し、成功時は保存失敗フラグを解除する。
  if(!cleanupResult || !cleanupResult.count) return {attempted:false, ok:false};
  const ok = save(true);
  return {attempted:true, ok:!!ok};
}
function updateStorageStatus(){
  const el=$('sbStorageStatus');if(!el) return;
  const u=getStorageUsage();
  const lastSave=state.lastSavedAt?fmtDate(state.lastSavedAt):'未保存';
  const warn = u > STORAGE_WARN_BYTES || __lastSaveFailed;
  const statusText = __lastSaveFailed ? `保存失敗：${escapeHtml(__lastSaveFailureMessage || '未保存の変更があります')}` : lastSave;
  el.innerHTML=`<span style="color:${warn?'var(--warn)':'inherit'}">保存:${formatBytes(u)}</span> / ${statusText}`;
}

/* ============================================================
   背景画像の圧縮
   ============================================================ */

const StorageCoreApi = Object.freeze({
  addonStorageKeys,
  isInvalidAddonSnapshotValue,
  getAddonStorageSnapshot,
  captureAddonRawStorage,
  restoreAddonRawStorage,
  rollbackAddonStorageAfterRestoreFailure,
  sanitizeStage8AddonForRestore,
  sanitizeAddonForRestore,
  restoreAddonStorageSnapshot,
  clearAddonStorage,
  notifyStorageFailure,
  dataSnapshot,
  dataSnapshotForBackup,
  hasPendingSave,
  hasUnresolvedSaveFailure,
  flushPendingSave,
  detachPersistedBackgroundsForSave,
  restorePersistedBackgroundsAfterSaveFailure,
  save,
  getStorageUsageExcludingKey,
  writeBackupArrayWithTrim,
  countPersistedBackgroundsInSnapshot,
  backupNow,
  requestReloadAfterDataRestore,
  cloneStateForRestoreRollback,
  restoreStateFromRollbackSnapshot,
  persistRollbackStateAfterRestoreFailure,
  isRestorePlainObject,
  cloneRestoreArray,
  normalizeRestoreId,
  isRestoreSafeIdString,
  normalizeRestoreSafeId,
  normalizeRestoreTemplateIds,
  normalizeRestorePrinterIds,
  normalizeRestoreString,
  normalizeRestoreNumber,
  normalizeRestoreBool,
  normalizeRestoreSource,
  normalizeRestoreZipConfig,
  normalizeRestoreField,
  normalizeRestoreTemplateFields,
  sanitizeSnapshotForRestore,
  cloneLoadArray,
  sanitizeSnapshotForLoad,
  applySanitizedSnapshotToState,
  applySnapshotToState,
  restoreFullBackupSafely,
  getBackups,
  hasActiveWizardDraft,
  shouldBlockUnloadForSaveFailure,
  load,
  getStorageUsage,
  isObsoleteStorageKey,
  getObsoleteStorageEntries,
  getObsoleteStorageUsage,
  removeObsoleteStorageKeys,
  retrySaveAfterObsoleteKeyCleanup,
  updateStorageStatus
});

Object.assign(global, {
  addonStorageKeys,
  isInvalidAddonSnapshotValue,
  getAddonStorageSnapshot,
  captureAddonRawStorage,
  restoreAddonRawStorage,
  rollbackAddonStorageAfterRestoreFailure,
  sanitizeStage8AddonForRestore,
  sanitizeAddonForRestore,
  restoreAddonStorageSnapshot,
  clearAddonStorage,
  notifyStorageFailure,
  dataSnapshot,
  dataSnapshotForBackup,
  hasPendingSave,
  hasUnresolvedSaveFailure,
  flushPendingSave,
  detachPersistedBackgroundsForSave,
  restorePersistedBackgroundsAfterSaveFailure,
  save,
  getStorageUsageExcludingKey,
  writeBackupArrayWithTrim,
  countPersistedBackgroundsInSnapshot,
  backupNow,
  requestReloadAfterDataRestore,
  cloneStateForRestoreRollback,
  restoreStateFromRollbackSnapshot,
  persistRollbackStateAfterRestoreFailure,
  isRestorePlainObject,
  cloneRestoreArray,
  normalizeRestoreId,
  isRestoreSafeIdString,
  normalizeRestoreSafeId,
  normalizeRestoreTemplateIds,
  normalizeRestorePrinterIds,
  normalizeRestoreString,
  normalizeRestoreNumber,
  normalizeRestoreBool,
  normalizeRestoreSource,
  normalizeRestoreZipConfig,
  normalizeRestoreField,
  normalizeRestoreTemplateFields,
  sanitizeSnapshotForRestore,
  cloneLoadArray,
  sanitizeSnapshotForLoad,
  applySanitizedSnapshotToState,
  applySnapshotToState,
  restoreFullBackupSafely,
  getBackups,
  hasActiveWizardDraft,
  shouldBlockUnloadForSaveFailure,
  load,
  getStorageUsage,
  isObsoleteStorageKey,
  getObsoleteStorageEntries,
  getObsoleteStorageUsage,
  removeObsoleteStorageKeys,
  retrySaveAfterObsoleteKeyCleanup,
  updateStorageStatus,
  EnvelopePrintStorageCore: StorageCoreApi
});
})(typeof window !== 'undefined' ? window : globalThis);
