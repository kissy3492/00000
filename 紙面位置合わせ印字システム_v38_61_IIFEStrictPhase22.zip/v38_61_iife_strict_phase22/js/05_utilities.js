(function(global){
  'use strict';
/* ============================================================
   v38-3 共通ユーティリティ集約
   目的：core本体から通知・コピー・a11y・モーダル・表示補助を分離する。
   注意：保存形式・印刷ロジック・field.source名は変更しない。
   読み込み順：00_pdf_loader.js → 05_utilities.js → 10_core.js
   ============================================================ */

/* ============================================================
   ユーティリティ
   ============================================================ */
const $ = id => document.getElementById(id);
function uid(prefix='id'){return prefix+'_'+Math.random().toString(36).slice(2,9)}
function toast(msg,kind=''){
  const t=$('toast');
  if(t){
    t.textContent=msg;
    t.className='toast show'+(kind?' '+kind:'');
  }
  announceA11y(msg);
  clearTimeout(toast._t);
  toast._t=setTimeout(()=>{ if(t) t.classList.remove('show'); },2500);
}
function announceA11y(msg){
  // v37 step48: toastや重要状態変化をスクリーンリーダーへ伝えるための共通ライブリージョン。
  const live=$('a11yStatus');
  if(!live) return;
  live.textContent='';
  const text=msg == null ? '' : String(msg);
  clearTimeout(announceA11y._t);
  announceA11y._t=setTimeout(()=>{ live.textContent=text; },20);
}
function ensureElementId(el, prefix){
  if(!el) return '';
  if(!el.id) el.id=uid(prefix||'el');
  return el.id;
}
function applyLabelForA11y(root){
  // v37 step48: 既存HTMLを大改修せず、ラベルと入力部品の紐付けを動的に補完する。
  const base=root || document;
  base.querySelectorAll('label').forEach(label=>{
    if(label.getAttribute('for')) return;
    let control=label.querySelector('input:not([type=hidden]),select,textarea');
    if(!control && label.parentElement) control=label.parentElement.querySelector('input:not([type=hidden]),select,textarea');
    if(!control) return;
    const id=ensureElementId(control,'ctl');
    if(id) label.setAttribute('for',id);
  });
}
function getTableA11yLabel(table){
  if(!table) return '';
  if(table.classList.contains('preview-table')) return 'Excel貼付プレビュー表';
  if(table.classList.contains('stage5-table')) return '管理一覧表';
  if(table.classList.contains('stage6-table')) return '郵便番号候補表';
  if(table.classList.contains('stage7-guide-table')) return 'ガイド表';
  if(table.classList.contains('stage8-table')) return '印刷ガイド確認表';
  const box = table.closest('.modal-box,.stage8-card,.stage7-card,.stage6-card,.stage5-card,section,main') || table.parentElement;
  const heading = box ? box.querySelector('h1,h2,h3,h4,h5') : null;
  const text = heading ? String(heading.textContent||'').trim() : '';
  return text ? text + 'の表' : '一覧表';
}
function applyTableA11y(root){
  // v37 step50: 既存の表UIに最小限のARIA・scopeを補完する。表構造やデータは変更しない。
  const base=root || document;
  base.querySelectorAll('table').forEach(table=>{
    if(!table.getAttribute('role')) table.setAttribute('role','table');
    if(!table.getAttribute('aria-label') && !table.querySelector('caption')){
      table.setAttribute('aria-label', getTableA11yLabel(table));
    }
    table.querySelectorAll('thead th').forEach(th=>{ if(!th.getAttribute('scope')) th.setAttribute('scope','col'); });
    const rows = Array.from(table.rows || []);
    if(!table.tHead && rows.length){
      const firstRowTh = Array.from(rows[0].cells||[]).filter(c=>c.tagName && c.tagName.toLowerCase()==='th');
      if(firstRowTh.length){
        firstRowTh.forEach(th=>{ if(!th.getAttribute('scope')) th.setAttribute('scope','col'); });
      }
    }
    const bodyRows = table.tBodies && table.tBodies.length ? Array.from(table.tBodies).flatMap(tb=>Array.from(tb.rows)) : rows.slice(table.tHead?0:1);
    bodyRows.forEach(row=>{
      const first = row.cells && row.cells[0];
      if(first && first.tagName && first.tagName.toLowerCase()==='th' && !first.getAttribute('scope')) first.setAttribute('scope','row');
    });
  });
}
function setInputInvalidState(input, invalid, message){
  if(!input || input.type==='hidden') return;
  input.setAttribute('aria-invalid', invalid ? 'true' : 'false');
  let msgEl=null;
  if(message){
    const msgId=ensureElementId(input,'ctl')+'_err';
    msgEl=document.getElementById(msgId);
    if(!msgEl){
      msgEl=document.createElement('div');
      msgEl.id=msgId;
      msgEl.className='sr-only';
      input.insertAdjacentElement('afterend',msgEl);
    }
    msgEl.textContent=message;
    input.setAttribute('aria-describedby', msgId);
  }else if(!invalid){
    const described=input.getAttribute('aria-describedby');
    if(described && described.endsWith('_err')) input.removeAttribute('aria-describedby');
  }
}
function clearInputInvalidStates(root){
  const base=root || document;
  base.querySelectorAll('[aria-invalid="true"]').forEach(el=>setInputInvalidState(el,false,''));
}
function markInputFieldsInvalid(ids, message){
  // v37 step48: 必須入力不足を視覚toastだけでなくaria-invalidとしても示す。
  let first=null;
  (ids||[]).forEach(id=>{
    const el=$(id);
    if(!el || el.type==='hidden') return;
    setInputInvalidState(el,true,message);
    if(!first) first=el;
  });
  announceA11y(message);
  if(first && typeof first.focus==='function') first.focus();
}
function addAriaDescribedBy(el, id){
  if(!el || !id) return;
  const parts=(el.getAttribute('aria-describedby')||'').split(/\s+/).filter(Boolean);
  if(!parts.includes(id)) parts.push(id);
  el.setAttribute('aria-describedby', parts.join(' '));
}
function removeAriaDescribedBy(el, predicate){
  if(!el) return;
  const parts=(el.getAttribute('aria-describedby')||'').split(/\s+/).filter(Boolean);
  const kept=parts.filter(id=>!(predicate && predicate(id)));
  if(kept.length) el.setAttribute('aria-describedby', kept.join(' '));
  else el.removeAttribute('aria-describedby');
}
function ensureRequiredHint(form, id, message){
  let hint=document.getElementById(id);
  if(!hint){
    hint=document.createElement('div');
    hint.id=id;
    hint.className='sr-only';
    (form || document.body).appendChild(hint);
  }
  hint.textContent=message || '';
  return hint;
}
function setInputRequiredA11y(input, required, message, hintId){
  if(!input || input.type==='hidden') return;
  removeAriaDescribedBy(input, id=>/_req$/.test(id) || id===hintId);
  if(required){
    input.setAttribute('aria-required','true');
    if(message && hintId){
      addAriaDescribedBy(input, hintId);
    }
  }else{
    input.removeAttribute('aria-required');
  }
}
function applyInputRequiredA11y(root){
  // v37 step51: HTML required属性で既存挙動を変えず、スクリーンリーダー向けに必須相当項目だけaria-requiredで明示する。
  const base=root || document;
  const form = (base.id==='inputForm') ? base : (base.querySelector ? base.querySelector('#inputForm') : document.getElementById('inputForm'));
  if(!form) return;
  form.querySelectorAll('input:not([type=hidden]),select,textarea').forEach(el=>setInputRequiredA11y(el,false));
  const t = (typeof getCurrentTpl === 'function') ? getCurrentTpl() : null;
  const isReply = !!(t && t.isReply);
  const groupId = isReply ? 'input_required_reply_req' : 'input_required_normal_req';
  const msg = isReply ? '会社名、部署名、氏名または担当者名のいずれかは入力が必要です。' : '氏名または会社名のいずれかは入力が必要です。';
  ensureRequiredHint(form, groupId, msg);
  const ids = isReply ? ['iCompany','iDept','iName'] : ['iName','iCompany'];
  ids.forEach(id=>{
    const el=document.getElementById(id);
    if(el) setInputRequiredA11y(el,true,msg,groupId);
  });
}
function applyInputTabsA11y(){
  const tablist=document.querySelector('.input-tabs');
  if(!tablist) return;
  tablist.setAttribute('role','tablist');
  tablist.setAttribute('aria-label','入力方法の切替');
  const tabs=Array.from(tablist.querySelectorAll('.input-tab'));
  tabs.forEach(tab=>{
    const paneName=tab.dataset.pane;
    if(!paneName) return;
    const pane=document.querySelector(`.input-pane[data-pane="${paneName}"]`);
    const tabId=ensureElementId(tab,'input_tab');
    if(pane) ensureElementId(pane,'input_panel');
    tab.setAttribute('role','tab');
    tab.setAttribute('aria-selected',tab.classList.contains('active')?'true':'false');
    tab.setAttribute('tabindex',tab.classList.contains('active')?'0':'-1');
    if(pane) tab.setAttribute('aria-controls',pane.id);
    if(pane){
      pane.setAttribute('role','tabpanel');
      pane.setAttribute('aria-labelledby',tabId);
      pane.setAttribute('aria-hidden',pane.classList.contains('active')?'false':'true');
    }
  });
}
function applyCustomTabbarA11y(tabbar, options){
  // v37 step49: Stage6/Stage7等の独自タブ風UIにもrole/ariaとキーボード操作を付与する。
  if(!tabbar) return;
  const opt = options || {};
  const tabAttr = opt.tabAttr || 'tab';
  const panel = typeof opt.panel === 'string' ? document.querySelector(opt.panel) : opt.panel;
  const label = opt.label || 'タブ切替';
  const tabs = Array.from(tabbar.querySelectorAll('button')).filter(b=>b.dataset && b.dataset[tabAttr] !== undefined);
  if(!tabs.length) return;
  tabbar.setAttribute('role','tablist');
  tabbar.setAttribute('aria-label',label);
  if(panel){
    ensureElementId(panel,'custom_tab_panel');
    panel.setAttribute('role','tabpanel');
    panel.setAttribute('aria-hidden','false');
  }
  const active = tabs.find(b=>b.classList.contains('active')) || tabs[0];
  tabs.forEach(tab=>{
    const tabId = ensureElementId(tab,'custom_tab');
    const isActive = tab === active;
    tab.setAttribute('role','tab');
    tab.setAttribute('aria-selected',isActive?'true':'false');
    tab.setAttribute('tabindex',isActive?'0':'-1');
    if(panel){
      tab.setAttribute('aria-controls',panel.id);
      if(isActive) panel.setAttribute('aria-labelledby',tabId);
    }
  });
  if(!tabbar.dataset.a11yTabsBound){
    tabbar.dataset.a11yTabsBound='1';
    tabbar.addEventListener('keydown',e=>{
      const currentTabs = Array.from(tabbar.querySelectorAll('button')).filter(b=>b.dataset && b.dataset[tabAttr] !== undefined);
      if(!currentTabs.length) return;
      const current = document.activeElement && currentTabs.includes(document.activeElement) ? document.activeElement : (currentTabs.find(b=>b.getAttribute('aria-selected')==='true') || currentTabs[0]);
      const i = Math.max(0, currentTabs.indexOf(current));
      let next = null;
      if(e.key==='ArrowRight') next = currentTabs[(i+1)%currentTabs.length];
      else if(e.key==='ArrowLeft') next = currentTabs[(i-1+currentTabs.length)%currentTabs.length];
      else if(e.key==='Home') next = currentTabs[0];
      else if(e.key==='End') next = currentTabs[currentTabs.length-1];
      if(next){
        e.preventDefault();
        next.focus();
        next.click();
      }
    });
  }
}
function applyScreenA11y(root){
  // v37 step48: 全画面a11y第一段階。ラベル紐付け、入力タブARIA、ライブリージョンを補完する。
  // v37 step50: 表UIのscope/aria-label補完も同じ入口で実行する。
  // v37 step51: 必須相当の入力項目にaria-requiredを補完する。HTML required属性は既存挙動維持のため付けない。
  const base=root || document;
  applyLabelForA11y(base);
  applyInputRequiredA11y(base);
  applyTableA11y(base);
  applyInputTabsA11y();
}
function escapeHtml(s){
  if(s==null) return '';
  return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function getTpl(id){return state.templates.find(t=>t.id===id)}
function getCurrentTpl(){return getTpl(state.selectedTplId)}
function getPrinter(id){return state.printerProfiles.find(p=>p.id===id)}
function getCurrentPrinter(){return getPrinter(state.selectedPrinterId)}
function getPrinterCorrection(printerId, tplId){
  const p=getPrinter(printerId);
  if(!p||!tplId||!p.perTpl||!p.perTpl[tplId]) return {rightShift:0,downShift:0,widthDiff:0,heightDiff:0};
  return p.perTpl[tplId];
}
function setPrinterCorrection(printerId, tplId, corr){
  const p=getPrinter(printerId);if(!p) return;
  if(!p.perTpl) p.perTpl={};
  p.perTpl[tplId]=corr;
}
function correctionToTransform(corr, tplW, tplH){
  const offsetX = -corr.rightShift;
  const offsetY = -corr.downShift;
  const scaleX = tplW>0 ? (tplW - corr.widthDiff) / tplW : 1;
  const scaleY = tplH>0 ? (tplH - corr.heightDiff) / tplH : 1;
  return {offsetX, offsetY, scaleX, scaleY};
}
function hasAnyCorrection(corr){
  return !!(corr.rightShift||corr.downShift||corr.widthDiff||corr.heightDiff);
}
function getBgImage(tpl){
  if(!tpl) return null;
  if(tpl.bgPersist&&tpl.bgImage) return {data:tpl.bgImage,name:tpl.bgSourceName,bytes:estimateDataUrlBytes(tpl.bgImage)};
  const tb=transientBg[tpl.id];
  if(tb) return {data:tb.dataUrl,name:tb.name,bytes:tb.bytes};
  return null;
}
function fmtDate(ts){
  if(!ts) return '—';
  const d=new Date(ts);const pad=n=>String(n).padStart(2,'0');
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function formatBytes(b){
  if(b<1024) return b+' B';
  if(b<1024*1024) return (b/1024).toFixed(1)+' KB';
  return (b/1024/1024).toFixed(2)+' MB';
}
function estimateStorageBytes(value, key){
  // v37 step10: localStorage容量判定は文字数ではなく、UTF-16換算の概算バイトで揃える。
  const v = value == null ? '' : String(value);
  const k = key == null ? '' : String(key);
  return (v.length + k.length) * 2;
}
function estimateDataUrlBytes(dataUrl){
  // v37 step10: DataURLの表示容量は文字列長ではなく、実ペイロード相当の概算バイトで揃える。
  const s = dataUrl == null ? '' : String(dataUrl);
  const comma = s.indexOf(',');
  if(comma < 0) return s.length;
  const meta = s.slice(0, comma).toLowerCase();
  const body = s.slice(comma + 1).replace(/\s/g, '');
  if(meta.includes(';base64')){
    const padding = body.endsWith('==') ? 2 : (body.endsWith('=') ? 1 : 0);
    return Math.max(0, Math.floor(body.length * 3 / 4) - padding);
  }
  try{return decodeURIComponent(body).length}catch(e){return body.length}
}

/* ============================================================
   カスタムモーダルa11y補助
   ============================================================ */
function getFocusableElements(root){
  // v37 step44: カスタムモーダル内のTab移動対象を抽出する。
  if(!root) return [];
  return Array.from(root.querySelectorAll('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])'))
    .filter(el=>!el.disabled && el.getAttribute('aria-hidden')!=='true' && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
}

function prepareAccessibleModal(modal, options){
  // v37 step44: role/aria付きモーダルでフォーカスを閉じ込め、閉じた後は元のフォーカスへ戻す。
  const opt = options || {};
  const previous = document.activeElement && document.activeElement !== document.body ? document.activeElement : null;
  const onKeyDown = e=>{
    if(e.key !== 'Tab') return;
    const focusables = getFocusableElements(modal);
    if(!focusables.length){
      e.preventDefault();
      if(typeof modal.focus === 'function') modal.focus();
      return;
    }
    const first = focusables[0], last = focusables[focusables.length - 1];
    if(e.shiftKey && document.activeElement === first){
      e.preventDefault();
      last.focus();
    }else if(!e.shiftKey && document.activeElement === last){
      e.preventDefault();
      first.focus();
    }
  };
  modal.addEventListener('keydown', onKeyDown);
  return {
    focusInitial(){
      setTimeout(()=>{
        const explicit = opt.initialFocus ? modal.querySelector(opt.initialFocus) : null;
        const target = explicit || getFocusableElements(modal)[0] || modal.querySelector('[role=dialog]') || modal;
        if(target && typeof target.focus === 'function') target.focus();
      }, 0);
    },
    close(options){
      const closeOpt = options || {};
      modal.removeEventListener('keydown', onKeyDown);
      modal.remove();
      // v37 step67: モーダル内遷移では旧モーダルのフォーカス復帰が新モーダル初期フォーカスを奪わないよう抑止する。
      if(!closeOpt.suppressFocusRestore && previous && typeof previous.focus === 'function' && document.contains(previous)){
        setTimeout(()=>{try{previous.focus()}catch(e){}}, 0);
      }
    }
  };
}

function applyLegacyModalA11y(modal, options){
  // v37 step45: 既存DOMモーダルにもrole/aria、フォーカストラップ、閉じた後のフォーカス復帰を段階適用する。
  if(!modal) return null;
  const opt = options || {};
  modal.dataset.legacyModal = '1';
  modal.tabIndex = -1;
  const box = modal.querySelector('.modal-box') || modal.firstElementChild;
  if(box){
    if(!box.getAttribute('role')) box.setAttribute('role', opt.role || 'dialog');
    box.setAttribute('aria-modal','true');
    if(!box.getAttribute('tabindex')) box.setAttribute('tabindex','-1');
    const titleEl = (opt.titleSelector && box.querySelector(opt.titleSelector)) || box.querySelector('h3,h2,h4');
    if(titleEl){
      if(!titleEl.id) titleEl.id = uid('dlgTitle');
      box.setAttribute('aria-labelledby', titleEl.id);
    }
    const descEl = (opt.descSelector && box.querySelector(opt.descSelector)) || box.querySelector('p,.hint,.stage7-callout,.stage5-danger-note,.stage6-mini');
    if(descEl){
      if(!descEl.id) descEl.id = uid('dlgDesc');
      box.setAttribute('aria-describedby', descEl.id);
    }
  }
  applyLabelForA11y(modal);
  applyTableA11y(modal);
  const a11y = prepareAccessibleModal(modal, {initialFocus: opt.initialFocus || '[data-stage8-close],button,input,select,textarea'});
  modal.__legacyA11y = a11y;
  a11y.focusInitial();
  return a11y;
}

function closeAccessibleModal(modal, options){
  // v37 step45: 既存モーダルを閉じる時も、可能ならフォーカス復帰を通す。
  // v37 step67: モーダル内遷移では options.suppressFocusRestore で復帰を抑止できる。
  if(!modal) return;
  const opt = options || {};
  if(modal.__legacyA11y && typeof modal.__legacyA11y.close === 'function'){
    modal.__legacyA11y.close(opt);
    return;
  }
  modal.remove();
}


/* ============================================================
   汎用通知モーダル
   ============================================================ */
function showAppAlert(message, title){
  // v37 step33: 情報通知系alertをブラウザ標準ダイアログからDOMモーダルへ移行する。
  // v37 step44: role/aria、フォーカストラップ、閉じた後のフォーカス復帰を追加する。
  return new Promise(resolve=>{
    const modal=document.createElement('div');
    modal.className='modal-overlay';
    modal.dataset.appAlert='1';
    modal.tabIndex=-1;
    const ttl = title || 'お知らせ';
    const titleId = uid('dlgTitle');
    const msgId = uid('dlgMsg');
    modal.innerHTML=`<div class="modal-box" role="dialog" aria-modal="true" aria-labelledby="${titleId}" aria-describedby="${msgId}" tabindex="-1" style="min-width:360px;max-width:min(560px,90vw)">
      <h3 id="${titleId}">${escapeHtml(ttl)}</h3>
      <p id="${msgId}" style="white-space:pre-wrap">${escapeHtml(message == null ? '' : String(message))}</p>
      <div class="actions"><button class="btn primary" data-app-alert-close>閉じる</button></div>
    </div>`;
    const a11y = prepareAccessibleModal(modal, {initialFocus:'[data-app-alert-close]'});
    let done=false;
    const close=()=>{if(done) return; done=true; a11y.close(); resolve(true);};
    modal.querySelector('[data-app-alert-close]').addEventListener('click',close);
    modal.addEventListener('click',e=>{if(e.target===modal) close();});
    document.body.appendChild(modal);
    a11y.focusInitial();
  });
}

function showAppConfirm(message, title, options){
  // v37 step34: 低リスクな確認だけを非同期DOMモーダルへ移行するための共通confirm。
  // v37 step44: role/aria、フォーカストラップ、閉じた後のフォーカス復帰を追加する。
  const opt = options || {};
  return new Promise(resolve=>{
    const modal=document.createElement('div');
    modal.className='modal-overlay';
    modal.dataset.appConfirm='1';
    modal.tabIndex=-1;
    const ttl = title || '確認';
    const okLabel = opt.okLabel || '実行';
    const cancelLabel = opt.cancelLabel || 'キャンセル';
    const okClass = opt.danger ? 'btn danger' : 'btn primary';
    const titleId = uid('dlgTitle');
    const msgId = uid('dlgMsg');
    modal.innerHTML=`<div class="modal-box" role="alertdialog" aria-modal="true" aria-labelledby="${titleId}" aria-describedby="${msgId}" tabindex="-1" style="min-width:360px;max-width:min(560px,90vw)">
      <h3 id="${titleId}">${escapeHtml(ttl)}</h3>
      <p id="${msgId}" style="white-space:pre-wrap">${escapeHtml(message == null ? '' : String(message))}</p>
      <div class="actions"><button class="btn ghost" data-app-confirm-cancel>${escapeHtml(cancelLabel)}</button><button class="${okClass}" data-app-confirm-ok>${escapeHtml(okLabel)}</button></div>
    </div>`;
    const a11y = prepareAccessibleModal(modal, {initialFocus:'[data-app-confirm-cancel]'});
    let done=false;
    const close=(value)=>{if(done) return; done=true; a11y.close(); resolve(!!value);};
    modal.querySelector('[data-app-confirm-ok]').addEventListener('click',()=>close(true));
    modal.querySelector('[data-app-confirm-cancel]').addEventListener('click',()=>close(false));
    modal.addEventListener('click',e=>{if(e.target===modal) close(false);});
    document.body.appendChild(modal);
    a11y.focusInitial();
  });
}

function showAppPrompt(message, defaultValue, title, options){
  // v37 step42: ブラウザ標準promptをDOM入力モーダルへ移行する。キャンセル時は従来promptと同じくnullを返す。
  // v37 step44: role/aria、フォーカストラップ、閉じた後のフォーカス復帰を追加する。
  const opt = options || {};
  return new Promise(resolve=>{
    const modal=document.createElement('div');
    modal.className='modal-overlay';
    modal.dataset.appPrompt='1';
    modal.tabIndex=-1;
    const ttl = title || '入力';
    const okLabel = opt.okLabel || 'OK';
    const cancelLabel = opt.cancelLabel || 'キャンセル';
    const inputId = uid('inp');
    const titleId = uid('dlgTitle');
    const msgId = uid('dlgMsg');
    modal.innerHTML=`<div class="modal-box" role="dialog" aria-modal="true" aria-labelledby="${titleId}" aria-describedby="${msgId}" tabindex="-1" style="min-width:360px;max-width:min(560px,90vw)">
      <h3 id="${titleId}">${escapeHtml(ttl)}</h3>
      <label id="${msgId}" for="${inputId}" style="display:block;font-size:12px;color:#555;margin-bottom:6px;white-space:pre-wrap">${escapeHtml(message == null ? '' : String(message))}</label>
      <input id="${inputId}" data-app-prompt-input aria-describedby="${msgId}" style="width:100%;box-sizing:border-box" />
      <div class="actions"><button class="btn ghost" data-app-prompt-cancel>${escapeHtml(cancelLabel)}</button><button class="btn primary" data-app-prompt-ok>${escapeHtml(okLabel)}</button></div>
    </div>`;
    const input=modal.querySelector('[data-app-prompt-input]');
    const a11y = prepareAccessibleModal(modal, {initialFocus:'[data-app-prompt-input]'});
    let done=false;
    const close=(value)=>{if(done) return; done=true; a11y.close(); resolve(value);};
    if(input) input.value = defaultValue == null ? '' : String(defaultValue);
    modal.querySelector('[data-app-prompt-ok]').addEventListener('click',()=>close(input ? input.value : ''));
    modal.querySelector('[data-app-prompt-cancel]').addEventListener('click',()=>close(null));
    modal.addEventListener('click',e=>{if(e.target===modal) close(null);});
    if(input) input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();close(input.value);}});
    document.body.appendChild(modal);
    a11y.focusInitial();
    if(input) setTimeout(()=>{try{input.select()}catch(e){}}, 0);
  });
}

async function copyTextToClipboard(text, options){
  // v37 step64: クリップボードコピー経路を一本化し、直叩きとStage8専用copyTextの二重管理を避ける。
  const opt = options || {};
  const raw = text == null ? '' : String(text);
  const successMessage = opt.successMessage || 'クリップボードにコピーしました';
  const fallbackMessage = opt.fallbackMessage || 'テキストを選択しました（Ctrl+Cでコピー）';
  try{
    if(navigator.clipboard && navigator.clipboard.writeText){
      await navigator.clipboard.writeText(raw);
      toast(successMessage,'ok');
      return true;
    }
  }catch(e){ console.warn('clipboard write failed', e); }
  let ta = opt.fallbackElement || null;
  let created = false;
  if(!ta){
    ta = document.createElement('textarea');
    ta.style.position='fixed';
    ta.style.left='-9999px';
    ta.style.top='0';
    document.body.appendChild(ta);
    created = true;
  }
  try{
    ta.value = raw;
    ta.focus();
    ta.select();
    const ok = document.execCommand ? document.execCommand('copy') : false;
    toast(ok ? successMessage : fallbackMessage, ok ? 'ok' : 'warn');
    return !!ok;
  }catch(e){
    console.warn('fallback clipboard copy failed', e);
    toast(fallbackMessage,'warn');
    return false;
  }finally{
    if(created && ta) ta.remove();
  }
}



  const UtilitiesApi = Object.freeze({
    $,
    uid,
    toast,
    announceA11y,
    ensureElementId,
    applyLabelForA11y,
    getTableA11yLabel,
    applyTableA11y,
    setInputInvalidState,
    clearInputInvalidStates,
    markInputFieldsInvalid,
    addAriaDescribedBy,
    removeAriaDescribedBy,
    ensureRequiredHint,
    setInputRequiredA11y,
    applyInputRequiredA11y,
    applyInputTabsA11y,
    applyCustomTabbarA11y,
    applyScreenA11y,
    escapeHtml,
    getTpl,
    getCurrentTpl,
    getPrinter,
    getCurrentPrinter,
    getPrinterCorrection,
    setPrinterCorrection,
    correctionToTransform,
    hasAnyCorrection,
    getBgImage,
    fmtDate,
    formatBytes,
    estimateStorageBytes,
    estimateDataUrlBytes,
    getFocusableElements,
    prepareAccessibleModal,
    applyLegacyModalA11y,
    closeAccessibleModal,
    showAppAlert,
    showAppConfirm,
    showAppPrompt,
    copyTextToClipboard
  });

  Object.assign(global, {
    $,
    uid,
    toast,
    announceA11y,
    ensureElementId,
    applyLabelForA11y,
    getTableA11yLabel,
    applyTableA11y,
    setInputInvalidState,
    clearInputInvalidStates,
    markInputFieldsInvalid,
    addAriaDescribedBy,
    removeAriaDescribedBy,
    ensureRequiredHint,
    setInputRequiredA11y,
    applyInputRequiredA11y,
    applyInputTabsA11y,
    applyCustomTabbarA11y,
    applyScreenA11y,
    escapeHtml,
    getTpl,
    getCurrentTpl,
    getPrinter,
    getCurrentPrinter,
    getPrinterCorrection,
    setPrinterCorrection,
    correctionToTransform,
    hasAnyCorrection,
    getBgImage,
    fmtDate,
    formatBytes,
    estimateStorageBytes,
    estimateDataUrlBytes,
    getFocusableElements,
    prepareAccessibleModal,
    applyLegacyModalA11y,
    closeAccessibleModal,
    showAppAlert,
    showAppConfirm,
    showAppPrompt,
    copyTextToClipboard
  });
  global.EnvelopePrintUtilities = UtilitiesApi;
})(typeof window !== 'undefined' ? window : globalThis);
