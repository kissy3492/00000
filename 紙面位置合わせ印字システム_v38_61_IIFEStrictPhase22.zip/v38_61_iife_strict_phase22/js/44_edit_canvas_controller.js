(function(global){
  'use strict';

/* ============================================================
   v38-20/v38-23/v38-54: Edit Canvas Controller
   詳細編集画面の描画入口、ドラッグ操作、mm換算、避ける範囲ドラフト作成を担当。

   契約:
   - classic script / IIFE + explicit window export。
   - 保存キー・保存形式・field.source名は変更しない。
   - renderEnvelopeInto() / renderFieldList() / renderZoneList() / save() / state は実行時参照。
   - v38-23で renderEnvelope() 本体をcoreから移した。
   - v38-54で EnvelopePrintEditCanvasController を明示API化した。
   ============================================================ */

  let addingZoneMode = false;
  let zoneDraft = null;

  function renderEnvelope(){
    const env=$('envelope');
    const t=getCurrentTpl();
    if(!t){
      env.style.width='240mm';
      env.style.height='332mm';
      env.innerHTML='';
      return;
    }
    const sample=getSampleData(t);
    renderEnvelopeInto(env, t, sample, {
      editable: state.mode==='edit',
      scale: state.zoom,
      interactive: state.mode==='edit',
      showBg: state.mode==='edit',
      showZones: state.mode==='edit',
      applyCorrection: false
    });
  }

  function getMMperPxOf(env){
    const r=env.getBoundingClientRect();
    return parseFloat(env.style.width)/r.width;
  }
  function getMMperPx(){return getMMperPxOf($('envelope'))}
  function getDragPoint(e){
    // v37 step18: mouse/touch の座標取得を共通化し、タッチでサロゲートの mouse 依存を避ける。
    const p = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e;
    return {clientX:p.clientX, clientY:p.clientY};
  }
  function isPrimaryDragStart(e){
    if(e.type === 'mousedown') return e.button === 0;
    if(e.type === 'touchstart') return e.touches && e.touches.length === 1;
    return false;
  }
  function preventDragDefault(e){
    if(e && e.cancelable !== false) e.preventDefault();
  }
  function addDragDocumentListeners(moveFn, upFn){
    document.addEventListener('mousemove', moveFn);
    document.addEventListener('mouseup', upFn);
    document.addEventListener('touchmove', moveFn, {passive:false});
    document.addEventListener('touchend', upFn);
    document.addEventListener('touchcancel', upFn);
  }
  function removeDragDocumentListeners(moveFn, upFn){
    document.removeEventListener('mousemove', moveFn);
    document.removeEventListener('mouseup', upFn);
    document.removeEventListener('touchmove', moveFn);
    document.removeEventListener('touchend', upFn);
    document.removeEventListener('touchcancel', upFn);
  }

  function attachFieldDrag(el,fld){
    function startDrag(e){
      if(!isPrimaryDragStart(e)||addingZoneMode) return;
      const t = getCurrentTpl();
      if(t && t.locked){
        toast('ロックされています。先にロック解除してください','warn');
        return;
      }
      preventDragDefault(e);
      const mmPx=getMMperPx();const p=getDragPoint(e);const sx=p.clientX,sy=p.clientY;
      const ox=fld.x,oy=fld.y;
      state.selectedFieldId=fld.id;state.selectedZoneId=null;
      function onMove(ev){
        preventDragDefault(ev);
        const mp=getDragPoint(ev);
        fld.x=Math.max(0,Math.round((ox+(mp.clientX-sx)*mmPx)*2)/2);
        fld.y=Math.max(0,Math.round((oy+(mp.clientY-sy)*mmPx)*2)/2);
        renderEnvelope();
      }
      function onUp(){
        removeDragDocumentListeners(onMove,onUp);
        markLayoutChanged(t);
        save();renderFieldList();
      }
      addDragDocumentListeners(onMove,onUp);
    }
    el.addEventListener('mousedown',startDrag);
    el.addEventListener('touchstart',startDrag,{passive:false});
  }
  function attachZoneDrag(el,zone){
    const corner=el.querySelector('.resize-corner');
    if(corner){
      function startResize(e){
        if(!isPrimaryDragStart(e)) return;
        e.stopPropagation();preventDragDefault(e);
        const mmPx=getMMperPx();
        const p=getDragPoint(e);
        const sx=p.clientX,sy=p.clientY,sw=zone.w,sh=zone.h;
        function mv(ev){
          preventDragDefault(ev);
          const mp=getDragPoint(ev);
          zone.w=Math.max(5,Math.round((sw+(mp.clientX-sx)*mmPx)*2)/2);
          zone.h=Math.max(5,Math.round((sh+(mp.clientY-sy)*mmPx)*2)/2);
          renderEnvelope();
        }
        function up(){
          removeDragDocumentListeners(mv,up);
          markLayoutChanged(getCurrentTpl());
          save();renderZoneList();
        }
        addDragDocumentListeners(mv,up);
      }
      corner.addEventListener('mousedown',startResize);
      corner.addEventListener('touchstart',startResize,{passive:false});
    }
    function startMove(e){
      if(e.target===corner||!isPrimaryDragStart(e)) return;
      preventDragDefault(e);
      const mmPx=getMMperPx();
      const p=getDragPoint(e);
      const sx=p.clientX,sy=p.clientY,ox=zone.x,oy=zone.y;
      state.selectedZoneId=zone.id;state.selectedFieldId=null;
      function mv(ev){
        preventDragDefault(ev);
        const mp=getDragPoint(ev);
        zone.x=Math.max(0,Math.round((ox+(mp.clientX-sx)*mmPx)*2)/2);
        zone.y=Math.max(0,Math.round((oy+(mp.clientY-sy)*mmPx)*2)/2);
        renderEnvelope();
      }
      function up(){
        removeDragDocumentListeners(mv,up);
        markLayoutChanged(getCurrentTpl());
        save();renderZoneList();
      }
      addDragDocumentListeners(mv,up);
    }
    el.addEventListener('mousedown',startMove);
    el.addEventListener('touchstart',startMove,{passive:false});
  }

  function startAddZone(){
    if(!getCurrentTpl()){toast('テンプレート未選択','warn');return}
    const t=getCurrentTpl();
    if(t.locked){toast('ロック中は範囲追加できません','warn');return}
    addingZoneMode=true;
    $('envelope').classList.add('adding-zone');
    toast('封筒上でドラッグして範囲を描いてください');
  }

  function startEnvelopeZoneDraft(e){
    if(!addingZoneMode||!isPrimaryDragStart(e)) return;
    preventDragDefault(e);
    const env=$('envelope');const rect=env.getBoundingClientRect();
    const mmPx=getMMperPx();
    const p=getDragPoint(e);
    const sx=(p.clientX-rect.left)*mmPx;const sy=(p.clientY-rect.top)*mmPx;
    zoneDraft=document.createElement('div');zoneDraft.className='zone-draft';
    zoneDraft.style.left=(sx*state.zoom)+'mm';zoneDraft.style.top=(sy*state.zoom)+'mm';
    zoneDraft.style.width='0';zoneDraft.style.height='0';
    env.appendChild(zoneDraft);
    let curX=sx,curY=sy,curW=0,curH=0;
    function mv(ev){
      preventDragDefault(ev);
      const mp=getDragPoint(ev);
      const x2=(mp.clientX-rect.left)*mmPx,y2=(mp.clientY-rect.top)*mmPx;
      curX=Math.min(sx,x2);curY=Math.min(sy,y2);
      curW=Math.abs(x2-sx);curH=Math.abs(y2-sy);
      zoneDraft.style.left=(curX*state.zoom)+'mm';zoneDraft.style.top=(curY*state.zoom)+'mm';
      zoneDraft.style.width=(curW*state.zoom)+'mm';zoneDraft.style.height=(curH*state.zoom)+'mm';
    }
    function up(){
      removeDragDocumentListeners(mv,up);
      addingZoneMode=false;
      $('envelope').classList.remove('adding-zone');
      if(zoneDraft) zoneDraft.remove();zoneDraft=null;
      if(curW<5||curH<5){toast('範囲が小さすぎます','warn');return}
      const t=getCurrentTpl();
      if(!t.excludeZones) t.excludeZones=[];
      t.excludeZones.push({id:uid('z'),x:Math.round(curX*2)/2,y:Math.round(curY*2)/2,w:Math.round(curW*2)/2,h:Math.round(curH*2)/2,label:''});
      markLayoutChanged(t);save();renderZoneList();renderEnvelope();
      $('zoneBadge').textContent=t.excludeZones.length;
      toast('避ける範囲を追加','ok');
    }
    addDragDocumentListeners(mv,up);
  }

  function attachEnvelopeZoneDraftHandler(env){
    if(!env) return;
    env.addEventListener('mousedown',startEnvelopeZoneDraft);
    env.addEventListener('touchstart',startEnvelopeZoneDraft,{passive:false});
  }

  function getEditCanvasControllerState(){
    return {addingZoneMode, hasZoneDraft:!!zoneDraft};
  }

  const EditCanvasControllerApi = Object.freeze({
    renderEnvelope,
    getMMperPxOf,
    getMMperPx,
    getDragPoint,
    isPrimaryDragStart,
    preventDragDefault,
    addDragDocumentListeners,
    removeDragDocumentListeners,
    attachFieldDrag,
    attachZoneDrag,
    startAddZone,
    startEnvelopeZoneDraft,
    attachEnvelopeZoneDraftHandler,
    getEditCanvasControllerState
  });

  Object.assign(global, {
    renderEnvelope,
    getMMperPxOf,
    getMMperPx,
    getDragPoint,
    isPrimaryDragStart,
    preventDragDefault,
    addDragDocumentListeners,
    removeDragDocumentListeners,
    attachFieldDrag,
    attachZoneDrag,
    startAddZone,
    startEnvelopeZoneDraft,
    attachEnvelopeZoneDraftHandler,
    getEditCanvasControllerState,
    EnvelopePrintEditCanvasController: EditCanvasControllerApi
  });
})(typeof window !== 'undefined' ? window : globalThis);
