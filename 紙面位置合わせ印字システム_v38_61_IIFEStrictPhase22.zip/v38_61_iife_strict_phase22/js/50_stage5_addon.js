(function(){
  'use strict';
  const ADDON_KEY = 'paper_position_print_system_v37_stage5_addons';
  const DEFAULT_STAMPS = [
    {id:'st_default_1', text:'親展', category:'注意'},
    {id:'st_default_2', text:'重要', category:'注意'},
    {id:'st_default_3', text:'書類在中', category:'内容物'},
    {id:'st_default_4', text:'請求書在中', category:'内容物'},
    {id:'st_default_5', text:'納品書在中', category:'内容物'},
    {id:'st_default_6', text:'折曲厳禁', category:'注意'},
    {id:'st_default_7', text:'水濡注意', category:'注意'},
    {id:'st_default_8', text:'料金後納郵便', category:'郵便'},
    {id:'st_default_9', text:'料金別納郵便', category:'郵便'},
    {id:'st_default_10', text:'速達', category:'郵便'},
    {id:'st_default_11', text:'簡易書留', category:'郵便'}
  ];
  const DEFAULT_TAGS = ['取引先','官公署','個人','法人','定期送付','要確認','重複候補'];

  let addon = loadAddon();

  function loadAddon(){
    try{
      const raw = localStorage.getItem(ADDON_KEY);
      if(raw){
        const d = JSON.parse(raw);
        if(!Array.isArray(d.senderProfiles)) d.senderProfiles = [];
        if(!Array.isArray(d.stampLibrary) || !d.stampLibrary.length) d.stampLibrary = DEFAULT_STAMPS.slice();
        if(!Array.isArray(d.tags) || !d.tags.length) d.tags = DEFAULT_TAGS.slice();
        return d;
      }
    }catch(e){ console.warn('Stage5 addon load failed', e); try{ toast('差出人・部品データの読込に失敗しました','warn'); }catch(_e){} }
    return {senderProfiles:[], stampLibrary:DEFAULT_STAMPS.slice(), tags:DEFAULT_TAGS.slice(), savedAt:null};
  }
  function saveAddon(){
    addon.savedAt = Date.now();
    try{
      localStorage.setItem(ADDON_KEY, JSON.stringify(addon));
      return true;
    }catch(e){
      // v37 step9: Stage5拡張データの保存失敗を黙殺せず、処理全体を落とさない。
      console.warn('Stage5 addon save failed', e);
      try{ if(typeof toast === 'function') toast('差出人・部品データの保存に失敗しました','warn'); }catch(_e){}
      return false;
    }
  }
  function stageId(prefix){ return prefix + '_' + Math.random().toString(36).slice(2,9); }
  function esc(s){ return window.escapeHtml ? escapeHtml(s) : String(s ?? '').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
  function byId(id){ return document.getElementById(id); }
  function toHalfWidth(s){
    return String(s||'').replace(/[！-～]/g, ch=>String.fromCharCode(ch.charCodeAt(0)-0xFEE0)).replace(/　/g,' ');
  }
  function normalizeZip(v){
    let s = toHalfWidth(v).replace(/[〒\s]/g,'').replace(/[^0-9-]/g,'');
    s = s.replace(/-/g,'');
    if(s.length>3) s = s.slice(0,3)+'-'+s.slice(3,7);
    return s;
  }
  function normalizeSpaces(s){ return toHalfWidth(s).replace(/[ \t]+/g,' ').trim(); }
  function normalizeAddrKey(s){ return toHalfWidth(s).replace(/[\s　\-－ー―‐]/g,'').replace(/[丁目番地号]/g,''); }

  function analyzeAddressData(data, tpl){
    data = Object.assign({}, data||{});
    const messages = [];
    const warnings = [];
    const errors = [];
    const isReply = tpl && tpl.isReply;
    if(!isReply){
      if(data.zip && !/^\d{3}-\d{4}$/.test(normalizeZip(data.zip))) warnings.push('郵便番号が7桁形式ではありません。');
      if(!data.addr && !data.full_addr) warnings.push('住所が未入力です。封筒印字では住所抜けに注意してください。');
      if(!data.name && !data.company && !data.corp) errors.push('氏名・会社名・宛名のいずれかが必要です。');
    } else {
      if(!data.company && !data.dept && !data.name && !data.corp) errors.push('返信用は会社名・部署名・担当者名のいずれかが必要です。');
    }
    if(data.name2 && !data.name) warnings.push('連名だけが入力されています。主たる宛名の入力漏れを確認してください。');
    if(data.honor==='御中' && data.name) warnings.push('個人名に「御中」が付いています。「様」との使い分けを確認してください。');
    if((data.company||data.corp||data.dept) && !data.name && data.honor==='様') warnings.push('法人・部署宛のみなら「御中」の方が自然な場合があります。');
    const senderAny = data.sender_zip||data.sender_addr||data.sender_company||data.sender_dept||data.sender_name||data.sender_tel;
    if(senderAny && data.sender_zip && !/^\d{3}-\d{4}$/.test(normalizeZip(data.sender_zip))) warnings.push('差出人郵便番号が7桁形式ではありません。');
    if(errors.length) return {level:'ng', errors, warnings, messages};
    if(warnings.length) return {level:'warn', errors, warnings, messages};
    return {level:'ok', errors, warnings, messages:['入力形式に大きな問題は見つかりません。']};
  }

  function getCurrentInputDataSafe(){
    try{ return window.getInputData ? getInputData() : {}; }catch(e){ return {}; }
  }

  function renderValidationPanel(){
    const panel = byId('stage5ValidationPanel');
    if(!panel) return;
    const tpl = window.getCurrentTpl ? getCurrentTpl() : null;
    const data = getCurrentInputDataSafe();
    const v = analyzeAddressData(data, tpl);
    const cls = v.level==='ok'?'ok':(v.level==='warn'?'warn':'warn');
    const title = v.level==='ok' ? '入力チェック：問題なし' : (v.level==='ng' ? '入力チェック：要修正' : '入力チェック：要確認');
    const items = [...v.errors.map(x=>'❌ '+x), ...v.warnings.map(x=>'⚠ '+x), ...v.messages.map(x=>'✓ '+x)];
    panel.className = 'stage5-check '+cls;
    panel.innerHTML = `<div class="ttl">${esc(title)}</div><ul>${items.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>
      <div class="stage5-actions" style="margin-top:6px">
        <button class="btn sm ghost" id="stage5NormalizeInput">入力を軽く整形</button>
        <button class="btn sm ghost" id="stage5ApplyDefaultSender">既定の差出人を反映</button>
      </div>`;
    const norm = byId('stage5NormalizeInput');
    if(norm) norm.addEventListener('click', normalizeVisibleInput);
    const ap = byId('stage5ApplyDefaultSender');
    if(ap) ap.addEventListener('click', applyDefaultSenderToInput);
  }

  function normalizeVisibleInput(){
    const zip = byId('iZip'); if(zip) zip.value = normalizeZip(zip.value);
    const szip = byId('iSenderZip'); if(szip) szip.value = normalizeZip(szip.value);
    ['iAddr','iAddr2','iCompany','iDept','iTitle','iName','iName2','iSenderAddr','iSenderCompany','iSenderDept','iSenderName','iSenderTel'].forEach(id=>{
      const el = byId(id); if(el) el.value = normalizeSpaces(el.value);
    });
    renderValidationPanel();
    if(window.toast) toast('入力を整形しました','ok');
  }

  function getDefaultSender(){ return addon.senderProfiles.find(p=>p.isDefault) || addon.senderProfiles[0] || null; }
  function setInput(id, val){ const el=byId(id); if(el) el.value = val||''; }
  function applySenderToInput(p){
    if(!p){ if(window.toast) toast('差出人プロファイルがありません','warn'); return; }
    setInput('iSenderZip', normalizeZip(p.zip));
    setInput('iSenderAddr', p.addr);
    setInput('iSenderCompany', p.company);
    setInput('iSenderDept', p.dept);
    setInput('iSenderName', p.name);
    setInput('iSenderTel', p.tel);
    renderValidationPanel();
    if(window.toast) toast(`差出人「${p.profileName||p.name||'無名'}」を反映しました`,'ok');
  }
  function applyDefaultSenderToInput(){ applySenderToInput(getDefaultSender()); }

  function injectStep3Addon(){
    const form = byId('inputForm');
    if(form && !byId('stage5SenderProfileBox')){
      const box = document.createElement('div');
      box.id = 'stage5SenderProfileBox';
      box.className = 'stage5-card';
      const opts = addon.senderProfiles.map(p=>`<option value="${esc(p.id)}">${esc((p.isDefault?'★ ':'')+(p.profileName||p.name||'無名'))}</option>`).join('');
      box.innerHTML = `<h4>差出人プロファイル</h4>
        <div class="stage5-actions">
          <select id="stage5SenderSelect" style="max-width:260px"><option value="">差出人を選択</option>${opts}</select>
          <button class="btn sm" id="stage5ApplySender">反映</button>
          <button class="btn sm ghost" id="stage5OpenSenderMgmt">管理</button>
        </div>
        <div class="stage5-mini" style="margin-top:4px">よく使う差出人を登録しておくと、毎回の入力を省略できます。</div>`;
      form.parentNode.insertBefore(box, form.nextSibling);
      byId('stage5ApplySender').addEventListener('click',()=>{
        const id = byId('stage5SenderSelect').value;
        applySenderToInput(addon.senderProfiles.find(p=>p.id===id) || getDefaultSender());
      });
      byId('stage5OpenSenderMgmt').addEventListener('click',showSenderProfileModal);
    }
    const inputArea = document.querySelector('.input-pane.active');
    if(inputArea && !byId('stage5ValidationPanel')){
      const panel = document.createElement('div');
      panel.id = 'stage5ValidationPanel';
      inputArea.appendChild(panel);
    }
    const f = byId('inputForm');
    if(f){
      f.querySelectorAll('input,textarea,select').forEach(el=>{
        el.removeEventListener('input', renderValidationPanel);
        el.removeEventListener('change', renderValidationPanel);
        el.addEventListener('input', renderValidationPanel);
        el.addEventListener('change', renderValidationPanel);
      });
    }
    renderValidationPanel();
  }

  function showSenderProfileModal(){
    const modal = document.createElement('div'); modal.className = 'modal-overlay';
    const rows = addon.senderProfiles.map(p=>`<tr>
      <td>${p.isDefault?'<span class="stage5-chip ok">既定</span>':''}${esc(p.profileName||p.name||'無名')}</td>
      <td>${esc([p.zip,p.addr,p.company,p.dept,p.name,p.tel].filter(Boolean).join(' / '))}</td>
      <td class="stage5-actions"><button class="btn sm" data-apply="${esc(p.id)}">反映</button><button class="btn sm ghost" data-default="${esc(p.id)}">既定</button><button class="btn sm ghost" data-edit="${esc(p.id)}">編集</button><button class="btn sm danger" data-del="${esc(p.id)}">削除</button></td>
    </tr>`).join('');
    modal.innerHTML = `<div class="modal-box" style="min-width:760px">
      <h3>差出人プロファイル管理</h3>
      <p>表面・裏面の差出人印字、返信用封筒、帳票追記に使う差出人情報を登録します。</p>
      <div id="stage5SenderForm"></div>
      <h4 class="serif" style="font-size:13px;margin:14px 0 6px">登録済み</h4>
      <table class="stage5-table"><thead><tr><th style="width:160px">名称</th><th>内容</th><th style="width:240px">操作</th></tr></thead><tbody>${rows||'<tr><td colspan="3">未登録</td></tr>'}</tbody></table>
      <div class="actions"><button class="btn ghost" id="stage5SenderClose">閉じる</button></div>
    </div>`;
    document.body.appendChild(modal);
    applyLegacyModalA11y(modal,{title:'差出人プロファイル管理', initialFocus:'#stage5SenderClose'});
    renderSenderForm(modal, null);
    modal.querySelector('#stage5SenderClose').addEventListener('click',()=>closeAccessibleModal(modal));
    modal.addEventListener('click',e=>{ if(e.target===modal) closeAccessibleModal(modal); });
    modal.querySelectorAll('[data-apply]').forEach(b=>b.addEventListener('click',()=>applySenderToInput(addon.senderProfiles.find(p=>p.id===b.dataset.apply))));
    modal.querySelectorAll('[data-default]').forEach(b=>b.addEventListener('click',()=>{ addon.senderProfiles.forEach(p=>p.isDefault=p.id===b.dataset.default); saveAddon(); closeAccessibleModal(modal); showSenderProfileModal(); }));
    modal.querySelectorAll('[data-edit]').forEach(b=>b.addEventListener('click',()=>renderSenderForm(modal, addon.senderProfiles.find(p=>p.id===b.dataset.edit))));
    modal.querySelectorAll('[data-del]').forEach(b=>b.addEventListener('click',async ()=>{
      // v37 step35: Stage5削除確認をブラウザ標準confirmからDOMモーダルへ移行する。
      if(await showAppConfirm('削除しますか？','差出人プロファイルの削除',{okLabel:'削除する',danger:true})){
        addon.senderProfiles=addon.senderProfiles.filter(p=>p.id!==b.dataset.del); saveAddon(); closeAccessibleModal(modal); showSenderProfileModal();
      }
    }));
  }
  function renderSenderForm(modal, p){
    const target = modal.querySelector('#stage5SenderForm');
    const cur = p || {id:'',profileName:'',zip:'',addr:'',company:'',dept:'',name:'',tel:'',isDefault:addon.senderProfiles.length===0};
    target.innerHTML = `<fieldset class="stage5-fieldset"><legend>${p?'編集':'新規登録'}</legend>
      <div class="stage5-grid3">
        <div><label>表示名</label><input type="text" id="spProfileName" value="${esc(cur.profileName||'')}"></div>
        <div><label>郵便番号</label><input type="text" id="spZip" value="${esc(cur.zip||'')}"></div>
        <div><label>氏名・担当</label><input type="text" id="spName" value="${esc(cur.name||'')}"></div>
      </div>
      <div class="row"><label>住所</label><input type="text" id="spAddr" value="${esc(cur.addr||'')}"></div>
      <div class="stage5-grid3"><div><label>会社</label><input type="text" id="spCompany" value="${esc(cur.company||'')}"></div><div><label>部署</label><input type="text" id="spDept" value="${esc(cur.dept||'')}"></div><div><label>電話</label><input type="text" id="spTel" value="${esc(cur.tel||'')}"></div></div>
      <label class="checkbox-row" style="margin-top:6px"><input type="checkbox" id="spDefault" ${cur.isDefault?'checked':''}><span>既定の差出人にする</span></label>
      <div class="stage5-actions" style="margin-top:8px"><button class="btn sm primary" id="spSave">保存</button><button class="btn sm ghost" id="spFromInput">現在の入力欄から作成</button></div>
    </fieldset>`;
    target.querySelector('#spFromInput').addEventListener('click',()=>{
      byId('spZip').value = byId('iSenderZip') ? byId('iSenderZip').value : '';
      byId('spAddr').value = byId('iSenderAddr') ? byId('iSenderAddr').value : '';
      byId('spCompany').value = byId('iSenderCompany') ? byId('iSenderCompany').value : '';
      byId('spDept').value = byId('iSenderDept') ? byId('iSenderDept').value : '';
      byId('spName').value = byId('iSenderName') ? byId('iSenderName').value : '';
      byId('spTel').value = byId('iSenderTel') ? byId('iSenderTel').value : '';
      if(!byId('spProfileName').value) byId('spProfileName').value = byId('spName').value || byId('spCompany').value || '差出人';
    });
    target.querySelector('#spSave').addEventListener('click',()=>{
      const obj = {
        id: cur.id || stageId('sender'),
        profileName: normalizeSpaces(byId('spProfileName').value) || '差出人',
        zip: normalizeZip(byId('spZip').value),
        addr: normalizeSpaces(byId('spAddr').value),
        company: normalizeSpaces(byId('spCompany').value),
        dept: normalizeSpaces(byId('spDept').value),
        name: normalizeSpaces(byId('spName').value),
        tel: normalizeSpaces(byId('spTel').value),
        isDefault: byId('spDefault').checked
      };
      if(obj.isDefault) addon.senderProfiles.forEach(x=>x.isDefault=false);
      const idx = addon.senderProfiles.findIndex(x=>x.id===obj.id);
      if(idx>=0) addon.senderProfiles[idx]=obj; else addon.senderProfiles.push(obj);
      saveAddon();
      closeAccessibleModal(modal); showSenderProfileModal();
      if(window.toast) toast('差出人プロファイルを保存しました','ok');
    });
  }

  function showStampLibraryModal(){
    const modal = document.createElement('div'); modal.className='modal-overlay';
    const grouped = addon.stampLibrary.reduce((a,s)=>{ (a[s.category||'その他']||(a[s.category||'その他']=[])).push(s); return a; },{});
    const list = Object.entries(grouped).map(([cat,items])=>`<h4 class="serif" style="font-size:13px;margin:12px 0 6px">${esc(cat)}</h4><div class="stage5-actions">${items.map(s=>`<button class="btn sm" data-stamp="${esc(s.id)}">${esc(s.text)}</button>`).join('')}</div>`).join('');
    modal.innerHTML = `<div class="modal-box" style="min-width:660px">
      <h3>スタンプ部品ライブラリ</h3>
      <p>よく使う「親展」「請求書在中」などを部品として追加します。</p>
      ${list}
      <fieldset class="stage5-fieldset"><legend>追加・編集</legend>
        <div class="stage5-grid2"><div><label>文字</label><input id="stText" type="text" placeholder="例：至急"></div><div><label>分類</label><input id="stCat" type="text" placeholder="注意 / 郵便 / 内容物"></div></div>
        <div class="stage5-actions" style="margin-top:8px"><button class="btn sm" id="stAdd">ライブラリに追加</button><button class="btn sm ghost" id="stReset">初期セットを補充</button></div>
      </fieldset>
      <div class="stage5-danger-note">テンプレートにスタンプを追加するには、対象テンプレートを選び、ロック解除後にこの一覧から選択してください。</div>
      <div class="actions"><button class="btn ghost" id="stClose">閉じる</button></div>
    </div>`;
    document.body.appendChild(modal);
    applyLegacyModalA11y(modal,{title:'スタンプ部品ライブラリ', initialFocus:'#stClose'});
    modal.querySelector('#stClose').addEventListener('click',()=>closeAccessibleModal(modal));
    modal.addEventListener('click',e=>{ if(e.target===modal) closeAccessibleModal(modal); });
    modal.querySelectorAll('[data-stamp]').forEach(b=>b.addEventListener('click',()=>{
      const s = addon.stampLibrary.find(x=>x.id===b.dataset.stamp); if(!s) return;
      const t = window.getCurrentTpl ? getCurrentTpl() : null;
      if(!t){ if(window.toast) toast('テンプレートを選択してください','warn'); return; }
      if(t.locked){ if(window.toast) toast('ロック中は追加できません','warn'); return; }
      t.fields.push(createStampField(t, s.text));
      if(window.markLayoutChanged) markLayoutChanged(t);
      if(window.save) save();
      if(window.renderFieldList) renderFieldList();
      if(window.renderEnvelope) renderEnvelope();
      if(byId('fldBadge')) byId('fldBadge').textContent=t.fields.length;
      if(window.toast) toast(`スタンプ「${s.text}」を追加しました`,'ok');
      closeAccessibleModal(modal);
    }));
    modal.querySelector('#stAdd').addEventListener('click',()=>{
      const text = normalizeSpaces(modal.querySelector('#stText').value);
      const cat = normalizeSpaces(modal.querySelector('#stCat').value) || 'その他';
      if(!text){ if(window.toast) toast('文字を入力してください','warn'); return; }
      addon.stampLibrary.push({id:stageId('stamp'), text, category:cat}); saveAddon(); closeAccessibleModal(modal); showStampLibraryModal();
    });
    modal.querySelector('#stReset').addEventListener('click',()=>{
      DEFAULT_STAMPS.forEach(s=>{ if(!addon.stampLibrary.some(x=>x.text===s.text)) addon.stampLibrary.push(Object.assign({},s,{id:stageId('stamp')})); });
      saveAddon(); closeAccessibleModal(modal); showStampLibraryModal();
    });
  }

  function findAddressBookDuplicates(){
    const groups = {};
    (state.addressBook||[]).forEach((a,idx)=>{
      const key = [normalizeZip(a.zip||''), normalizeAddrKey((a.addr||'')+(a.addr2||'')), normalizeSpaces(a.name||a.company||a.corp||'')].join('|');
      if(key.replace(/\|/g,'')) (groups[key]||(groups[key]=[])).push({a,idx});
    });
    return Object.values(groups).filter(g=>g.length>1);
  }
  function showAddressBookManager(){
    const modal = document.createElement('div'); modal.className='modal-overlay';
    const dups = findAddressBookDuplicates();
    const tagOptions = addon.tags.map(t=>`<option value="${esc(t)}">${esc(t)}</option>`).join('');
    const rows = (state.addressBook||[]).map((a,i)=>`<tr>
      <td>${esc(a.name||a.company||a.corp||'無名')}</td>
      <td>${esc([a.zip,a.addr,a.addr2].filter(Boolean).join(' / '))}</td>
      <td>${(a.tags||[]).map(t=>`<span class="stage5-chip">${esc(t)}</span>`).join('')||'<span class="stage5-mini">未分類</span>'}</td>
      <td class="stage5-actions"><button class="btn sm" data-load-ab="${i}">入力へ</button><button class="btn sm ghost" data-tag-ab="${i}">タグ</button><button class="btn sm danger" data-del-ab="${i}">削除</button></td>
    </tr>`).join('');
    modal.innerHTML = `<div class="modal-box" style="min-width:900px">
      <h3>住所録管理</h3>
      <div class="stage5-grid3" style="background:var(--paper-2);padding:10px;margin-bottom:10px;font-size:12px"><div>住所録：<strong>${state.addressBook.length}</strong>件</div><div>重複候補：<strong style="color:${dups.length?'var(--warn)':'inherit'}">${dups.length}</strong>組</div><div>タグ：<strong>${addon.tags.length}</strong>件</div></div>
      <div class="stage5-actions"><select id="abTagSelect"><option value="">タグ選択</option>${tagOptions}</select><button class="btn sm" id="abAddTag">選択中のタグを新規追加</button><input type="text" id="abNewTag" placeholder="新しいタグ名" style="max-width:180px"></div>
      <div class="stage5-check ${dups.length?'warn':'ok'}"><div class="ttl">重複候補チェック</div>${dups.length?`<ul>${dups.slice(0,5).map(g=>`<li>${g.map(x=>esc(x.a.name||x.a.company||x.a.corp||'無名')).join(' / ')}</li>`).join('')}</ul>`:'<div>明確な重複候補は見つかりません。</div>'}</div>
      <table class="stage5-table"><thead><tr><th>宛名</th><th>住所</th><th>タグ</th><th style="width:180px">操作</th></tr></thead><tbody>${rows||'<tr><td colspan="4">住所録は空です</td></tr>'}</tbody></table>
      <div class="actions"><button class="btn ghost" id="abmClose">閉じる</button></div>
    </div>`;
    document.body.appendChild(modal);
    applyLegacyModalA11y(modal,{title:'住所録管理', initialFocus:'#abmClose'});
    modal.querySelector('#abmClose').addEventListener('click',()=>closeAccessibleModal(modal));
    modal.addEventListener('click',e=>{ if(e.target===modal) closeAccessibleModal(modal); });
    modal.querySelector('#abAddTag').addEventListener('click',()=>{
      const t = normalizeSpaces(modal.querySelector('#abNewTag').value);
      if(t && !addon.tags.includes(t)){ addon.tags.push(t); saveAddon(); closeAccessibleModal(modal); showAddressBookManager(); }
    });
    modal.querySelectorAll('[data-load-ab]').forEach(b=>b.addEventListener('click',()=>{ if(window.loadAddrToInput) loadAddrToInput(state.addressBook[+b.dataset.loadAb]); closeAccessibleModal(modal); injectStep3Addon(); }));
    modal.querySelectorAll('[data-del-ab]').forEach(b=>b.addEventListener('click',async ()=>{
      // v37 step35: Stage5住所録削除確認をブラウザ標準confirmからDOMモーダルへ移行する。
      if(await showAppConfirm('住所録から削除しますか？','住所録の削除',{okLabel:'削除する',danger:true})){
        state.addressBook.splice(+b.dataset.delAb,1); if(window.save) save(); closeAccessibleModal(modal); showAddressBookManager();
      }
    }));
    modal.querySelectorAll('[data-tag-ab]').forEach(b=>b.addEventListener('click',()=>{
      const idx = +b.dataset.tagAb; const tag = modal.querySelector('#abTagSelect').value;
      if(!tag){ if(window.toast) toast('タグを選択してください','warn'); return; }
      const a = state.addressBook[idx]; if(!a.tags) a.tags=[];
      if(!a.tags.includes(tag)) a.tags.push(tag);
      if(window.save) save(); closeAccessibleModal(modal); showAddressBookManager();
    }));
  }

  function addTopbarButtons(){
    const topbar = document.querySelector('.topbar');
    const ref = byId('btnHelp');
    if(!topbar || byId('stage5SenderBtn')) return;
    const btn1 = document.createElement('button'); btn1.className='stage5-top-btn'; btn1.id='stage5SenderBtn'; btn1.textContent='差出人';
    const btn2 = document.createElement('button'); btn2.className='stage5-top-btn'; btn2.id='stage5StampBtn'; btn2.textContent='部品';
    const btn3 = document.createElement('button'); btn3.className='stage5-top-btn'; btn3.id='stage5AddrMgrBtn'; btn3.textContent='住所録管理';
    topbar.insertBefore(btn1, ref);
    topbar.insertBefore(btn2, ref);
    topbar.insertBefore(btn3, ref);
    btn1.addEventListener('click',showSenderProfileModal);
    btn2.addEventListener('click',showStampLibraryModal);
    btn3.addEventListener('click',showAddressBookManager);
  }

  function patchRendering(){
    if(window.__stage5Patched) return; window.__stage5Patched = true;
    const step3Ext = window.Step3ExtensionRegistry;
    if(step3Ext && typeof step3Ext.registerRenderHook === 'function'){
      // v29 Step3: renderStep3/switchInputPaneの多重ラッパー解消に向け、Stage5は本体関数を上書きせずhook登録する。
      step3Ext.registerRenderHook(injectStep3Addon, 'Stage5.injectStep3Addon.render');
    }else{
      console.warn('Step3ExtensionRegistry is not available. Stage5 Step3 addon hook was not registered.');
    }
    if(step3Ext && typeof step3Ext.registerManualPaneHook === 'function'){
      // v29 Step3: manualタブ復帰時もRegistry経由でStage5補助UIを再注入する。
      step3Ext.registerManualPaneHook(injectStep3Addon, 'Stage5.injectStep3Addon.manual');
    }
    // v37 step25: btnAddStampの挙動切替は本体handleAddStampClickへ移行済み。ここではイベントを乗っ取らない。
    const inputValidation = window.InputValidationRegistry;
    if(inputValidation && typeof inputValidation.registerBeforeAddQueueHook === 'function'){
      // v37 step26: btnAddQueueの入力NG阻止はキャプチャフェーズ乗っ取りではなく、明示的な検証hookで行う。
      inputValidation.registerBeforeAddQueueHook(function stage5BeforeAddQueueValidation(context){
        const tpl = (context && context.tpl) || (window.getCurrentTpl ? getCurrentTpl() : null);
        const data = (context && context.data) || getCurrentInputDataSafe();
        const v = analyzeAddressData(data, tpl);
        if(v.level==='ng'){
          renderValidationPanel();
          if(window.toast) toast('入力に不足があります。入力チェックを確認してください','warn');
          return false;
        }
        return true;
      }, 'Stage5 before add queue validation');
    }else{
      console.warn('InputValidationRegistry is not available. Stage5 add queue validation hook was not registered.');
    }
  }

  function exposeStage5(){
    window.EnvelopePrintStage5 = {
      addon, saveAddon, showSenderProfileModal, showStampLibraryModal, showAddressBookManager,
      analyzeAddressData, normalizeZip, applyDefaultSenderToInput
    };
    if(window.EnvelopePrintModules && window.EnvelopePrintModules.Extensions){
      window.EnvelopePrintModules.Extensions.Stage5 = window.EnvelopePrintStage5;
    }
  }

  function init(){
    addTopbarButtons();
    patchRendering();
    exposeStage5();
    if(state.currentStep===3) injectStep3Addon();
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
