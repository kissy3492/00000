#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }

function assertIifeStrict(rel){
  const src = read(rel);
  assert.match(src, /^\(function(?:\s*\([^)]*\))?\s*\{/, `${rel} must start with an IIFE`);
  assert.match(src.slice(0, 180), /['"]use strict['"]\s*;/, `${rel} must enable strict mode near the top`);
}

assertIifeStrict('js/20_registries.js');

const sandbox = {
  window:{},
  console:{warn(){}, log(){}, error(){}},
};
sandbox.globalThis = sandbox.window;
Object.assign(sandbox.window, {
  normalizeAddressData(data){
    data = data || {};
    if(!data.corp) data.corp = [data.company, data.dept].filter(Boolean).join('\n');
    if(!data.full_addr) data.full_addr = [data.addr, data.addr2].filter(Boolean).join('\n');
    return data;
  },
  joinLines(parts){ return parts.map(v=>(v||'').trim()).filter(Boolean).join('\n'); },
  buildOrgText(data){ return (data && data.corp) || [data && data.company, data && data.dept, data && data.title].filter(Boolean).join('\n'); },
  buildOrgFullText(data){ return [data && data.company, data && data.dept, data && data.title].filter(Boolean).join('\n') || (data && data.corp) || ''; },
  buildNameWithHonor(name, honor){ return name ? `${name}${honor ? ' ' + honor : ''}` : ''; },
  buildSenderText(data){ return [data && data.sender_addr, data && data.sender_name].filter(Boolean).join('\n'); },
  escapeHtml(value){ return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
});
vm.runInNewContext(read('js/20_registries.js'), sandbox, { filename:'js/20_registries.js' });
const api = sandbox.window;

const expectedGlobals = [
  'FieldSourceRegistry','Step3ExtensionRegistry','Step5ExtensionRegistry','PrintExecutionRegistry',
  'InputValidationRegistry','InputDataExtensionRegistry','SampleDataRegistry',
  'registerBuiltinFieldSources','getFieldSourceEntries','getFieldSourceLabel','sourceOptionsHtml','registerBuiltinSampleData'
];
assert.ok(api.EnvelopePrintRegistryCore, 'EnvelopePrintRegistryCore must be exported');
for(const name of expectedGlobals){
  assert.ok(name in api, `global export missing: ${name}`);
  assert.ok(name in api.EnvelopePrintRegistryCore, `RegistryCore API missing: ${name}`);
}

assert.ok(api.FieldSourceRegistry.hasSource('zip'), 'builtin zip source must be registered at load time');
assert.ok(api.FieldSourceRegistry.hasSource('org_full'), 'builtin org_full source must be registered at load time');
assert.strictEqual(api.FieldSourceRegistry.resolve('name_honor', {}, {name:'山田', honor:'様'}).value, '山田 様', 'name_honor resolver must keep contract');
assert.strictEqual(api.getFieldSourceLabel('sender_full'), '差出人まとめ', 'field source labels must be available');
assert.match(api.sourceOptionsHtml('<bad>'), /&lt;bad&gt;/, 'sourceOptionsHtml must escape unknown selected key');

let step3Runs = 0;
function hook(){ step3Runs += 1; }
assert.strictEqual(api.Step3ExtensionRegistry.registerRenderHook(hook, 'h'), true, 'first render hook registration succeeds');
assert.strictEqual(api.Step3ExtensionRegistry.registerRenderHook(hook, 'h'), false, 'duplicate render hook registration is ignored');
api.Step3ExtensionRegistry.runRenderHooks();
assert.strictEqual(step3Runs, 1, 'registered Step3 render hook runs once');

let validationRuns = 0;
api.InputValidationRegistry.registerBeforeAddQueueHook(()=>{ validationRuns += 1; return false; }, 'stop');
assert.strictEqual(api.InputValidationRegistry.runBeforeAddQueueHooks({}), false, 'validation hook can stop queue add');
assert.strictEqual(validationRuns, 1, 'validation hook runs once');

assert.ok(api.SampleDataRegistry.listDefaultKeys().includes('issue_no'), 'builtin sample defaults must be registered');
const sample = api.SampleDataRegistry.build({}, {name:'A'});
assert.strictEqual(sample.issue_no, 'No.0001', 'sample data build must merge builtin defaults');

const core = read('js/10_core.js');
assert.match(core, /RegistryCore:EnvelopePrintRegistryCore/, 'EnvelopePrintModules must expose RegistryCore API');
const overview = read('js/52_data_management_ui.js');
assert.match(overview, /RegistryCore:\['FieldSourceRegistry','Step3ExtensionRegistry','Step5ExtensionRegistry','PrintExecutionRegistry','InputValidationRegistry','InputDataExtensionRegistry','SampleDataRegistry'/, 'getModuleOverview must expose RegistryCore APIs');

console.log('IIFE strict phase4 tests: OK');
