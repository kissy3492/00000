#!/usr/bin/env node
/* v38-29: release version synchronization tests. */
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
function read(p){ return fs.readFileSync(path.join(root, p), 'utf8'); }

const manifest = JSON.parse(read('split_manifest.json'));
const manifestVersion = (manifest.version || '').match(/v\d+-\d+/)?.[0];
assert(manifestVersion, 'split_manifest.json version must include release id');

const readme = read('README.md');
const index = read('index.html');
const core = read('js/10_core.js');

assert(readme.startsWith(`# 紙面位置合わせ印字システム ${manifestVersion} `), 'README H1 must match manifest release id');
assert(index.includes(`<title>紙面位置合わせ印字システム ${manifestVersion} `), 'index title must match manifest release id');
assert(index.includes(`<span class="logo-sub">${manifest.version} / storage v37</span>`), 'visible logo subtitle must match manifest version');
assert(core.includes(`const APP_RELEASE_LABEL = '${manifest.version}';`), 'APP_RELEASE_LABEL must match manifest version');
assert(core.includes(`const APP_MODULE_API_VERSION = '${manifest.version.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}';`), 'APP_MODULE_API_VERSION must be slugified manifest version');

const releaseNotes = Array.from(core.matchAll(/\{step:'(v38-\d+)'/g)).map(m=>m[1]);
const latestNo = Number(manifestVersion.split('-')[1]);
for(let n=25; n<=latestNo; n++){
  assert(releaseNotes.includes(`v38-${n}`), `APP_RELEASE_NOTES missing v38-${n}`);
}
assert(fs.existsSync(path.join(root, 'tools/sync_version.js')), 'tools/sync_version.js must exist');
assert(readme.includes('tools/sync_version.js'), 'README file list must include tools/sync_version.js');

console.log('Version Sync Guard tests: OK');
