#!/usr/bin/env node
/* v38-60 IIFE Strict Phase21 tests: Step4 Test Print UI scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const step4 = fs.readFileSync(path.join(root, 'js', '48_step4_test_print_ui.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataMgmtUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

function ok(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

const legacyFns = ['renderStep4','renderPrinterProfileSection','updateStep4Summary','bindEventsForStep4'];

ok('step4 test print UI starts with IIFE + strict', ()=>{
  assert.ok(/^\(function\(global\)\{/.test(step4), 'Step4 Test Print UI must start with IIFE');
  assert.ok(step4.slice(0, 180).includes("'use strict';"), 'Step4 Test Print UI must enable strict mode near the top');
});

ok('step4 test print UI exposes legacy globals and EnvelopePrintStep4TestPrintUI API', ()=>{
  for(const name of legacyFns){
    assert.ok(new RegExp(`function\\s+${name}\\s*\\(`).test(step4), `${name} must remain present`);
  }
  assert.ok(/const\s+Step4TestPrintUiApi\s*=\s*Object\.freeze\(\{[\s\S]*renderStep4[\s\S]*bindEventsForStep4/.test(step4), 'Step4TestPrintUiApi freeze block missing');
  assert.ok(/EnvelopePrintStep4TestPrintUI:\s*Step4TestPrintUiApi/.test(step4), 'EnvelopePrintStep4TestPrintUI export missing');
  assert.ok(/Object\.assign\(global,[\s\S]*renderStep4[\s\S]*bindEventsForStep4[\s\S]*EnvelopePrintStep4TestPrintUI/.test(step4), 'legacy Step4 exports must remain assigned to global');
});

ok('lightweight VM load exposes step4 API and preserves test print contracts', ()=>{
  function makeElement(id){
    return {
      id,
      checked:false,
      textContent:'',
      innerHTML:'',
      disabled:false,
      style:{},
      handlers:{},
      addEventListener(type, fn){ this.handlers[type] = fn; }
    };
  }
  const elements = {};
  const ids = [
    'queueMismatchBanner','mismatchDetail','layoutChangedBanner','printerProfileSection',
    'sumPrinter','sumRightShift','sumDownShift','sumWidthDiff','sumHeightDiff','sumTestStatus',
    'markTestPrinted','step4Back','step4Next','btnFixMismatch','btnRemoveMismatch','btnTestSample','btnTestFirst','btnTestCross'
  ];
  for(const id of ids) elements[id] = makeElement(id);
  const calls = [];
  const tpl = {id:'tpl1', name:'通常', adjustmentStatus:{lastLayoutChangedAt:10}};
  const sandbox = {
    console,
    window:null,
    globalThis:null,
    state:{
      selectedTplId:'tpl1',
      queue:[{tplId:'tpl1', name:'山田'}, {tplId:'tpl2', name:'佐藤'}],
      selectedPrinterId:'p1'
    },
    $(id){ return elements[id] || (elements[id] = makeElement(id)); },
    getCurrentTpl(){ return tpl; },
    getTpl(id){ return id === 'tpl1' ? tpl : {id, name:'別テンプレ'}; },
    escapeHtml(v){ return String(v == null ? '' : v).replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])); },
    getTplAdjustmentSummary(){ return {testPrinted:false}; },
    renderPrinterCalibForm(){ calls.push('renderPrinterCalibForm'); return '<div>calib</div>'; },
    bindPrinterCalibForm(t){ calls.push(['bindPrinterCalibForm', t.id]); },
    getCurrentPrinter(){ return {id:'p1', name:'Main Printer'}; },
    getPrinterCorrection(){ return {rightShift:1, downShift:2, widthDiff:3, heightDiff:4}; },
    goToStep(n){ calls.push(['goToStep', n]); },
    showAppConfirm: async () => true,
    save(){ calls.push('save'); },
    renderQueue(){ calls.push('renderQueue'); },
    renderSteps(){ calls.push('renderSteps'); },
    toast(msg, type){ calls.push(['toast', msg, type]); },
    getSampleData(t){ return {name:'sample', tplId:t.id}; },
    doPrint(opts){ calls.push(['doPrint', opts]); }
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(step4, sandbox, {filename:'js/48_step4_test_print_ui.js'});

  assert.strictEqual(typeof sandbox.EnvelopePrintStep4TestPrintUI, 'object');
  assert.ok(Object.isFrozen(sandbox.EnvelopePrintStep4TestPrintUI), 'EnvelopePrintStep4TestPrintUI must be frozen');
  assert.strictEqual(sandbox.EnvelopePrintStep4TestPrintUI.renderStep4, sandbox.renderStep4);

  sandbox.renderStep4();
  assert.strictEqual(elements.queueMismatchBanner.style.display, 'block');
  assert.ok(elements.mismatchDetail.innerHTML.includes('1件'), 'mismatch count should be rendered');
  assert.strictEqual(elements.layoutChangedBanner.style.display, 'block');
  assert.strictEqual(elements.printerProfileSection.innerHTML, '<div>calib</div>');
  assert.strictEqual(elements.sumPrinter.textContent, 'Main Printer');
  assert.strictEqual(elements.sumRightShift.textContent, '1 mm');
  assert.strictEqual(elements.sumTestStatus.textContent, '未確認');
  assert.strictEqual(elements.markTestPrinted.checked, false);

  sandbox.bindEventsForStep4();
  elements.btnTestSample.handlers.click();
  const samplePrint = calls.find(item => Array.isArray(item) && item[0] === 'doPrint' && item[1].queue && item[1].queue[0] && item[1].queue[0].name === 'sample');
  assert.ok(samplePrint, 'sample test print should delegate to doPrint with one sample item');
  elements.btnTestFirst.handlers.click();
  const firstPrint = calls.find(item => Array.isArray(item) && item[0] === 'doPrint' && item[1].queue && item[1].queue[0] && item[1].queue[0].name === '山田');
  assert.ok(firstPrint, 'first valid test print should use first matching queue item');
  elements.btnTestCross.handlers.click();
  assert.ok(calls.some(item => Array.isArray(item) && item[0] === 'doPrint' && item[1].testCross === true), 'cross test must set testCross');

  elements.markTestPrinted.checked = true;
  elements.markTestPrinted.handlers.change({target:elements.markTestPrinted});
  assert.ok(tpl.adjustmentStatus.testPrintedAt, 'testPrintedAt must be set by confirmation checkbox');
  assert.ok(calls.includes('save'), 'confirmation change must save');
  assert.ok(calls.includes('renderSteps'), 'confirmation change must refresh steps');
});

ok('global module indexes expose Step4 Test Print UI API', ()=>{
  assert.ok(/Step4TestPrint:EnvelopePrintStep4TestPrintUI/.test(core), 'EnvelopePrintModules must expose EnvelopePrintStep4TestPrintUI');
  assert.ok(/Step4TestPrint:\['EnvelopePrintStep4TestPrintUI','renderStep4','renderPrinterProfileSection','updateStep4Summary','bindEventsForStep4'\]/.test(dataMgmtUi), 'getModuleOverview must expose Step4 Test Print UI API');
});

ok('verification pipeline includes phase21 guard', ()=>{
  assert.ok(verify.includes('js/48_step4_test_print_ui.js'), 'verify_structure must include Step4 Test Print UI guard');
  assert.ok(verify.includes('EnvelopePrintStep4TestPrintUI'), 'verify_structure must check EnvelopePrintStep4TestPrintUI');
  assert.ok(verifySh.includes('tests/iife_strict_phase21_tests.js'), 'verify.sh must run phase21 tests');
});

console.log('IIFE strict phase21 tests: OK');
