#!/usr/bin/env node
/* v38-22: Parts Actions Controller unit tests.
   目的: coreから分離した差出人欄・スタンプfield生成/追加操作が既存契約を保つことを確認する。 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const code = fs.readFileSync(path.join(root, 'js', '41_parts_actions.js'), 'utf8');

let uidCounter = 0;
const sandbox = {
  console,
  window: null,
  globalThis: null,
  uid(prefix='id'){ uidCounter += 1; return `${prefix}_${uidCounter}`; }
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(code, sandbox, { filename: 'js/41_parts_actions.js' });
const api = sandbox;

function test(name, fn){
  try{
    const ret = fn();
    if(ret && typeof ret.then === 'function'){
      return ret.then(()=>console.log(`OK ${name}`)).catch(e=>{ console.error(`NG ${name}`); throw e; });
    }
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

(async ()=>{
  await test('exports expected parts actions API', ()=>{
    for(const name of ['createSenderFields','createStampField','refreshPartsActionUi','addSenderBlockToCurrentTpl','addStampToCurrentTpl','handleAddStampClick']){
      assert.strictEqual(typeof api[name], 'function', `${name} must be exported`);
    }
  });

  await test('createSenderFields returns vertical sender address/name for vertical templates', ()=>{
    const tpl = { w:120, h:235, fields:[{source:'addr', vertical:true}] };
    const fields = api.createSenderFields(tpl);
    assert.strictEqual(fields.length, 2);
    assert.strictEqual(fields[0].source, 'sender_addr');
    assert.strictEqual(fields[1].source, 'sender_name');
    assert.strictEqual(fields[0].vertical, true);
    assert.strictEqual(fields[1].anchor, 'tc');
  });

  await test('createSenderFields returns horizontal sender_full when template is horizontal', ()=>{
    const tpl = { w:148, h:100, fields:[{source:'addr', vertical:false}] };
    const fields = api.createSenderFields(tpl);
    assert.strictEqual(fields.length, 1);
    assert.strictEqual(fields[0].source, 'sender_full');
    assert.strictEqual(fields[0].vertical, false);
    assert.ok(fields[0].w >= 60);
  });

  await test('createStampField keeps stamp source and custom text contract', ()=>{
    const field = api.createStampField({ w:120, h:235 }, '重要');
    assert.strictEqual(field.source, 'stamp');
    assert.strictEqual(field.customText, '重要');
    assert.strictEqual(field.label, '重要');
    assert.strictEqual(field.bold, true);
  });

  await test('addSenderBlockToCurrentTpl appends fields and refreshes UI hooks', ()=>{
    const tpl = { id:'t1', w:120, h:235, locked:false, fields:[{source:'addr', vertical:true}] };
    let marked=0, saved=0, listed=0, rendered=0, zip=0;
    const badge = { textContent:'' };
    sandbox.getCurrentTpl = () => tpl;
    sandbox.markLayoutChanged = target => { assert.strictEqual(target, tpl); marked++; };
    sandbox.save = () => { saved++; };
    sandbox.renderFieldList = () => { listed++; };
    sandbox.renderEnvelope = () => { rendered++; };
    sandbox.renderZipConfig = () => { zip++; };
    sandbox.$ = id => id === 'fldBadge' ? badge : null;
    sandbox.toast = () => {};
    api.addSenderBlockToCurrentTpl();
    assert.strictEqual(tpl.fields.length, 3);
    assert.deepStrictEqual([marked,saved,listed,rendered,zip], [1,1,1,1,1]);
    assert.strictEqual(badge.textContent, 3);
  });

  await test('addStampToCurrentTpl trims input and appends stamp field', async ()=>{
    const tpl = { id:'t2', w:120, h:235, locked:false, fields:[] };
    sandbox.getCurrentTpl = () => tpl;
    sandbox.showAppPrompt = async () => '  親展  ';
    sandbox.markLayoutChanged = () => {};
    sandbox.save = () => {};
    sandbox.renderFieldList = () => {};
    sandbox.renderEnvelope = () => {};
    sandbox.renderZipConfig = () => {};
    sandbox.$ = () => null;
    sandbox.toast = () => {};
    await api.addStampToCurrentTpl();
    assert.strictEqual(tpl.fields.length, 1);
    assert.strictEqual(tpl.fields[0].source, 'stamp');
    assert.strictEqual(tpl.fields[0].customText, '親展');
  });

  await test('addStampToCurrentTpl does nothing when prompt is cancelled', async ()=>{
    const tpl = { id:'t3', w:120, h:235, locked:false, fields:[] };
    sandbox.getCurrentTpl = () => tpl;
    sandbox.showAppPrompt = async () => null;
    sandbox.toast = () => {};
    await api.addStampToCurrentTpl();
    assert.strictEqual(tpl.fields.length, 0);
  });

  await test('handleAddStampClick delegates to Stage5 stamp library when available', async ()=>{
    let delegated = 0;
    let fallback = 0;
    sandbox.EnvelopePrintStage5 = { showStampLibraryModal(){ delegated++; } };
    sandbox.addStampToCurrentTpl = async () => { fallback++; };
    await api.handleAddStampClick();
    assert.strictEqual(delegated, 1);
    assert.strictEqual(fallback, 0);
    delete sandbox.EnvelopePrintStage5;
  });

  console.log('OK 8 parts actions tests passed');
})();
