#!/usr/bin/env node
/* v38-49 IIFE Strict Phase10 tests: Common UI Binder scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const commonUi = fs.readFileSync(path.join(root, 'js', '54_common_ui_binder.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataMgmt = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

function ok(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

ok('common UI binder starts with IIFE + strict', ()=>{
  assert.ok(/^\(function\(global\)\{/.test(commonUi), 'Common UI binder must start with IIFE');
  assert.ok(commonUi.slice(0, 180).includes("'use strict';"), 'Common UI binder must enable strict mode near the top');
});

ok('common UI binder exposes legacy global and EnvelopePrintCommonUI API', ()=>{
  assert.ok(/global\.bindEventsForCommonUI\s*=\s*bindEventsForCommonUI/.test(commonUi), 'legacy bindEventsForCommonUI export missing');
  assert.ok(/const\s+CommonUiApi\s*=\s*Object\.freeze\(\{[\s\S]*bindEventsForCommonUI/.test(commonUi), 'CommonUiApi freeze block missing');
  assert.ok(/global\.EnvelopePrintCommonUI\s*=\s*CommonUiApi/.test(commonUi), 'EnvelopePrintCommonUI export missing');
});

ok('lightweight VM load exposes common UI API and preserves mode switching contract', ()=>{
  const elements = Object.fromEntries(['btnHelp','btnDataMgmt','modeSimple','modeAdvanced'].map(id=>[id, {
    id,
    listeners:{},
    classList:{
      values:new Set(),
      add(name){ this.values.add(name); },
      remove(name){ this.values.delete(name); },
      contains(name){ return this.values.has(name); }
    },
    addEventListener(type, handler){ this.listeners[type] = handler; }
  }]));
  let helpCount = 0;
  let dataMgmtCount = 0;
  const calls = [];
  const sandbox = {
    console,
    window:null,
    globalThis:null,
    $: id => elements[id],
    showHelp: () => { helpCount++; },
    showDataMgmt: () => { dataMgmtCount++; },
    state:{uiMode:'advanced', currentStep:2},
    renderSteps: () => calls.push('renderSteps'),
    goToStep: step => calls.push(`goToStep:${step}`)
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(commonUi, sandbox, {filename:'js/54_common_ui_binder.js'});
  assert.strictEqual(typeof sandbox.bindEventsForCommonUI, 'function');
  assert.strictEqual(sandbox.EnvelopePrintCommonUI.bindEventsForCommonUI, sandbox.bindEventsForCommonUI);
  sandbox.bindEventsForCommonUI();
  elements.btnHelp.listeners.click();
  elements.btnDataMgmt.listeners.click();
  assert.strictEqual(helpCount, 1);
  assert.strictEqual(dataMgmtCount, 1);
  elements.modeSimple.listeners.click();
  assert.strictEqual(sandbox.state.uiMode, 'simple');
  assert.strictEqual(sandbox.state.currentStep, 1, 'simple mode must move Step2 back to Step1');
  assert.deepStrictEqual(calls, ['renderSteps','goToStep:1']);
});

ok('global module indexes expose Common UI Binder API', ()=>{
  assert.ok(/CommonUI:EnvelopePrintCommonUI/.test(core), 'EnvelopePrintModules must expose EnvelopePrintCommonUI');
  assert.ok(/CommonUI:\['EnvelopePrintCommonUI','bindEventsForCommonUI'\]/.test(dataMgmt), 'getModuleOverview must expose Common UI Binder API');
});

ok('verification pipeline includes phase10 guard', ()=>{
  assert.ok(verify.includes('js/54_common_ui_binder.js'), 'verify_structure must include common UI binder in IIFE strict source list');
  assert.ok(verifySh.includes('tests/iife_strict_phase10_tests.js'), 'verify.sh must run phase10 tests');
});

console.log('IIFE strict phase10 tests: OK');
