#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }

function assertIifeStrict(rel){
  const src = read(rel);
  assert.match(src, /^\(function(?:\s*\([^)]*\))?\s*\{/, `${rel} must start with an IIFE`);
  assert.match(src.slice(0, 180), /['"]use strict['"]\s*;/, `${rel} must enable strict mode near the top`);
}

assertIifeStrict('js/40_templates.js');

const expected = [
  'ENVELOPE_SIZES',
  'normalizeTpl','markLayoutChanged','defaultLabelConfig','getLabelConfig','labelCapacity','getEffectivePrintPageCount',
  'buildExcludeZonesForPreset','initialTemplates','buildFieldsForPreset','buildFieldsForSize',
  'buildVerticalFields','buildHorizontalFields','buildPostcardFields','buildCardFields','buildLabelSheetFields',
  'buildWindowEnvelopeFields','buildWindowDocumentFields','buildSingleLabelFields','buildFormOverlayFields','buildCertificateFields','buildReplyFields'
];

const sandbox = {
  window:{},
  uid(prefix='id'){ return `${prefix}_unit`; },
  console
};
vm.runInNewContext(read('js/40_templates.js'), sandbox, { filename:'js/40_templates.js' });

assert.ok(sandbox.window.EnvelopePrintTemplateModel, 'EnvelopePrintTemplateModel must be exported');
for(const name of expected){
  assert.ok(name in sandbox.window, `global export missing: ${name}`);
  assert.ok(name in sandbox.window.EnvelopePrintTemplateModel, `TemplateModel API missing: ${name}`);
}
assert.ok(Array.isArray(sandbox.window.ENVELOPE_SIZES['長形']), 'ENVELOPE_SIZES must remain available globally');
assert.strictEqual(typeof sandbox.window.normalizeTpl, 'function', 'normalizeTpl must remain callable');
assert.strictEqual(sandbox.window.defaultLabelConfig('A4 12面ラベル').cols, 2, 'defaultLabelConfig must preserve label layout contract');
const fields = sandbox.window.buildFieldsForSize(120, 235, true, false);
assert.ok(Array.isArray(fields) && fields.length >= 3, 'buildFieldsForSize must still generate default fields');
assert.ok(fields.some(f => f.source === 'zip'), 'generated fields must include zip source');

const core = read('js/10_core.js');
assert.match(core, /Template:\{ENVELOPE_SIZES, normalizeTpl, markLayoutChanged, defaultLabelConfig, getLabelConfig, labelCapacity, getEffectivePrintPageCount, buildExcludeZonesForPreset, initialTemplates, buildFieldsForPreset, buildFieldsForSize\}/, 'EnvelopePrintModules.Template must expose template model APIs');

const overview = read('js/52_data_management_ui.js');
assert.match(overview, /Template:\['ENVELOPE_SIZES','normalizeTpl','markLayoutChanged','defaultLabelConfig','getLabelConfig','labelCapacity','getEffectivePrintPageCount','buildExcludeZonesForPreset','initialTemplates','buildFieldsForPreset','buildFieldsForSize'\]/, 'getModuleOverview must expose template model APIs');

console.log('IIFE strict phase3 tests: OK');
