#!/usr/bin/env node
/* v38-49: Common UI Binder unit tests.
   目的: Bootstrapから分離したヘルプ・データ管理・表示モード切替イベントが単独で接続されることを確認する。 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const code = fs.readFileSync(path.join(root, 'js', '54_common_ui_binder.js'), 'utf8');
const bootstrap = fs.readFileSync(path.join(root, 'js', '90_bootstrap.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const index = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

function makeElement(id){
  return {
    id,
    listeners: {},
    classList: {
      values: new Set(),
      add(name){ this.values.add(name); },
      remove(name){ this.values.delete(name); },
      contains(name){ return this.values.has(name); }
    },
    addEventListener(type, handler){ this.listeners[type] = handler; }
  };
}

const elements = Object.fromEntries(['btnHelp','btnDataMgmt','modeSimple','modeAdvanced'].map(id=>[id, makeElement(id)]));
let helpCount = 0;
let dataMgmtCount = 0;
const calls = [];
const sandbox = {
  console,
  window: null,
  globalThis: null,
  $: id => elements[id],
  showHelp: () => { helpCount++; },
  showDataMgmt: () => { dataMgmtCount++; },
  state: { uiMode: 'advanced', currentStep: 2 },
  renderSteps: () => calls.push('renderSteps'),
  goToStep: n => calls.push(`goToStep:${n}`)
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(code, sandbox, { filename: 'js/54_common_ui_binder.js' });

function test(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

test('exports bindEventsForCommonUI API', ()=>{
  assert.strictEqual(typeof sandbox.bindEventsForCommonUI, 'function');
  assert.ok(sandbox.EnvelopePrintCommonUI);
  assert.strictEqual(sandbox.EnvelopePrintCommonUI.bindEventsForCommonUI, sandbox.bindEventsForCommonUI);
});

test('connects help/data/mode fixed listeners', ()=>{
  sandbox.bindEventsForCommonUI();
  for(const id of ['btnHelp','btnDataMgmt','modeSimple','modeAdvanced']){
    assert.strictEqual(typeof elements[id].listeners.click, 'function', `${id} click listener missing`);
  }
});

test('help and data management handlers are delegated unchanged', ()=>{
  elements.btnHelp.listeners.click();
  elements.btnDataMgmt.listeners.click();
  assert.strictEqual(helpCount, 1);
  assert.strictEqual(dataMgmtCount, 1);
});

test('simple mode resets Step2 to Step1 and rerenders', ()=>{
  calls.length = 0;
  sandbox.state.uiMode = 'advanced';
  sandbox.state.currentStep = 2;
  elements.modeSimple.listeners.click();
  assert.strictEqual(sandbox.state.uiMode, 'simple');
  assert.strictEqual(sandbox.state.currentStep, 1);
  assert.ok(elements.modeSimple.classList.contains('active'));
  assert.ok(!elements.modeAdvanced.classList.contains('active'));
  assert.deepStrictEqual(calls, ['renderSteps','goToStep:1']);
});

test('advanced mode keeps current step and rerenders', ()=>{
  calls.length = 0;
  sandbox.state.uiMode = 'simple';
  sandbox.state.currentStep = 3;
  elements.modeAdvanced.listeners.click();
  assert.strictEqual(sandbox.state.uiMode, 'advanced');
  assert.strictEqual(sandbox.state.currentStep, 3);
  assert.ok(elements.modeAdvanced.classList.contains('active'));
  assert.ok(!elements.modeSimple.classList.contains('active'));
  assert.deepStrictEqual(calls, ['renderSteps','goToStep:3']);
});

test('bootstrap delegates common UI and does not own common fixed listeners', ()=>{
  assert.ok(/bindEventsForCommonUI\(\);/.test(bootstrap), 'bootstrap must delegate common UI binder');
  for(const id of ['btnHelp','btnDataMgmt','modeSimple','modeAdvanced']){
    assert.ok(!new RegExp(id + '[\\s\\S]{0,180}addEventListener').test(bootstrap), `bootstrap still owns listener: ${id}`);
  }
});

test('index load order and public module index are updated', ()=>{
  const scripts = Array.from(index.matchAll(/<script[^>]+src="([^"]+)"/g)).map(m=>m[1]);
  const pos = name => scripts.indexOf(name);
  assert.ok(pos('js/53_adjustment_status.js') >= 0, 'adjustment status script missing');
  assert.ok(pos('js/54_common_ui_binder.js') >= 0, 'common UI binder script missing');
  assert.ok(pos('js/53_adjustment_status.js') < pos('js/54_common_ui_binder.js'), 'common UI binder must load after adjustment status');
  assert.ok(pos('js/54_common_ui_binder.js') < pos('js/10_core.js'), 'common UI binder must load before core module index');
  assert.ok(/CommonUI:EnvelopePrintCommonUI/.test(core), 'EnvelopePrintModules must expose Common UI Binder API');
});

console.log('OK 7 common UI binder tests passed');
