#!/usr/bin/env node
/* v38-56 IIFE Strict Phase17 tests: Step1 Template UI scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const step1 = fs.readFileSync(path.join(root, 'js', '48_step1_template_ui.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataMgmtUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

function ok(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

const legacyFns = ['bindEventsForStep1','renderStep1','handleTplCardClick','showUnadjustedGuide','duplicateTpl'];

ok('step1 template UI starts with IIFE + strict', ()=>{
  assert.ok(/^\(function\(global\)\{/.test(step1), 'Step1 Template UI must start with IIFE');
  assert.ok(step1.slice(0, 260).includes("'use strict';"), 'Step1 Template UI must enable strict mode near the top');
});

ok('step1 template UI exposes legacy globals and EnvelopePrintStep1TemplateUI API', ()=>{
  for(const name of legacyFns){
    assert.ok(new RegExp(`function\\s+${name}\\s*\\(`).test(step1), `${name} must remain present`);
  }
  assert.ok(/const\s+Step1TemplateUiApi\s*=\s*Object\.freeze\(\{[\s\S]*bindEventsForStep1[\s\S]*duplicateTpl/.test(step1), 'Step1TemplateUiApi freeze block missing');
  assert.ok(/EnvelopePrintStep1TemplateUI:\s*Step1TemplateUiApi/.test(step1), 'EnvelopePrintStep1TemplateUI export missing');
  assert.ok(/Object\.assign\(global,[\s\S]*bindEventsForStep1[\s\S]*duplicateTpl[\s\S]*EnvelopePrintStep1TemplateUI/.test(step1), 'legacy Step1 exports must remain assigned to global');
});

ok('lightweight VM load exposes step1 API and preserves fixed-button routing contract', ()=>{
  function makeElement(id){
    return {
      id,
      innerHTML:'',
      textContent:'',
      disabled:false,
      handlers:{},
      addEventListener(type, fn){ this.handlers[type] = fn; },
      click(){ if(this.handlers.click) this.handlers.click({target:this}); }
    };
  }
  const elements = {
    pinnedSection: makeElement('pinnedSection'),
    otherSection: makeElement('otherSection'),
    newTplCta: makeElement('newTplCta'),
    newReplyCta: makeElement('newReplyCta'),
    step1Next: makeElement('step1Next')
  };
  const calls = [];
  const sandbox = {
    console,
    window:null,
    globalThis:null,
    document:{
      querySelectorAll(){ return []; },
      createElement(){ return {className:'', innerHTML:'', querySelector(){ return null; }, addEventListener(){}}; },
      body:{appendChild(){}}
    },
    state:{templates:[], selectedTplId:null, lastUsedTplId:null, uiMode:'advanced', printerProfiles:[]},
    transientBg:{},
    uid(prefix='id'){ return `${prefix}_x`; },
    $(id){ return elements[id] || makeElement(id); },
    escapeHtml(v){ return String(v ?? ''); },
    getTplAdjustmentSummary(){ return {bgAligned:true, layoutChecked:true, testPrinted:true, printerCalibrated:true}; },
    getTpl(id){ return sandbox.state.templates.find(t=>t.id===id) || null; },
    save(){ calls.push('save'); },
    renderSteps(){ calls.push('renderSteps'); },
    toast(msg, kind){ calls.push(['toast', msg, kind]); },
    openWizard(...args){ calls.push(['openWizard', ...args]); },
    goToStep(n){ calls.push(['goToStep', n]); },
    showAppConfirm: async () => false,
    applyLegacyModalA11y(){},
    closeAccessibleModal(){}
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(step1, sandbox, {filename:'js/48_step1_template_ui.js'});

  assert.strictEqual(typeof sandbox.EnvelopePrintStep1TemplateUI, 'object');
  assert.ok(Object.isFrozen(sandbox.EnvelopePrintStep1TemplateUI), 'EnvelopePrintStep1TemplateUI must be frozen');
  assert.strictEqual(sandbox.EnvelopePrintStep1TemplateUI.renderStep1, sandbox.renderStep1);
  sandbox.bindEventsForStep1();
  elements.newTplCta.click();
  assert.deepStrictEqual(calls.pop(), ['openWizard', null, 'new', false]);
  elements.newReplyCta.click();
  assert.deepStrictEqual(calls.pop(), ['openWizard', null, 'new', true]);
  elements.step1Next.click();
  assert.deepStrictEqual(calls.pop(), ['goToStep', 2]);
  sandbox.state.uiMode = 'simple';
  elements.step1Next.click();
  assert.deepStrictEqual(calls.pop(), ['goToStep', 3]);
  sandbox.renderStep1();
  assert.match(elements.otherSection.innerHTML, /テンプレートがありません/);
  assert.strictEqual(elements.step1Next.disabled, true);
});

ok('global module indexes expose Step1 Template UI API', ()=>{
  assert.ok(/Step1TemplateUI:EnvelopePrintStep1TemplateUI/.test(core), 'EnvelopePrintModules must expose EnvelopePrintStep1TemplateUI');
  assert.ok(/Step1TemplateUI:\['EnvelopePrintStep1TemplateUI','bindEventsForStep1','renderStep1','handleTplCardClick','showUnadjustedGuide','duplicateTpl'\]/.test(dataMgmtUi), 'getModuleOverview must expose Step1 Template UI API');
});

ok('verification pipeline includes phase17 guard', ()=>{
  assert.ok(verify.includes('js/48_step1_template_ui.js'), 'verify_structure must include step1 template UI guard');
  assert.ok(verify.includes('EnvelopePrintStep1TemplateUI'), 'verify_structure must check EnvelopePrintStep1TemplateUI');
  assert.ok(verifySh.includes('tests/iife_strict_phase17_tests.js'), 'verify.sh must run phase17 tests');
});

console.log('IIFE strict phase17 tests: OK');
