#!/usr/bin/env node
/* v38-16: Address Data Formatter unit tests.
   目的: ファイル分離後も宛名整形APIの優先順位・返却契約が崩れないことを確認する。 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.resolve(__dirname, '..');
const code = fs.readFileSync(path.join(root, 'js', '15_address_data.js'), 'utf8');
const sandbox = { console, window: {} };
sandbox.globalThis = sandbox.window;
vm.createContext(sandbox);
vm.runInContext(code, sandbox, { filename: 'js/15_address_data.js' });
const api = sandbox.window;

const tests = [];
function test(name, fn){ tests.push({name, fn}); }
function assertEqual(actual, expected, detail){
  if(actual !== expected){
    throw new Error(`${detail || 'value mismatch'}\nexpected: ${JSON.stringify(expected)}\nactual:   ${JSON.stringify(actual)}`);
  }
}
function assertOk(value, detail){ if(!value) throw new Error(detail || 'assertion failed'); }

test('joinLines trims and removes empty parts', ()=>{
  assertEqual(api.joinLines([' A ', '', null, 'B']), 'A\nB');
});

test('buildOrgText prioritizes explicit corp', ()=>{
  assertEqual(api.buildOrgText({corp:'X', company:'Y', dept:'Z'}), 'X');
});

test('buildOrgText builds from company/dept/title when corp is empty', ()=>{
  assertEqual(api.buildOrgText({company:'A', dept:'B', title:'C'}), 'A\nB\nC');
});

test('buildOrgFullText prioritizes structured company/dept/title over corp', ()=>{
  assertEqual(api.buildOrgFullText({corp:'X', company:'Y', dept:'Z'}), 'Y\nZ');
});

test('buildOrgFullText falls back to corp when structured fields are empty', ()=>{
  assertEqual(api.buildOrgFullText({corp:'X'}), 'X');
});

test('buildNameWithHonor appends honor only when name exists', ()=>{
  assertEqual(api.buildNameWithHonor('山田 太郎', '様'), '山田 太郎 様');
  assertEqual(api.buildNameWithHonor('', '様'), '');
});

test('buildSenderText returns plain text and keeps HTML-looking characters unescaped', ()=>{
  const value = api.buildSenderText({sender_zip:'〒030-0000', sender_addr:'<青森>&', sender_name:'森谷', sender_tel:'017'});
  assertEqual(value, '〒030-0000\n<青森>&\n森谷\nTEL 017');
});

test('normalizeAddressData derives corp and full_addr', ()=>{
  const data = api.normalizeAddressData({company:'A', dept:'B', addr:'住所1', addr2:'住所2'});
  assertEqual(data.corp, 'A\nB');
  assertEqual(data.full_addr, '住所1\n住所2');
});

test('defaultDataForTemplate switches reply sample', ()=>{
  assertEqual(api.defaultDataForTemplate({isReply:true}).honor, '行');
  assertEqual(api.defaultDataForTemplate({isReply:false}).honor, '様');
});

test('getFieldText delegates to FieldSourceRegistry and postProcessor', ()=>{
  api.FieldSourceRegistry = {
    resolve(source, f, data){ return {found:true, value:`${source}:${data.name}`}; },
    applyPostProcessors(f, value){ return value + ':post'; }
  };
  assertEqual(api.getFieldText({source:'name'}, {name:'山田'}, {tpl:{id:'tpl1'}}), 'name:山田:post');
});

test('getSampleData delegates to SampleDataRegistry', ()=>{
  api.SampleDataRegistry = { build(tpl, base){ return Object.assign({}, base, {extra:'ok'}); } };
  assertEqual(api.getSampleData({}).extra, 'ok');
});

let failed = 0;
for(const t of tests){
  try{
    t.fn();
    console.log(`OK ${t.name}`);
  }catch(e){
    failed++;
    console.error(`NG ${t.name}`);
    console.error(e && e.stack || e);
  }
}
if(failed){
  console.error(`${failed}/${tests.length} failed`);
  process.exit(1);
}
console.log(`OK ${tests.length} address data tests passed`);
