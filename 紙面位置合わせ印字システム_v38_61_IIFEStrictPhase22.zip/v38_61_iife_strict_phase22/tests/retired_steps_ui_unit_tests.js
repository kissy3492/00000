#!/usr/bin/env node
/* v38-38: Retired Step UI marker tests.
   目的: 48_steps_ui.js が履歴マーカーから完全退役し、読込・manifest・READMEのファイル構成に残らないことを固定する。 */
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
function read(p){ return fs.readFileSync(path.join(root, p), 'utf8'); }

const retiredPath = path.join(root, 'js', '48_steps_ui.js');
const index = read('index.html');
const readme = read('README.md');
const manifest = JSON.parse(read('split_manifest.json'));
const core = read('js/10_core.js');

assert.strictEqual(fs.existsSync(retiredPath), false, 'js/48_steps_ui.js must not exist after v38-38');
assert.ok(!index.includes('js/48_steps_ui.js'), 'index.html must not load retired js/48_steps_ui.js');
assert.ok(!(manifest.files || []).some(item => item.path === 'js/48_steps_ui.js'), 'manifest must not list retired js/48_steps_ui.js');
assert.ok(!/\n\s{2}48_steps_ui\.js\n/.test(readme), 'README file tree must not list retired 48_steps_ui.js');
assert.match(core, /\{step:'v38-38'[\s\S]*48_steps_ui\.js/ , 'release notes must record v38-38 retired steps UI');

console.log('Retired Step UI tests: OK');
