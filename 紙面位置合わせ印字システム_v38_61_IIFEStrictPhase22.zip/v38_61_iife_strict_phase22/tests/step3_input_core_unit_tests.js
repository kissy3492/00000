#!/usr/bin/env node
/* v38-32: Step3 Input Core static tests.
   目的: Step3手入力フォーム責務とStep3固定イベント接続を48_step3_input_core.js側で固定する。 */
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const inputCore = fs.readFileSync(path.join(root, 'js', '48_step3_input_core.js'), 'utf8');
const retiredStepsPath = path.join(root, 'js', '48_steps_ui.js');
const steps = fs.existsSync(retiredStepsPath) ? fs.readFileSync(retiredStepsPath, 'utf8') : '';
const index = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

function bodyOf(src, fnName){
  const marker = `function ${fnName}(`;
  const start = src.indexOf(marker);
  assert.ok(start >= 0, `${fnName} must exist`);
  const brace = src.indexOf('{', start);
  let depth = 0;
  for(let i=brace; i<src.length; i++){
    const ch = src[i];
    if(ch === '{') depth++;
    if(ch === '}') depth--;
    if(depth === 0) return src.slice(start, i + 1);
  }
  throw new Error(`could not parse ${fnName}`);
}

function test(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

test('Step3 input core module defines and exports the moved functions', ()=>{
  for(const fn of ['renderStep3','renderInputForm','getInputData','loadAddrToInput','clearInput','switchInputPane','bindEventsForStep3']){
    assert.match(inputCore, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} missing from input core`);
    assert.match(inputCore, new RegExp(`\\b${fn}\\b`), `${fn} missing from export block`);
    assert.doesNotMatch(steps, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} must not remain in 48_steps_ui.js`);
  }
  assert.match(inputCore, /const\s+Step3InputCoreApi\s*=\s*Object\.freeze\(\{[\s\S]*renderStep3[\s\S]*bindEventsForStep3/);
  assert.match(inputCore, /Object\.assign\(global,\s*\{[\s\S]*EnvelopePrintStep3InputCore/);
  assert.match(inputCore, /EnvelopePrintStep3InputCore:\s*Step3InputCoreApi/);
});

test('Step3 render still orchestrates queue, address book, history and paste panes', ()=>{
  const body = bodyOf(inputCore, 'renderStep3');
  for(const call of ['renderInputForm()','renderQueue()','renderAddrbook()','renderHistory()','renderPasteImport()']){
    assert.ok(body.includes(call), `${call} missing`);
  }
  assert.match(body, /step3Next[\s\S]*disabled=state\.queue\.length===0/);
  assert.match(body, /Step3ExtensionRegistry[\s\S]*runRenderHooks/);
});

test('input-data extension hooks are preserved in moved functions', ()=>{
  assert.match(bodyOf(inputCore, 'getInputData'), /normalizeAddressData\(data\)[\s\S]*InputDataExtensionRegistry[\s\S]*runCollectHooks/);
  assert.match(bodyOf(inputCore, 'loadAddrToInput'), /normalizeAddressData[\s\S]*InputDataExtensionRegistry[\s\S]*runLoadHooks/);
  assert.match(bodyOf(inputCore, 'clearInput'), /clearInputInvalidStates[\s\S]*InputDataExtensionRegistry[\s\S]*runClearHooks/);
  assert.match(bodyOf(inputCore, 'switchInputPane'), /name==='manual'[\s\S]*Step3ExtensionRegistry[\s\S]*runManualPaneHooks/);
});

test('manual and reply input forms keep the same core field ids', ()=>{
  const body = bodyOf(inputCore, 'renderInputForm');
  for(const id of ['iZip','iAddr','iAddr2','iCompany','iDept','iTitle','iCorp','iName','iHonor','iName2','iHonor2','iSenderZip','iSenderAddr','iSenderCompany','iSenderDept','iSenderName','iSenderTel']){
    assert.ok(body.includes(id), `${id} missing from renderInputForm`);
  }
  assert.match(body, /maxlength="8"/);
  assert.match(body, /replace\(\/\[\^\\d-\]\/g,''\)\.replace\(\/-\/g,''\)/);
});


test('Step3 fixed event binder owns tabs, queue, address book and clear actions', ()=>{
  const body = bodyOf(inputCore, 'bindEventsForStep3');
  for(const id of ['step3Back','step3Next','btnAddQueue','btnSaveToAddrbook','btnClearInput','abSearch','btnClearQueue','btnClearHistory']){
    assert.ok(body.includes(id), `${id} listener missing from bindEventsForStep3`);
  }
  assert.match(body, /document\.querySelectorAll\('\.input-tab'\)/);
  assert.match(body, /InputValidationRegistry[\s\S]*runBeforeAddQueueHooks/);
  assert.match(body, /state\.queue\.push\(\{\.\.\.d,tplId:state\.selectedTplId\}\)/);
  assert.match(body, /showAppConfirm[\s\S]*キューの全削除/);
  const bootstrap = fs.readFileSync(path.join(root, 'js', '90_bootstrap.js'), 'utf8');
  assert.ok(bootstrap.includes('bindEventsForStep3();'), 'bootstrap must delegate Step3 events');
  assert.doesNotMatch(bootstrap, /btnAddQueue[\s\S]{0,160}addEventListener/, 'bootstrap must not own AddQueue listener');
  assert.doesNotMatch(bootstrap, /btnSaveToAddrbook[\s\S]{0,160}addEventListener/, 'bootstrap must not own addressbook save listener');
});


test('script order loads input core before Step3 queue UI and core', ()=>{
  const order = Array.from(index.matchAll(/<script[^>]+src="([^"]+)"/g)).map(m=>m[1]);
  const pos = name => order.indexOf(name);
  assert.ok(pos('js/48_step1_template_ui.js') >= 0);
  assert.ok(pos('js/48_step3_input_core.js') >= 0);
  assert.ok(pos('js/48_step3_queue_ui.js') >= 0);
  assert.strictEqual(pos('js/48_steps_ui.js'), -1, 'retired 48_steps_ui.js must not be loaded');
  assert.ok(pos('js/48_step1_template_ui.js') < pos('js/48_step3_input_core.js'));
  assert.ok(pos('js/48_step3_input_core.js') < pos('js/48_step3_queue_ui.js'));
  assert.ok(pos('js/48_step3_queue_ui.js') < pos('js/10_core.js'));
});


test('public module index exposes Step3 Input Core API', ()=>{
  const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
  const dataMgmt = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
  assert.match(core, /Step3Input:EnvelopePrintStep3InputCore/, 'EnvelopePrintModules must expose Step3Input as explicit API');
  assert.match(dataMgmt, /Step3Input:\['EnvelopePrintStep3InputCore','renderStep3','renderInputForm','getInputData','loadAddrToInput','clearInput','switchInputPane','bindEventsForStep3'\]/, 'getModuleOverview must expose Step3 Input Core API');
});

console.log('OK 7 step3 input core tests passed');
