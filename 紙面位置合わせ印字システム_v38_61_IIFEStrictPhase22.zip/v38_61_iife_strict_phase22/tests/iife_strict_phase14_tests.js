#!/usr/bin/env node
/* v38-53 IIFE Strict Phase14 tests: Background Assets scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const background = fs.readFileSync(path.join(root, 'js', '43_background_assets.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataMgmtUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

async function ok(name, fn){
  try{
    await fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

(async ()=>{
  await ok('background assets starts with IIFE + strict', ()=>{
    assert.ok(/^\(function\(global\)\{/.test(background), 'Background Assets must start with IIFE');
    assert.ok(background.slice(0, 220).includes("'use strict';"), 'Background Assets must enable strict mode near the top');
  });

  await ok('background assets exposes legacy globals and EnvelopePrintBackgroundAssets API', ()=>{
    for(const name of ['compressImageDataUrl','loadBackgroundFileInto','fileToDataURL','loadBackgroundPDF','loadBackgroundImage','setBackgroundOnTpl']){
      assert.ok(new RegExp(`function\\s+${name}\\s*\\(`).test(background) || new RegExp(`async\\s+function\\s+${name}\\s*\\(`).test(background), `${name} must remain present`);
    }
    assert.ok(/const\s+BackgroundAssetsApi\s*=\s*Object\.freeze\(\{[\s\S]*BG_MAX_LONG_EDGE[\s\S]*loadBackgroundFileInto[\s\S]*setBackgroundOnTpl/.test(background), 'BackgroundAssetsApi freeze block missing');
    assert.ok(/EnvelopePrintBackgroundAssets:\s*BackgroundAssetsApi/.test(background), 'EnvelopePrintBackgroundAssets export missing');
    assert.ok(/Object\.assign\(global,[\s\S]*compressImageDataUrl[\s\S]*setBackgroundOnTpl[\s\S]*EnvelopePrintBackgroundAssets/.test(background), 'legacy background exports must remain assigned to global');
  });

  await ok('lightweight VM load exposes background API and preserves template background contract', async()=>{
    const calls = [];
    const sandbox = {
      console,
      window:null,
      globalThis:null,
      transientBg:{},
      markLayoutChanged(tpl){ tpl.__layoutMarked = true; },
      toast(message, kind){ calls.push({message, kind}); },
      FileReader: class {
        readAsDataURL(){
          this.result = 'data:mock/plain;base64,AAAA';
          if(this.onload) this.onload();
        }
      }
    };
    sandbox.window = sandbox;
    sandbox.globalThis = sandbox;
    vm.createContext(sandbox);
    vm.runInContext(background, sandbox, {filename:'js/43_background_assets.js'});

    assert.strictEqual(sandbox.BG_MAX_LONG_EDGE, 1600);
    assert.strictEqual(sandbox.BG_JPEG_QUALITY, 0.8);
    assert.strictEqual(typeof sandbox.EnvelopePrintBackgroundAssets, 'object');
    assert.strictEqual(sandbox.EnvelopePrintBackgroundAssets.loadBackgroundFileInto, sandbox.loadBackgroundFileInto);
    assert.ok(Object.isFrozen(sandbox.EnvelopePrintBackgroundAssets), 'EnvelopePrintBackgroundAssets must be frozen');

    const persistent = {id:'tpl_persist', bgPersist:true};
    assert.strictEqual(sandbox.setBackgroundOnTpl(persistent, 'data:persist', 'persist.png', 100), true);
    assert.strictEqual(persistent.bgImage, 'data:persist');
    assert.strictEqual(persistent.bgSourceName, 'persist.png');
    assert.strictEqual(persistent.bgBytes, 100);
    assert.strictEqual(persistent.__layoutMarked, true);

    const transient = {id:'tpl_transient', bgPersist:false};
    assert.strictEqual(sandbox.setBackgroundOnTpl(transient, 'data:transient', 'transient.png', 200), true);
    assert.strictEqual(sandbox.transientBg.tpl_transient.dataUrl, 'data:transient');
    assert.strictEqual(transient.bgImage, undefined);
    assert.strictEqual(transient.__layoutMarked, true);

    const value = await sandbox.fileToDataURL({});
    assert.strictEqual(value, 'data:mock/plain;base64,AAAA');
    await sandbox.loadBackgroundFileInto({type:'text/plain', name:'memo.txt'}, {id:'tpl'});
    assert.strictEqual(calls.at(-1).message, '対応形式：画像 または PDF');
    assert.strictEqual(calls.at(-1).kind, 'warn');
  });

  await ok('global module indexes expose Background Assets API', ()=>{
    assert.ok(/BackgroundAssets:EnvelopePrintBackgroundAssets/.test(core), 'EnvelopePrintModules must expose EnvelopePrintBackgroundAssets');
    assert.ok(/BackgroundAssets:\['EnvelopePrintBackgroundAssets','BG_MAX_LONG_EDGE','BG_JPEG_QUALITY','compressImageDataUrl','loadBackgroundFileInto','fileToDataURL','loadBackgroundPDF','loadBackgroundImage','setBackgroundOnTpl'\]/.test(dataMgmtUi), 'getModuleOverview must expose Background Assets API');
  });

  await ok('verification pipeline includes phase14 guard', ()=>{
    assert.ok(verify.includes('js/43_background_assets.js'), 'verify_structure must include background assets guard');
    assert.ok(verify.includes('EnvelopePrintBackgroundAssets'), 'verify_structure must check EnvelopePrintBackgroundAssets');
    assert.ok(verifySh.includes('tests/iife_strict_phase14_tests.js'), 'verify.sh must run phase14 tests');
  });

  console.log('IIFE strict phase14 tests: OK');
})();
