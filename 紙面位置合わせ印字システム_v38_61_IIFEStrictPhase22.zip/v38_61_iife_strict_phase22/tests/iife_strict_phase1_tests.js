#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }

function assertIifeStrict(rel){
  const src = read(rel);
  assert.match(src, /^\(function(?:\s*\([^)]*\))?\s*\{/, `${rel} must start with an IIFE`);
  assert.match(src.slice(0, 160), /['"]use strict['"]\s*;/, `${rel} must enable strict mode near the top`);
}

for(const rel of ['js/00_pdf_loader.js','js/42_layout_math.js','js/99_audit_marker.js']){
  assertIifeStrict(rel);
}

{
  const sandbox = { window:{} };
  vm.runInNewContext(read('js/42_layout_math.js'), sandbox, { filename:'42_layout_math.js' });
  for(const name of ['overlap','adjustFieldRect','approxChar','estimatePrintCharUnits','wrapTextByPrintUnits','fitText']){
    assert.strictEqual(typeof sandbox.window[name], 'function', `layout math must export ${name} on window`);
    assert.strictEqual(typeof sandbox.window.EnvelopePrintLayoutMath[name], 'function', `EnvelopePrintLayoutMath must expose ${name}`);
  }
  assert.strictEqual(sandbox.window.MIN_FONT_PT, undefined, 'MIN_FONT_PT must remain private after IIFE conversion');
  assert.strictEqual(sandbox.window.overlap({x:0,y:0,w:10,h:10},{x:9,y:9,w:2,h:2}), true);
  assert.deepStrictEqual(Array.from(sandbox.window.wrapTextByPrintUnits('ABCDE', 2, false)), ['ABC','DE']);
  const fit = sandbox.window.fitText('ABCDE', { fontSize:10, vertical:false }, { w:20, h:20 });
  assert.strictEqual(typeof fit.text, 'string');
  assert.strictEqual(typeof fit.fontSize, 'number');
}

{
  const appended = [];
  const sandboxWindow = {
    document:{
      createElement(tag){ return { tagName:tag, set src(v){ this._src = v; }, get src(){ return this._src; } }; },
      head:{ appendChild(el){ appended.push(el); } }
    },
    pdfjsLib:{ GlobalWorkerOptions:{} }
  };
  vm.runInNewContext(read('js/00_pdf_loader.js'), { window:sandboxWindow }, { filename:'00_pdf_loader.js' });
  assert.strictEqual(appended.length, 1, 'pdf loader must append one script element');
  assert.strictEqual(appended[0].src, './pdf.min.js');
  appended[0].onload();
  assert.strictEqual(sandboxWindow.__pdfjsAvailable, true);
  assert.strictEqual(sandboxWindow.pdfjsLib.GlobalWorkerOptions.workerSrc, './pdf.worker.min.js');
}

{
  vm.runInNewContext(read('js/99_audit_marker.js'), {}, { filename:'99_audit_marker.js' });
}

console.log('IIFE strict phase1 tests: OK');
