#!/usr/bin/env node
/* v38-30: Step1 Template UI Controller unit tests.
   目的: Step1テンプレート選択UIと固定ボタンevent binderが公開入口と主要契約を保つことを確認する。 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const code = fs.readFileSync(path.join(root, 'js', '48_step1_template_ui.js'), 'utf8');
const retiredStepsPath = path.join(root, 'js', '48_steps_ui.js');
const stepsCode = fs.existsSync(retiredStepsPath) ? fs.readFileSync(retiredStepsPath, 'utf8') : '';

function makeSandbox(){
  let uidCounter = 0;
  function makeElement(id){
    return {
      id,
      innerHTML:'',
      textContent:'',
      disabled:false,
      handlers:{},
      addEventListener(type, fn){ this.handlers[type] = fn; },
      click(){ if(this.handlers.click) this.handlers.click({target:this}); }
    };
  }
  const elements = {
    pinnedSection: makeElement('pinnedSection'),
    otherSection: makeElement('otherSection'),
    newTplCta: makeElement('newTplCta'),
    newReplyCta: makeElement('newReplyCta'),
    step1Next: makeElement('step1Next')
  };
  const sandbox = {
    console,
    window:null,
    globalThis:null,
    document: {
      querySelectorAll(){ return []; },
      createElement(tag){ return { tagName:tag.toUpperCase(), className:'', innerHTML:'', querySelector(){ return null; } }; },
      body: { appendChild(){} }
    },
    state: { templates:[], selectedTplId:null, lastUsedTplId:null, uiMode:'advanced', printerProfiles:[] },
    transientBg: {},
    uid(prefix='id'){ uidCounter += 1; return `${prefix}_${uidCounter}`; },
    $(id){ return elements[id] || { innerHTML:'', textContent:'', disabled:false }; },
    escapeHtml(v){ return String(v ?? ''); },
    getTplAdjustmentSummary(){ return { bgAligned:true, layoutChecked:true, testPrinted:true, printerCalibrated:true }; },
    getTpl(id){ return sandbox.state.templates.find(t=>t.id===id) || null; },
    save(){ sandbox.saved = (sandbox.saved || 0) + 1; },
    renderSteps(){ sandbox.renderedSteps = (sandbox.renderedSteps || 0) + 1; },
    toast(msg, kind){ sandbox.lastToast = { msg, kind }; },
    openWizard(...args){ sandbox.openedWizard = true; sandbox.openedWizardArgs = args; },
    goToStep(n){ sandbox.lastStep = n; },
    showAppConfirm: async () => false,
    applyLegacyModalA11y(){},
    closeAccessibleModal(){}
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  sandbox.__elements = elements;
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox, { filename:'js/48_step1_template_ui.js' });
  return sandbox;
}

function test(name, fn){
  try{
    const ret = fn();
    if(ret && typeof ret.then === 'function'){
      return ret.then(()=>console.log(`OK ${name}`)).catch(e=>{ console.error(`NG ${name}`); throw e; });
    }
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

(async ()=>{
  await test('exports expected Step1 UI API', ()=>{
    const sandbox = makeSandbox();
    for(const name of ['bindEventsForStep1','renderStep1','handleTplCardClick','showUnadjustedGuide','duplicateTpl']){
      assert.strictEqual(typeof sandbox[name], 'function', `${name} must be exported`);
    }
    assert.strictEqual(typeof sandbox.EnvelopePrintStep1TemplateUI, 'object', 'EnvelopePrintStep1TemplateUI must be exported');
    assert.ok(Object.isFrozen(sandbox.EnvelopePrintStep1TemplateUI), 'EnvelopePrintStep1TemplateUI must be frozen');
    assert.strictEqual(sandbox.EnvelopePrintStep1TemplateUI.renderStep1, sandbox.renderStep1);
  });

  await test('retired 48_steps_ui no longer owns Step1 concrete functions', ()=>{
    assert.strictEqual(fs.existsSync(retiredStepsPath), false, '48_steps_ui.js must remain retired');
    assert.ok(!/function\s+renderStep1\s*\(/.test(stepsCode));
    assert.ok(!/function\s+handleTplCardClick\s*\(/.test(stepsCode));
    assert.ok(!/function\s+showUnadjustedGuide\s*\(/.test(stepsCode));
    assert.ok(!/function\s+duplicateTpl\s*\(/.test(stepsCode));
    assert.ok(!/newTplCta[\s\S]*addEventListener/.test(stepsCode), 'Step1 fixed button listeners must not remain in 48_steps_ui.js');
  });


  await test('bindEventsForStep1 connects new/template next buttons', ()=>{
    const sandbox = makeSandbox();
    sandbox.bindEventsForStep1();
    sandbox.__elements.newTplCta.click();
    assert.deepStrictEqual(sandbox.openedWizardArgs, [null, 'new', false]);
    sandbox.__elements.newReplyCta.click();
    assert.deepStrictEqual(sandbox.openedWizardArgs, [null, 'new', true]);
    sandbox.state.uiMode = 'advanced';
    sandbox.__elements.step1Next.click();
    assert.strictEqual(sandbox.lastStep, 2);
    sandbox.state.uiMode = 'simple';
    sandbox.__elements.step1Next.click();
    assert.strictEqual(sandbox.lastStep, 3);
  });

  await test('renderStep1 supports empty template list and keeps next button disabled', ()=>{
    const sandbox = makeSandbox();
    sandbox.renderStep1();
    assert.match(sandbox.__elements.otherSection.innerHTML, /テンプレートがありません/);
    assert.strictEqual(sandbox.__elements.step1Next.disabled, true);
    assert.match(sandbox.__elements.step1Next.textContent, /詳細編集/);
  });

  await test('handleTplCardClick records selected and last-used template', ()=>{
    const sandbox = makeSandbox();
    sandbox.state.templates = [{ id:'tpl_a', name:'長3', w:120, h:235, fields:[], isPreset:true }];
    sandbox.handleTplCardClick('tpl_a');
    assert.strictEqual(sandbox.state.selectedTplId, 'tpl_a');
    assert.strictEqual(sandbox.state.lastUsedTplId, 'tpl_a');
    assert.strictEqual(sandbox.saved, 1);
    assert.strictEqual(sandbox.__elements.step1Next.disabled, false);
  });

  await test('duplicateTpl deep-copies template and resets adjustment/background contracts', ()=>{
    const sandbox = makeSandbox();
    sandbox.state.templates = [{
      id:'tpl_src', name:'原本', w:120, h:235, pinned:true, isPreset:true, presetNote:'preset', locked:true,
      bgImage:'data:image/png;base64,xxx', bgSourceName:'src.png', bgBytes:123,
      fields:[{ id:'f_old', source:'addr', x:1, y:2 }],
      excludeZones:[{ id:'z_old', x:1, y:1, w:10, h:10 }],
      adjustmentStatus:{ testPrintedAt:1, lastLayoutChangedAt:1 }
    }];
    sandbox.duplicateTpl('tpl_src');
    assert.strictEqual(sandbox.state.templates.length, 2);
    const copy = sandbox.state.templates[1];
    assert.notStrictEqual(copy.id, 'tpl_src');
    assert.strictEqual(copy.name, '原本 (複製)');
    assert.strictEqual(copy.pinned, false);
    assert.strictEqual(copy.isPreset, false);
    assert.strictEqual(copy.presetNote, '');
    assert.strictEqual(copy.locked, false);
    assert.strictEqual(copy.bgImage, undefined);
    assert.strictEqual(copy.bgSourceName, undefined);
    assert.strictEqual(copy.bgBytes, undefined);
    assert.notStrictEqual(copy.fields[0].id, 'f_old');
    assert.notStrictEqual(copy.excludeZones[0].id, 'z_old');
    assert.strictEqual(copy.adjustmentStatus.testPrintedAt, null);
    assert.ok(copy.adjustmentStatus.lastLayoutChangedAt >= 1);
    assert.strictEqual(sandbox.state.selectedTplId, copy.id);
    assert.strictEqual(sandbox.saved, 1);
    assert.strictEqual(sandbox.renderedSteps, 1);
    assert.strictEqual(sandbox.lastToast.kind, 'ok');
  });

  console.log('OK 6 step1 template UI tests passed');
})();
