const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const code = fs.readFileSync(path.join(__dirname, '../js/43_background_assets.js'), 'utf8');
const calls = [];
const context = {
  console,
  transientBg: {},
  markLayoutChanged(tpl){ tpl.__layoutMarked = true; },
  toast(message, kind){ calls.push({message, kind}); },
  FileReader: class {
    readAsDataURL(){
      this.result = 'data:mock/plain;base64,AAAA';
      if(this.onload) this.onload();
    }
  }
};
vm.createContext(context);
vm.runInContext(code, context, {filename:'43_background_assets.js'});

function test(name, fn){
  try{
    const result = fn();
    if(result && typeof result.then === 'function'){
      return result.then(()=>console.log('OK', name));
    }
    console.log('OK', name);
  }catch(e){
    console.error('NG', name);
    throw e;
  }
}

(async()=>{
  await test('exports background constants and explicit API', ()=>{
    assert.strictEqual(context.BG_MAX_LONG_EDGE, 1600);
    assert.strictEqual(context.BG_JPEG_QUALITY, 0.8);
    assert.strictEqual(typeof context.EnvelopePrintBackgroundAssets, 'object');
    assert.strictEqual(context.EnvelopePrintBackgroundAssets.loadBackgroundFileInto, context.loadBackgroundFileInto);
    assert.strictEqual(context.EnvelopePrintBackgroundAssets.setBackgroundOnTpl, context.setBackgroundOnTpl);
    assert.strictEqual(Object.isFrozen(context.EnvelopePrintBackgroundAssets), true);
  });

  await test('setBackgroundOnTpl stores persistent background on template', ()=>{
    const tpl = {id:'tpl_persist', bgPersist:true};
    assert.strictEqual(context.setBackgroundOnTpl(tpl, 'data:persist', 'persist.png', 100), true);
    assert.strictEqual(tpl.bgImage, 'data:persist');
    assert.strictEqual(tpl.bgSourceName, 'persist.png');
    assert.strictEqual(tpl.bgBytes, 100);
    assert.strictEqual(tpl.__layoutMarked, true);
  });

  await test('setBackgroundOnTpl stores non-persistent background in transientBg', ()=>{
    const tpl = {id:'tpl_transient', bgPersist:false};
    assert.strictEqual(context.setBackgroundOnTpl(tpl, 'data:transient', 'transient.png', 200), true);
    assert.strictEqual(context.transientBg.tpl_transient.dataUrl, 'data:transient');
    assert.strictEqual(context.transientBg.tpl_transient.name, 'transient.png');
    assert.strictEqual(context.transientBg.tpl_transient.bytes, 200);
    assert.strictEqual(tpl.bgImage, undefined);
    assert.strictEqual(tpl.__layoutMarked, true);
  });

  await test('setBackgroundOnTpl safely rejects empty template', ()=>{
    assert.strictEqual(context.setBackgroundOnTpl(null, 'data:x', 'x.png', 1), false);
  });

  await test('fileToDataURL uses FileReader wrapper', async()=>{
    const value = await context.fileToDataURL({});
    assert.strictEqual(value, 'data:mock/plain;base64,AAAA');
  });

  await test('loadBackgroundFileInto rejects unsupported files without throwing', async()=>{
    calls.length = 0;
    await context.loadBackgroundFileInto({type:'text/plain', name:'memo.txt'}, {id:'tpl'});
    assert.strictEqual(calls.at(-1).message, '対応形式：画像 または PDF');
    assert.strictEqual(calls.at(-1).kind, 'warn');
  });

  await test('loadBackgroundFileInto detects PDF extension when MIME type is empty', async()=>{
    calls.length = 0;
    await context.loadBackgroundFileInto({type:'', name:'scan.pdf'}, {id:'tpl'});
    assert.strictEqual(calls.at(-1).message, 'PDF読込機能が無効です。同フォルダにpdf.min.jsを置いてください');
    assert.strictEqual(calls.at(-1).kind, 'warn');
  });

  console.log('OK 7 background asset tests passed');
})();
