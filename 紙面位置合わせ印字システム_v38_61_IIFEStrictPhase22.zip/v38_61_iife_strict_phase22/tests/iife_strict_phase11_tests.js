#!/usr/bin/env node
/* v38-50 IIFE Strict Phase11 tests: Parts Actions scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const parts = fs.readFileSync(path.join(root, 'js', '41_parts_actions.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataMgmt = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

async function ok(name, fn){
  try{
    await fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

(async ()=>{
  await ok('parts actions starts with IIFE + strict', ()=>{
    assert.ok(/^\(function\(global\)\{/.test(parts), 'Parts Actions must start with IIFE');
    assert.ok(parts.slice(0, 220).includes("'use strict';"), 'Parts Actions must enable strict mode near the top');
  });

  await ok('parts actions exposes legacy globals and EnvelopePrintPartsActions API', ()=>{
    for(const name of ['createSenderFields','createStampField','refreshPartsActionUi','addSenderBlockToCurrentTpl','addStampToCurrentTpl','handleAddStampClick']){
      assert.ok(new RegExp(`${name}[\\s\\S]*`).test(parts), `${name} must remain present`);
    }
    assert.ok(/const\s+PartsActionsApi\s*=\s*Object\.freeze\(\{[\s\S]*createSenderFields[\s\S]*handleAddStampClick/.test(parts), 'PartsActionsApi freeze block missing');
    assert.ok(/EnvelopePrintPartsActions:\s*PartsActionsApi/.test(parts), 'EnvelopePrintPartsActions export missing');
  });

  await ok('lightweight VM load exposes parts actions API and preserves field contracts', async ()=>{
    let uidCounter = 0;
    const sandbox = {
      console,
      window:null,
      globalThis:null,
      uid(prefix='id'){ uidCounter += 1; return `${prefix}_${uidCounter}`; }
    };
    sandbox.window = sandbox;
    sandbox.globalThis = sandbox;
    vm.createContext(sandbox);
    vm.runInContext(parts, sandbox, {filename:'js/41_parts_actions.js'});
    assert.strictEqual(typeof sandbox.EnvelopePrintPartsActions, 'object');
    assert.strictEqual(sandbox.EnvelopePrintPartsActions.createSenderFields, sandbox.createSenderFields);
    assert.ok(Object.isFrozen(sandbox.EnvelopePrintPartsActions), 'EnvelopePrintPartsActions must be frozen');

    const senderFields = sandbox.EnvelopePrintPartsActions.createSenderFields({w:120,h:235,fields:[{source:'addr',vertical:true}]});
    assert.strictEqual(senderFields[0].source, 'sender_addr');
    assert.strictEqual(senderFields[1].source, 'sender_name');
    assert.strictEqual(senderFields[0].vertical, true);

    const stamp = sandbox.EnvelopePrintPartsActions.createStampField({w:120,h:235}, '重要');
    assert.strictEqual(stamp.source, 'stamp');
    assert.strictEqual(stamp.customText, '重要');
    assert.strictEqual(stamp.bold, true);

    let delegated = 0;
    sandbox.EnvelopePrintStage5 = { showStampLibraryModal(){ delegated += 1; } };
    await sandbox.EnvelopePrintPartsActions.handleAddStampClick();
    assert.strictEqual(delegated, 1, 'Stage5 stamp library delegation contract must be preserved');
  });

  await ok('global module indexes expose Parts Actions API', ()=>{
    assert.ok(/Parts:EnvelopePrintPartsActions/.test(core), 'EnvelopePrintModules must expose EnvelopePrintPartsActions');
    assert.ok(/Parts:\['EnvelopePrintPartsActions','createSenderFields','createStampField','refreshPartsActionUi','addSenderBlockToCurrentTpl','addStampToCurrentTpl','handleAddStampClick'\]/.test(dataMgmt), 'getModuleOverview must expose Parts Actions API');
  });

  await ok('verification pipeline includes phase11 guard', ()=>{
    assert.ok(verify.includes('js/41_parts_actions.js'), 'verify_structure must include parts actions guard');
    assert.ok(verify.includes('EnvelopePrintPartsActions'), 'verify_structure must check EnvelopePrintPartsActions');
    assert.ok(verifySh.includes('tests/iife_strict_phase11_tests.js'), 'verify.sh must run phase11 tests');
  });

  console.log('IIFE strict phase11 tests: OK');
})();
