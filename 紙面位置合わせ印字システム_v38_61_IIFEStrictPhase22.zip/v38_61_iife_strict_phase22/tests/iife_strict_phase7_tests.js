#!/usr/bin/env node
/* v38-46: IIFE Strict Phase7 tests.
   目的: 共通ユーティリティをIIFE + strict化しても、主要グローバル互換・明示API・公開API索引が崩れないことを確認する。 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const utilities = read('js/05_utilities.js');
const core = read('js/10_core.js');
const dataUi = read('js/52_data_management_ui.js');
const verifyStructure = read('tools/verify_structure.js');
const verifySh = read('tools/verify.sh');

function test(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

test('utilities module starts with IIFE + strict', ()=>{
  assert.match(utilities, /^\(function\(global\)\{\s*'use strict';/);
});

test('utilities exports legacy globals and EnvelopePrintUtilities API', ()=>{
  assert.match(utilities, /Object\.assign\(global,[\s\S]*uid[\s\S]*toast[\s\S]*escapeHtml[\s\S]*showAppConfirm[\s\S]*copyTextToClipboard/);
  assert.match(utilities, /const\s+UtilitiesApi\s*=\s*Object\.freeze\(\{[\s\S]*uid[\s\S]*toast[\s\S]*applyScreenA11y[\s\S]*copyTextToClipboard/);
  assert.match(utilities, /global\.EnvelopePrintUtilities\s*=\s*UtilitiesApi/);
});

test('lightweight VM load exposes utilities without touching DOM', ()=>{
  const sandbox = { console, window: null, globalThis: null };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(utilities, sandbox, { filename:'js/05_utilities.js' });
  for(const name of ['$', 'uid', 'toast', 'escapeHtml', 'formatBytes', 'fmtDate', 'showAppAlert', 'showAppConfirm', 'showAppPrompt', 'copyTextToClipboard']){
    assert.strictEqual(typeof sandbox[name], 'function', `${name} must remain globally exported`);
    assert.strictEqual(sandbox.EnvelopePrintUtilities[name], sandbox[name], `Utilities API mismatch: ${name}`);
  }
  assert.strictEqual(sandbox.escapeHtml('<>&"\''), '&lt;&gt;&amp;&quot;&#39;');
  assert.strictEqual(sandbox.formatBytes(1024), '1.0 KB');
  assert.ok(/^x_[a-z0-9]+$/.test(sandbox.uid('x')));
});

test('global module indexes expose Utilities API', ()=>{
  assert.match(core, /Utilities:EnvelopePrintUtilities/);
  assert.match(core, /\{step:'v38-46'[\s\S]*05_utilitiesをIIFE \+ strict化/);
  assert.match(dataUi, /Utilities:\['EnvelopePrintUtilities','\$','uid','toast','announceA11y','escapeHtml','formatBytes','fmtDate','showAppAlert','showAppConfirm','showAppPrompt','copyTextToClipboard','applyScreenA11y','applyLegacyModalA11y','closeAccessibleModal'\]/);
});

test('verification pipeline includes phase7 guard', ()=>{
  assert.match(verifyStructure, /js\/05_utilities\.js/);
  assert.match(verifyStructure, /EnvelopePrintUtilities/);
  assert.match(verifySh, /iife_strict_phase7_tests\.js/);
});

console.log('IIFE strict phase7 tests: OK');
