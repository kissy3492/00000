#!/usr/bin/env node
/* v38-39: Docs inventory consolidation tests.
   目的: 個別の棚卸しメモを量産せず、過去メモは統合アーカイブへ寄せ、最新状態はcore残存台帳を正とする。 */
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
function read(p){ return fs.readFileSync(path.join(root, p), 'utf8'); }
function exists(p){ return fs.existsSync(path.join(root, p)); }

const legacyInventoryFiles = [
  'docs/adjustment_status_inventory.md',
  'docs/stage_addons_inventory.md',
  'docs/step1_template_ui_inventory.md',
  'docs/step2_edit_canvas_inventory.md',
  'docs/step2_edit_ui_inventory.md',
  'docs/step3_input_core_inventory.md',
  'docs/step3_input_queue_inventory.md',
  'docs/step4_step5_ui_inventory.md'
];

for(const file of legacyInventoryFiles){
  assert.strictEqual(exists(file), false, `${file} must be consolidated into docs/refactor_inventory_archive.md`);
}

assert.ok(exists('docs/refactor_inventory_archive.md'), 'consolidated refactor inventory archive must exist');
assert.ok(exists('docs/core_residual_inventory.md'), 'current core residual inventory must remain');

const archive = read('docs/refactor_inventory_archive.md');
for(const file of legacyInventoryFiles){
  assert.ok(archive.includes(`旧ファイル: \`${file}\``), `archive must contain original section marker for ${file}`);
}
assert.match(archive, /^# v38-39 Refactor Inventory Archive/m, 'archive heading must identify v38-39 consolidation');

const readme = read('README.md');
assert.ok(/\n\s{2}refactor_inventory_archive\.md\n/.test(readme), 'README docs tree must list refactor_inventory_archive.md');
for(const file of legacyInventoryFiles){
  const base = path.basename(file);
  assert.ok(!new RegExp(`\\n\\s{2}${base.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\n`).test(readme), `README docs tree must not list retired ${base}`);
}

const core = read('js/10_core.js');
assert.match(core, /\{step:'v38-39'[\s\S]*docs\/refactor_inventory_archive\.md/, 'release notes must record docs inventory consolidation');

console.log('Docs inventory consolidation tests: OK');
