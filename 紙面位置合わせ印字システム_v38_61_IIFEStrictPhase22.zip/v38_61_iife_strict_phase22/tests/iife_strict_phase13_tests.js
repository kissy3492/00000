#!/usr/bin/env node
/* v38-52 IIFE Strict Phase13 tests: Storage Core scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const storage = fs.readFileSync(path.join(root, 'js', '30_storage.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataMgmtUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

async function ok(name, fn){
  try{
    await fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

function makeLocalStorage(){
  const store = Object.create(null);
  return {
    get length(){ return Object.keys(store).length; },
    key(i){ return Object.keys(store)[i] || null; },
    getItem(k){ return Object.prototype.hasOwnProperty.call(store, k) ? store[k] : null; },
    setItem(k, v){ store[k] = String(v); },
    removeItem(k){ delete store[k]; }
  };
}

(async ()=>{
  await ok('storage core starts with IIFE + strict', ()=>{
    assert.ok(/^\(function\(global\)\{/.test(storage), 'Storage Core must start with IIFE');
    assert.ok(storage.slice(0, 180).includes("'use strict';"), 'Storage Core must enable strict mode near the top');
  });

  await ok('storage core exposes legacy globals and EnvelopePrintStorageCore API', ()=>{
    for(const name of ['dataSnapshot','dataSnapshotForBackup','save','backupNow','restoreFullBackupSafely','load','getStorageUsage','getBackups','clearAddonStorage','sanitizeSnapshotForLoad','sanitizeSnapshotForRestore']){
      assert.ok(new RegExp(`function\\s+${name}\\s*\\(`).test(storage) || new RegExp(`async\\s+function\\s+${name}\\s*\\(`).test(storage), `${name} must remain present`);
    }
    assert.ok(/const\s+StorageCoreApi\s*=\s*Object\.freeze\(\{[\s\S]*dataSnapshot[\s\S]*dataSnapshotForBackup[\s\S]*restoreFullBackupSafely[\s\S]*updateStorageStatus/.test(storage), 'StorageCoreApi freeze block missing');
    assert.ok(/EnvelopePrintStorageCore:\s*StorageCoreApi/.test(storage), 'EnvelopePrintStorageCore export missing');
    assert.ok(/Object\.assign\(global,[\s\S]*dataSnapshot[\s\S]*restoreFullBackupSafely[\s\S]*updateStorageStatus[\s\S]*EnvelopePrintStorageCore/.test(storage), 'legacy storage exports must remain assigned to global');
  });

  await ok('lightweight VM load exposes storage API and preserves keys/snapshot contract', ()=>{
    let beforeUnloadHandler = null;
    const sandbox = {
      console,
      window:null,
      globalThis:null,
      localStorage:makeLocalStorage(),
      addEventListener:(type, handler)=>{ if(type === 'beforeunload') beforeUnloadHandler = handler; },
      clearTimeout:()=>{},
      setTimeout:()=>1,
      Date,
      Math,
      JSON,
      Object,
      Array,
      String,
      Number,
      RegExp,
      Error,
      APP_STORAGE_SCHEMA_VERSION:19,
      STORAGE_KEY:'paper_position_print_system_v37',
      BACKUP_KEY:'paper_position_print_system_v37_backups',
      STORAGE_WARN_BYTES:4 * 1024 * 1024,
      STORAGE_HARD_LIMIT:4.5 * 1024 * 1024,
      MAX_BACKUPS:5,
      transientBg:{},
      state:{
        templates:[{id:'tpl1',name:'T',bgPersist:false,bgImage:'data:image/png;base64,AAAA',bgSourceName:'bg.png',bgBytes:123,fields:[]}],
        queue:[],addressBook:[],history:[],printAttempts:[],printerProfiles:[],lastUsedTplId:null,selectedPrinterId:null,lastSavedAt:null
      },
      estimateStorageBytes:(value, key)=>String(value || '').length + String(key || '').length,
      estimateDataUrlBytes:()=>4,
      toast:()=>{},
      fmtDate:v=>String(v),
      formatBytes:v=>`${v}B`,
      escapeHtml:v=>String(v),
      $:()=>null,
      initialTemplates:()=>[],
      normalizeTpl:t=>t,
      renderAll:()=>{},
      showAppAlert:async()=>{},
      location:{reload:()=>{}}
    };
    sandbox.window = sandbox;
    sandbox.globalThis = sandbox;
    vm.createContext(sandbox);
    vm.runInContext(storage, sandbox, {filename:'js/30_storage.js'});

    assert.strictEqual(typeof sandbox.dataSnapshot, 'function');
    assert.strictEqual(typeof sandbox.dataSnapshotForBackup, 'function');
    assert.strictEqual(typeof sandbox.save, 'function');
    assert.strictEqual(typeof sandbox.restoreFullBackupSafely, 'function');
    assert.strictEqual(typeof sandbox.EnvelopePrintStorageCore, 'object');
    assert.strictEqual(sandbox.EnvelopePrintStorageCore.dataSnapshot, sandbox.dataSnapshot);
    assert.ok(Object.isFrozen(sandbox.EnvelopePrintStorageCore), 'EnvelopePrintStorageCore must be frozen');
    assert.strictEqual(typeof beforeUnloadHandler, 'function', 'beforeunload handler must still be registered when available');

    assert.deepStrictEqual(JSON.parse(JSON.stringify(sandbox.addonStorageKeys())), {
      stage5:'paper_position_print_system_v37_stage5_addons',
      stage6:'paper_position_print_system_v37_stage6',
      stage7:'paper_position_print_system_v37_stage7_addon',
      stage8:'paper_position_print_system_v37_stage8_validation'
    });
    const snap = sandbox.dataSnapshot();
    assert.strictEqual(snap.version, 19);
    assert.strictEqual(snap.templates.length, 1);
    assert.strictEqual(Object.prototype.hasOwnProperty.call(snap.templates[0], 'bgImage'), false, 'non-persistent backgrounds must be stripped from normal save snapshot');
  });

  await ok('global module indexes expose Storage Core API', ()=>{
    assert.ok(/StorageCore:EnvelopePrintStorageCore/.test(core), 'EnvelopePrintModules must expose EnvelopePrintStorageCore');
    assert.ok(/Storage:\{dataSnapshot, save, backupNow, load, getStorageUsage\}/.test(core), 'legacy Storage bucket must remain available');
    assert.ok(/StorageCore:\['EnvelopePrintStorageCore','dataSnapshot','dataSnapshotForBackup','save','backupNow','restoreFullBackupSafely','load','getStorageUsage','getBackups','clearAddonStorage','removeObsoleteStorageKeys','retrySaveAfterObsoleteKeyCleanup','sanitizeSnapshotForLoad','sanitizeSnapshotForRestore'\]/.test(dataMgmtUi), 'getModuleOverview must expose Storage Core API');
  });

  await ok('verification pipeline includes phase13 guard', ()=>{
    assert.ok(verify.includes('js/30_storage.js'), 'verify_structure must include storage guard');
    assert.ok(verify.includes('EnvelopePrintStorageCore'), 'verify_structure must check EnvelopePrintStorageCore');
    assert.ok(verifySh.includes('tests/iife_strict_phase13_tests.js'), 'verify.sh must run phase13 tests');
  });

  console.log('IIFE strict phase13 tests: OK');
})();
