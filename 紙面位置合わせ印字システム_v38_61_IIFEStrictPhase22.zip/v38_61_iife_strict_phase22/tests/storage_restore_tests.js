(function(){
  'use strict';
  const results = [];
  const $ = id => document.getElementById(id);
  function record(ok, name, detail){
    results.push({ok, name, detail: detail || ''});
    render();
  }
  function assert(name, condition, detail){
    if(!condition) throw new Error(name + (detail ? ': ' + detail : ''));
  }
  function render(){
    const tbody = $('results');
    tbody.innerHTML = results.map(r=>`<tr><td class="${r.ok?'ok':'ng'}">${r.ok?'OK':'NG'}</td><td>${escapeHtml(r.name)}</td><td>${escapeHtml(r.detail)}</td></tr>`).join('');
    const ok = results.filter(r=>r.ok).length;
    const ng = results.length - ok;
    $('summary').className = 'summary ' + (ng ? 'ng' : 'ok');
    $('summary').textContent = `${ok}/${results.length} 件成功` + (ng ? `、${ng} 件失敗` : '');
  }
  function escapeHtml(s){
    return String(s == null ? '' : s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }
  function run(name, fn){
    try{ fn(); record(true, name, ''); }
    catch(e){ console.error(e); record(false, name, e && e.message ? e.message : String(e)); }
  }
  function getHooks(win){
    const modules = win.EnvelopePrintModules;
    if(!modules || !modules.TestHooks) throw new Error('EnvelopePrintModules.TestHooks が見つかりません');
    return modules.TestHooks;
  }
  function safeId(v){ return typeof v === 'string' && /^[A-Za-z0-9_-]{1,80}$/.test(v); }

  function runTests(win){
    const h = getHooks(win);

    run('TestHooks が必要関数を公開している', ()=>{
      ['sanitizeSnapshotForLoad','sanitizeSnapshotForRestore','sanitizeStage8AddonForRestore','normalizeRestoreField','addonStorageKeys'].forEach(k=>{
        assert(k, typeof h[k] === 'function');
      });
    });

    run('不正fieldをload sanitizeで安全補正する', ()=>{
      const out = h.sanitizeSnapshotForLoad({
        templates:[{id:'tpl_ok',name:'T',w:100,h:200,fields:[{id:'" onclick="x',source:'<bad>',label:{x:1},x:'abc',y:'99999',w:-9,h:0,fontSize:'big',anchor:'evil',zipConfig:{digitOffsets:['x']}}]}],
        queue:[],addressBook:[],history:[],printAttempts:[],printerProfiles:[]
      });
      const f = out.templates[0].fields[0];
      assert('field.id safe', safeId(f.id), f.id);
      assert('source fallback custom', f.source === 'custom', f.source);
      assert('w補正', typeof f.w === 'number' && f.w >= 1, f.w);
      assert('h補正', typeof f.h === 'number' && f.h >= 1, f.h);
      assert('fontSize補正', f.fontSize >= 6 && f.fontSize <= 72, f.fontSize);
      assert('anchor補正', ['tl','tr','tc','ml','mc','mr','bl','bc','br'].includes(f.anchor), f.anchor);
    });

    run('template.id安全化時にtplId参照を同時変換する', ()=>{
      const badTpl = '" onclick="tpl';
      const out = h.sanitizeSnapshotForLoad({
        templates:[{id:badTpl,name:'T',w:100,h:200,fields:[]}],
        queue:[{tplId:badTpl,name:'A'}],
        addressBook:[],
        history:[{tplId:badTpl,name:'H'}],
        printAttempts:[{tplId:badTpl,name:'P'}],
        printerProfiles:[{id:'printer_ok',name:'P',perTpl:{[badTpl]:{dx:1,dy:2}}}],
        lastUsedTplId:badTpl
      });
      const newTpl = out.templates[0].id;
      assert('new template id safe', safeId(newTpl), newTpl);
      assert('queue.tplId remapped', out.queue[0].tplId === newTpl, out.queue[0].tplId);
      assert('history.tplId remapped', out.history[0].tplId === newTpl, out.history[0].tplId);
      assert('printAttempts.tplId remapped', out.printAttempts[0].tplId === newTpl, out.printAttempts[0].tplId);
      assert('lastUsedTplId remapped', out.lastUsedTplId === newTpl, out.lastUsedTplId);
      assert('perTpl remapped', Object.prototype.hasOwnProperty.call(out.printerProfiles[0].perTpl, newTpl));
    });

    run('printerProfile.id安全化時にselectedPrinterIdを同時変換する', ()=>{
      const badPrinter = '<printer>';
      const out = h.sanitizeSnapshotForLoad({
        templates:[{id:'tpl_ok',name:'T',w:100,h:200,fields:[]}],
        queue:[],addressBook:[],history:[],printAttempts:[],
        printerProfiles:[{id:badPrinter,name:'P',perTpl:{}}],
        selectedPrinterId:badPrinter
      });
      const newPrinter = out.printerProfiles[0].id;
      assert('new printer id safe', safeId(newPrinter), newPrinter);
      assert('selectedPrinterId remapped', out.selectedPrinterId === newPrinter, out.selectedPrinterId);
    });

    run('Stage8 addonのrecords/profiles/manualProgressをID変換する', ()=>{
      const ctx = {
        __restoreTplIdMap:{oldTpl:'newTpl'},
        __restoreTplIds:{newTpl:true},
        __restorePrinterIdMap:{oldPrinter:'newPrinter'},
        __restorePrinterIds:{newPrinter:true}
      };
      const addon = h.sanitizeStage8AddonForRestore({
        records:[{id:'bad id!',tplId:'oldTpl',printerId:'oldPrinter',tplName:'T',printerName:'P'}],
        profiles:{'oldTpl::oldPrinter':{tplId:'oldTpl',printerId:'oldPrinter',memo:'x'}},
        manualProgress:{'oldTpl::oldPrinter':{tplId:'oldTpl',printerId:'oldPrinter',items:{base_target:true,'bad item!':true},updatedAt:123}}
      }, ctx);
      assert('record tpl remapped', addon.records[0].tplId === 'newTpl', addon.records[0].tplId);
      assert('record printer remapped', addon.records[0].printerId === 'newPrinter', addon.records[0].printerId);
      assert('record id safe', safeId(addon.records[0].id), addon.records[0].id);
      assert('profile key remapped', !!addon.profiles['newTpl::newPrinter']);
      assert('manualProgress key remapped', !!addon.manualProgress['newTpl::newPrinter']);
      assert('manual item cleaned', addon.manualProgress['newTpl::newPrinter'].items.base_target === true && !('bad item!' in addon.manualProgress['newTpl::newPrinter'].items));
    });
  }

  window.addEventListener('load', ()=>{
    const frame = $('appFrame');
    frame.addEventListener('load', ()=>{
      // アプリ側のDOMContentLoaded処理完了を少し待ってからTestHooksを確認する。
      setTimeout(()=>runTests(frame.contentWindow), 100);
    });
  });
})();
