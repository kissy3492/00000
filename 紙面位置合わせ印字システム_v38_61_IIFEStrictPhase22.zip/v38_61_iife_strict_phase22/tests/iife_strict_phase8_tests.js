#!/usr/bin/env node
/* v38-47: IIFE Strict Phase8 tests.
   目的: Address Data FormatterをIIFE + strict化しても、プレーンテキスト契約・Registry実行時参照・明示API・公開API索引が崩れないことを確認する。 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const addressData = read('js/15_address_data.js');
const core = read('js/10_core.js');
const dataUi = read('js/52_data_management_ui.js');
const verifyStructure = read('tools/verify_structure.js');
const verifySh = read('tools/verify.sh');

function test(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

test('address data module starts with IIFE + strict', ()=>{
  assert.match(addressData, /^\(function\(global\)\{\s*'use strict';/);
});

test('address data exports legacy globals and EnvelopePrintAddressData API', ()=>{
  assert.match(addressData, /Object\.assign\(global,[\s\S]*joinLines[\s\S]*buildOrgText[\s\S]*normalizeAddressData[\s\S]*getFieldText[\s\S]*EnvelopePrintAddressData/);
  assert.match(addressData, /const\s+AddressDataApi\s*=\s*Object\.freeze\(\{[\s\S]*joinLines[\s\S]*buildOrgFullText[\s\S]*getSampleData/);
  assert.match(addressData, /EnvelopePrintAddressData:\s*AddressDataApi/);
});

test('lightweight VM load exposes address data without touching DOM', ()=>{
  const sandbox = { console, window: null, globalThis: null };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(addressData, sandbox, { filename:'js/15_address_data.js' });
  for(const name of ['joinLines', 'buildOrgText', 'buildOrgFullText', 'buildNameWithHonor', 'buildSenderText', 'normalizeAddressData', 'defaultDataForTemplate', 'getFieldText', 'getSampleData']){
    assert.strictEqual(typeof sandbox[name], 'function', `${name} must remain globally exported`);
    assert.strictEqual(sandbox.EnvelopePrintAddressData[name], sandbox[name], `AddressData API mismatch: ${name}`);
  }
  assert.strictEqual(sandbox.buildSenderText({sender_addr:'<青森>&', sender_name:'森谷'}), '<青森>&\n森谷');
  sandbox.FieldSourceRegistry = {
    resolve(source, f, data){ return {found:true, value:`${source}:${data.name}`}; },
    applyPostProcessors(f, value){ return value + ':post'; }
  };
  assert.strictEqual(sandbox.getFieldText({source:'name'}, {name:'山田'}), 'name:山田:post');
});

test('global module indexes expose Address Data Formatter API', ()=>{
  assert.match(core, /AddressData:EnvelopePrintAddressData/);
  assert.match(core, /\{step:'v38-47'[\s\S]*15_address_dataをIIFE \+ strict化/);
  assert.match(dataUi, /AddressData:\['EnvelopePrintAddressData','joinLines','buildOrgText','buildOrgFullText','buildNameWithHonor','buildSenderText','normalizeAddressData','defaultDataForTemplate','getFieldText','getSampleData'\]/);
});

test('verification pipeline includes phase8 guard', ()=>{
  assert.match(verifyStructure, /js\/15_address_data\.js/);
  assert.match(verifyStructure, /EnvelopePrintAddressData/);
  assert.match(verifySh, /iife_strict_phase8_tests\.js/);
});

console.log('IIFE strict phase8 tests: OK');
