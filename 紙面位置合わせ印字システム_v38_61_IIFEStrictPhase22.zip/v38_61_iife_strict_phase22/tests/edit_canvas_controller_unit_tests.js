#!/usr/bin/env node
/* v38-23: Edit Canvas Controller unit tests.
   目的: coreから分離したrenderEnvelope・mm換算・ドラッグ入口・避ける範囲開始処理が単独で壊れていないことを確認する。 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const code = fs.readFileSync(path.join(root, 'js', '44_edit_canvas_controller.js'), 'utf8');

const listenerMap = new Map();
const listenerLog = [];
const sandbox = {
  console,
  window: null,
  globalThis: null,
  document: {
    addEventListener(type, fn, opts){
      listenerLog.push(['add', type, !!(opts && opts.passive === false)]);
      listenerMap.set(type, fn);
    },
    removeEventListener(type, fn){
      listenerLog.push(['remove', type, listenerMap.get(type) === fn]);
      if(listenerMap.get(type) === fn) listenerMap.delete(type);
    },
    createElement(tag){
      return { tagName:tag.toUpperCase(), className:'', style:{}, remove(){ this.removed = true; } };
    }
  }
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(code, sandbox, { filename: 'js/44_edit_canvas_controller.js' });
const api = sandbox;

function test(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}
function makeEvent(props={}){
  return Object.assign({
    type:'mousedown', button:0, clientX:0, clientY:0, cancelable:true,
    preventDefault(){ this.prevented = true; },
    stopPropagation(){ this.stopped = true; }
  }, props);
}
function makeElement(){
  const handlers = {};
  return {
    handlers,
    addEventListener(type, fn, opts){ handlers[type] = {fn, opts}; },
    querySelector(){ return null; }
  };
}


test('exports expected edit canvas API', ()=>{
  for(const name of ['renderEnvelope','getMMperPxOf','getMMperPx','getDragPoint','isPrimaryDragStart','preventDragDefault','addDragDocumentListeners','removeDragDocumentListeners','attachFieldDrag','attachZoneDrag','startAddZone','startEnvelopeZoneDraft','attachEnvelopeZoneDraftHandler','getEditCanvasControllerState']){
    assert.strictEqual(typeof api[name], 'function', `${name} must be exported`);
  }
  assert.strictEqual(typeof api.EnvelopePrintEditCanvasController, 'object', 'EnvelopePrintEditCanvasController must be exported');
  assert.strictEqual(api.EnvelopePrintEditCanvasController.renderEnvelope, api.renderEnvelope);
  assert.ok(Object.isFrozen(api.EnvelopePrintEditCanvasController), 'EnvelopePrintEditCanvasController must be frozen');
});

test('getMMperPxOf converts rendered pixels to millimeters', ()=>{
  const env = { style:{width:'240mm'}, getBoundingClientRect(){ return {width:960}; } };
  assert.strictEqual(api.getMMperPxOf(env), 0.25);
});

test('renderEnvelope clears the edit canvas when no template is selected', ()=>{
  const env = { style:{}, innerHTML:'old' };
  sandbox.$ = id => id === 'envelope' ? env : null;
  sandbox.getCurrentTpl = () => null;
  api.renderEnvelope();
  assert.strictEqual(env.style.width, '240mm');
  assert.strictEqual(env.style.height, '332mm');
  assert.strictEqual(env.innerHTML, '');
});

test('renderEnvelope delegates to renderEnvelopeInto with edit-state options', ()=>{
  const env = { style:{}, innerHTML:'' };
  const tpl = { id:'t1', w:100, h:200 };
  const sample = { name:'sample' };
  let call = null;
  sandbox.$ = id => id === 'envelope' ? env : null;
  sandbox.getCurrentTpl = () => tpl;
  sandbox.getSampleData = target => { assert.strictEqual(target, tpl); return sample; };
  sandbox.state = { mode:'edit', zoom:1.25 };
  sandbox.renderEnvelopeInto = (targetEnv, targetTpl, targetSample, opts) => {
    call = { targetEnv, targetTpl, targetSample, opts };
  };
  api.renderEnvelope();
  assert.strictEqual(call.targetEnv, env);
  assert.strictEqual(call.targetTpl, tpl);
  assert.strictEqual(call.targetSample, sample);
  assert.strictEqual(JSON.stringify(call.opts), JSON.stringify({
    editable:true,
    scale:1.25,
    interactive:true,
    showBg:true,
    showZones:true,
    applyCorrection:false
  }));
});

test('getDragPoint accepts mouse, touch, and changed touch events', ()=>{
  assert.strictEqual(JSON.stringify(api.getDragPoint({clientX:10, clientY:20})), JSON.stringify({clientX:10, clientY:20}));
  assert.strictEqual(JSON.stringify(api.getDragPoint({touches:[{clientX:30, clientY:40}]})), JSON.stringify({clientX:30, clientY:40}));
  assert.strictEqual(JSON.stringify(api.getDragPoint({changedTouches:[{clientX:50, clientY:60}]})), JSON.stringify({clientX:50, clientY:60}));
});

test('isPrimaryDragStart filters non-primary and multi-touch events', ()=>{
  assert.strictEqual(api.isPrimaryDragStart({type:'mousedown', button:0}), true);
  assert.strictEqual(api.isPrimaryDragStart({type:'mousedown', button:2}), false);
  assert.strictEqual(api.isPrimaryDragStart({type:'touchstart', touches:[{}]}), true);
  assert.strictEqual(api.isPrimaryDragStart({type:'touchstart', touches:[{},{}]}), false);
  assert.strictEqual(api.isPrimaryDragStart({type:'keydown'}), false);
});

test('preventDragDefault respects non-cancelable events', ()=>{
  const ev1 = makeEvent();
  api.preventDragDefault(ev1);
  assert.strictEqual(ev1.prevented, true);
  const ev2 = makeEvent({cancelable:false});
  api.preventDragDefault(ev2);
  assert.strictEqual(ev2.prevented, undefined);
});

test('document drag listeners are attached and removed symmetrically', ()=>{
  listenerLog.length = 0;
  function mv(){}
  function up(){}
  api.addDragDocumentListeners(mv, up);
  api.removeDragDocumentListeners(mv, up);
  assert.deepStrictEqual(listenerLog.map(x=>x[0]+':'+x[1]), [
    'add:mousemove','add:mouseup','add:touchmove','add:touchend','add:touchcancel',
    'remove:mousemove','remove:mouseup','remove:touchmove','remove:touchend','remove:touchcancel'
  ]);
});

test('attachFieldDrag updates field position and calls save/UI hooks on mouse drag', ()=>{
  listenerMap.clear();
  const env = { style:{width:'100mm'}, getBoundingClientRect(){ return {width:100}; } };
  const elements = { envelope: env };
  sandbox.$ = id => elements[id];
  const tpl = { id:'t1' };
  sandbox.getCurrentTpl = () => tpl;
  sandbox.state = { selectedFieldId:null, selectedZoneId:'z1', mode:'edit', zoom:1 };
  let rendered = 0, saved = 0, listed = 0, marked = 0;
  sandbox.getSampleData = () => ({});
  sandbox.renderEnvelopeInto = () => { rendered++; };
  sandbox.save = () => { saved++; };
  sandbox.renderFieldList = () => { listed++; };
  sandbox.markLayoutChanged = target => { assert.strictEqual(target, tpl); marked++; };
  sandbox.toast = () => {};

  const el = makeElement();
  const fld = { id:'f1', x:10, y:20 };
  api.attachFieldDrag(el, fld);
  el.handlers.mousedown.fn(makeEvent({clientX:10, clientY:20}));
  assert.strictEqual(sandbox.state.selectedFieldId, 'f1');
  assert.strictEqual(sandbox.state.selectedZoneId, null);
  listenerMap.get('mousemove')(makeEvent({type:'mousemove', clientX:15, clientY:30}));
  assert.strictEqual(JSON.stringify({x:fld.x, y:fld.y}), JSON.stringify({x:15, y:30}));
  listenerMap.get('mouseup')(makeEvent({type:'mouseup'}));
  assert.strictEqual(rendered, 1);
  assert.strictEqual(saved, 1);
  assert.strictEqual(listed, 1);
  assert.strictEqual(marked, 1);
});

test('startAddZone marks envelope as adding-zone without changing save data', ()=>{
  const classes = new Set();
  const env = { classList:{ add:c=>classes.add(c), remove:c=>classes.delete(c) } };
  sandbox.$ = id => id === 'envelope' ? env : null;
  sandbox.getCurrentTpl = () => ({ id:'t1', locked:false });
  let toastMsg = '';
  sandbox.toast = msg => { toastMsg = msg; };
  api.startAddZone();
  assert.strictEqual(classes.has('adding-zone'), true);
  assert.match(toastMsg, /ドラッグ/);
  assert.strictEqual(JSON.stringify(api.getEditCanvasControllerState()), JSON.stringify({addingZoneMode:true, hasZoneDraft:false}));
});

test('attachEnvelopeZoneDraftHandler connects mouse and touch starts', ()=>{
  const el = makeElement();
  api.attachEnvelopeZoneDraftHandler(el);
  assert.strictEqual(typeof el.handlers.mousedown.fn, 'function');
  assert.strictEqual(typeof el.handlers.touchstart.fn, 'function');
  assert.strictEqual(JSON.stringify(el.handlers.touchstart.opts), JSON.stringify({passive:false}));
});

console.log('OK 11 edit canvas controller tests passed');
