#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }

function assertIifeStrict(rel){
  const src = read(rel);
  assert.match(src, /^\(function(?:\s*\([^)]*\))?\s*\{/, `${rel} must start with an IIFE`);
  assert.match(src.slice(0, 180), /['"]use strict['"]\s*;/, `${rel} must enable strict mode near the top`);
}

assertIifeStrict('js/90_bootstrap.js');

const order = [];
const sandbox = {
  console,
  window:{},
  __ENVELOPE_PRINT_BOOTSTRAP_TEST_MODE: true,
  state: { selectedTplId: null, lastUsedTplId: null },
  getTpl: () => null,
  load:()=>order.push('load'),
  setupKeyboard:()=>order.push('setupKeyboard'),
  setupEscapeToCloseOverlays:()=>order.push('setupEscapeToCloseOverlays'),
  bindEventsForCommonUI:()=>order.push('common'),
  bindEventsForStep1:()=>order.push('step1'),
  bindEventsForStep2:()=>order.push('step2'),
  bindEventsForStep3:()=>order.push('step3'),
  bindEventsForStep4:()=>order.push('step4'),
  bindEventsForStep5:()=>order.push('step5'),
  goToStep:n=>order.push(`goToStep:${n}`),
  updateStorageStatus:()=>order.push('updateStorageStatus')
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(read('js/90_bootstrap.js'), sandbox, { filename:'js/90_bootstrap.js' });

assert.ok(sandbox.EnvelopePrintBootstrap, 'EnvelopePrintBootstrap must be exported');
for(const name of ['bindEvents','selectLastUsedTemplate','initializeApp']){
  assert.strictEqual(typeof sandbox[name], 'function', `global compatibility export missing: ${name}`);
  assert.strictEqual(sandbox.EnvelopePrintBootstrap[name], sandbox[name], `Bootstrap API mismatch: ${name}`);
}

sandbox.bindEvents();
assert.deepStrictEqual(order.splice(0), ['common','step1','step2','step3','step4','step5'], 'bindEvents must preserve delegation order');

sandbox.getTpl = id => id === 'tpl-last' ? {id} : null;
sandbox.state.selectedTplId = 'tpl-current';
sandbox.state.lastUsedTplId = 'tpl-last';
assert.strictEqual(sandbox.selectLastUsedTemplate(), 'tpl-last', 'selectLastUsedTemplate must preserve restore contract');
assert.strictEqual(sandbox.state.selectedTplId, 'tpl-last', 'selected template must be updated');

sandbox.initializeApp();
assert.deepStrictEqual(order.splice(0), [
  'load','setupKeyboard','setupEscapeToCloseOverlays','common','step1','step2','step3','step4','step5','goToStep:1','updateStorageStatus'
], 'initializeApp must preserve default startup order');

const structure = read('tools/verify_structure.js');
assert.match(structure, /js\/90_bootstrap\.js'\]/, 'verify_structure must include bootstrap in IIFE strict source list');

console.log('IIFE strict phase5 tests: OK');
