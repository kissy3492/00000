#!/usr/bin/env node
/* v38-24: Adjustment Status unit tests.
   目的: coreから分離した getTplAdjustmentSummary() が既存のタイムスタンプ判定契約を保つことを確認する。 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const code = fs.readFileSync(path.join(root, 'js', '53_adjustment_status.js'), 'utf8');

const sandbox = {
  console,
  window: null,
  globalThis: null,
  state: { selectedPrinterId: null },
  getBgImage: tpl => tpl && tpl.bgImage,
  getPrinterCorrection: () => null,
  hasAnyCorrection: corr => !!(corr && (corr.dx || corr.dy || corr.scaleX || corr.scaleY))
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(code, sandbox, { filename: 'js/53_adjustment_status.js' });
const api = sandbox;

function test(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

test('exports getTplAdjustmentSummary', ()=>{
  assert.strictEqual(typeof api.getTplAdjustmentSummary, 'function');
});

test('returns null for missing template', ()=>{
  assert.strictEqual(api.getTplAdjustmentSummary(null), null);
});

test('marks checks valid when timestamps are newer than layout change', ()=>{
  const tpl = {
    id:'tpl1',
    bgImage:'data:image/png;base64,abc',
    adjustmentStatus:{
      lastLayoutChangedAt:100,
      bgAlignedAt:110,
      zipCheckedAt:111,
      layoutCheckedAt:112,
      testPrintedAt:113
    }
  };
  const stat = api.getTplAdjustmentSummary(tpl);
  assert.strictEqual(stat.bgAligned, true);
  assert.strictEqual(stat.zipChecked, true);
  assert.strictEqual(stat.layoutChecked, true);
  assert.strictEqual(stat.testPrinted, true);
  assert.strictEqual(stat.printerCalibrated, false);
  assert.strictEqual(stat.hasBg, true);
});

test('invalidates stale checks when layout changed later', ()=>{
  const tpl = {
    id:'tpl2',
    bgImage:null,
    adjustmentStatus:{
      lastLayoutChangedAt:200,
      bgAlignedAt:199,
      zipCheckedAt:198,
      layoutCheckedAt:197,
      testPrintedAt:196,
      printerCheckedAt:195
    }
  };
  sandbox.state.selectedPrinterId = 'printer1';
  sandbox.getPrinterCorrection = () => ({dx:0,dy:0,scaleX:0,scaleY:0});
  const stat = api.getTplAdjustmentSummary(tpl);
  assert.strictEqual(stat.bgAligned, false);
  assert.strictEqual(stat.zipChecked, false);
  assert.strictEqual(stat.layoutChecked, false);
  assert.strictEqual(stat.testPrinted, false);
  assert.strictEqual(stat.printerCalibrated, false);
  assert.strictEqual(stat.hasBg, false);
});

test('printer calibration is true when correction values exist', ()=>{
  const tpl = { id:'tpl3', adjustmentStatus:{lastLayoutChangedAt:300} };
  sandbox.state.selectedPrinterId = 'printer2';
  sandbox.getPrinterCorrection = (printerId, tplId) => {
    assert.strictEqual(printerId, 'printer2');
    assert.strictEqual(tplId, 'tpl3');
    return {dx:1,dy:0,scaleX:0,scaleY:0};
  };
  const stat = api.getTplAdjustmentSummary(tpl);
  assert.strictEqual(stat.printerCalibrated, true);
});

test('printer calibration is true when printerCheckedAt is newer than layout change', ()=>{
  const tpl = { id:'tpl4', adjustmentStatus:{lastLayoutChangedAt:400, printerCheckedAt:401} };
  sandbox.state.selectedPrinterId = 'printer3';
  sandbox.getPrinterCorrection = () => null;
  const stat = api.getTplAdjustmentSummary(tpl);
  assert.strictEqual(stat.printerCalibrated, true);
});

console.log('OK 6 adjustment status tests passed');
