#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
function read(rel){ return fs.readFileSync(path.join(root, rel), 'utf8'); }

function assertIifeStrict(rel){
  const src = read(rel);
  assert.match(src, /^\(function(?:\s*\([^)]*\))?\s*\{/, `${rel} must start with an IIFE`);
  assert.match(src.slice(0, 180), /['"]use strict['"]\s*;/, `${rel} must enable strict mode near the top`);
}

const modules = [
  {
    rel:'js/45_render_fields.js',
    objectName:'EnvelopePrintFieldRenderer',
    exports:['renderNormalField','renderZipField']
  },
  {
    rel:'js/46_render_envelope.js',
    objectName:'EnvelopePrintEnvelopeRenderer',
    exports:['renderEnvelopeInto','renderLabelCellInto','buildLabelSheetStack','buildPrintStack']
  },
  {
    rel:'js/47_print.js',
    objectName:'EnvelopePrintControl',
    exports:['addPrintAttempt','getPrintRecordCount','renderFinalChecklist','getHardPrintIssues','getQueueTemplateGroups','renderJobGroupSummary','renderPrintActionArea','executePrint','doPrint']
  }
];

for(const mod of modules){
  assertIifeStrict(mod.rel);
  const sandbox = { window:{} };
  vm.runInNewContext(read(mod.rel), sandbox, { filename:mod.rel });
  assert.ok(sandbox.window[mod.objectName], `${mod.objectName} must be exported`);
  for(const name of mod.exports){
    assert.strictEqual(typeof sandbox.window[name], 'function', `${mod.rel} must preserve global export ${name}`);
    assert.strictEqual(typeof sandbox.window[mod.objectName][name], 'function', `${mod.objectName} must expose ${name}`);
  }
}

const core = read('js/10_core.js');
assert.match(core, /Layout:\{overlap, adjustFieldRect, approxChar, estimatePrintCharUnits, wrapTextByPrintUnits, fitText, renderEnvelope, renderEnvelopeInto, renderNormalField, renderZipField, renderLabelCellInto, buildLabelSheetStack, buildPrintStack\}/, 'EnvelopePrintModules.Layout must include render stack APIs');
assert.match(core, /Print:\{addPrintAttempt, getPrintRecordCount, renderFinalChecklist, getHardPrintIssues, renderPrintActionArea, executePrint, buildPrintStack, doPrint\}/, 'EnvelopePrintModules.Print must include print control APIs');

console.log('IIFE strict phase2 tests: OK');
