#!/usr/bin/env node
/* v38-59 IIFE Strict Phase20 tests: Step3 Queue UI scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const queueUi = fs.readFileSync(path.join(root, 'js', '48_step3_queue_ui.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataMgmtUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

function ok(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

const legacyFns = ['renderQueue','cloneQueueItemFromRecord','renderAddrbook','renderHistory','addToHistory','renderPasteImport','analyzePastedData','renderPastePreview','doImportPaste'];

ok('step3 queue UI starts with IIFE + strict', ()=>{
  assert.ok(/^\(function\(global\)\{/.test(queueUi), 'Step3 Queue UI must start with IIFE');
  assert.ok(queueUi.slice(0, 180).includes("'use strict';"), 'Step3 Queue UI must enable strict mode near the top');
});

ok('step3 queue UI exposes legacy globals and EnvelopePrintStep3QueueUI API', ()=>{
  for(const name of legacyFns){
    assert.ok(new RegExp(`function\\s+${name}\\s*\\(`).test(queueUi), `${name} must remain present`);
  }
  assert.ok(/const\s+Step3QueueUiApi\s*=\s*Object\.freeze\(\{[\s\S]*renderQueue[\s\S]*doImportPaste/.test(queueUi), 'Step3QueueUiApi freeze block missing');
  assert.ok(/EnvelopePrintStep3QueueUI:\s*Step3QueueUiApi/.test(queueUi), 'EnvelopePrintStep3QueueUI export missing');
  assert.ok(/Object\.assign\(global,[\s\S]*renderQueue[\s\S]*doImportPaste[\s\S]*EnvelopePrintStep3QueueUI/.test(queueUi), 'legacy Step3 queue exports must remain assigned to global');
});

ok('lightweight VM load exposes step3 queue API and preserves queue/import contracts', ()=>{
  function makeElement(id){
    return {
      id,
      value:'',
      checked:false,
      textContent:'',
      innerHTML:'',
      disabled:false,
      dataset:{},
      handlers:{},
      className:'',
      style:{},
      classList:{toggle(){}, add(){}, remove(){}},
      addEventListener(type, fn){ this.handlers[type] = fn; },
      querySelector(){ return makeElement(`${id}_qs`); },
      querySelectorAll(){ return []; },
      appendChild(child){ this.children = this.children || []; this.children.push(child); }
    };
  }
  const elements = {};
  const ids = ['queueList','qCount','step3Next','abList','abSearch','abTabCount','histList','pasteImportArea','pasteTxt','pastePreview','skipDuplicates','doPasteImport'];
  for(const id of ids) elements[id] = makeElement(id);
  elements.skipDuplicates.checked = false;
  const calls = [];
  const sandbox = {
    console,
    window:null,
    globalThis:null,
    state:{
      selectedTplId:'tpl1',
      queue:[],
      addressBook:[],
      history:[]
    },
    document:{
      createElement(tag){ const el = makeElement(tag); el.tagName = tag.toUpperCase(); return el; },
      querySelectorAll(sel){ if(sel === '[data-col]') return []; return []; }
    },
    $(id){ return elements[id] || (elements[id] = makeElement(id)); },
    getTpl(id){ return id === 'tpl1' ? {id:'tpl1', name:'通常'} : null; },
    getCurrentTpl(){ return {id:'tpl1', name:'通常', isReply:false}; },
    escapeHtml(v){ return String(v == null ? '' : v).replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])); },
    fmtDate(v){ return `date:${v}`; },
    uid(prefix){ return `${prefix}_1`; },
    save(){ calls.push('save'); },
    renderSteps(){ calls.push('renderSteps'); },
    loadAddrToInput(data){ calls.push(['loadAddrToInput', data.name]); },
    switchInputPane(pane){ calls.push(['switchInputPane', pane]); },
    showAppConfirm: async () => true,
    toast(msg, type){ calls.push(['toast', msg, type]); },
    applyScreenA11y(){ calls.push('applyScreenA11y'); },
    normalizeAddressData(data){ return Object.assign({normalized:true, corp:data.company || data.corp || ''}, data); }
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(queueUi, sandbox, {filename:'js/48_step3_queue_ui.js'});

  assert.strictEqual(typeof sandbox.EnvelopePrintStep3QueueUI, 'object');
  assert.ok(Object.isFrozen(sandbox.EnvelopePrintStep3QueueUI), 'EnvelopePrintStep3QueueUI must be frozen');
  assert.strictEqual(sandbox.EnvelopePrintStep3QueueUI.renderQueue, sandbox.renderQueue);

  const q = sandbox.cloneQueueItemFromRecord({id:'a1', printedAt:1, attemptedAt:2, historyKind:'done', status:'ok', savedAt:3, name:'山田', stage7Extra:{x:1}}, 'tpl1');
  assert.strictEqual(q.id, undefined);
  assert.strictEqual(q.printedAt, undefined);
  assert.strictEqual(JSON.stringify(q.stage7Extra), JSON.stringify({x:1}));
  assert.strictEqual(q.tplId, 'tpl1');

  sandbox.addToHistory({name:'履歴'});
  assert.strictEqual(sandbox.state.history.length, 1);
  assert.strictEqual(sandbox.state.history[0].id, 'h_1');
  sandbox.state.history = Array.from({length:501}, (_, i)=>({i}));
  sandbox.addToHistory({name:'trim'});
  assert.strictEqual(sandbox.state.history.length, 500);

  elements.pasteTxt.value = '郵便番号\t住所\t会社名\t氏名\n〒030-0000\t青森市\t株式会社A\t山田太郎';
  sandbox.analyzePastedData();
  assert.ok(elements.pastePreview.innerHTML.includes('列の対応を確認'), 'paste preview should render after analysis');
  sandbox.doImportPaste(new Set());
  assert.strictEqual(sandbox.state.addressBook.length, 1);
  assert.strictEqual(sandbox.state.addressBook[0].zip, '030-0000');
  assert.strictEqual(sandbox.state.addressBook[0].company, '株式会社A');
  assert.strictEqual(sandbox.state.addressBook[0].honor, '様');
  assert.ok(calls.includes('save'));
  assert.ok(calls.some(item => Array.isArray(item) && item[0] === 'switchInputPane' && item[1] === 'addrbook'));
});

ok('global module indexes expose Step3 Queue UI API', ()=>{
  assert.ok(/Step3Queue:EnvelopePrintStep3QueueUI/.test(core), 'EnvelopePrintModules must expose EnvelopePrintStep3QueueUI');
  assert.ok(/Step3Queue:\['EnvelopePrintStep3QueueUI','renderQueue','cloneQueueItemFromRecord','renderAddrbook','renderHistory','addToHistory','renderPasteImport','analyzePastedData','renderPastePreview','doImportPaste'\]/.test(dataMgmtUi), 'getModuleOverview must expose Step3 Queue UI API');
});

ok('verification pipeline includes phase20 guard', ()=>{
  assert.ok(verify.includes('js/48_step3_queue_ui.js'), 'verify_structure must include Step3 queue UI guard');
  assert.ok(verify.includes('EnvelopePrintStep3QueueUI'), 'verify_structure must check EnvelopePrintStep3QueueUI');
  assert.ok(verifySh.includes('tests/iife_strict_phase20_tests.js'), 'verify.sh must run phase20 tests');
});

console.log('IIFE strict phase20 tests: OK');
