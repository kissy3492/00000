#!/usr/bin/env node
/* v38-19: Help / Data Management UI Controller unit tests.
   目的: 分離後も公開入口と概要APIが壊れていないことを確認する。 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const code = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const sandbox = { console, window: {} };
sandbox.globalThis = sandbox.window;
vm.createContext(sandbox);
vm.runInContext(code, sandbox, { filename: 'js/52_data_management_ui.js' });
const api = sandbox.window;

function test(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

test('exports expected UI entry points', ()=>{
  assert.strictEqual(typeof api.showHelp, 'function');
  assert.strictEqual(typeof api.showDataMgmt, 'function');
  assert.strictEqual(typeof api.getModuleOverview, 'function');
  assert.strictEqual(typeof api.EnvelopePrintDataManagementUI, 'object');
  assert.strictEqual(api.EnvelopePrintDataManagementUI.showHelp, api.showHelp);
  assert.strictEqual(api.EnvelopePrintDataManagementUI.showDataMgmt, api.showDataMgmt);
  assert.strictEqual(api.EnvelopePrintDataManagementUI.getModuleOverview, api.getModuleOverview);
});

test('getModuleOverview keeps core module buckets', ()=>{
  const overview = api.getModuleOverview();
  for(const key of ['Metadata','Architecture','DataManagementUI','Core','Storage','Template','Data','Step3Input','Layout','EditCanvasController','Adjustment','Wizard','Print','Parts','Jobs','Paper']){
    assert.ok(Array.isArray(overview[key]), `${key} must be an array`);
  }
  assert.ok(overview.Storage.includes('backupNow'));
  assert.ok(overview.Step3Input.includes('bindEventsForStep3'));
  assert.ok(overview.Step3Input.includes('loadAddrToInput'));
  assert.ok(overview.Layout.includes('buildPrintStack'));
  assert.ok(overview.EditCanvasController.includes('attachFieldDrag'));
  assert.ok(overview.EditCanvasController.includes('EnvelopePrintEditCanvasController'));
  assert.ok(overview.Parts.includes('addStampToCurrentTpl'));
  assert.ok(overview.Adjustment.includes('getTplAdjustmentSummary'));
});

test('help/data UI file does not eagerly touch DOM during load', ()=>{
  assert.ok(true, 'module loaded without document stub');
});

console.log('OK 3 data management UI tests passed');
