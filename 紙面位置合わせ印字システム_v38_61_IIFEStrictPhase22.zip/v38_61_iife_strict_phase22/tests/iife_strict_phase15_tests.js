#!/usr/bin/env node
/* v38-54 IIFE Strict Phase15 tests: Edit Canvas Controller scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const editCanvas = fs.readFileSync(path.join(root, 'js', '44_edit_canvas_controller.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataMgmtUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

function ok(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

ok('edit canvas controller starts with IIFE + strict', ()=>{
  assert.ok(/^\(function\(global\)\{/.test(editCanvas), 'Edit Canvas Controller must start with IIFE');
  assert.ok(editCanvas.slice(0, 220).includes("'use strict';"), 'Edit Canvas Controller must enable strict mode near the top');
});

ok('edit canvas controller exposes legacy globals and EnvelopePrintEditCanvasController API', ()=>{
  for(const name of ['renderEnvelope','getMMperPxOf','getMMperPx','getDragPoint','isPrimaryDragStart','preventDragDefault','addDragDocumentListeners','removeDragDocumentListeners','attachFieldDrag','attachZoneDrag','startAddZone','startEnvelopeZoneDraft','attachEnvelopeZoneDraftHandler','getEditCanvasControllerState']){
    assert.ok(new RegExp(`function\\s+${name}\\s*\\(`).test(editCanvas), `${name} must remain present`);
  }
  assert.ok(/const\s+EditCanvasControllerApi\s*=\s*Object\.freeze\(\{[\s\S]*renderEnvelope[\s\S]*attachFieldDrag[\s\S]*getEditCanvasControllerState/.test(editCanvas), 'EditCanvasControllerApi freeze block missing');
  assert.ok(/EnvelopePrintEditCanvasController:\s*EditCanvasControllerApi/.test(editCanvas), 'EnvelopePrintEditCanvasController export missing');
  assert.ok(/Object\.assign\(global,[\s\S]*renderEnvelope[\s\S]*attachFieldDrag[\s\S]*getEditCanvasControllerState[\s\S]*EnvelopePrintEditCanvasController/.test(editCanvas), 'legacy edit canvas exports must remain assigned to global');
});

ok('lightweight VM load exposes edit canvas API and preserves drag helper contracts', ()=>{
  const listenerMap = new Map();
  const listenerLog = [];
  const sandbox = {
    console,
    window:null,
    globalThis:null,
    document:{
      addEventListener(type, fn, opts){
        listenerLog.push(['add', type, !!(opts && opts.passive === false)]);
        listenerMap.set(type, fn);
      },
      removeEventListener(type, fn){
        listenerLog.push(['remove', type, listenerMap.get(type) === fn]);
        if(listenerMap.get(type) === fn) listenerMap.delete(type);
      },
      createElement(tag){
        return {tagName:tag.toUpperCase(), className:'', style:{}, remove(){ this.removed = true; }};
      }
    }
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(editCanvas, sandbox, {filename:'js/44_edit_canvas_controller.js'});

  assert.strictEqual(typeof sandbox.EnvelopePrintEditCanvasController, 'object');
  assert.ok(Object.isFrozen(sandbox.EnvelopePrintEditCanvasController), 'EnvelopePrintEditCanvasController must be frozen');
  assert.strictEqual(sandbox.EnvelopePrintEditCanvasController.renderEnvelope, sandbox.renderEnvelope);
  assert.strictEqual(sandbox.EnvelopePrintEditCanvasController.attachFieldDrag, sandbox.attachFieldDrag);
  assert.strictEqual(JSON.stringify(sandbox.getDragPoint({clientX:10, clientY:20})), JSON.stringify({clientX:10, clientY:20}));
  assert.strictEqual(JSON.stringify(sandbox.getDragPoint({touches:[{clientX:30, clientY:40}]})), JSON.stringify({clientX:30, clientY:40}));
  assert.strictEqual(sandbox.isPrimaryDragStart({type:'mousedown', button:0}), true);
  assert.strictEqual(sandbox.isPrimaryDragStart({type:'mousedown', button:2}), false);
  assert.strictEqual(sandbox.isPrimaryDragStart({type:'touchstart', touches:[{}]}), true);
  assert.strictEqual(sandbox.isPrimaryDragStart({type:'touchstart', touches:[{},{}]}), false);

  function mv(){}
  function up(){}
  sandbox.addDragDocumentListeners(mv, up);
  sandbox.removeDragDocumentListeners(mv, up);
  assert.deepStrictEqual(listenerLog.map(x=>x[0]+':'+x[1]), [
    'add:mousemove','add:mouseup','add:touchmove','add:touchend','add:touchcancel',
    'remove:mousemove','remove:mouseup','remove:touchmove','remove:touchend','remove:touchcancel'
  ]);
});

ok('global module indexes expose Edit Canvas Controller API', ()=>{
  assert.ok(/EditCanvasController:EnvelopePrintEditCanvasController/.test(core), 'EnvelopePrintModules must expose EnvelopePrintEditCanvasController');
  assert.ok(/EditCanvas:EnvelopePrintEditCanvasController/.test(core), 'legacy EditCanvas module bucket must delegate to EnvelopePrintEditCanvasController');
  assert.ok(/EditCanvasController:\['EnvelopePrintEditCanvasController','renderEnvelope','getMMperPxOf','getMMperPx','getDragPoint','isPrimaryDragStart','preventDragDefault','addDragDocumentListeners','removeDragDocumentListeners','attachFieldDrag','attachZoneDrag','startAddZone','startEnvelopeZoneDraft','attachEnvelopeZoneDraftHandler','getEditCanvasControllerState'\]/.test(dataMgmtUi), 'getModuleOverview must expose Edit Canvas Controller API');
});

ok('verification pipeline includes phase15 guard', ()=>{
  assert.ok(verify.includes('js/44_edit_canvas_controller.js'), 'verify_structure must include edit canvas guard');
  assert.ok(verify.includes('EnvelopePrintEditCanvasController'), 'verify_structure must check EnvelopePrintEditCanvasController');
  assert.ok(verifySh.includes('tests/iife_strict_phase15_tests.js'), 'verify.sh must run phase15 tests');
});

console.log('IIFE strict phase15 tests: OK');
