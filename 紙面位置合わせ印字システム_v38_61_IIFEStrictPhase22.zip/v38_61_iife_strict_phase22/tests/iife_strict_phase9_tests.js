#!/usr/bin/env node
/* v38-48: IIFE Strict Phase9 tests.
   目的: Adjustment StatusをIIFE + strict化しても、タイムスタンプ判定契約・実行時参照・明示API・公開API索引が崩れないことを確認する。 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const adjustmentStatus = read('js/53_adjustment_status.js');
const core = read('js/10_core.js');
const dataUi = read('js/52_data_management_ui.js');
const verifyStructure = read('tools/verify_structure.js');
const verifySh = read('tools/verify.sh');

function test(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

test('adjustment status module starts with IIFE + strict', ()=>{
  assert.match(adjustmentStatus, /^\(function\(global\)\{\s*'use strict';/);
});

test('adjustment status exports legacy global and EnvelopePrintAdjustmentStatus API', ()=>{
  assert.match(adjustmentStatus, /Object\.assign\(global,[\s\S]*getTplAdjustmentSummary[\s\S]*EnvelopePrintAdjustmentStatus/);
  assert.match(adjustmentStatus, /const\s+AdjustmentStatusApi\s*=\s*Object\.freeze\(\{[\s\S]*getTplAdjustmentSummary/);
  assert.match(adjustmentStatus, /EnvelopePrintAdjustmentStatus:\s*AdjustmentStatusApi/);
});

test('lightweight VM load exposes adjustment status API and preserves status contract', ()=>{
  const sandbox = {
    console,
    window: null,
    globalThis: null,
    state: { selectedPrinterId: 'printer-a' },
    getBgImage: tpl => tpl && tpl.bgImage,
    getPrinterCorrection: (printerId, tplId) => ({ dx: printerId === 'printer-a' && tplId === 'tpl-a' ? 1 : 0 }),
    hasAnyCorrection: corr => !!(corr && (corr.dx || corr.dy || corr.scaleX || corr.scaleY))
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(adjustmentStatus, sandbox, { filename:'js/53_adjustment_status.js' });
  assert.strictEqual(typeof sandbox.getTplAdjustmentSummary, 'function');
  assert.strictEqual(sandbox.EnvelopePrintAdjustmentStatus.getTplAdjustmentSummary, sandbox.getTplAdjustmentSummary);
  const stat = sandbox.getTplAdjustmentSummary({
    id:'tpl-a',
    bgImage:'data:image/png;base64,abc',
    adjustmentStatus:{
      lastLayoutChangedAt:100,
      bgAlignedAt:101,
      zipCheckedAt:102,
      layoutCheckedAt:103,
      testPrintedAt:104
    }
  });
  assert.strictEqual(stat.bgAligned, true);
  assert.strictEqual(stat.zipChecked, true);
  assert.strictEqual(stat.layoutChecked, true);
  assert.strictEqual(stat.testPrinted, true);
  assert.strictEqual(stat.printerCalibrated, true);
  assert.strictEqual(stat.hasBg, true);
});

test('global module indexes expose Adjustment Status API', ()=>{
  assert.match(core, /AdjustmentStatus:EnvelopePrintAdjustmentStatus/);
  assert.match(core, /Adjustment:\{getTplAdjustmentSummary\}/);
  assert.match(core, /\{step:'v38-48'[\s\S]*53_adjustment_statusをIIFE \+ strict Phase9/);
  assert.match(dataUi, /AdjustmentStatus:\['EnvelopePrintAdjustmentStatus','getTplAdjustmentSummary'\]/);
});

test('verification pipeline includes phase9 guard', ()=>{
  assert.match(verifyStructure, /js\/53_adjustment_status\.js/);
  assert.match(verifyStructure, /EnvelopePrintAdjustmentStatus/);
  assert.match(verifySh, /iife_strict_phase9_tests\.js/);
});

console.log('IIFE strict phase9 tests: OK');
