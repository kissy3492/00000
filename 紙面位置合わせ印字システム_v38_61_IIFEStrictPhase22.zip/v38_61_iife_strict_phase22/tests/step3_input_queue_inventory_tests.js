#!/usr/bin/env node
/* v38-32: Step3 Queue UI static tests.
   目的: Step3キュー・住所録・履歴・貼付取込分離後の契約を静的に固定する。 */
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const retiredStepsPath = path.join(root, 'js', '48_steps_ui.js');
const steps = fs.existsSync(retiredStepsPath) ? fs.readFileSync(retiredStepsPath, 'utf8') : '';
const queueUi = fs.readFileSync(path.join(root, 'js', '48_step3_queue_ui.js'), 'utf8');
const inputCore = fs.readFileSync(path.join(root, 'js', '48_step3_input_core.js'), 'utf8');
const index = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

function bodyOf(fnName, src = queueUi){
  const marker = `function ${fnName}(`;
  const start = src.indexOf(marker);
  assert.ok(start >= 0, `${fnName} must exist`);
  const brace = src.indexOf('{', start);
  let depth = 0;
  for(let i=brace; i<src.length; i++){
    const ch = src[i];
    if(ch === '{') depth++;
    if(ch === '}') depth--;
    if(depth === 0) return src.slice(start, i + 1);
  }
  throw new Error(`could not parse ${fnName}`);
}

function test(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

test('Step3 input core and queue UI functions are split into their own files', ()=>{
  for(const fn of ['renderStep3','renderInputForm','getInputData','loadAddrToInput','clearInput','switchInputPane']){
    assert.match(inputCore, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} missing from input core`);
    assert.doesNotMatch(steps, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} must not remain in 48_steps_ui.js`);
  }
  for(const fn of [
    'renderQueue','cloneQueueItemFromRecord','renderAddrbook','renderHistory',
    'addToHistory','renderPasteImport','analyzePastedData','renderPastePreview','doImportPaste'
  ]){
    assert.match(queueUi, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} missing from 48_step3_queue_ui.js`);
    assert.doesNotMatch(steps, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} must not remain in 48_steps_ui.js`);
  }
});

test('Step3 and input-data extension hooks are preserved after input core split', ()=>{
  assert.match(bodyOf('renderStep3', inputCore), /Step3ExtensionRegistry[\s\S]*runRenderHooks/);
  assert.match(bodyOf('switchInputPane', inputCore), /name==='manual'[\s\S]*Step3ExtensionRegistry[\s\S]*runManualPaneHooks/);
  assert.match(bodyOf('getInputData', inputCore), /normalizeAddressData\(data\)[\s\S]*InputDataExtensionRegistry[\s\S]*runCollectHooks/);
  assert.match(bodyOf('loadAddrToInput', inputCore), /normalizeAddressData[\s\S]*InputDataExtensionRegistry[\s\S]*runLoadHooks/);
  assert.match(bodyOf('clearInput', inputCore), /clearInputInvalidStates[\s\S]*InputDataExtensionRegistry[\s\S]*runClearHooks/);
});

test('cloneQueueItemFromRecord keeps extension fields by deep-copying instead of whitelist-copying', ()=>{
  const body = bodyOf('cloneQueueItemFromRecord');
  assert.match(body, /JSON\.parse\(JSON\.stringify\(record \|\| \{\}\)\)/);
  for(const key of ['id','printedAt','attemptedAt','historyKind','status','savedAt']){
    assert.match(body, new RegExp(`delete\\s+q\\.${key}`), `${key} must be stripped`);
  }
  assert.match(body, /q\.tplId\s*=\s*tplId/);
  assert.doesNotMatch(body, /\{\s*zip\s*:/, 'must not revert to limited field whitelist');
});



test('Step3 queue UI exposes explicit frozen API while keeping legacy globals', ()=>{
  assert.match(queueUi, /const\s+Step3QueueUiApi\s*=\s*Object\.freeze\(\{[\s\S]*renderQueue[\s\S]*doImportPaste/, 'Step3QueueUiApi freeze block missing');
  assert.match(queueUi, /EnvelopePrintStep3QueueUI:\s*Step3QueueUiApi/, 'EnvelopePrintStep3QueueUI export missing');
  assert.match(queueUi, /Object\.assign\(global,\s*\{[\s\S]*renderQueue[\s\S]*doImportPaste[\s\S]*EnvelopePrintStep3QueueUI/, 'Step3 queue legacy + explicit exports missing');
});

test('queue mutation refreshes save, queue, next button and step navigation state', ()=>{
  const body = bodyOf('renderQueue');
  assert.match(body, /state\.queue\[i-1\]/, 'up action must exist');
  assert.match(body, /state\.queue\[i\+1\]/, 'down action must exist');
  assert.match(body, /state\.queue\.splice\(i,1\)/, 'remove action must exist');
  assert.match(body, /save\(\);renderQueue\(\)/, 'queue actions must save and rerender queue');
  assert.match(body, /step3Next[\s\S]*disabled=state\.queue\.length===0/);
  assert.match(body, /renderSteps\(\)/);
});

test('paste import mapping preserves address, joint-name and sender contracts', ()=>{
  const preview = bodyOf('renderPastePreview');
  for(const key of [
    '_skip','zip','addr','addr2','company','dept','title','corp','name','honor','name2','honor2',
    'sender_zip','sender_addr','sender_company','sender_dept','sender_name','sender_tel'
  ]){
    assert.ok(preview.includes(`v:'${key}'`) || preview.includes(`${key}:`), `${key} mapping missing`);
  }
  const analyze = bodyOf('analyzePastedData');
  assert.match(analyze, /差出\.\*郵便/);
  assert.match(analyze, /会社\|法人\|company\|corp\|organization/);
  assert.match(analyze, /部署\|部門\|課\|係\|dept\|section/);
  const imp = bodyOf('doImportPaste');
  assert.match(imp, /normalizeAddressData\(obj\)/);
  assert.match(imp, /!normalized\.name && !normalized\.corp && !normalized\.company/, 'company-only corporation destinations must not be skipped');
});

test('index loads Step3 queue UI after input core and before later UI/core', ()=>{
  const order = Array.from(index.matchAll(/<script[^>]+src="([^"]+)"/g)).map(m=>m[1]);
  const pos = name => order.indexOf(name);
  assert.ok(pos('js/48_step1_template_ui.js') >= 0);
  assert.strictEqual(pos('js/48_steps_ui.js'), -1, 'retired 48_steps_ui.js must not be loaded');
  assert.ok(pos('js/48_step1_template_ui.js') < pos('js/48_step3_input_core.js'));
  assert.ok(pos('js/48_step3_queue_ui.js') >= 0);
  assert.ok(pos('js/48_step3_input_core.js') < pos('js/48_step3_queue_ui.js'));
  assert.ok(pos('js/48_step3_queue_ui.js') < pos('js/48_step4_test_print_ui.js'));
  assert.ok(pos('js/48_step3_queue_ui.js') < pos('js/10_core.js'));
});

console.log('OK 6 step3 queue UI tests passed');
