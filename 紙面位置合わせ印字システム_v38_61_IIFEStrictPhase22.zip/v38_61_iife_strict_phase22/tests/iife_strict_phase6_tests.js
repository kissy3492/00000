#!/usr/bin/env node
/* v38-45: IIFE Strict Phase6 tests.
   目的: Wizard ControllerをIIFE + strict化しても、公開入口・wizardState互換・公開API索引が崩れないことを確認する。 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const wizard = read('js/49_wizard.js');
const core = read('js/10_core.js');
const dataUi = read('js/52_data_management_ui.js');
const verifyStructure = read('tools/verify_structure.js');
const verifySh = read('tools/verify.sh');

function test(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

test('wizard module starts with IIFE + strict', ()=>{
  assert.match(wizard, /^\(function\(global\)\{\s*'use strict';/);
});

test('wizardState compatibility accessor is defined on global', ()=>{
  assert.match(wizard, /Object\.defineProperty\(global,\s*'wizardState',[\s\S]*get\(\)\{ return wizardState; \}[\s\S]*set\(value\)\{ wizardState = value; \}/);
});

test('wizard exports legacy function names and EnvelopePrintWizard API', ()=>{
  assert.match(wizard, /Object\.assign\(global,\s*\{[\s\S]*openWizard[\s\S]*closeWizard[\s\S]*renderWizard[\s\S]*wizardNext[\s\S]*commitWizardDraft[\s\S]*renderWzStep8/);
  assert.match(wizard, /global\.EnvelopePrintWizard\s*=\s*Object\.freeze\(\{[\s\S]*openWizard[\s\S]*closeWizard[\s\S]*commitWizardDraft[\s\S]*get state\(\)/);
});

test('lightweight VM load exposes wizard API without touching DOM', ()=>{
  const sandbox = { console, window: null, globalThis: null };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(wizard, sandbox, { filename:'js/49_wizard.js' });
  assert.strictEqual(typeof sandbox.openWizard, 'function');
  assert.strictEqual(typeof sandbox.closeWizard, 'function');
  assert.strictEqual(typeof sandbox.renderWizard, 'function');
  assert.strictEqual(typeof sandbox.commitWizardDraft, 'function');
  assert.ok(sandbox.EnvelopePrintWizard);
  assert.strictEqual(sandbox.EnvelopePrintWizard.openWizard, sandbox.openWizard);
  assert.strictEqual(sandbox.wizardState, null);
  sandbox.wizardState = { mode:'test', step:2 };
  assert.deepStrictEqual(sandbox.EnvelopePrintWizard.state, { mode:'test', step:2 });
});

test('global module indexes expose Wizard Controller API', ()=>{
  assert.match(core, /Wizard:EnvelopePrintWizard/);
  assert.match(core, /\{step:'v38-45'[\s\S]*49_wizardをIIFE \+ strict化/);
  assert.match(dataUi, /Wizard:\['EnvelopePrintWizard','openWizard','renderWizard','wizardNext','closeWizard','commitWizardDraft'\]/);
});

test('verification pipeline includes phase6 guard', ()=>{
  assert.match(verifyStructure, /js\/49_wizard\.js/);
  assert.match(verifyStructure, /EnvelopePrintWizard/);
  assert.match(verifySh, /iife_strict_phase6_tests\.js/);
});

console.log('IIFE strict phase6 tests: OK');
