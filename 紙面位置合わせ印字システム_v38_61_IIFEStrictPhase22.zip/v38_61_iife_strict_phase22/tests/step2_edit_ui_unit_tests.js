#!/usr/bin/env node
/* v38-36: Step2 Edit UI static tests.
   目的: Step2詳細編集UIの関数配置、event binder委譲、公開API、読込順、主要契約を固定する。 */
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const step2 = fs.readFileSync(path.join(root, 'js', '48_step2_edit_ui.js'), 'utf8');
const retiredStepsPath = path.join(root, 'js', '48_steps_ui.js');
const steps = fs.existsSync(retiredStepsPath) ? fs.readFileSync(retiredStepsPath, 'utf8') : '';
const nav = fs.readFileSync(path.join(root, 'js', '48_step_navigation.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const bootstrap = fs.readFileSync(path.join(root, 'js', '90_bootstrap.js'), 'utf8');
const index = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

function bodyOf(src, fnName){
  const marker = `function ${fnName}(`;
  const start = src.indexOf(marker);
  assert.ok(start >= 0, `${fnName} must exist`);
  const brace = src.indexOf('{', start);
  let depth = 0;
  for(let i=brace; i<src.length; i++){
    const ch = src[i];
    if(ch === '{') depth++;
    if(ch === '}') depth--;
    if(depth === 0) return src.slice(start, i + 1);
  }
  throw new Error(`could not parse ${fnName}`);
}

function test(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

const step2Fns = ['renderStep2','renderFieldList','renderZipConfig','renderZoneList','renderBgUI','bindEventsForStep2'];

test('Step2 Edit UI module defines and exports moved functions', ()=>{
  assert.match(step2, /\(function\(global\)\{[\s\S]*'use strict';/);
  for(const fn of step2Fns){
    assert.match(step2, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} missing from Step2 module`);
    assert.doesNotMatch(steps, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} must not remain in 48_steps_ui.js`);
  }
  assert.match(step2, /Object\.assign\(global,\s*\{[\s\S]*renderStep2[\s\S]*renderBgUI[\s\S]*EnvelopePrintStep2EditUI/);
  assert.match(step2, /const\s+Step2EditUiApi\s*=\s*Object\.freeze\(\{[\s\S]*renderStep2[\s\S]*bindEventsForStep2/);
});

test('retired 48_steps_ui has no concrete step functions', ()=>{
  assert.strictEqual(fs.existsSync(retiredStepsPath), false, '48_steps_ui.js must remain retired');
  for(const fn of ['renderStep1','renderStep2','renderStep3','renderStep4','renderStep5','renderQueue','goToStep','bindEventsForStep2']){
    assert.doesNotMatch(steps, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} must not remain in 48_steps_ui.js`);
  }
});

test('Step2 edit UI keeps layout-change, save, render, and deletion contracts', ()=>{
  const fieldBody = bodyOf(step2, 'renderFieldList');
  const zipBody = bodyOf(step2, 'renderZipConfig');
  const zoneBody = bodyOf(step2, 'renderZoneList');
  assert.match(fieldBody, /markLayoutChanged\(t\);renderEnvelope\(\);save\(\);renderZipConfig\(\);/);
  assert.match(fieldBody, /showAppConfirm[\s\S]*フィールドの削除/);
  assert.match(fieldBody, /fld\.zipConfig=\{showFrame:false,showMark:false,charSpacing:1\.2,gapAfter3:1\.5,digitOffsets:\[\]\}/);
  assert.match(fieldBody, /fld\.customText='親展'/);
  assert.match(zipBody, /while\(zc\.digitOffsets\.length<7\)/);
  assert.match(zipBody, /markLayoutChanged\(t\);renderEnvelope\(\);save\(\);/);
  assert.match(zoneBody, /showAppConfirm[\s\S]*避ける範囲の削除/);
  assert.match(zoneBody, /markLayoutChanged\(t\);save\(\);renderZoneList\(\);renderEnvelope\(\);/);
});



test('Step2 event binder moved fixed listeners out of bootstrap', ()=>{
  const binderBody = bodyOf(step2, 'bindEventsForStep2');
  for(const id of ['btnReWizard','btnUnlock','step2Back','step2Next','tName','tW','tH','tIsReply','tLocked','btnAddField','btnAddSenderBlock','btnAddStamp','btnAddZone','btnLoadBg','fileBg','btnClearBg','bgPersist','bgOpacity','bgOffX','bgOffY','bgScaleX','bgScaleY','bgRotation','btnBgReset','btnZoomIn','btnZoomOut','envelope']){
    assert.match(binderBody, new RegExp(id), `${id} must be owned by bindEventsForStep2`);
  }
  assert.match(binderBody, /attachEnvelopeZoneDraftHandler\(\$\('envelope'\)\)/);
  assert.match(bootstrap, /bindEventsForStep2\(\);/);
  for(const id of ['btnReWizard','btnUnlock','step2Back','step2Next','btnAddField','btnLoadBg','btnZoomIn','btnZoomOut']){
    assert.doesNotMatch(bootstrap, new RegExp(id + '[\\s\\S]{0,180}addEventListener'), `${id} listener must not remain in bootstrap`);
  }
});

test('script order loads Step2 edit UI before Step1/Step3 and core', ()=>{
  const order = Array.from(index.matchAll(/<script[^>]+src="([^"]+)"/g)).map(m=>m[1]);
  const pos = name => order.indexOf(name);
  for(const name of ['js/48_step_navigation.js','js/48_step2_edit_ui.js','js/48_step1_template_ui.js','js/48_step3_input_core.js','js/10_core.js']){
    assert.ok(pos(name) >= 0, `${name} missing from script order`);
  }
  assert.strictEqual(pos('js/48_steps_ui.js'), -1, 'retired 48_steps_ui.js must not be loaded');
  assert.ok(pos('js/48_step_navigation.js') < pos('js/48_step2_edit_ui.js'));
  assert.ok(pos('js/48_step2_edit_ui.js') < pos('js/48_step1_template_ui.js'));
  assert.ok(pos('js/48_step2_edit_ui.js') < pos('js/48_step3_input_core.js'));
  assert.ok(pos('js/48_step2_edit_ui.js') < pos('js/10_core.js'));
});

test('public module index exposes Step2Edit API and navigation routes to renderStep2', ()=>{
  assert.match(core, /Step2Edit:EnvelopePrintStep2EditUI/);
  assert.match(dataUi, /Step2Edit:\['EnvelopePrintStep2EditUI','renderStep2','renderFieldList','renderZipConfig','renderZoneList','renderBgUI','bindEventsForStep2'\]/);
  assert.match(nav, /if\(n===2\) renderStep2\(\);/);
  assert.match(core, /\{step:'v38-36'[\s\S]*Step2固定イベント/);
});

console.log('OK 6 step2 edit UI tests passed');
