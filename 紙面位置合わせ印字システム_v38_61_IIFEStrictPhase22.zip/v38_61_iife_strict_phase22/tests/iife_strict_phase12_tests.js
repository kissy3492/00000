#!/usr/bin/env node
/* v38-51 IIFE Strict Phase12 tests: Data Management UI scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const dataMgmtUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

async function ok(name, fn){
  try{
    await fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

(async ()=>{
  await ok('data management UI starts with IIFE + strict', ()=>{
    assert.ok(/^\(function\(global\)\{/.test(dataMgmtUi), 'Data Management UI must start with IIFE');
    assert.ok(dataMgmtUi.slice(0, 180).includes("'use strict';"), 'Data Management UI must enable strict mode near the top');
  });

  await ok('data management UI exposes legacy globals and EnvelopePrintDataManagementUI API', ()=>{
    for(const name of ['showHelp','showDataMgmt','getModuleOverview']){
      assert.ok(new RegExp(`function\\s+${name}\\s*\\(`).test(dataMgmtUi), `${name} must remain present`);
    }
    assert.ok(/const\s+DataManagementUiApi\s*=\s*Object\.freeze\(\{[\s\S]*showHelp[\s\S]*showDataMgmt[\s\S]*getModuleOverview/.test(dataMgmtUi), 'DataManagementUiApi freeze block missing');
    assert.ok(/EnvelopePrintDataManagementUI:\s*DataManagementUiApi/.test(dataMgmtUi), 'EnvelopePrintDataManagementUI export missing');
  });

  await ok('lightweight VM load exposes data management UI API without touching DOM', ()=>{
    const sandbox = { console, window:null, globalThis:null };
    sandbox.window = sandbox;
    sandbox.globalThis = sandbox;
    vm.createContext(sandbox);
    vm.runInContext(dataMgmtUi, sandbox, {filename:'js/52_data_management_ui.js'});
    assert.strictEqual(typeof sandbox.showHelp, 'function');
    assert.strictEqual(typeof sandbox.showDataMgmt, 'function');
    assert.strictEqual(typeof sandbox.getModuleOverview, 'function');
    assert.strictEqual(typeof sandbox.EnvelopePrintDataManagementUI, 'object');
    assert.strictEqual(sandbox.EnvelopePrintDataManagementUI.showHelp, sandbox.showHelp);
    assert.strictEqual(sandbox.EnvelopePrintDataManagementUI.showDataMgmt, sandbox.showDataMgmt);
    assert.strictEqual(sandbox.EnvelopePrintDataManagementUI.getModuleOverview, sandbox.getModuleOverview);
    assert.ok(Object.isFrozen(sandbox.EnvelopePrintDataManagementUI), 'EnvelopePrintDataManagementUI must be frozen');
    const overview = sandbox.EnvelopePrintDataManagementUI.getModuleOverview();
    assert.deepStrictEqual(Array.from(overview.DataManagementUI), ['EnvelopePrintDataManagementUI','showHelp','showDataMgmt','getModuleOverview']);
    assert.ok(Array.isArray(overview.Storage), 'existing Storage overview bucket must remain available');
  });

  await ok('global module indexes expose Data Management UI API', ()=>{
    assert.ok(/DataManagementUI:EnvelopePrintDataManagementUI/.test(core), 'EnvelopePrintModules must expose EnvelopePrintDataManagementUI');
    assert.ok(/DataManagementUI:\['EnvelopePrintDataManagementUI','showHelp','showDataMgmt','getModuleOverview'\]/.test(dataMgmtUi), 'getModuleOverview must expose Data Management UI API');
  });

  await ok('verification pipeline includes phase12 guard', ()=>{
    assert.ok(verify.includes('js/52_data_management_ui.js'), 'verify_structure must include data management UI guard');
    assert.ok(verify.includes('EnvelopePrintDataManagementUI'), 'verify_structure must check EnvelopePrintDataManagementUI');
    assert.ok(verifySh.includes('tests/iife_strict_phase12_tests.js'), 'verify.sh must run phase12 tests');
  });

  console.log('IIFE strict phase12 tests: OK');
})();
