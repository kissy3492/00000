#!/usr/bin/env node
/* v38-33: Step4/Step5 UI static tests.
   目的: Step4テスト印刷・プリンタ補正UIとStep5本印刷プレビューUIの関数配置、固定イベント接続、公開APIを固定する。 */
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const step4 = fs.readFileSync(path.join(root, 'js', '48_step4_test_print_ui.js'), 'utf8');
const step5 = fs.readFileSync(path.join(root, 'js', '48_step5_final_print_ui.js'), 'utf8');
const retiredStepsPath = path.join(root, 'js', '48_steps_ui.js');
const steps = fs.existsSync(retiredStepsPath) ? fs.readFileSync(retiredStepsPath, 'utf8') : '';
const bootstrap = fs.readFileSync(path.join(root, 'js', '90_bootstrap.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const index = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

function bodyOf(src, fnName){
  const marker = `function ${fnName}(`;
  const start = src.indexOf(marker);
  assert.ok(start >= 0, `${fnName} must exist`);
  const brace = src.indexOf('{', start);
  let depth = 0;
  for(let i=brace; i<src.length; i++){
    const ch = src[i];
    if(ch === '{') depth++;
    if(ch === '}') depth--;
    if(depth === 0) return src.slice(start, i + 1);
  }
  throw new Error(`could not parse ${fnName}`);
}

function test(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

test('Step4 Test Print UI defines and exports moved functions', ()=>{
  for(const fn of ['renderStep4','renderPrinterProfileSection','updateStep4Summary','bindEventsForStep4']){
    assert.match(step4, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} missing from Step4 module`);
    assert.doesNotMatch(steps, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} must not remain in 48_steps_ui.js`);
    assert.match(step4, new RegExp(`\\b${fn}\\b`), `${fn} missing from export block`);
  }
  assert.match(step4, /^\(function\(global\)\{[\s\S]*'use strict';/);
  assert.match(step4, /const\s+Step4TestPrintUiApi\s*=\s*Object\.freeze\(\{[\s\S]*renderStep4[\s\S]*bindEventsForStep4/);
  assert.match(step4, /Object\.assign\(global,\s*\{[\s\S]*bindEventsForStep4[\s\S]*EnvelopePrintStep4TestPrintUI/);
});

test('Step5 Final Print UI defines and exports moved functions', ()=>{
  for(const fn of ['renderStep5','bindEventsForStep5']){
    assert.match(step5, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} missing from Step5 module`);
    assert.doesNotMatch(steps, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} must not remain in 48_steps_ui.js`);
    assert.match(step5, new RegExp(`\\b${fn}\\b`), `${fn} missing from export block`);
  }
  assert.match(step5, /^\(function\(global\)\{[\s\S]*'use strict';/);
  assert.match(step5, /Step5ExtensionRegistry[\s\S]*runRenderHooks/);
  assert.match(step5, /const\s+Step5FinalPrintUiApi\s*=\s*Object\.freeze\(\{[\s\S]*renderStep5[\s\S]*bindEventsForStep5/);
  assert.match(step5, /Object\.assign\(global,\s*\{[\s\S]*bindEventsForStep5[\s\S]*EnvelopePrintStep5FinalPrintUI/);
});

test('Step4 fixed event binder owns Step4 buttons and bootstrap delegates', ()=>{
  const body = bodyOf(step4, 'bindEventsForStep4');
  for(const id of ['step4Back','step4Next','btnFixMismatch','btnRemoveMismatch','btnTestSample','btnTestFirst','btnTestCross','markTestPrinted']){
    assert.ok(body.includes(id), `${id} listener missing from Step4 binder`);
  }
  assert.match(body, /showAppConfirm[\s\S]*キューのテンプレート整合/);
  assert.match(body, /doPrint\(\{queue:\[sample\]\}\)/);
  assert.match(body, /doPrint\(\{queue:\[valid\[0\]\]\}\)/);
  assert.match(body, /doPrint\(\{queue:\[\],testCross:true\}\)/);
  assert.ok(bootstrap.includes('bindEventsForStep4();'), 'bootstrap must delegate Step4 events');
  assert.doesNotMatch(bootstrap, /btnFixMismatch[\s\S]{0,180}addEventListener/, 'bootstrap must not own Step4 mismatch listener');
  assert.doesNotMatch(bootstrap, /markTestPrinted[\s\S]{0,180}addEventListener/, 'bootstrap must not own Step4 confirmation listener');
});

test('Step5 fixed event binder owns Step5 buttons and bootstrap delegates', ()=>{
  const body = bodyOf(step5, 'bindEventsForStep5');
  for(const id of ['step5Back','btnStartOver']){
    assert.ok(body.includes(id), `${id} listener missing from Step5 binder`);
  }
  assert.match(body, /showAppConfirm[\s\S]*最初のステップへ戻る/);
  assert.ok(bootstrap.includes('bindEventsForStep5();'), 'bootstrap must delegate Step5 events');
  assert.doesNotMatch(bootstrap, /btnStartOver[\s\S]{0,180}addEventListener/, 'bootstrap must not own Step5 start-over listener');
});

test('script order loads Step4 and Step5 UI before core bootstrap', ()=>{
  const order = Array.from(index.matchAll(/<script[^>]+src="([^"]+)"/g)).map(m=>m[1]);
  const pos = name => order.indexOf(name);
  for(const name of ['js/48_step3_queue_ui.js','js/48_step4_test_print_ui.js','js/48_step5_final_print_ui.js','js/10_core.js','js/90_bootstrap.js']){
    assert.ok(pos(name) >= 0, `${name} missing from script order`);
  }
  assert.strictEqual(pos('js/48_steps_ui.js'), -1, 'retired 48_steps_ui.js must not be loaded');
  assert.ok(pos('js/48_step3_queue_ui.js') < pos('js/48_step4_test_print_ui.js'));
  assert.ok(pos('js/48_step4_test_print_ui.js') < pos('js/48_step5_final_print_ui.js'));
  assert.ok(pos('js/48_step4_test_print_ui.js') < pos('js/10_core.js'));
  assert.ok(pos('js/48_step5_final_print_ui.js') < pos('js/10_core.js'));
});

test('public module index exposes Step4TestPrint and Step5FinalPrint APIs', ()=>{
  assert.match(core, /Step4TestPrint:EnvelopePrintStep4TestPrintUI/);
  assert.match(core, /Step5FinalPrint:EnvelopePrintStep5FinalPrintUI/);
  assert.match(dataUi, /Step4TestPrint:\['EnvelopePrintStep4TestPrintUI','renderStep4','renderPrinterProfileSection','updateStep4Summary','bindEventsForStep4'\]/);
  assert.match(dataUi, /Step5FinalPrint:\['EnvelopePrintStep5FinalPrintUI','renderStep5','bindEventsForStep5'\]/);
});

console.log('OK 6 step4/step5 UI tests passed');
