#!/usr/bin/env node
/* v38-57 IIFE Strict Phase18 tests: Step2 Edit UI scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const step2 = fs.readFileSync(path.join(root, 'js', '48_step2_edit_ui.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataMgmtUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

function ok(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

const legacyFns = ['renderStep2','renderFieldList','renderZipConfig','renderZoneList','renderBgUI','bindEventsForStep2'];

ok('step2 edit UI starts with IIFE + strict', ()=>{
  assert.ok(/^\(function\(global\)\{/.test(step2), 'Step2 Edit UI must start with IIFE');
  assert.ok(step2.slice(0, 260).includes("'use strict';"), 'Step2 Edit UI must enable strict mode near the top');
});

ok('step2 edit UI exposes legacy globals and EnvelopePrintStep2EditUI API', ()=>{
  for(const name of legacyFns){
    assert.ok(new RegExp(`function\\s+${name}\\s*\\(`).test(step2), `${name} must remain present`);
  }
  assert.ok(/const\s+Step2EditUiApi\s*=\s*Object\.freeze\(\{[\s\S]*renderStep2[\s\S]*bindEventsForStep2/.test(step2), 'Step2EditUiApi freeze block missing');
  assert.ok(/EnvelopePrintStep2EditUI:\s*Step2EditUiApi/.test(step2), 'EnvelopePrintStep2EditUI export missing');
  assert.ok(/Object\.assign\(global,[\s\S]*renderStep2[\s\S]*bindEventsForStep2[\s\S]*EnvelopePrintStep2EditUI/.test(step2), 'legacy Step2 exports must remain assigned to global');
});

ok('lightweight VM load exposes step2 API and preserves add-field/background routing contracts', ()=>{
  function makeElement(id){
    return {
      id,
      value:'',
      checked:false,
      textContent:'',
      innerHTML:'',
      style:{display:''},
      dataset:{mode:id === 'modePreview' ? 'preview' : 'edit'},
      files:[],
      handlers:{},
      classList:{add(){}, remove(){}, toggle(){}},
      addEventListener(type, fn){ this.handlers[type] = fn; },
      click(){ if(this.handlers.click) this.handlers.click({target:this, stopPropagation(){}, preventDefault(){}}); },
      querySelectorAll(){ return []; },
      appendChild(){},
      setAttribute(){},
      removeAttribute(){}
    };
  }
  const ids = ['btnReWizard','btnUnlock','step2Back','step2Next','tName','tW','tH','tIsReply','tLocked','btnAddField','btnAddSenderBlock','btnAddStamp','btnAddZone','btnLoadBg','fileBg','btnClearBg','bgPersist','bgOpacity','bgOffX','bgOffY','bgScaleX','bgScaleY','bgRotation','btnBgReset','btnZoomIn','btnZoomOut','envelope','fldBadge','zoomLabel','basicBadge','step2Title','replyBanner','lockBanner','bgOpacityVal','bgDot','bgInfo','bgBadge','fieldList','zoneList','zipConfigBody','pdfNotice','bgSizeInfo'];
  const elements = Object.fromEntries(ids.map(id => [id, makeElement(id)]));
  const modeButtons = [makeElement('modeEdit'), makeElement('modePreview')];
  const calls = [];
  const tpl = {id:'tpl1', name:'封筒', w:120, h:235, locked:false, fields:[], excludeZones:[], bgImage:'data:image/png;base64,x', bgSourceName:'bg.png', bgBytes:12};
  const sandbox = {
    console,
    window:null,
    globalThis:null,
    document:{
      querySelectorAll(sel){ return sel === '.mode-toggle button' ? modeButtons : []; },
      createElement(){ return makeElement('created'); }
    },
    state:{selectedFieldId:null, selectedZoneId:null, mode:'edit', zoom:1},
    transientBg:{},
    __pdfjsAvailable:false,
    $(id){ return elements[id] || (elements[id] = makeElement(id)); },
    uid(prefix='id'){ return `${prefix}_${tpl.fields.length + 1}`; },
    getCurrentTpl(){ return tpl; },
    getBgImage(t){ return t.bgImage ? {dataUrl:t.bgImage, name:t.bgSourceName, bytes:t.bgBytes} : null; },
    formatBytes(v){ return `${v}B`; },
    escapeHtml(v){ return String(v ?? ''); },
    getFieldSourceLabel(v){ return v; },
    sourceOptionsHtml(){ return '<option value="custom">custom</option>'; },
    ANCHOR_KEYS:['tl'],
    ANCHOR_LABELS:{tl:'左上'},
    markLayoutChanged(){ calls.push('markLayoutChanged'); },
    renderEnvelope(){ calls.push('renderEnvelope'); },
    save(){ calls.push('save'); },
    renderSteps(){ calls.push('renderSteps'); },
    renderFieldList(){ calls.push('outerRenderFieldList'); },
    showAppConfirm: async () => true,
    openWizard(){ calls.push('openWizard'); },
    goToStep(n){ calls.push(['goToStep', n]); },
    buildFieldsForSize(){ return []; },
    addSenderBlockToCurrentTpl(){ calls.push('addSenderBlockToCurrentTpl'); },
    handleAddStampClick(){ calls.push('handleAddStampClick'); },
    startAddZone(){ calls.push('startAddZone'); },
    loadBackgroundFileInto: async () => { calls.push('loadBackgroundFileInto'); },
    attachEnvelopeZoneDraftHandler(el){ calls.push(['attachEnvelopeZoneDraftHandler', el.id]); },
    applyScreenA11y(){ calls.push('applyScreenA11y'); }
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(step2, sandbox, {filename:'js/48_step2_edit_ui.js'});

  assert.strictEqual(typeof sandbox.EnvelopePrintStep2EditUI, 'object');
  assert.ok(Object.isFrozen(sandbox.EnvelopePrintStep2EditUI), 'EnvelopePrintStep2EditUI must be frozen');
  assert.strictEqual(sandbox.EnvelopePrintStep2EditUI.renderStep2, sandbox.renderStep2);
  sandbox.bindEventsForStep2();
  assert.deepStrictEqual(calls.pop(), ['attachEnvelopeZoneDraftHandler', 'envelope']);
  elements.btnAddField.click();
  assert.strictEqual(tpl.fields.length, 1);
  assert.strictEqual(tpl.fields[0].source, 'custom');
  assert.strictEqual(tpl.fields[0].customText, 'サンプル');
  assert.ok(calls.includes('markLayoutChanged'));
  assert.ok(calls.includes('save'));
  assert.ok(calls.includes('renderEnvelope'));
  elements.bgPersist.checked = false;
  elements.bgPersist.handlers.change({target:elements.bgPersist});
  assert.ok(sandbox.transientBg.tpl1, 'non-persistent background must move to transientBg');
  assert.strictEqual(tpl.bgImage, undefined);
});

ok('global module indexes expose Step2 Edit UI API', ()=>{
  assert.ok(/Step2Edit:EnvelopePrintStep2EditUI/.test(core), 'EnvelopePrintModules must expose EnvelopePrintStep2EditUI');
  assert.ok(/Step2Edit:\['EnvelopePrintStep2EditUI','renderStep2','renderFieldList','renderZipConfig','renderZoneList','renderBgUI','bindEventsForStep2'\]/.test(dataMgmtUi), 'getModuleOverview must expose Step2 Edit UI API');
});

ok('verification pipeline includes phase18 guard', ()=>{
  assert.ok(verify.includes('js/48_step2_edit_ui.js'), 'verify_structure must include Step2 edit UI guard');
  assert.ok(verify.includes('EnvelopePrintStep2EditUI'), 'verify_structure must check EnvelopePrintStep2EditUI');
  assert.ok(verifySh.includes('tests/iife_strict_phase18_tests.js'), 'verify.sh must run phase18 tests');
});

console.log('IIFE strict phase18 tests: OK');
