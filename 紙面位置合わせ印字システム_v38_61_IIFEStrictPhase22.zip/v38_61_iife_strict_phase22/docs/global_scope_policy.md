# v38-61 グローバルスコープ方針

## 方針

v38はES Modulesではなくclassic scriptで動かす。`file://`直開き互換を優先するためである。
ただし、classic scriptだからといって暗黙のグローバル汚染を増やさない。

## 新規・修正済みモジュールの原則

- IIFE + `'use strict'` を基本形にする。
- 外部から使う関数だけ `window` へ明示的にexportする。
- 返す文字列がHTMLなのかプレーンテキストなのかをコメントで明示する。
- 依存するグローバル関数はREADMEとverifyで読み込み順を確認する。

## 既存ファイルについて

既存の `48_steps_ui.js` はv38-38で退役済み。既存の `30_storage.js`、`40_templates.js`、`45_render_fields.js`、`46_render_envelope.js`、`47_print.js` などは、過去の段階分離の結果として素のclassic scriptになっている。
これらを一括IIFE化すると依存確認が広範囲になるため、別Stepで段階的に処理する。

## Address Data Formatterの契約

`js/15_address_data.js` が返す文字列はプレーンテキストである。HTMLとして安全化された文字列ではない。
DOMへ入れる側が `textContent`、`escapeHtml()`、またはtextarea `.value` を使って安全性を担保する。


## v38-17 適用

`js/06_keyboard_overlay.js` は IIFE + strict + 明示 `window` export で作成した。新規・修正済みモジュールはこの形式を基本とする。

## v38-18 適用

`js/43_background_assets.js` も IIFE + strict + 明示 `window` export で作成した。
公開する入口は `BG_MAX_LONG_EDGE` / `BG_JPEG_QUALITY` / `compressImageDataUrl()` / `loadBackgroundFileInto()` / `fileToDataURL()` / `loadBackgroundPDF()` / `loadBackgroundImage()` / `setBackgroundOnTpl()` に限定する。

背景データの置き場である `transientBg` は、保存・復元・Wizardスナップショットと共有されるため、v38-18では移動しない。


## v38-19 適用

`js/52_data_management_ui.js` も IIFE + strict + 明示 `window` export で作成した。公開する入口は `showHelp()` / `showDataMgmt()` / `getModuleOverview()` に限定する。

`showDataMgmt()` は実行時に `state`、`transientBg`、Storage API、共通モーダルAPIへ接続する。データ置き場や保存形式は移動しない。


## v38-20 適用

`js/44_edit_canvas_controller.js` も IIFE + strict + 明示 `window` export で作成した。公開する入口は `getMMperPxOf()` / `getMMperPx()` / `getDragPoint()` / `isPrimaryDragStart()` / `preventDragDefault()` / `addDragDocumentListeners()` / `removeDragDocumentListeners()` / `attachFieldDrag()` / `attachZoneDrag()` / `startAddZone()` / `startEnvelopeZoneDraft()` / `attachEnvelopeZoneDraftHandler()` / `getEditCanvasControllerState()` に限定する。

`renderEnvelope()` 本体、`state`、`save()`、`renderFieldList()`、`renderZoneList()` は実行時参照に留め、保存形式や画面状態の置き場は移動しない。


## v38-21 適用

`js/90_bootstrap.js` は当初、既存のclassic script相互参照を維持するため通常のclassic scriptとして作成した。

v38-44で IIFE + strict 化した後も、互換維持のため `bindEvents()` / `selectLastUsedTemplate()` / `initializeApp()` は従来どおり `window` へ明示exportする。まとまった公開入口として `window.EnvelopePrintBootstrap` も維持する。テスト時のみ `window.__ENVELOPE_PRINT_BOOTSTRAP_TEST_MODE` で自動起動を抑止する。

起動順は `10_core.js` の直後、Stage5〜8 addonの直前に維持する。保存形式やデータ置き場は変更しない。


## v38-22 適用

`js/41_parts_actions.js` も IIFE + strict + 明示 `window` export で作成した。公開する入口は `createSenderFields()` / `createStampField()` / `refreshPartsActionUi()` / `addSenderBlockToCurrentTpl()` / `addStampToCurrentTpl()` / `handleAddStampClick()` に限定する。

`addSenderBlockToCurrentTpl()` と `addStampToCurrentTpl()` は実行時に `state`、`getCurrentTpl()`、`save()`、`renderFieldList()`、`renderEnvelope()`、`renderZipConfig()`、共通モーダルAPIへ接続する。保存形式やfield.source名は変更しない。


## v38-23 適用

`js/44_edit_canvas_controller.js` の公開入口に `renderEnvelope()` を追加した。公開入口は、Step2編集キャンバスの描画入口、mm換算、ドラッグ、避ける範囲作成に限定する。

`renderEnvelope()` は実行時に `state`、`getCurrentTpl()`、`getSampleData()`、`renderEnvelopeInto()` へ接続する。state本体と保存形式は移動しない。


## v38-24 適用

`js/53_adjustment_status.js` も IIFE + strict + 明示 `window` export で作成した。公開する入口は `getTplAdjustmentSummary()` に限定する。

`getTplAdjustmentSummary()` は実行時に `state.selectedPrinterId`、`getBgImage()`、`getPrinterCorrection()`、`hasAnyCorrection()` へ接続する。state本体、背景データ、プリンタ補正データ、保存形式は移動しない。


## v38-40 適用

`js/00_pdf_loader.js` / `js/42_layout_math.js` / `js/99_audit_marker.js` を IIFE + strict 化した。

`js/42_layout_math.js` は既存互換のため `overlap()` / `adjustFieldRect()` / `approxChar()` / `estimatePrintCharUnits()` / `wrapTextByPrintUnits()` / `fitText()` を従来どおり `window` へ明示exportする。あわせて `EnvelopePrintLayoutMath` を追加し、今後の参照入口を明確化した。

`MIN_FONT_PT` は内部定数として閉じ込め、グローバルへ出さない。保存キー・保存形式・`field.source` 名は変更しない。

## v38-43 適用

`js/20_registries.js` を IIFE + strict 化した。

既存互換のため、以下は従来どおり `window` へ明示exportする。

- `FieldSourceRegistry`
- `Step3ExtensionRegistry`
- `Step5ExtensionRegistry`
- `PrintExecutionRegistry`
- `InputValidationRegistry`
- `InputDataExtensionRegistry`
- `SampleDataRegistry`
- `registerBuiltinFieldSources()`
- `getFieldSourceEntries()`
- `getFieldSourceLabel()`
- `sourceOptionsHtml()`
- `registerBuiltinSampleData()`

あわせて `EnvelopePrintRegistryCore` を追加し、Registry Coreの参照入口を明確化した。
保存キー・保存形式・`field.source` 名は変更しない。


## v38-44 適用

`js/90_bootstrap.js` を IIFE + strict 化した。

起動順序とイベント委譲順を変えず、既存互換のため以下は従来どおり `window` へ明示exportする。

- `bindEvents()`
- `selectLastUsedTemplate()`
- `initializeApp()`
- `EnvelopePrintBootstrap`

保存キー・保存形式・`field.source` 名は変更しない。


## v38-45 適用

`js/49_wizard.js` を IIFE + strict 化した。

既存互換のため、位置合わせウィザード関連の主要関数は従来どおり `window` へ明示exportする。あわせて `window.EnvelopePrintWizard` を追加し、Wizard Controllerの参照入口を明確化した。

`wizardState` はIIFE内部状態として閉じるが、`06_keyboard_overlay.js` と `30_storage.js` が既存どおり参照できるよう `window.wizardState` の getter/setter を維持する。保存キー・保存形式・`field.source` 名は変更しない。


## v38-46 適用

`js/05_utilities.js` を IIFE + strict 化した。

既存互換のため、通知・コピー・a11y・モーダル・表示補助系の主要関数は従来どおり `window` へ明示exportする。あわせて `window.EnvelopePrintUtilities` を追加し、共通ユーティリティの参照入口を明確化した。

`state`、`transientBg`、保存処理、DOM本体は移動しない。保存キー・保存形式・`field.source` 名は変更しない。

## v38-47 適用

`js/15_address_data.js` を IIFE + strict 化した。

既存互換のため、宛名・差出人データ整形、サンプルデータ、field text解決入口の主要関数は従来どおり `window` へ明示exportする。あわせて `window.EnvelopePrintAddressData` を追加し、Address Data Formatterの参照入口を明確化した。

このモジュールが返す文字列は引き続きHTMLではなくプレーンテキストである。DOMへ挿入する側が `textContent`、`escapeHtml()`、またはtextarea `.value` で安全性を担保する。Registry系は実行時参照とし、保存キー・保存形式・`field.source` 名は変更しない。



## v38-48 適用

`js/53_adjustment_status.js` を IIFE + strict Phase9 として再整備した。

既存互換のため、`getTplAdjustmentSummary()` は従来どおり `window` へ明示exportする。あわせて `window.EnvelopePrintAdjustmentStatus` を追加し、Adjustment Statusの参照入口を明確化した。

`getTplAdjustmentSummary()` は実行時に `state.selectedPrinterId`、`getBgImage()`、`getPrinterCorrection()`、`hasAnyCorrection()` へ接続する。state本体、背景データ、プリンタ補正データ、保存形式は移動しない。保存キー・保存形式・`field.source` 名は変更しない。

## v38-49 適用

`js/54_common_ui_binder.js` を IIFE Strict Phase10 として再整備した。

既存互換のため `bindEventsForCommonUI()` は従来どおり `window` へ明示exportする。あわせて `EnvelopePrintCommonUI` を公開入口として整理し、`EnvelopePrintModules.CommonUI` と `getModuleOverview().CommonUI` から同じ境界を確認できるようにした。

`btnHelp`、`btnDataMgmt`、`modeSimple`、`modeAdvanced` の固定イベント接続は引き続き Common UI Binder が担当し、`90_bootstrap.js` は委譲だけを行う。保存キー・保存形式・`field.source` 名は変更しない。

## v38-50 適用

`js/41_parts_actions.js` を Phase11対象として再整備し、Parts Actions の公開入口を `EnvelopePrintPartsActions` に明示した。従来互換として `createSenderFields()` / `createStampField()` / `refreshPartsActionUi()` / `addSenderBlockToCurrentTpl()` / `addStampToCurrentTpl()` / `handleAddStampClick()` は `window` export を維持する。保存キー・保存形式・field.source名は変更しない。


## v38-51 適用

`js/52_data_management_ui.js` を IIFE Strict Phase12 として再整備し、Data Management UI の公開入口を `EnvelopePrintDataManagementUI` に明示した。従来互換として `showHelp()` / `showDataMgmt()` / `getModuleOverview()` は `window` export を維持する。

`showDataMgmt()` は引き続き実行時に `state`、Storage API、共通モーダルAPIへ接続する。保存キー・保存形式・field.source名は変更しない。


## v38-52 適用

`js/30_storage.js` を IIFE Strict Phase13 として再整備し、Storage Core の公開入口を `EnvelopePrintStorageCore` に明示した。従来互換として `dataSnapshot()` / `dataSnapshotForBackup()` / `save()` / `backupNow()` / `restoreFullBackupSafely()` / `load()` / `getStorageUsage()` / `getBackups()` / `clearAddonStorage()` / `removeObsoleteStorageKeys()` などは `window` export を維持する。

この段階では保存キー、保存形式、アドオン保存キー、`field.source` 名は変更しない。`beforeunload` の未保存・保存失敗保護は維持し、Storage APIは引き続き実行時に `state`、`transientBg`、Template Model、Utilitiesへ接続する。

## v38-53 適用

`js/43_background_assets.js` を IIFE Strict Phase14 として再整備し、Background Assets の公開入口を `EnvelopePrintBackgroundAssets` に明示した。従来互換として `BG_MAX_LONG_EDGE` / `BG_JPEG_QUALITY` / `compressImageDataUrl()` / `loadBackgroundFileInto()` / `fileToDataURL()` / `loadBackgroundPDF()` / `loadBackgroundImage()` / `setBackgroundOnTpl()` は `window` export を維持する。

この段階では背景画像/PDFの取込処理、永続背景と非永続背景の保存先、PDF読込の有効判定、保存キー、保存形式、`field.source` 名は変更しない。Background Assets APIは引き続き実行時に `transientBg`、`markLayoutChanged()`、`save()`、Utilities、pdf.jsへ接続する。

## v38-54 適用

`js/44_edit_canvas_controller.js` を IIFE Strict Phase15 として再整備し、Edit Canvas Controller の公開入口を `EnvelopePrintEditCanvasController` に明示した。従来互換として `renderEnvelope()` / `getMMperPxOf()` / `getMMperPx()` / `getDragPoint()` / `isPrimaryDragStart()` / `preventDragDefault()` / `addDragDocumentListeners()` / `removeDragDocumentListeners()` / `attachFieldDrag()` / `attachZoneDrag()` / `startAddZone()` / `startEnvelopeZoneDraft()` / `attachEnvelopeZoneDraftHandler()` / `getEditCanvasControllerState()` は `window` export を維持する。

この段階では編集キャンバスの描画入口、field/zoneドラッグ、避ける範囲ドラフト作成、保存キー、保存形式、`field.source` 名は変更しない。Edit Canvas Controller APIは引き続き実行時に `state`、`getCurrentTpl()`、`renderEnvelopeInto()`、`renderFieldList()`、`renderZoneList()`、`markLayoutChanged()`、`save()`、Utilitiesへ接続する。


## v38-55 適用

`js/48_step_navigation.js` を IIFE Strict Phase16 として再整備し、Step Navigation の公開入口を `EnvelopePrintStepNavigation` に明示した。従来互換として `getActiveSteps()` / `stepIndex()` / `renderSteps()` / `getStepStatus()` / `canSkipTo()` / `canGoToStep()` / `goToStep()` は `window` export を維持する。

この段階ではStep遷移条件、Step1〜5への描画委譲、simple modeでStep2を無効化する契約、保存キー、保存形式、`field.source` 名は変更しない。Step Navigation APIは引き続き実行時に `state`、`STEPS_SIMPLE`、`STEPS_ADVANCED`、Step UI、Storage UI、Utilitiesへ接続する。


## v38-56 適用

`js/48_step1_template_ui.js` を IIFE Strict Phase17 として再整備し、Step1 Template UI の公開入口を `EnvelopePrintStep1TemplateUI` に明示した。従来互換として `bindEventsForStep1()` / `renderStep1()` / `handleTplCardClick()` / `showUnadjustedGuide()` / `duplicateTpl()` は `window` export を維持する。

この段階ではテンプレート選択、複製、削除、未調整ガイド、新規作成/返信用作成ボタン、保存キー、保存形式、`field.source` 名は変更しない。Step1 Template UI APIは引き続き実行時に `state`、Template Model、Adjustment Status、Wizard、Step Navigation、Storage、Utilitiesへ接続する。


## v38-57 適用

`js/48_step2_edit_ui.js` を IIFE Strict Phase18 として再整備し、Step2 Edit UI の公開入口を `EnvelopePrintStep2EditUI` に明示した。従来互換として `renderStep2()` / `renderFieldList()` / `renderZipConfig()` / `renderZoneList()` / `renderBgUI()` / `bindEventsForStep2()` は `window` export を維持する。

この段階ではStep2詳細編集、field一覧、郵便番号詳細、避ける範囲一覧、背景UI、固定イベント接続、保存キー、保存形式、`field.source` 名は変更しない。Step2 Edit UI APIは引き続き実行時に Template Model、Background Assets、Edit Canvas Controller、Parts Actions、Step Navigation、Storage、Utilitiesへ接続する。

## v38-58 適用

`js/48_step3_input_core.js` を IIFE Strict Phase19 として再整備し、Step3 Input Core の公開入口を `EnvelopePrintStep3InputCore` に明示した。従来互換として `renderStep3()` / `renderInputForm()` / `getInputData()` / `loadAddrToInput()` / `clearInput()` / `switchInputPane()` / `bindEventsForStep3()` は `window` export を維持する。

この段階ではStep3描画、手入力フォーム、入力データ収集/復元/クリア、入力ペイン切替、固定イベント接続、保存キー、保存形式、`field.source` 名、入力データキーは変更しない。Step3 Input Core APIは引き続き実行時に `state`、Address Data Formatter、Step3 Queue UI、Step Navigation、Storage、Utilities、`Step3ExtensionRegistry`、`InputDataExtensionRegistry`、`InputValidationRegistry` へ接続する。

## v38-59 適用

`js/48_step3_queue_ui.js` を IIFE Strict Phase20 として再整備し、Step3 Queue UI の公開入口を `EnvelopePrintStep3QueueUI` に明示した。従来互換として `renderQueue()` / `cloneQueueItemFromRecord()` / `renderAddrbook()` / `renderHistory()` / `addToHistory()` / `renderPasteImport()` / `analyzePastedData()` / `renderPastePreview()` / `doImportPaste()` は `window` export を維持する。

この段階ではキュー、住所録、履歴、Excel貼付取込、重複候補判定、保存キー、保存形式、`field.source` 名、入力データキー、貼付取込マッピングは変更しない。Step3 Queue UI APIは引き続き実行時に `state`、Address Data Formatter、Step3 Input Core、Step Navigation、Storage、Utilitiesへ接続する。

## v38-60 適用

`js/48_step4_test_print_ui.js` を IIFE Strict Phase21 として再整備し、Step4 Test Print UI の公開入口を `EnvelopePrintStep4TestPrintUI` に明示した。従来互換として `renderStep4()` / `renderPrinterProfileSection()` / `updateStep4Summary()` / `bindEventsForStep4()` は `window` export を維持する。

この段階ではキュー不整合表示、プリンタ補正表示、試し刷りサンプル/先頭宛先/十字テスト、結果確認チェック、保存キー、保存形式、`field.source` 名、印刷実行経路は変更しない。Step4 Test Print UI APIは引き続き実行時に `state`、Adjustment Status、Printer Correction、Step Navigation、Step3 Queue UI、Storage、Utilities、Print Controlへ接続する。


## v38-61 適用

`js/48_step5_final_print_ui.js` を IIFE Strict Phase22 として再整備し、Step5 Final Print UI の公開入口を `EnvelopePrintStep5FinalPrintUI` に明示した。従来互換として `renderStep5()` / `bindEventsForStep5()` は `window` export を維持する。

この段階では本番印刷サマリー、最終チェックリスト、印刷アクション、プレビュー、Step5ExtensionRegistry hook、Step5固定イベント接続、保存キー、保存形式、`field.source` 名、印刷実行経路は変更しない。Step5 Final Print UI APIは引き続き実行時に `state`、Template Model、Address Data Formatter、Envelope Renderer、Print Control、Step Navigation、Utilitiesへ接続する。
