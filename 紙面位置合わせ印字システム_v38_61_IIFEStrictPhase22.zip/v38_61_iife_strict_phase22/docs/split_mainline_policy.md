# v38-5 分割版本流化方針

## 結論

v38-5以降、開発・レビュー・テストの基準成果物は分割版とする。

## 理由

- 単体HTMLは8,000行を超え、レビュー不能に近い。
- 保存・復元・印刷・a11y・Stage addonが混在し、責務境界が見えにくい。
- ファイル単位でテスト・レビューできる分割構成の方が安全。

## 単体HTMLの扱い

単体HTMLは廃止ではなく、必要時のみ作る派生成果物とする。

想定用途:

- 職場PCで外部JS/CSS読込が制限される場合
- フォルダ配布が困難な場合
- 一時的に1ファイルで受け渡したい場合

## 禁止事項

- 分割版と単体HTMLを同時に本流扱いしない。
- 単体HTML側だけを直接修正しない。
- 保存形式変更やlocalStorageキー変更をリファクタと混ぜない。


## v38-6

Registry Core と Storage / Backup を `10_core.js` から段階分離した。保存形式・保存キー・field.source名は変更しない。


## v38-10補足

Envelope/Canvas描画のうち、`renderEnvelopeInto()` と印刷スタック生成を `js/46_render_envelope.js` へ分離した。編集操作・ドラッグ処理は状態更新と密接なため、まだ `10_core.js` に残す。

## v38-19補足

ヘルプ・バックアップ管理・疑似モジュール概要を `js/52_data_management_ui.js` へ分離した。分割版を本流とする方針は維持し、保存形式・localStorageキー・field.source名は変更しない。


## v38-21補足

イベント接続と初期化順序を `js/90_bootstrap.js` へ分離した。分割版を本流とする方針は維持し、`10_core.js` には起動実行を残さない。保存形式・localStorageキー・field.source名は変更しない。

## v38-22補足

差出人欄・スタンプfield生成と追加操作を `js/41_parts_actions.js` へ分離した。分割版を本流とする方針は維持し、保存形式・localStorageキー・field.source名は変更しない。

## v38-23補足

詳細編集画面の描画入口 `renderEnvelope()` を `js/44_edit_canvas_controller.js` へ分離した。分割版を本流とする方針は維持し、保存形式・localStorageキー・field.source名は変更しない。


## v38-24補足

調整ステータス判定 `getTplAdjustmentSummary()` を `js/53_adjustment_status.js` へ分離した。分割版を本流とする方針は維持し、保存形式・localStorageキー・field.source名は変更しない。
