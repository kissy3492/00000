# v38-39 Refactor Inventory Archive

> v38-39で、個別の `*_inventory.md` をこの1ファイルへ統合しました。最新状態の確認は `docs/core_residual_inventory.md` と `tools/verify_structure.js` を優先します。

## 統合対象

- `docs/adjustment_status_inventory.md`
- `docs/stage_addons_inventory.md`
- `docs/step1_template_ui_inventory.md`
- `docs/step2_edit_canvas_inventory.md`
- `docs/step2_edit_ui_inventory.md`
- `docs/step3_input_core_inventory.md`
- `docs/step3_input_queue_inventory.md`
- `docs/step4_step5_ui_inventory.md`

## アーカイブ本文

---

## 旧ファイル: `docs/adjustment_status_inventory.md`

## v38-24 Adjustment Status棚卸し

### 目的

`getTplAdjustmentSummary()` は、Step表示、印刷前チェック、位置合わせウィザード、プリンタ補正導線から参照される小さな状態判定関数である。

v38-24では、`state` や保存データ本体は動かさず、判定関数だけを `js/53_adjustment_status.js` へ分離した。

### 判定対象

| 戻り値 | 判定内容 |
|---|---|
| `hasBg` | 背景画像/PDF由来画像がテンプレートまたは一時背景に存在するか |
| `bgAligned` | `bgAlignedAt` があり、かつ `lastLayoutChangedAt` 以降か |
| `zipChecked` | `zipCheckedAt` があり、かつ `lastLayoutChangedAt` 以降か |
| `layoutChecked` | `layoutCheckedAt` があり、かつ `lastLayoutChangedAt` 以降か |
| `testPrinted` | `testPrintedAt` があり、かつ `lastLayoutChangedAt` 以降か。実印刷成功ではなく、テスト印刷結果をユーザが確認した時刻という互換名 |
| `printerCalibrated` | 選択プリンタがあり、補正値が存在する、または `printerCheckedAt` が `lastLayoutChangedAt` 以降か |

### 依存

- `state.selectedPrinterId`
- `getBgImage(tpl)`
- `getPrinterCorrection(printerId, tplId)`
- `hasAnyCorrection(corr)`

これらはすべて実行時参照に留める。`state`、`transientBg`、プリンタプロファイル、保存形式は移動しない。

### 検証

`tests/adjustment_status_unit_tests.js` で以下を確認する。

- `null` テンプレートは `null` を返す。
- 各確認タイムスタンプが `lastLayoutChangedAt` 以降であれば有効になる。
- レイアウト変更より古い確認タイムスタンプは無効になる。
- 補正値が存在する場合、プリンタ補正済みになる。
- 補正値がなくても `printerCheckedAt` が新しければ補正済みになる。

### 変更しないもの

- 保存キー
- 保存スキーマ
- `adjustmentStatus` のプロパティ名
- `field.source` 名
- プリンタ補正データの構造

---

## 旧ファイル: `docs/stage_addons_inventory.md`

## v38-25 Stage5〜8 Addon 棚卸し

### 目的

Stage5〜8 addon は、紙面位置合わせ印字システムを「封筒専用」から、はがき・ラベル・帳票追記・証明書・名札・席札等へ広げるための拡張層である。現時点では core からは独立しているが、DOM・Registry・保存キー・描画更新に接続するため、今後の分割や修正前に依存関係を固定しておく。

本版 v38-25 では、機能挙動は変更せず、addon層の構造検証と棚卸しを追加する。

### 読込順

classic script の順序読込を維持する。

```text
90_bootstrap.js
  ↓
50_stage5_addon.js
60_stage6_addon.js
70_stage7_addon.js
80_stage8_addon.js
  ↓
99_audit_marker.js
```

Stage addon は本体初期化後に登録される後付け拡張として扱う。ES Modules化はまだ行わない。

### Addon別の責務

| ファイル | 主責務 | 主な接続先 | 保存キー |
|---|---|---|---|
| `50_stage5_addon.js` | 差出人プロファイル、スタンプライブラリ、住所録補助、入力検証拡張 | `Step3ExtensionRegistry`, `InputValidationRegistry`, `EnvelopePrintModules.Extensions.Stage5` | `paper_position_print_system_v37_stage5_addons` |
| `60_stage6_addon.js` | 郵便番号辞書、住所補助、縦書き向け変換、ラベル開始位置補助 | `FieldSourceRegistry.registerPostProcessor`, `Step3ExtensionRegistry`, `Step5ExtensionRegistry` | `paper_position_print_system_v37_stage6` |
| `70_stage7_addon.js` | はがき裏面、帳票追記、証明書、名札等の汎用フィールド追加 | `FieldSourceRegistry`, `SampleDataRegistry`, `InputDataExtensionRegistry`, `Step3ExtensionRegistry`, `EnvelopePrintModules.Extensions.Stage7` | `paper_position_print_system_v37_stage7_addon` |
| `80_stage8_addon.js` | 実機検証記録、プリンタ調整ガイド、最終確認、印刷前hook | `Step5ExtensionRegistry`, `PrintExecutionRegistry`, `EnvelopePrintModules.Extensions.Stage8` | `paper_position_print_system_v37_stage8_validation` |

### 固定する境界

- addon の保存キーは変更しない。
- `field.source` 名は変更しない。
- `getFieldText()` を上書きしない。解決経路は Registry / postProcessor に寄せる。
- addon は本体関数を直接再定義しない。
- DOMContentLoaded / 即時初期化の既存挙動は維持する。
- Stage addon は、読み込み時点で本体の `Registry` 類と `renderStep*` が存在する前提にする。

### 現時点のリスク

1. **Stage5〜8がそれぞれ大きい**  
   1ファイル内にUI描画、保存、イベント接続、データ整形が混在している。次に分けるなら、Stage addon全体をいきなり崩さず、各Stage内で「storage」「field registration」「modal UI」を小分けする。

2. **DOM依存が強い**  
   自動テストは静的検証中心に留めている。実ブラウザでの導線確認は別途必要。

3. **Stage番号と機能名が一致しなくなりつつある**  
   封筒専用ではなく紙面印字汎用システムに拡張済みのため、将来的には `stage` より `extensions` / `assist` などの名前に寄せる余地がある。ただし、保存キーや読み込み順と混ぜて変更しない。

### 次の安全な改修候補

- Step1 テンプレート選択UIは v38-26 で `48_step1_template_ui.js` へ分離済み。
- 次候補は `48_steps_ui.js` から Step3 入力・キューUIを分離すること。
- `50_stage5_addon.js` 内の差出人プロファイル管理だけを小分けする。
- `80_stage8_addon.js` 内の実機検証記録ストアだけを小分けする。

優先度としては、coreの分離とStep1分離が完了した現在、次は Step3 入力・キューUI の依存棚卸しが自然である。

---

## 旧ファイル: `docs/step1_template_ui_inventory.md`

## v38-26 Step1 Template UI 棚卸し

### 目的

`js/48_steps_ui.js` の肥大化を抑えるため、Step1のテンプレート選択カード描画とテンプレート選択操作を `js/48_step1_template_ui.js` に分離した。

今回の分離は保守性改善のみを目的とし、保存キー・保存形式・`field.source` 名は変更しない。

### 分離対象

`js/48_step1_template_ui.js` が担当する関数は以下のとおり。

- `renderStep1()`
- `handleTplCardClick(tplId)`
- `showUnadjustedGuide(t, stat)`
- `duplicateTpl(id)`

### 残した責務

`js/48_steps_ui.js` には以下を残した。

- Step進行制御
- Step2詳細編集UI
- Step3宛先入力・キューUI
- Step4補正UI
- Step5本印刷プレビューUI

### 読込順

`js/47_print.js` → `js/48_step_navigation.js` → Step別UI群 → `js/49_wizard.js`

Step1 UIは `renderStep1()` を公開し、`48_steps_ui.js` の `goToStep(1)` から従来どおり呼び出される。

### 依存関係

Step1 UIは実行時に以下を参照する。

- `state`
- `getTpl()` / `getCurrentTpl()` 系
- `getTplAdjustmentSummary()`
- `save()`
- `renderSteps()`
- `goToStep()`
- `openWizard()`
- `showAppConfirm()`
- `toast()`
- `$()` / `escapeHtml()` / modal a11y helper

いずれも保存形式やデータ構造の変更を伴わないUI側依存である。

### 検証

`tests/step1_template_ui_unit_tests.js` で以下を確認する。

- Step1 UI APIが公開されていること
- `48_steps_ui.js` からStep1具体関数が除去されていること
- テンプレート0件時の描画契約
- テンプレート選択時の `selectedTplId` / `lastUsedTplId` 更新
- 複製時のID再採番、背景削除、調整状態リセット

`tools/verify_structure.js` では、読込順とREADME/manifest記載漏れを検出する。

### 次候補

次に切るなら、Step3宛先入力・キューUIを `js/48_step3_queue_ui.js` として分離するのが自然である。ただし、Stage6〜8の入力拡張hookと密接なため、先にStep3依存棚卸しを作るのが安全である。


### v38-30 追加契約

`bindEventsForStep1()` はStep1固定ボタンのイベント接続を担当します。

- `newTplCta`: 新規テンプレート作成ウィザード
- `newReplyCta`: 返信用テンプレート作成ウィザード
- `step1Next`: simple modeならStep3、advanced modeならStep2へ進む

`90_bootstrap.js` はこの関数を呼び出すだけにし、Step1固定ボタンの具体リスナーを直接持たない方針です。

---

## 旧ファイル: `docs/step2_edit_canvas_inventory.md`

## v38-23 Step2編集キャンバス棚卸し

### 目的

Step2詳細編集画面は、紙面上のfield配置、避ける範囲、背景画像、ズーム、選択状態、保存更新が交差するため、描画入口を不用意に移動するとドラッグや再描画が壊れやすい。

v38-23では、v38-20で分離済みだったmm換算・ドラッグ・避ける範囲作成に加え、描画入口 `renderEnvelope()` を `js/44_edit_canvas_controller.js` へ移した。

### Step2編集キャンバスの責務

| 責務 | 現在の配置 | 補足 |
|---|---|---|
| 編集キャンバス描画入口 | `js/44_edit_canvas_controller.js` | `renderEnvelope()` |
| 実描画 | `js/46_render_envelope.js` | `renderEnvelopeInto()` |
| field単体描画 | `js/45_render_fields.js` | `renderNormalField()` / `renderZipField()` |
| ドラッグ操作 | `js/44_edit_canvas_controller.js` | field/zone移動、zoneリサイズ |
| 避ける範囲作成 | `js/44_edit_canvas_controller.js` | `startAddZone()` / `startEnvelopeZoneDraft()` |
| 背景画像/PDF取込 | `js/43_background_assets.js` | 背景設定と圧縮 |
| Step2 UIパネル | `js/48_steps_ui.js` | field一覧、zone一覧、背景UI、zip設定 |
| イベント接続 | `js/90_bootstrap.js` | ボタン、入力、ズーム、背景取込 |
| 状態置き場 | `js/10_core.js` | `state` / `transientBg` は残置 |

### `renderEnvelope()` の依存

`renderEnvelope()` は次の実行時グローバルを参照する。

- `$()`
- `getCurrentTpl()`
- `getSampleData()`
- `renderEnvelopeInto()`
- `state.mode`
- `state.zoom`

この依存は、保存形式やデータ構造を変えずに関数位置だけを移す範囲に収まる。したがってv38-23では、state本体を移動せず、描画入口だけをEdit Canvas Controllerへ寄せた。

### 変更しないもの

- 保存キー
- 保存スキーマ
- field.source名
- `state` / `transientBg` の置き場
- `renderEnvelopeInto()` の描画契約
- 印刷時描画・補正処理

### 検証方針

- `tests/edit_canvas_controller_unit_tests.js` で `renderEnvelope()` の無選択時クリアと `renderEnvelopeInto()` 委譲オプションを検証する。
- `tools/verify_structure.js` で `10_core.js` に `renderEnvelope()` が残っていないこと、`44_edit_canvas_controller.js` が `renderEnvelope()` を定義・exportしていることを検証する。

### 次候補

`getTplAdjustmentSummary()` はv38-24で `js/53_adjustment_status.js` へ分離済み。背景調整、郵便番号確認、レイアウト確認、テスト印刷確認、プリンタ補正状態をまたぐため、Step2編集キャンバスではなく小さな状態判定モジュールとして扱う。

---

## 旧ファイル: `docs/step2_edit_ui_inventory.md`

## v38-36 Step2詳細編集UI 台帳

### 目的

`js/48_steps_ui.js` に最後まで残っていたStep2詳細編集UIと、`90_bootstrap.js` に残っていたStep2固定イベントを `js/48_step2_edit_ui.js` へ分離した状態を記録する。

### 分離した責務

- `renderStep2()`
  - 選択テンプレートの詳細編集画面を初期化する。
  - 基本情報、背景情報、field一覧、避ける範囲一覧、郵便番号詳細、編集キャンバス描画を呼び出す。
- `renderFieldList()`
  - field一覧、fieldプロパティ編集、anchor選択、削除確認を担当する。
- `renderZipConfig()`
  - 郵便番号fieldの詳細設定、〒記号、枠線、文字間隔、桁別位置調整を担当する。
- `renderZoneList()`
  - 避ける範囲一覧、位置・サイズ・ラベル編集、削除確認を担当する。
- `renderBgUI()`
  - 背景画像/PDF取込状態、保存/一時状態、背景バッジを担当する。
- `bindEventsForStep2()`
  - Step2戻る/次へ、基本情報、返信用切替、ロック、field追加、背景取込、背景調整、編集/プレビュー切替、ズーム、キャンバスクリック、避ける範囲作成handlerを担当する。

### 維持した契約

- 保存キー、保存形式、`field.source` 名は変更しない。
- `renderEnvelope()`、`save()`、`markLayoutChanged()`、`getCurrentTpl()` は実行時参照のまま維持する。
- field削除、避ける範囲削除では `showAppConfirm()` を使い、標準 `confirm()` は復活させない。
- field変更時は `markLayoutChanged(t)`、`renderEnvelope()`、`save()` を呼ぶ。
- 郵便番号source選択時は `zipConfig` を初期化する。
- `source === 'stamp'` 選択時は `customText` の既定値として `親展` を入れる。
- Step2自体の遷移制御は `js/48_step_navigation.js` が担当し、Step2画面内の固定イベント接続は `bindEventsForStep2()` が担当する。
- `90_bootstrap.js` は `bindEventsForStep2()` を呼ぶだけにし、Step2 DOM IDごとのリスナーを直接持たない。
- `48_steps_ui.js` はv38-38で完全退役済み。

### 読込順

`index.html` では以下の順序にする。

1. `js/48_step_navigation.js`
2. `js/48_step2_edit_ui.js`
3. `js/48_step1_template_ui.js`
4. `js/48_step3_input_core.js`
5. `js/48_steps_ui.js`
6. `js/10_core.js`

### 次候補

`js/48_steps_ui.js` は履歴マーカーになった。次の候補は、共通モード切替やHelp/Data Managementなど、`90_bootstrap.js` に残る非Step別イベントの整理。

---

## 旧ファイル: `docs/step3_input_core_inventory.md`

## v38-32 Step3 Input Core分離メモ

### 目的

`js/48_step3_input_core.js` は、Step3の全体描画、手入力フォーム、入力データ収集/復元/クリア、入力ペイン切替、Step3固定イベント接続を担当します。

v38-32時点では、キュー・住所録・履歴・Excel貼付取込は `js/48_step3_queue_ui.js` へ分離済みです。保存キー・保存形式・`field.source` 名・入力データキーは変更していません。

### 担当責務

- `renderStep3()`
  - Step3全体の見出し、返送テンプレート表示、各ペイン描画呼出し、件数バッジ、次へボタン状態、`Step3ExtensionRegistry.runRenderHooks()`
- `renderInputForm()`
  - 通常宛先フォーム、返送先フォーム、郵便番号整形、A11y適用
- `getInputData()`
  - 基本入力欄の収集、`normalizeAddressData()`、`InputDataExtensionRegistry.runCollectHooks()`
- `loadAddrToInput()`
  - 住所録・履歴データのフォーム復元、`InputDataExtensionRegistry.runLoadHooks()`
- `clearInput()`
  - 入力欄クリア、敬称初期化、`InputDataExtensionRegistry.runClearHooks()`
- `switchInputPane()`
  - 入力タブ切替、`applyInputTabsA11y()`、manual表示時の `Step3ExtensionRegistry.runManualPaneHooks()`
- `bindEventsForStep3()`
  - Step3戻る/次へ、入力タブ、キュー追加、住所録保存、入力クリア、住所録検索、キュー/履歴クリアの固定イベント接続

### 連携先

`renderStep3()` は以下を呼びます。

- `renderQueue()`
- `renderAddrbook()`
- `renderHistory()`
- `renderPasteImport()`

これらは `js/48_step3_queue_ui.js` が公開します。

### 読込順

```text
47_print.js
48_step1_template_ui.js
48_step3_input_core.js
48_step3_queue_ui.js
48_steps_ui.js
49_wizard.js
```

### v38-31以降のイベント契約

`90_bootstrap.js` はStep3固定イベントを直接持たず、`bindEventsForStep3()` を呼び出すだけにします。

### v38-32以降のキュー契約

`48_steps_ui.js` はStep3のキュー・住所録・履歴・Excel貼付取込関数を持ちません。これらは `48_step3_queue_ui.js` にあり、`EnvelopePrintModules.Step3Queue` からも確認できます。

---

## 旧ファイル: `docs/step3_input_queue_inventory.md`

## v38-32 Step3 Input / Queue UI 棚卸し

### 目的

Step3周辺を、手入力coreとキュー系UIに分けて保守しやすくするための現行台帳です。

v38-28でStep3手入力coreを `js/48_step3_input_core.js` へ分離し、v38-31でStep3固定イベント接続を同ファイルへ移しました。v38-32では、キュー・住所録・履歴・Excel貼付取込を `js/48_step3_queue_ui.js` へ分離しました。

保存キー・保存形式・`field.source` 名・入力データキーは変更していません。

### 現在の配置

#### `js/48_step3_input_core.js`

- `renderStep3()`
  - 返送テンプレートか通常テンプレートかで見出しを切替
  - `renderInputForm()` / `renderQueue()` / `renderAddrbook()` / `renderHistory()` / `renderPasteImport()` を呼び出す
  - 住所録件数・履歴件数・次へボタン状態を更新
  - `Step3ExtensionRegistry.runRenderHooks()` を最後に実行する
- `renderInputForm()`
- `getInputData()`
- `loadAddrToInput()`
- `clearInput()`
- `switchInputPane()`
- `bindEventsForStep3()`

#### `js/48_step3_queue_ui.js`

- `renderQueue()`
  - `state.queue` を表示
  - テンプレート不一致を `mismatch` 表示
  - 上下移動・削除後に `save()` / `renderQueue()` / `renderSteps()` を実行
- `cloneQueueItemFromRecord()`
  - 住所録・履歴からキューへ戻す際、拡張項目を落とさないためJSON深いコピーを使う
  - `id` / `printedAt` / `attemptedAt` / `historyKind` / `status` / `savedAt` など履歴・住所録側の管理項目だけを除去する
  - `tplId` は追加先テンプレートで上書きする
- `renderAddrbook()`
  - `state.addressBook` を検索・表示
  - 住所録から現テンプレートのキューへ追加
  - 住所録データを手入力フォームへ読込
  - DOMモーダル `showAppConfirm()` で削除確認
- `renderHistory()`
  - `state.history` の直近100件を表示
  - 元テンプレートまたは現テンプレートで再キュー追加
- `addToHistory()`
  - 印刷履歴を最大500件に制限する
- `renderPasteImport()` / `analyzePastedData()` / `renderPastePreview()` / `doImportPaste()`
  - Excel貼付テキストを解析
  - 郵便番号・住所・法人・部署・役職・氏名・敬称・連名・差出人項目を推定マッピング
  - `normalizeAddressData()` 後に空行判定し、companyのみの法人宛先を誤ってスキップしない

### 拡張hook契約

Stage6〜8 addonは、Step3周辺を直接上書きせず、Registry hook経由で合流させる方針です。

- `Step3ExtensionRegistry.runRenderHooks()`
- `Step3ExtensionRegistry.runManualPaneHooks()`
- `InputDataExtensionRegistry.runCollectHooks()`
- `InputDataExtensionRegistry.runLoadHooks()`
- `InputDataExtensionRegistry.runClearHooks()`

### 読込順

```text
47_print.js
48_step1_template_ui.js
48_step3_input_core.js
48_step3_queue_ui.js
48_steps_ui.js
49_wizard.js
```

`renderStep3()` は `48_step3_queue_ui.js` の関数を呼びますが、実行されるのは全スクリプト読込後の画面遷移時です。そのため、input core → queue UI → remaining steps UI の順で安全に読み込めます。

### 分離時の注意点

- `cloneQueueItemFromRecord()` は拡張項目を保持するため、限定コピーへ戻さない。
- `getInputData()` / `loadAddrToInput()` / `clearInput()` のRegistry hookを消さない。
- Excel貼付取込のfield mapは住所録・差出人・連名・法人宛先の互換性に関わるため、分離と同時に変更しない。
- `state.queue` / `state.addressBook` / `state.history` の保存形式を変更しない。
- `step3Next` のdisabled更新と `renderSteps()` 呼び出しは、キュー件数表示だけでなくStep進行制御にも影響する。

---

## 旧ファイル: `docs/step4_step5_ui_inventory.md`

## v38-33 Step4 / Step5 UI Inventory

### 目的

Step4テスト印刷・プリンタ補正UIとStep5本印刷プレビューUIを `48_steps_ui.js` から分離し、`90_bootstrap.js` に残っていた固定イベント接続も各Step側へ移した。

v38-33では保存キー、保存形式、`field.source` 名、印刷実行本体は変更しない。

### 分離後の担当

#### `js/48_step4_test_print_ui.js`

- `renderStep4()`
- `renderPrinterProfileSection()`
- `updateStep4Summary()`
- `bindEventsForStep4()`

担当範囲は、キュー整合確認、テスト印刷導線、クロス印刷、テスト印刷結果確認チェック、プリンタ補正表示である。

#### `js/48_step5_final_print_ui.js`

- `renderStep5()`
- `bindEventsForStep5()`

担当範囲は、最終確認、印刷プレビュー、本印刷前UI、Step5拡張hook、最初へ戻る導線である。

### 維持した契約

- `renderStep4()` は `getTplAdjustmentSummary()` によるテスト印刷確認状態を維持する。
- `markTestPrinted` は実印刷成功ではなく、ユーザがテスト印刷結果を確認した時刻として `adjustmentStatus.testPrintedAt` を更新する。
- Step4のテスト印刷は `doPrint()` を呼び出すだけで、印刷実行本体には触れない。
- Step5は `renderFinalChecklist()`、`renderPrintActionArea()`、`Step5ExtensionRegistry.runRenderHooks()` を維持する。
- ラベル面付けプレビューの `labelStartIndex` 反映を維持する。
- `90_bootstrap.js` は `bindEventsForStep4()` / `bindEventsForStep5()` を呼ぶだけにする。

### 検証

- `tests/step4_step5_ui_unit_tests.js` で関数配置、固定イベント委譲、公開API、読込順を静的検証する。
- `tools/verify_structure.js` でも `48_steps_ui.js` への残存定義、bootstrap直書きリスナー、公開APIを検出する。
