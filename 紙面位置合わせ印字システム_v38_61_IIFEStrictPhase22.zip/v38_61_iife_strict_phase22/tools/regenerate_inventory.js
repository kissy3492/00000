#!/usr/bin/env node
/* v38-39: regenerate core residual inventory from current split source.
   This script is documentation automation only. It never changes storage keys,
   storage schema, or field.source names. */
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
function read(p){ return fs.readFileSync(path.join(root, p), 'utf8'); }
function write(p, text){ fs.writeFileSync(path.join(root, p), text, 'utf8'); }

const manifest = JSON.parse(read('split_manifest.json'));
const releaseId = ((manifest.version || '').match(/v\d+-\d+/) || ['v38-38'])[0];
const core = read('js/10_core.js');
const jsFiles = fs.readdirSync(path.join(root, 'js')).filter(f => f.endsWith('.js')).sort();
const functionRegex = /\b(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(/g;
function functionsOf(relPath){
  const src = read(relPath);
  return Array.from(src.matchAll(functionRegex)).map(m => m[1]);
}
const coreFunctions = functionsOf('js/10_core.js');
const splitModules = jsFiles
  .filter(f => f !== '10_core.js')
  .map(f => ({ file:`js/${f}`, functions:functionsOf(`js/${f}`) }));

const lines = [];
lines.push(`# ${releaseId} Core残存責務台帳`);
lines.push('');
lines.push('> このファイルは `tools/regenerate_inventory.js` で生成します。手作業で長期運用メモを継ぎ足さず、現行ソースから再生成してください。');
lines.push('');
lines.push('## `10_core.js` の現況');
lines.push('');
lines.push(`- 行数: ${core.split(/\r?\n/).length}`);
lines.push(`- 通常関数定義数: ${coreFunctions.length}`);
lines.push(`- 通常関数一覧: ${coreFunctions.length ? coreFunctions.map(n => `\`${n}\``).join(', ') : 'なし'}`);
lines.push('- 残す責務: アプリ定数、保存キー、`state` / `transientBg`、公開モジュール索引、v38方針メモ');
lines.push('- 分離しないもの: 保存キー、保存形式、`field.source` 名');
lines.push('');
lines.push('## 分離済みJSファイルと関数定義数');
lines.push('');
lines.push('| ファイル | 関数定義数 | 主な関数 |');
lines.push('|---|---:|---|');
for(const mod of splitModules){
  const shown = mod.functions.slice(0, 8).map(n => `\`${n}\``).join(', ');
  const suffix = mod.functions.length > 8 ? ' ほか' : '';
  lines.push(`| ${mod.file} | ${mod.functions.length} | ${shown || '-'}${suffix} |`);
}
lines.push('');
lines.push('## 退役済みファイル');
lines.push('');
lines.push('- `js/48_steps_ui.js` — v38-38で履歴マーカーから完全退役。Step1〜5、Step進行、共通イベントは各専用ファイルへ分離済み。');
lines.push('');
lines.push('## 次の監視対象');
lines.push('');
lines.push('- `js/10_core.js` は通常関数0件を維持する。');
lines.push('- `js/90_bootstrap.js` は起動順序と委譲だけを担当し、具体DOMイベントを増やさない。');
lines.push('- 過去の個別棚卸しメモは `docs/refactor_inventory_archive.md` に統合済み。最新性は本ファイルと `tools/verify_structure.js` を優先する。');
lines.push('');
write('docs/core_residual_inventory.md', lines.join('\n'));
console.log(`Regenerated docs/core_residual_inventory.md for ${releaseId}`);
