#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tools/check_syntax.sh
node tests/address_data_unit_tests.js
node tests/background_assets_unit_tests.js
node tests/parts_actions_unit_tests.js
node tests/edit_canvas_controller_unit_tests.js
node tests/step_navigation_unit_tests.js
node tests/step2_edit_ui_unit_tests.js
node tests/step1_template_ui_unit_tests.js
node tests/step3_input_core_unit_tests.js
node tests/step3_input_queue_inventory_tests.js
node tests/step4_step5_ui_unit_tests.js
node tests/data_management_ui_unit_tests.js
node tests/common_ui_binder_unit_tests.js
node tests/adjustment_status_unit_tests.js
node tests/bootstrap_unit_tests.js
node tests/stage_addons_unit_tests.js
node tests/retired_steps_ui_unit_tests.js
node tests/docs_inventory_consolidation_tests.js
node tests/iife_strict_phase1_tests.js
node tests/iife_strict_phase2_tests.js
node tests/iife_strict_phase3_tests.js
node tests/iife_strict_phase4_tests.js
node tests/iife_strict_phase5_tests.js
node tests/iife_strict_phase6_tests.js
node tests/iife_strict_phase7_tests.js
node tests/iife_strict_phase8_tests.js
node tests/iife_strict_phase9_tests.js
node tests/iife_strict_phase10_tests.js
node tests/iife_strict_phase11_tests.js
node tests/iife_strict_phase12_tests.js
node tests/iife_strict_phase13_tests.js
node tests/iife_strict_phase14_tests.js
node tests/iife_strict_phase15_tests.js
node tests/iife_strict_phase16_tests.js
node tests/iife_strict_phase17_tests.js
node tests/iife_strict_phase18_tests.js
node tests/iife_strict_phase19_tests.js
node tests/iife_strict_phase20_tests.js
node tests/iife_strict_phase21_tests.js
node tests/iife_strict_phase22_tests.js
node tests/version_sync_unit_tests.js
node tools/verify_structure.js
echo "VERIFY OK"
