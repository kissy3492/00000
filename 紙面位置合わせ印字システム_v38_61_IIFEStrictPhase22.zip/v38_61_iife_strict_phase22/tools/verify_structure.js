#!/usr/bin/env node
/* v38-42: 分割版の構造整合性チェック。構文だけでは検出できないREADME/manifest/読込順/版数同期/イベント分離/退役ファイルのズレを検出する。 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.resolve(__dirname, '..');
function read(p){ return fs.readFileSync(path.join(root, p), 'utf8'); }
function exists(p){ return fs.existsSync(path.join(root, p)); }
function sha256(p){ return crypto.createHash('sha256').update(fs.readFileSync(path.join(root, p))).digest('hex'); }
function fail(msg){ throw new Error(msg); }

const manifest = JSON.parse(read('split_manifest.json'));
if(manifest.mainline !== 'split') fail('split_manifest.json mainline must be split');
for(const item of manifest.files || []){
  if(!exists(item.path)) fail(`manifest file missing: ${item.path}`);
  if(item.path !== 'split_manifest.json' && item.sha256 && item.sha256 !== sha256(item.path)){
    fail(`sha256 mismatch in manifest: ${item.path}`);
  }
}

const index = read('index.html');
const manifestVersion = manifest.version || '';
const manifestReleaseId = (manifestVersion.match(/v\d+-\d+/) || [])[0];
if(!manifestReleaseId) fail('split_manifest.json version must include release id such as v38-29');
const manifestApiVersion = manifestVersion.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const readmeForVersion = read('README.md');
const coreForVersion = read('js/10_core.js');
if(!readmeForVersion.startsWith(`# 紙面位置合わせ印字システム ${manifestReleaseId} `)) fail('README H1 release id must match split_manifest.json version');
if(!index.includes(`<title>紙面位置合わせ印字システム ${manifestReleaseId} `)) fail('index title release id must match split_manifest.json version');
if(!index.includes(`<span class="logo-sub">${manifestVersion} / storage v37</span>`)) fail('visible logo-sub must match split_manifest.json version');
if(!coreForVersion.includes(`const APP_RELEASE_LABEL = '${manifestVersion}';`)) fail('APP_RELEASE_LABEL must match split_manifest.json version');
if(!coreForVersion.includes(`const APP_MODULE_API_VERSION = '${manifestApiVersion}';`)) fail('APP_MODULE_API_VERSION must be slugified split_manifest.json version');
for(let n=25; n<=Number(manifestReleaseId.split('-')[1]); n++){
  if(!coreForVersion.includes(`{step:'v38-${n}'`)) fail(`APP_RELEASE_NOTES missing v38-${n}`);
}
if(!exists('tools/sync_version.js')) fail('tools/sync_version.js missing');

function assertIifeStrictSource(file){
  const src = read(file);
  if(!/^\(function(?:\s*\([^)]*\))?\s*\{/.test(src)) fail(`${file} must start with an IIFE`);
  if(!/[\'\"]use strict[\'\"]\s*;/.test(src.slice(0, 180))) fail(`${file} must enable strict mode near the top`);
}
for(const file of ['js/00_pdf_loader.js','js/05_utilities.js','js/15_address_data.js','js/20_registries.js','js/30_storage.js','js/40_templates.js','js/42_layout_math.js','js/43_background_assets.js','js/44_edit_canvas_controller.js','js/45_render_fields.js','js/46_render_envelope.js','js/47_print.js','js/48_step_navigation.js','js/48_step1_template_ui.js','js/48_step2_edit_ui.js','js/48_step3_input_core.js','js/48_step3_queue_ui.js','js/48_step4_test_print_ui.js','js/48_step5_final_print_ui.js','js/49_wizard.js','js/52_data_management_ui.js','js/53_adjustment_status.js','js/54_common_ui_binder.js','js/90_bootstrap.js','js/99_audit_marker.js']){
  assertIifeStrictSource(file);
}

const dataManagementUiForScope = read('js/52_data_management_ui.js');
if(!/Object\.assign\(global,[\s\S]*showHelp[\s\S]*showDataMgmt[\s\S]*getModuleOverview[\s\S]*EnvelopePrintDataManagementUI/.test(dataManagementUiForScope)) fail('data management UI must preserve global exports after IIFE conversion');
if(!/const\s+DataManagementUiApi\s*=\s*Object\.freeze\(\{[\s\S]*showHelp[\s\S]*showDataMgmt[\s\S]*getModuleOverview/.test(dataManagementUiForScope)) fail('data management UI must define DataManagementUiApi');
if(!/EnvelopePrintDataManagementUI:\s*DataManagementUiApi/.test(dataManagementUiForScope)) fail('data management UI must expose EnvelopePrintDataManagementUI');
if(!/DataManagementUI:EnvelopePrintDataManagementUI/.test(coreForVersion)) fail('EnvelopePrintModules must expose Data Management UI API');
if(!/DataManagementUI:\['EnvelopePrintDataManagementUI','showHelp','showDataMgmt','getModuleOverview'\]/.test(dataManagementUiForScope)) fail('getModuleOverview must expose Data Management UI API');


const storageCoreForScope = read('js/30_storage.js');
if(!/Object\.assign\(global,[\s\S]*dataSnapshot[\s\S]*restoreFullBackupSafely[\s\S]*updateStorageStatus[\s\S]*EnvelopePrintStorageCore/.test(storageCoreForScope)) fail('storage core must preserve global exports after IIFE conversion');
if(!/const\s+StorageCoreApi\s*=\s*Object\.freeze\(\{[\s\S]*dataSnapshot[\s\S]*dataSnapshotForBackup[\s\S]*restoreFullBackupSafely[\s\S]*updateStorageStatus/.test(storageCoreForScope)) fail('storage core must define StorageCoreApi');
if(!/EnvelopePrintStorageCore:\s*StorageCoreApi/.test(storageCoreForScope)) fail('storage core must expose EnvelopePrintStorageCore');
if(!/global\.addEventListener\('beforeunload'/.test(storageCoreForScope)) fail('storage core must preserve beforeunload protection with global event registration');
if(!/StorageCore:EnvelopePrintStorageCore/.test(coreForVersion)) fail('EnvelopePrintModules must expose Storage Core API');
if(!/StorageCore:\['EnvelopePrintStorageCore','dataSnapshot','dataSnapshotForBackup','save','backupNow','restoreFullBackupSafely','load','getStorageUsage','getBackups','clearAddonStorage','removeObsoleteStorageKeys','retrySaveAfterObsoleteKeyCleanup','sanitizeSnapshotForLoad','sanitizeSnapshotForRestore'\]/.test(dataManagementUiForScope)) fail('getModuleOverview must expose Storage Core API');

const utilitiesForScope = read('js/05_utilities.js');
if(!/Object\.assign\(global,[\s\S]*uid[\s\S]*toast[\s\S]*showAppConfirm[\s\S]*copyTextToClipboard/.test(utilitiesForScope)) fail('utilities must preserve global function exports after IIFE conversion');
if(!/global\.EnvelopePrintUtilities\s*=\s*UtilitiesApi/.test(utilitiesForScope)) fail('utilities must expose EnvelopePrintUtilities');
if(!/Utilities:EnvelopePrintUtilities/.test(coreForVersion)) fail('EnvelopePrintModules must expose Utilities API');
if(!/Utilities:\['EnvelopePrintUtilities','\$','uid','toast','announceA11y','escapeHtml','formatBytes','fmtDate','showAppAlert','showAppConfirm','showAppPrompt','copyTextToClipboard','applyScreenA11y','applyLegacyModalA11y','closeAccessibleModal'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Utilities API');

const addressDataForScope = read('js/15_address_data.js');
if(!/Object\.assign\(global,[\s\S]*joinLines[\s\S]*normalizeAddressData[\s\S]*getFieldText[\s\S]*EnvelopePrintAddressData/.test(addressDataForScope)) fail('address data must preserve global function exports after IIFE conversion');
if(!/const\s+AddressDataApi\s*=\s*Object\.freeze\(\{[\s\S]*joinLines[\s\S]*getFieldText[\s\S]*getSampleData/.test(addressDataForScope)) fail('address data must define AddressDataApi');
if(!/EnvelopePrintAddressData:\s*AddressDataApi/.test(addressDataForScope)) fail('address data must expose EnvelopePrintAddressData');
if(!/AddressData:EnvelopePrintAddressData/.test(coreForVersion)) fail('EnvelopePrintModules must expose Address Data Formatter API');
if(!/AddressData:\['EnvelopePrintAddressData','joinLines','buildOrgText','buildOrgFullText','buildNameWithHonor','buildSenderText','normalizeAddressData','defaultDataForTemplate','getFieldText','getSampleData'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Address Data Formatter API');

const layoutMathForScope = read('js/42_layout_math.js');
if(!/Object\.assign\(global,[\s\S]*overlap[\s\S]*adjustFieldRect[\s\S]*fitText/.test(layoutMathForScope)) fail('layout math must preserve global function exports after IIFE conversion');
if(!/global\.EnvelopePrintLayoutMath\s*=\s*Object\.freeze/.test(layoutMathForScope)) fail('layout math must expose EnvelopePrintLayoutMath');
if(/global\.MIN_FONT_PT/.test(layoutMathForScope)) fail('MIN_FONT_PT must remain private in layout math');

const renderFieldsForScope = read('js/45_render_fields.js');
if(!/Object\.assign\(global,[\s\S]*renderNormalField[\s\S]*renderZipField/.test(renderFieldsForScope)) fail('field renderer must preserve global function exports after IIFE conversion');
if(!/global\.EnvelopePrintFieldRenderer\s*=\s*Object\.freeze/.test(renderFieldsForScope)) fail('field renderer must expose EnvelopePrintFieldRenderer');
const envelopeRenderForScope = read('js/46_render_envelope.js');
if(!/Object\.assign\(global,[\s\S]*renderEnvelopeInto[\s\S]*buildPrintStack/.test(envelopeRenderForScope)) fail('envelope renderer must preserve global function exports after IIFE conversion');
if(!/global\.EnvelopePrintEnvelopeRenderer\s*=\s*Object\.freeze/.test(envelopeRenderForScope)) fail('envelope renderer must expose EnvelopePrintEnvelopeRenderer');
const printControlForScope = read('js/47_print.js');
if(!/Object\.assign\(global,[\s\S]*addPrintAttempt[\s\S]*doPrint/.test(printControlForScope)) fail('print control must preserve global function exports after IIFE conversion');
if(!/global\.EnvelopePrintControl\s*=\s*Object\.freeze/.test(printControlForScope)) fail('print control must expose EnvelopePrintControl');

const templateModelForScope = read('js/40_templates.js');
if(!/Object\.assign\(global,[\s\S]*ENVELOPE_SIZES[\s\S]*normalizeTpl[\s\S]*buildReplyFields/.test(templateModelForScope)) fail('template model must preserve global exports after IIFE conversion');
if(!/global\.EnvelopePrintTemplateModel\s*=\s*TemplateModelApi/.test(templateModelForScope)) fail('template model must expose EnvelopePrintTemplateModel');
if(!/Template:\{ENVELOPE_SIZES, normalizeTpl, markLayoutChanged, defaultLabelConfig, getLabelConfig, labelCapacity, getEffectivePrintPageCount, buildExcludeZonesForPreset, initialTemplates, buildFieldsForPreset, buildFieldsForSize\}/.test(coreForVersion)) fail('EnvelopePrintModules must expose Template Model API');
if(!/Template:\['ENVELOPE_SIZES','normalizeTpl','markLayoutChanged','defaultLabelConfig','getLabelConfig','labelCapacity','getEffectivePrintPageCount','buildExcludeZonesForPreset','initialTemplates','buildFieldsForPreset','buildFieldsForSize'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Template Model API');

const registryCoreForScope = read('js/20_registries.js');
if(!/Object\.assign\(global,[\s\S]*FieldSourceRegistry[\s\S]*registerBuiltinSampleData/.test(registryCoreForScope)) fail('registry core must preserve global exports after IIFE conversion');
if(!/global\.EnvelopePrintRegistryCore\s*=\s*RegistryCoreApi/.test(registryCoreForScope)) fail('registry core must expose EnvelopePrintRegistryCore');
if(!/RegistryCore:EnvelopePrintRegistryCore/.test(coreForVersion)) fail('EnvelopePrintModules must expose RegistryCore API');
if(!/RegistryCore:\['FieldSourceRegistry','Step3ExtensionRegistry','Step5ExtensionRegistry','PrintExecutionRegistry','InputValidationRegistry','InputDataExtensionRegistry','SampleDataRegistry'/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose RegistryCore APIs');

const wizardForScope = read('js/49_wizard.js');
if(!/Object\.defineProperty\(global,\s*'wizardState',[\s\S]*get\(\)\{ return wizardState; \}[\s\S]*set\(value\)\{ wizardState = value; \}/.test(wizardForScope)) fail('wizard must preserve wizardState compatibility accessor after IIFE conversion');
if(!/Object\.assign\(global,[\s\S]*openWizard[\s\S]*closeWizard[\s\S]*renderWizard[\s\S]*wizardNext[\s\S]*commitWizardDraft/.test(wizardForScope)) fail('wizard must preserve global function exports after IIFE conversion');
if(!/global\.EnvelopePrintWizard\s*=\s*Object\.freeze/.test(wizardForScope)) fail('wizard must expose EnvelopePrintWizard');
if(!/Wizard:EnvelopePrintWizard/.test(coreForVersion)) fail('EnvelopePrintModules must expose Wizard Controller API');
if(!/Wizard:\['EnvelopePrintWizard','openWizard','renderWizard','wizardNext','closeWizard','commitWizardDraft'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Wizard Controller APIs');

const legacyInventoryDocs = [
  'docs/adjustment_status_inventory.md',
  'docs/stage_addons_inventory.md',
  'docs/step1_template_ui_inventory.md',
  'docs/step2_edit_canvas_inventory.md',
  'docs/step2_edit_ui_inventory.md',
  'docs/step3_input_core_inventory.md',
  'docs/step3_input_queue_inventory.md',
  'docs/step4_step5_ui_inventory.md'
];
if(!exists('docs/refactor_inventory_archive.md')) fail('docs/refactor_inventory_archive.md missing');
for(const doc of legacyInventoryDocs){
  if(exists(doc)) fail(`legacy inventory doc must be consolidated: ${doc}`);
}
const refactorInventoryArchive = read('docs/refactor_inventory_archive.md');
for(const doc of legacyInventoryDocs){
  if(!refactorInventoryArchive.includes(`旧ファイル: \`${doc}\``)) fail(`refactor inventory archive missing original section: ${doc}`);
}

const scriptOrder = Array.from(index.matchAll(/<script[^>]+src="([^"]+)"/g)).map(m=>m[1]);
const pos = name => scriptOrder.indexOf(name);
['js/06_keyboard_overlay.js','js/15_address_data.js','js/20_registries.js','js/30_storage.js','js/40_templates.js','js/41_parts_actions.js','js/42_layout_math.js','js/43_background_assets.js','js/44_edit_canvas_controller.js','js/45_render_fields.js','js/46_render_envelope.js','js/47_print.js','js/48_step_navigation.js','js/48_step2_edit_ui.js','js/48_step1_template_ui.js','js/48_step3_input_core.js','js/48_step3_queue_ui.js','js/48_step4_test_print_ui.js','js/48_step5_final_print_ui.js','js/49_wizard.js','js/30_storage.js','js/52_data_management_ui.js','js/53_adjustment_status.js','js/54_common_ui_binder.js','js/10_core.js','js/90_bootstrap.js'].forEach(name=>{
  if(pos(name) < 0) fail(`script not loaded: ${name}`);
});
if(!(pos('js/06_keyboard_overlay.js') < pos('js/10_core.js'))) fail('keyboard_overlay must load before core bootstrap');
if(!(pos('js/15_address_data.js') < pos('js/20_registries.js'))) fail('address_data must load before registries');
if(!(pos('js/40_templates.js') < pos('js/30_storage.js'))) fail('templates must load before storage');
if(!(pos('js/40_templates.js') < pos('js/41_parts_actions.js'))) fail('templates must load before parts actions');
if(!(pos('js/41_parts_actions.js') < pos('js/42_layout_math.js'))) fail('parts actions must load before layout math');
if(!(pos('js/42_layout_math.js') < pos('js/43_background_assets.js'))) fail('layout math must load before background assets');
if(!(pos('js/43_background_assets.js') < pos('js/49_wizard.js'))) fail('background assets must load before wizard');
if(!(pos('js/47_print.js') < pos('js/48_step_navigation.js'))) fail('print must load before step navigation');
if(!(pos('js/48_step_navigation.js') < pos('js/48_step2_edit_ui.js'))) fail('step navigation must load before step2 edit UI');
if(!(pos('js/48_step2_edit_ui.js') < pos('js/48_step1_template_ui.js'))) fail('step2 edit UI must load before step1 template UI');
if(!(pos('js/48_step1_template_ui.js') < pos('js/48_step3_input_core.js'))) fail('step1 template UI must load before step3 input core');
if(!(pos('js/48_step3_input_core.js') < pos('js/48_step3_queue_ui.js'))) fail('step3 input core must load before step3 queue UI');
if(!(pos('js/48_step3_queue_ui.js') < pos('js/48_step4_test_print_ui.js'))) fail('step3 queue UI must load before step4 test print UI');
if(!(pos('js/48_step4_test_print_ui.js') < pos('js/48_step5_final_print_ui.js'))) fail('step4 test print UI must load before step5 final print UI');
if(!(pos('js/48_step_navigation.js') < pos('js/10_core.js'))) fail('step navigation must load before core bootstrap');
if(!(pos('js/48_step2_edit_ui.js') < pos('js/10_core.js'))) fail('step2 edit UI must load before core bootstrap');
if(!(pos('js/48_step1_template_ui.js') < pos('js/10_core.js'))) fail('step1 template UI must load before core bootstrap');
if(!(pos('js/48_step3_input_core.js') < pos('js/10_core.js'))) fail('step3 input core must load before core bootstrap');
if(!(pos('js/48_step3_queue_ui.js') < pos('js/10_core.js'))) fail('step3 queue UI must load before core bootstrap');
if(!(pos('js/48_step4_test_print_ui.js') < pos('js/10_core.js'))) fail('step4 test print UI must load before core bootstrap');
if(!(pos('js/48_step5_final_print_ui.js') < pos('js/10_core.js'))) fail('step5 final print UI must load before core bootstrap');
if(!(pos('js/43_background_assets.js') < pos('js/44_edit_canvas_controller.js'))) fail('background assets must load before edit canvas controller');
if(!(pos('js/44_edit_canvas_controller.js') < pos('js/45_render_fields.js'))) fail('edit canvas controller must load before field render');
if(!(pos('js/44_edit_canvas_controller.js') < pos('js/10_core.js'))) fail('edit canvas controller must load before core bootstrap');
if(!(pos('js/41_parts_actions.js') < pos('js/10_core.js'))) fail('parts actions must load before core bootstrap');
if(!(pos('js/43_background_assets.js') < pos('js/10_core.js'))) fail('background assets must load before core bootstrap');
if(!(pos('js/30_storage.js') < pos('js/52_data_management_ui.js'))) fail('storage must load before data management UI');
if(!(pos('js/52_data_management_ui.js') < pos('js/53_adjustment_status.js'))) fail('data management UI must load before adjustment status');
if(!(pos('js/53_adjustment_status.js') < pos('js/54_common_ui_binder.js'))) fail('adjustment status must load before common UI binder');
if(!(pos('js/54_common_ui_binder.js') < pos('js/10_core.js'))) fail('common UI binder must load before core module index');
if(!(pos('js/53_adjustment_status.js') < pos('js/10_core.js'))) fail('adjustment status must load before core bootstrap');
if(!(pos('js/52_data_management_ui.js') < pos('js/10_core.js'))) fail('data management UI must load before core bootstrap');
if(!(pos('js/30_storage.js') < pos('js/10_core.js'))) fail('storage must load before core bootstrap');
if(!(pos('js/10_core.js') < pos('js/90_bootstrap.js'))) fail('core must load before bootstrap');
if(!(pos('js/52_data_management_ui.js') < pos('js/90_bootstrap.js'))) fail('data management UI must load before bootstrap');
if(!(pos('js/53_adjustment_status.js') < pos('js/90_bootstrap.js'))) fail('adjustment status must load before bootstrap');
if(!(pos('js/54_common_ui_binder.js') < pos('js/90_bootstrap.js'))) fail('common UI binder must load before bootstrap');
for(const name of ['js/50_stage5_addon.js','js/60_stage6_addon.js','js/70_stage7_addon.js','js/80_stage8_addon.js','js/99_audit_marker.js']){
  if(pos(name) < 0) fail(`script not loaded: ${name}`);
}
if(!(pos('js/90_bootstrap.js') < pos('js/50_stage5_addon.js'))) fail('bootstrap must run before stage addons to preserve existing init order');
if(!(pos('js/50_stage5_addon.js') < pos('js/60_stage6_addon.js'))) fail('Stage5 addon must load before Stage6 addon');
if(!(pos('js/60_stage6_addon.js') < pos('js/70_stage7_addon.js'))) fail('Stage6 addon must load before Stage7 addon');
if(!(pos('js/70_stage7_addon.js') < pos('js/80_stage8_addon.js'))) fail('Stage7 addon must load before Stage8 addon');
if(!(pos('js/80_stage8_addon.js') < pos('js/99_audit_marker.js'))) fail('Stage8 addon must load before audit marker');

const readme = read('README.md');
function readmeHasTreeEntry(folder, file){
  return readme.includes(`${folder}/`) && readme.includes(`  ${file}`);
}
for(const file of fs.readdirSync(path.join(root, 'js')).filter(f=>f.endsWith('.js'))){
  if(!readmeHasTreeEntry('js', file)) fail(`README file list missing: js/${file}`);
}
for(const file of fs.readdirSync(path.join(root, 'tests')).filter(f=>/\.(js|html|md)$/.test(f))){
  if(!readmeHasTreeEntry('tests', file)) fail(`README file list missing: tests/${file}`);
}

for(const file of fs.readdirSync(path.join(root, 'docs')).filter(f=>/\.md$/.test(f))){
  if(!readmeHasTreeEntry('docs', file)) fail(`README file list missing: docs/${file}`);
}
for(const file of fs.readdirSync(path.join(root, 'tools')).filter(f=>/\.(js|sh)$/.test(f))){
  if(!readmeHasTreeEntry('tools', file)) fail(`README file list missing: tools/${file}`);
}


const core = read('js/10_core.js');
if(exists('js/48_steps_ui.js')) fail('js/48_steps_ui.js must remain retired after v38-38');
if(index.includes('js/48_steps_ui.js')) fail('index.html must not load retired js/48_steps_ui.js');
if((manifest.files || []).some(item => item.path === 'js/48_steps_ui.js')) fail('split_manifest.json must not list retired js/48_steps_ui.js');
const stepsUi = '';
const stepNavigation = read('js/48_step_navigation.js');
const step2Ui = read('js/48_step2_edit_ui.js');
const step1Ui = read('js/48_step1_template_ui.js');
const commonUiBinder = read('js/54_common_ui_binder.js');
const stepNavigationFns = ['getActiveSteps','stepIndex','renderSteps','getStepStatus','canSkipTo','canGoToStep','goToStep'];
for(const fn of stepNavigationFns){
  if(!new RegExp('function\\s+' + fn + '\\s*\\(').test(stepNavigation)) fail(`step navigation function missing: ${fn}`);
  if(new RegExp('function\\s+' + fn + '\\s*\\(').test(stepsUi)) fail(`steps UI still defines step navigation function: ${fn}`);
}
if(!/const\s+StepNavigationApi\s*=\s*Object\.freeze\(\{[\s\S]*getActiveSteps[\s\S]*goToStep/.test(stepNavigation)) fail('step navigation must define frozen StepNavigationApi');
if(!/Object\.assign\(global,\s*\{[\s\S]*getActiveSteps[\s\S]*goToStep[\s\S]*EnvelopePrintStepNavigation/.test(stepNavigation)) fail('step navigation export block missing');
if(!/EnvelopePrintStepNavigation:\s*StepNavigationApi/.test(stepNavigation)) fail('step navigation must expose EnvelopePrintStepNavigation API');
if(!/StepNavigation:EnvelopePrintStepNavigation/.test(core)) fail('EnvelopePrintModules must expose StepNavigation API');
if(!/StepNavigation:\['EnvelopePrintStepNavigation','getActiveSteps','stepIndex','renderSteps','getStepStatus','canSkipTo','canGoToStep','goToStep'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose StepNavigation API');

const step2Fns = ['renderStep2','renderFieldList','renderZipConfig','renderZoneList','renderBgUI','bindEventsForStep2'];
for(const fn of step2Fns){
  if(!new RegExp('function\\s+' + fn + '\\s*\\(').test(step2Ui)) fail(`Step2 edit UI function missing: ${fn}`);
  if(new RegExp('function\\s+' + fn + '\\s*\\(').test(stepsUi)) fail(`steps UI still defines Step2 edit UI function: ${fn}`);
}
if(!/const\s+Step2EditUiApi\s*=\s*Object\.freeze\(\{[\s\S]*renderStep2[\s\S]*bindEventsForStep2/.test(step2Ui)) fail('step2 edit UI must define frozen Step2EditUiApi');
if(!/Object\.assign\(global,\s*\{[\s\S]*renderStep2[\s\S]*renderBgUI[\s\S]*bindEventsForStep2[\s\S]*EnvelopePrintStep2EditUI/.test(step2Ui)) fail('step2 edit UI export block missing');
if(!/EnvelopePrintStep2EditUI:\s*Step2EditUiApi/.test(step2Ui)) fail('step2 edit UI must expose EnvelopePrintStep2EditUI API');
if(!/Step2Edit:EnvelopePrintStep2EditUI/.test(core)) fail('EnvelopePrintModules must expose Step2Edit API');
if(!/Step2Edit:\['EnvelopePrintStep2EditUI','renderStep2','renderFieldList','renderZipConfig','renderZoneList','renderBgUI','bindEventsForStep2'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Step2Edit API');

for(const fn of ['renderStep1','handleTplCardClick','showUnadjustedGuide','duplicateTpl']){
  if(new RegExp('function\\s+' + fn + '\\s*\\(').test(stepsUi)) fail(`steps UI still defines Step1 function: ${fn}`);
}
if(!/function\s+bindEventsForStep1\s*\(/.test(step1Ui)) fail('step1 template UI module must define bindEventsForStep1');
if(!/function\s+renderStep1\s*\(/.test(step1Ui)) fail('step1 template UI module must define renderStep1');
if(!/const\s+Step1TemplateUiApi\s*=\s*Object\.freeze\(\{[\s\S]*bindEventsForStep1[\s\S]*duplicateTpl/.test(step1Ui)) fail('step1 template UI module must define frozen Step1TemplateUiApi');
if(!/Object\.assign\(global,\s*\{[\s\S]*bindEventsForStep1[\s\S]*duplicateTpl[\s\S]*EnvelopePrintStep1TemplateUI/.test(step1Ui)) fail('step1 template UI module must preserve legacy exports and explicit API');
if(!/EnvelopePrintStep1TemplateUI:\s*Step1TemplateUiApi/.test(step1Ui)) fail('step1 template UI module must expose EnvelopePrintStep1TemplateUI API');
if(!/Step1TemplateUI:EnvelopePrintStep1TemplateUI/.test(core)) fail('EnvelopePrintModules must expose Step1 Template UI API');
if(!/Step1TemplateUI:\['EnvelopePrintStep1TemplateUI','bindEventsForStep1','renderStep1','handleTplCardClick','showUnadjustedGuide','duplicateTpl'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Step1 Template UI API');
const bootstrap = read('js/90_bootstrap.js');
if(/newTplCta[\s\S]{0,120}addEventListener/.test(bootstrap) || /newReplyCta[\s\S]{0,120}addEventListener/.test(bootstrap)) fail('bootstrap still owns Step1 fixed button listeners');
if(!/bindEventsForStep1\(\)/.test(bootstrap)) fail('bootstrap must delegate Step1 fixed button listeners to bindEventsForStep1');
if(!/bindEventsForStep2\(\);/.test(bootstrap)) fail('bootstrap must delegate Step2 fixed events to bindEventsForStep2');
for(const id of ['btnReWizard','btnUnlock','step2Back','step2Next','btnAddField','btnLoadBg','btnZoomIn','btnZoomOut']){
  if(new RegExp(id + '[\\s\\S]{0,180}addEventListener').test(bootstrap)) fail(`bootstrap still owns Step2 fixed listener: ${id}`);
}
for(const id of ['btnReWizard','btnUnlock','step2Back','step2Next','tName','tW','tH','tIsReply','tLocked','btnAddField','btnAddSenderBlock','btnAddStamp','btnAddZone','btnLoadBg','fileBg','btnClearBg','bgPersist','bgOpacity','bgOffX','bgOffY','bgScaleX','bgScaleY','bgRotation','btnBgReset','btnZoomIn','btnZoomOut','envelope']){
  if(!step2Ui.includes(id)) fail(`Step2 event binder missing DOM id: ${id}`);
}
if(!/attachEnvelopeZoneDraftHandler\(\$\('envelope'\)\)/.test(step2Ui)) fail('Step2 event binder must attach envelope zone draft handler');
if(!/function\s+bindEventsForCommonUI\s*\(/.test(commonUiBinder)) fail('Common UI binder must define bindEventsForCommonUI');
if(!/global\.bindEventsForCommonUI\s*=\s*bindEventsForCommonUI/.test(commonUiBinder)) fail('Common UI binder must export bindEventsForCommonUI');
if(!/const\s+CommonUiApi\s*=\s*Object\.freeze\(\{[\s\S]*bindEventsForCommonUI/.test(commonUiBinder)) fail('Common UI binder must define CommonUiApi');
if(!/global\.EnvelopePrintCommonUI\s*=\s*CommonUiApi/.test(commonUiBinder)) fail('Common UI binder must expose EnvelopePrintCommonUI');
for(const id of ['btnHelp','btnDataMgmt','modeSimple','modeAdvanced']){
  if(!commonUiBinder.includes(id)) fail(`Common UI binder missing DOM id: ${id}`);
  if(new RegExp(id + '[\\s\\S]{0,180}addEventListener').test(bootstrap)) fail(`bootstrap still owns common UI listener: ${id}`);
}
if(!/bindEventsForCommonUI\(\);/.test(bootstrap)) fail('bootstrap must delegate common UI events to bindEventsForCommonUI');
if(!/CommonUI:EnvelopePrintCommonUI/.test(core)) fail('EnvelopePrintModules must expose Common UI Binder API');
if(!/CommonUI:\['EnvelopePrintCommonUI','bindEventsForCommonUI'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Common UI Binder API');
if(!/Layout:\{overlap, adjustFieldRect, approxChar, estimatePrintCharUnits, wrapTextByPrintUnits, fitText, renderEnvelope, renderEnvelopeInto, renderNormalField, renderZipField, renderLabelCellInto, buildLabelSheetStack, buildPrintStack\}/.test(core)) fail('EnvelopePrintModules must expose Layout and render stack API');
if(!/Layout:\['overlap','adjustFieldRect','approxChar','estimatePrintCharUnits','wrapTextByPrintUnits','fitText','renderEnvelopeInto','renderNormalField','renderZipField','renderLabelCellInto','buildLabelSheetStack','buildPrintStack'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Layout and render stack API');
if(!/Print:\{addPrintAttempt, getPrintRecordCount, renderFinalChecklist, getHardPrintIssues, renderPrintActionArea, executePrint, buildPrintStack, doPrint\}/.test(core)) fail('EnvelopePrintModules must expose Print Control API');
if(!/Print:\['addPrintAttempt','getPrintRecordCount','renderFinalChecklist','getHardPrintIssues','renderPrintActionArea','executePrint','buildPrintStack','doPrint'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Print Control API');
for(const fn of ['compressImageDataUrl','loadBackgroundFileInto','fileToDataURL','loadBackgroundPDF','loadBackgroundImage','setBackgroundOnTpl']){
  if(new RegExp('function\\s+' + fn + '\\s*\\(').test(core)) fail(`core still defines background function: ${fn}`);
}
const backgroundAssets = read('js/43_background_assets.js');
if(!/const\s+BackgroundAssetsApi\s*=\s*Object\.freeze\(\{[\s\S]*BG_MAX_LONG_EDGE[\s\S]*loadBackgroundFileInto[\s\S]*setBackgroundOnTpl/.test(backgroundAssets)) fail('background assets must define frozen BackgroundAssetsApi');
if(!/EnvelopePrintBackgroundAssets:\s*BackgroundAssetsApi/.test(backgroundAssets)) fail('background assets must expose EnvelopePrintBackgroundAssets API');
if(!/Object\.assign\(global,[\s\S]*loadBackgroundFileInto[\s\S]*setBackgroundOnTpl[\s\S]*EnvelopePrintBackgroundAssets/.test(backgroundAssets)) fail('background assets must preserve legacy exports and explicit API');
if(!/BackgroundAssets:EnvelopePrintBackgroundAssets/.test(coreForVersion)) fail('EnvelopePrintModules must expose Background Assets API');
if(!/BackgroundAssets:\['EnvelopePrintBackgroundAssets','BG_MAX_LONG_EDGE','BG_JPEG_QUALITY','compressImageDataUrl','loadBackgroundFileInto','fileToDataURL','loadBackgroundPDF','loadBackgroundImage','setBackgroundOnTpl'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Background Assets API');
for(const fn of ['showHelp','showDataMgmt','getModuleOverview']){
  if(new RegExp('function\\s+' + fn + '\\s*\\(').test(core)) fail(`core still defines data management UI function: ${fn}`);
}

for(const fn of ['renderEnvelope','getMMperPxOf','getMMperPx','getDragPoint','isPrimaryDragStart','preventDragDefault','addDragDocumentListeners','removeDragDocumentListeners','attachFieldDrag','attachZoneDrag','startAddZone','startEnvelopeZoneDraft','attachEnvelopeZoneDraftHandler']){
  if(new RegExp('function\\s+' + fn + '\\s*\\(').test(core)) fail(`core still defines edit canvas function: ${fn}`);
}
const editCanvas = read('js/44_edit_canvas_controller.js');
if(!/function\s+renderEnvelope\s*\(/.test(editCanvas)) fail('edit canvas controller must define renderEnvelope');
if(!/const\s+EditCanvasControllerApi\s*=\s*Object\.freeze\(\{[\s\S]*renderEnvelope[\s\S]*attachFieldDrag[\s\S]*getEditCanvasControllerState/.test(editCanvas)) fail('edit canvas controller must define frozen EditCanvasControllerApi');
if(!/Object\.assign\(global,[\s\S]*renderEnvelope[\s\S]*attachFieldDrag[\s\S]*getEditCanvasControllerState[\s\S]*EnvelopePrintEditCanvasController/.test(editCanvas)) fail('edit canvas controller must preserve legacy exports and explicit API');
if(!/EnvelopePrintEditCanvasController:\s*EditCanvasControllerApi/.test(editCanvas)) fail('edit canvas controller must expose EnvelopePrintEditCanvasController API');
if(!/EditCanvasController:EnvelopePrintEditCanvasController/.test(coreForVersion)) fail('EnvelopePrintModules must expose Edit Canvas Controller API');
if(!/EditCanvas:EnvelopePrintEditCanvasController/.test(coreForVersion)) fail('EnvelopePrintModules legacy EditCanvas bucket must delegate to Edit Canvas Controller API');
if(!/EditCanvasController:\['EnvelopePrintEditCanvasController','renderEnvelope','getMMperPxOf','getMMperPx','getDragPoint','isPrimaryDragStart','preventDragDefault','addDragDocumentListeners','removeDragDocumentListeners','attachFieldDrag','attachZoneDrag','startAddZone','startEnvelopeZoneDraft','attachEnvelopeZoneDraftHandler','getEditCanvasControllerState'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Edit Canvas Controller API');

for(const fn of ['createSenderFields','createStampField','refreshPartsActionUi','addSenderBlockToCurrentTpl','addStampToCurrentTpl','handleAddStampClick']){
  if(new RegExp('function\\s+' + fn + '\\s*\\(').test(core)) fail(`core still defines parts action function: ${fn}`);
}
const partsActions = read('js/41_parts_actions.js');
if(!/^\(function\(global\)\{/.test(partsActions)) fail('parts actions must start with IIFE');
if(!partsActions.slice(0, 220).includes("'use strict';")) fail('parts actions must enable strict mode near the top');
if(!/const\s+PartsActionsApi\s*=\s*Object\.freeze\(\{[\s\S]*handleAddStampClick/.test(partsActions)) fail('parts actions must define frozen PartsActionsApi');
if(!/EnvelopePrintPartsActions:\s*PartsActionsApi/.test(partsActions)) fail('parts actions must expose EnvelopePrintPartsActions API');
if(!/Parts:EnvelopePrintPartsActions/.test(core)) fail('EnvelopePrintModules must expose Parts Actions API');
if(!/Parts:\['EnvelopePrintPartsActions','createSenderFields','createStampField','refreshPartsActionUi','addSenderBlockToCurrentTpl','addStampToCurrentTpl','handleAddStampClick'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Parts Actions API');

for(const fn of ['bindEvents','selectLastUsedTemplate','initializeApp']){
  if(new RegExp('function\\s+' + fn + '\\s*\\(').test(core)) fail(`core still defines bootstrap function: ${fn}`);
}

if(!/Object\.assign\(global,[\s\S]*bindEvents[\s\S]*selectLastUsedTemplate[\s\S]*initializeApp[\s\S]*EnvelopePrintBootstrap/.test(bootstrap)) fail('bootstrap must preserve global compatibility exports after IIFE conversion');
if(!/const\s+EnvelopePrintBootstrap\s*=\s*Object\.freeze/.test(bootstrap)) fail('bootstrap must expose EnvelopePrintBootstrap');

if(/function\s+getTplAdjustmentSummary\s*\(/.test(core)) fail('core still defines adjustment status function: getTplAdjustmentSummary');
const adjustmentStatus = read('js/53_adjustment_status.js');
if(!/function\s+getTplAdjustmentSummary\s*\(/.test(adjustmentStatus)) fail('adjustment status module must define getTplAdjustmentSummary');
if(!/Object\.assign\(global,[\s\S]*getTplAdjustmentSummary[\s\S]*EnvelopePrintAdjustmentStatus/.test(adjustmentStatus)) fail('adjustment status module must preserve global exports after IIFE conversion');
if(!/const\s+AdjustmentStatusApi\s*=\s*Object\.freeze\(\{[\s\S]*getTplAdjustmentSummary/.test(adjustmentStatus)) fail('adjustment status module must define AdjustmentStatusApi');
if(!/EnvelopePrintAdjustmentStatus:\s*AdjustmentStatusApi/.test(adjustmentStatus)) fail('adjustment status module must expose EnvelopePrintAdjustmentStatus');
if(!/AdjustmentStatus:EnvelopePrintAdjustmentStatus/.test(coreForVersion)) fail('EnvelopePrintModules must expose Adjustment Status API');
if(!/AdjustmentStatus:\['EnvelopePrintAdjustmentStatus','getTplAdjustmentSummary'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Adjustment Status API');

const stageAddons = [
  ['js/50_stage5_addon.js', 'paper_position_print_system_v37_stage5_addons'],
  ['js/60_stage6_addon.js', 'paper_position_print_system_v37_stage6'],
  ['js/70_stage7_addon.js', 'paper_position_print_system_v37_stage7_addon'],
  ['js/80_stage8_addon.js', 'paper_position_print_system_v37_stage8_validation']
];
for(const [file, key] of stageAddons){
  const src = read(file);
  if(!src.includes(key)) fail(`stage addon key changed or missing: ${file}`);
  if(/window\.getFieldText\s*=/.test(src)) fail(`stage addon must not monkey patch getFieldText: ${file}`);
}
if(/^\s*bindEvents\(\);/m.test(core)) fail('core still calls bindEvents directly');
if(/^\s*goToStep\(1\);/m.test(core)) fail('core still performs initial goToStep directly');



// v38-28: Step3手入力coreは分離済み。
// v38-29: 版数同期は manifest.version を基準にverifyで検出する。
// v38-31: Step3固定イベント接続はbootstrapからStep3 input coreへ委譲する。
// v38-32: Step3キュー・住所録・履歴・Excel貼付取込は48_step3_queue_ui.jsへ分離する。
// v38-33: Step4/Step5 UIと固定イベントは専用ファイルへ分離する。
// v38-34: Step navigationは48_step_navigation.jsへ分離する。
// v38-35: Step2詳細編集UIは48_step2_edit_ui.jsへ分離する。
// v38-36: Step2固定イベントは48_step2_edit_ui.jsへ移し、48_steps_ui.jsは履歴マーカー化する。
// v38-37: 共通UI固定イベントは54_common_ui_binder.jsへ移す。
// v38-38: 履歴マーカー化していた48_steps_ui.jsを読込・manifest・実ファイルから廃止する。
// v38-39: 個別棚卸しdocsをdocs/refactor_inventory_archive.mdへ統合する。
// v38-40: 00_pdf_loader / 42_layout_math / 99_audit_marker をIIFE + strict化する。
// v38-41: 45_render_fields / 46_render_envelope / 47_print をIIFE + strict化する。
// v38-42: 40_templates をIIFE + strict化する。
// v38-43: 20_registries をIIFE + strict化する。
// v38-44: 90_bootstrap をIIFE + strict化する。
// v38-45: 49_wizard をIIFE + strict化する。
// v38-46: 05_utilities をIIFE + strict化する。
// v38-47: 15_address_data をIIFE + strict化する。
// v38-51: 52_data_management_ui をIIFE + strict化のPhase対象として再整備する。
// v38-52: 30_storage.js をIIFE + strict化し、EnvelopePrintStorageCore を明示API化する。
// v38-53: 43_background_assets.js をIIFE + strict化のPhase対象として再整備し、EnvelopePrintBackgroundAssets を明示API化する。
// v38-54: 44_edit_canvas_controller.js をIIFE + strict化のPhase対象として再整備し、EnvelopePrintEditCanvasController を明示API化する。
// v38-55: 48_step_navigation.js をIIFE + strict化のPhase対象として再整備し、EnvelopePrintStepNavigation を明示API化する。
// v38-56: 48_step1_template_ui.js をIIFE Strict Phase17対象として再整備し、EnvelopePrintStep1TemplateUI を明示API化する。
// v38-57: 48_step2_edit_ui.js をIIFE Strict Phase18対象として再整備し、EnvelopePrintStep2EditUI を明示API化する。
// v38-58: 48_step3_input_core.js をIIFE Strict Phase19対象として再整備し、EnvelopePrintStep3InputCore を明示API化する。
// v38-59: 48_step3_queue_ui.js をIIFE Strict Phase20対象として再整備し、EnvelopePrintStep3QueueUI を明示API化する。
// v38-60: 48_step4_test_print_ui.js をIIFE Strict Phase21対象として再整備し、EnvelopePrintStep4TestPrintUI を明示API化する。
const step3InputCore = read('js/48_step3_input_core.js');
const step3QueueUi = read('js/48_step3_queue_ui.js');
const step3InputFns = ['renderStep3','renderInputForm','getInputData','loadAddrToInput','clearInput','switchInputPane','bindEventsForStep3'];
for(const fn of step3InputFns){
  if(!new RegExp('function\\s+' + fn + '\\s*\\(').test(step3InputCore)) fail(`Step3 input core function missing: ${fn}`);
  if(new RegExp('function\\s+' + fn + '\\s*\\(').test(stepsUi)) fail(`Step3 input core function still remains in 48_steps_ui.js: ${fn}`);
}
if(!/const\s+Step3InputCoreApi\s*=\s*Object\.freeze\(\{[\s\S]*renderStep3[\s\S]*bindEventsForStep3/.test(step3InputCore)) fail('step3 input core must define frozen Step3InputCoreApi');
if(!/Object\.assign\(global,\s*\{[\s\S]*renderStep3[\s\S]*switchInputPane[\s\S]*bindEventsForStep3[\s\S]*EnvelopePrintStep3InputCore/.test(step3InputCore)) fail('step3 input core export block missing');
if(!/EnvelopePrintStep3InputCore:\s*Step3InputCoreApi/.test(step3InputCore)) fail('step3 input core must expose EnvelopePrintStep3InputCore API');
if(!/Step3ExtensionRegistry[\s\S]*runRenderHooks/.test(step3InputCore)) fail('Step3 render hook contract missing');
if(!/Step3ExtensionRegistry[\s\S]*runManualPaneHooks/.test(step3InputCore)) fail('Step3 manual pane hook contract missing');
if(!/InputDataExtensionRegistry[\s\S]*runCollectHooks/.test(step3InputCore)) fail('InputData collect hook contract missing');
if(!/InputDataExtensionRegistry[\s\S]*runLoadHooks/.test(step3InputCore)) fail('InputData load hook contract missing');
if(!/InputDataExtensionRegistry[\s\S]*runClearHooks/.test(step3InputCore)) fail('InputData clear hook contract missing');
if(!/bindEventsForStep3\(\);/.test(bootstrap)) fail('bootstrap must delegate Step3 fixed events to bindEventsForStep3');
for(const id of ['step3Back','step3Next','btnAddQueue','btnSaveToAddrbook','btnClearInput','abSearch','btnClearQueue','btnClearHistory']){
  if(!step3InputCore.includes(id)) fail(`Step3 event binder missing DOM id: ${id}`);
}
if(/btnAddQueue[\s\S]{0,160}addEventListener/.test(bootstrap)) fail('bootstrap still owns Step3 add queue listener');
if(/btnSaveToAddrbook[\s\S]{0,160}addEventListener/.test(bootstrap)) fail('bootstrap still owns Step3 addressbook save listener');
if(!/Step3Input:EnvelopePrintStep3InputCore/.test(core)) fail('EnvelopePrintModules must expose Step3Input API');
if(!/Step3Input:\['EnvelopePrintStep3InputCore','renderStep3','renderInputForm','getInputData','loadAddrToInput','clearInput','switchInputPane','bindEventsForStep3'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Step3 Input Core API');
if(!/Step3Queue:EnvelopePrintStep3QueueUI/.test(core)) fail('EnvelopePrintModules must expose Step3Queue API');
const step3RemainingFns = [
  'renderQueue','cloneQueueItemFromRecord','renderAddrbook','renderHistory',
  'addToHistory','renderPasteImport','analyzePastedData','renderPastePreview','doImportPaste'
];
for(const fn of step3RemainingFns){
  if(!new RegExp('function\\s+' + fn + '\\s*\\(').test(step3QueueUi)) fail(`Step3 queue function missing from 48_step3_queue_ui.js: ${fn}`);
  if(new RegExp('function\\s+' + fn + '\\s*\\(').test(stepsUi)) fail(`Step3 queue function still remains in 48_steps_ui.js: ${fn}`);
}
if(!/const\s+Step3QueueUiApi\s*=\s*Object\.freeze\(\{[\s\S]*renderQueue[\s\S]*doImportPaste/.test(step3QueueUi)) fail('step3 queue UI must define frozen Step3QueueUiApi');
if(!/EnvelopePrintStep3QueueUI:\s*Step3QueueUiApi/.test(step3QueueUi)) fail('step3 queue UI must expose EnvelopePrintStep3QueueUI API');
if(!/Object\.assign\(global,\s*\{[\s\S]*renderQueue[\s\S]*doImportPaste[\s\S]*EnvelopePrintStep3QueueUI/.test(step3QueueUi)) fail('step3 queue UI export block missing');
if(!/Step3Queue:\['EnvelopePrintStep3QueueUI','renderQueue','cloneQueueItemFromRecord','renderAddrbook','renderHistory','addToHistory','renderPasteImport','analyzePastedData','renderPastePreview','doImportPaste'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Step3 Queue UI API');

if(!/JSON\.parse\(JSON\.stringify\(record \|\| \{\}\)\)/.test(step3QueueUi)) fail('cloneQueueItemFromRecord must preserve extension fields by deep copy');

// v38-33: Step4/Step5 UIと固定イベント接続はそれぞれ専用ファイルへ分離する。
const step4TestPrintUi = read('js/48_step4_test_print_ui.js');
const step5FinalPrintUi = read('js/48_step5_final_print_ui.js');
if(!/Step4TestPrint:EnvelopePrintStep4TestPrintUI/.test(core)) fail('EnvelopePrintModules must expose Step4 Test Print UI API');
if(!/const\s+Step4TestPrintUiApi\s*=\s*Object\.freeze\(\{[\s\S]*renderStep4[\s\S]*bindEventsForStep4/.test(step4TestPrintUi)) fail('step4 test print UI must define frozen Step4TestPrintUiApi');
if(!/EnvelopePrintStep4TestPrintUI:\s*Step4TestPrintUiApi/.test(step4TestPrintUi)) fail('step4 test print UI must expose EnvelopePrintStep4TestPrintUI API');
if(!/Object\.assign\(global,\s*\{[\s\S]*renderStep4[\s\S]*bindEventsForStep4[\s\S]*EnvelopePrintStep4TestPrintUI/.test(step4TestPrintUi)) fail('step4 test print UI export block missing');
if(!/Step4TestPrint:\['EnvelopePrintStep4TestPrintUI','renderStep4','renderPrinterProfileSection','updateStep4Summary','bindEventsForStep4'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Step4 Test Print UI API');
// v38-61: 48_step5_final_print_ui.js をIIFE Strict Phase22対象として再整備し、EnvelopePrintStep5FinalPrintUI を明示API化する。
if(!/Step5FinalPrint:EnvelopePrintStep5FinalPrintUI/.test(core)) fail('EnvelopePrintModules must expose Step5 Final Print UI API');
if(!/const\s+Step5FinalPrintUiApi\s*=\s*Object\.freeze\(\{[\s\S]*renderStep5[\s\S]*bindEventsForStep5/.test(step5FinalPrintUi)) fail('step5 final print UI must define frozen Step5FinalPrintUiApi');
if(!/EnvelopePrintStep5FinalPrintUI:\s*Step5FinalPrintUiApi/.test(step5FinalPrintUi)) fail('step5 final print UI must expose EnvelopePrintStep5FinalPrintUI API');
if(!/Object\.assign\(global,\s*\{[\s\S]*renderStep5[\s\S]*bindEventsForStep5[\s\S]*EnvelopePrintStep5FinalPrintUI/.test(step5FinalPrintUi)) fail('step5 final print UI export block missing');
if(!/Step5FinalPrint:\['EnvelopePrintStep5FinalPrintUI','renderStep5','bindEventsForStep5'\]/.test(read('js/52_data_management_ui.js'))) fail('getModuleOverview must expose Step5 Final Print UI API');
const step4Fns = ['renderStep4','renderPrinterProfileSection','updateStep4Summary','bindEventsForStep4'];
for(const fn of step4Fns){
  if(!new RegExp('function\\s+' + fn + '\\s*\\(').test(step4TestPrintUi)) fail(`Step4 test print function missing: ${fn}`);
  if(new RegExp('function\\s+' + fn + '\\s*\\(').test(stepsUi)) fail(`Step4 test print function still remains in 48_steps_ui.js: ${fn}`);
}
const step5Fns = ['renderStep5','bindEventsForStep5'];
for(const fn of step5Fns){
  if(!new RegExp('function\\s+' + fn + '\\s*\\(').test(step5FinalPrintUi)) fail(`Step5 final print function missing: ${fn}`);
  if(new RegExp('function\\s+' + fn + '\\s*\\(').test(stepsUi)) fail(`Step5 final print function still remains in 48_steps_ui.js: ${fn}`);
}
if(!/Object\.assign\(global,\s*\{[\s\S]*renderStep4[\s\S]*bindEventsForStep4/.test(step4TestPrintUi)) fail('step4 test print UI export block missing');
if(!/Object\.assign\(global,\s*\{[\s\S]*renderStep5[\s\S]*bindEventsForStep5/.test(step5FinalPrintUi)) fail('step5 final print UI export block missing');
if(!/bindEventsForStep4\(\);/.test(bootstrap)) fail('bootstrap must delegate Step4 fixed events to bindEventsForStep4');
if(!/bindEventsForStep5\(\);/.test(bootstrap)) fail('bootstrap must delegate Step5 fixed events to bindEventsForStep5');
for(const id of ['step4Back','step4Next','btnFixMismatch','btnRemoveMismatch','btnTestSample','btnTestFirst','btnTestCross','markTestPrinted']){
  if(!step4TestPrintUi.includes(id)) fail(`Step4 event binder missing DOM id: ${id}`);
}
for(const id of ['step5Back','btnStartOver']){
  if(!step5FinalPrintUi.includes(id)) fail(`Step5 event binder missing DOM id: ${id}`);
}
if(/btnFixMismatch[\s\S]{0,180}addEventListener/.test(bootstrap)) fail('bootstrap still owns Step4 mismatch listener');
if(/markTestPrinted[\s\S]{0,180}addEventListener/.test(bootstrap)) fail('bootstrap still owns Step4 test printed listener');
if(/btnStartOver[\s\S]{0,180}addEventListener/.test(bootstrap)) fail('bootstrap still owns Step5 start-over listener');
if(!/Step4TestPrint:EnvelopePrintStep4TestPrintUI/.test(core)) fail('EnvelopePrintModules must expose Step4TestPrint API');
if(!/Step5FinalPrint:EnvelopePrintStep5FinalPrintUI/.test(core)) fail('EnvelopePrintModules must expose Step5FinalPrint API');
// v38-38: 48_steps_ui.js is fully retired, not merely a history marker.
if(stepsUi !== '') fail('48_steps_ui.js source must be empty because the file is retired');

if(readme.includes('js/25_address_data.js')) fail('README still mentions obsolete js/25_address_data.js');
if(index.includes('js/25_address_data.js')) fail('index still mentions obsolete js/25_address_data.js');
console.log('OK structure verification passed');
