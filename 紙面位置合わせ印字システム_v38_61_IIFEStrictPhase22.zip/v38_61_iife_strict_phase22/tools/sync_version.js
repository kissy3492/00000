#!/usr/bin/env node
/* v38-29: release version labels synchronizer.
   Usage:
     node tools/sync_version.js v38-29 "version sync guard" "Version Sync Guard"
   This script intentionally does not change storage keys, storage schema, or field.source names. */
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const version = process.argv[2];
const label = process.argv[3] || 'version sync guard';
const titleLabel = process.argv[4] || label.replace(/\b\w/g, c => c.toUpperCase());

if(!/^v\d+-\d+$/.test(version || '')){
  console.error('Usage: node tools/sync_version.js v38-29 "version sync guard" "Version Sync Guard"');
  process.exit(1);
}
const fullLabel = `${version} ${label}`;
const apiVersion = `${version}-${label}`.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const appTitle = `紙面位置合わせ印字システム ${version} ${titleLabel}`;

function read(p){ return fs.readFileSync(path.join(root, p), 'utf8'); }
function write(p, text){ fs.writeFileSync(path.join(root, p), text, 'utf8'); }
function replaceOne(text, pattern, replacement, description){
  if(!pattern.test(text)) throw new Error(`sync_version failed: ${description}`);
  return text.replace(pattern, replacement);
}

let index = read('index.html');
index = replaceOne(index, /<title>[^<]*<\/title>/, `<title>${appTitle}</title>`, 'index title');
index = replaceOne(index, /<!--\s*v\d+-\d+[\s\S]*?-->/, `<!--\n  ${version} ${titleLabel}.\n  Visible release labels are synchronized by tools/sync_version.js and verified by tools/verify_structure.js.\n-->`, 'index version comment');
index = replaceOne(index, /<span class="logo-sub">[^<]*<\/span>/, `<span class="logo-sub">${fullLabel} / storage v37</span>`, 'logo subtitle');
write('index.html', index);

let core = read('js/10_core.js');
core = replaceOne(core, /const APP_RELEASE_LABEL = '[^']+';/, `const APP_RELEASE_LABEL = '${fullLabel}';`, 'APP_RELEASE_LABEL');
core = replaceOne(core, /const APP_MODULE_API_VERSION = '[^']+';/, `const APP_MODULE_API_VERSION = '${apiVersion}';`, 'APP_MODULE_API_VERSION');
write('js/10_core.js', core);

let readme = read('README.md');
readme = replaceOne(readme, /^# 紙面位置合わせ印字システム .+$/m, `# 紙面位置合わせ印字システム ${version} ${titleLabel}`, 'README H1');
write('README.md', readme);

let testsReadme = read('tests/README.md');
testsReadme = replaceOne(testsReadme, /^# v\d+-\d+ テスト（分割版本流）$/m, `# ${version} テスト（分割版本流）`, 'tests README H1');
write('tests/README.md', testsReadme);

const currentDocs = ['docs/core_residual_inventory.md', 'docs/global_scope_policy.md'];
for(const docPath of currentDocs){
  let doc = read(docPath);
  doc = doc.replace(/^# v\d+-\d+ /m, `# ${version} `);
  write(docPath, doc);
}

const manifestPath = path.join(root, 'split_manifest.json');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
manifest.version = fullLabel;
fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n', 'utf8');

console.log(`Synchronized release labels to ${fullLabel}`);
