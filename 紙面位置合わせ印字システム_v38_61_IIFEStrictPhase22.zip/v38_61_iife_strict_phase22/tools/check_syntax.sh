#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
for f in js/*.js tests/*.js tools/*.js; do
  [ -f "$f" ] || continue
  echo "node --check $f"
  node --check "$f"
done
echo "OK"
