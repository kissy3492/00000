# Aletheia VBA実装方針書 v1.4
作成日: 2026-05-22

## 1. 推奨マクロ

| マクロ | 役割 |
|---|---|
| SetupWorkbook_Aletheia | シート作成 |
| ImportGrimoireWorkbook | ブック取込 |
| OpenGrimoireWorkbookSafe | マクロ無効・ReadOnlyで開く |
| ValidateGrimoireWorkbook | 仕様ID・必須シート・停止条件確認 |
| CalculateGrimoireCheckSheets | C3等を再計算 |
| ImportGrimoireSummaryWide | 価格情報サマリーA4:BK5を取込 |
| ImportGrimoireLinkData | Aletheia連携データA:Zを取込 |
| ImportGrimoirePastedSummary | 手動貼付A:BK取込 |
| IssueImportId | 取込ID採番 |
| ArchivePreviousImport | 旧取込を非最新化 |
| RefreshComparisonAnalysis | 比較分析更新 |
| BuildAttentionList | 注意点一覧 |
| BuildOpinionMemo | 所見メモ |

## 2. 安全なブックオープン

```vba
Dim oldSecurity As MsoAutomationSecurity
oldSecurity = Application.AutomationSecurity
Application.AutomationSecurity = msoAutomationSecurityForceDisable

Set wbG = Workbooks.Open( _
    Filename:=path, _
    UpdateLinks:=0, _
    ReadOnly:=True, _
    AddToMru:=False)

' 必ず復元
wbG.Close SaveChanges:=False
Application.AutomationSecurity = oldSecurity
```

エラー時も必ず復元する。

## 3. 計算

読取前に、少なくとも以下をCalculateする。

```text
APIキー混入チェック
連携最終チェック
価格情報サマリー
Aletheia連携データ
```

C3が空欄・エラー・非数値なら停止。

## 4. 取込ID

```text
IMP_yyyymmdd_hhnnss_連番3桁
```

ブック全体で一意にする。

## 5. 値保存

Aletheia側には値で保存する。  
外部リンク数式を残さない。  
ハイパーリンクは必要なら表示文字列とリンク先を分けて保存する。

## 6. フルパス

初期設定ではGrimoireフルパスを保存しない。  
保存する場合はユーザーが明示的にONにする。
