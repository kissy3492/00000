# Aletheia 開発AI指示書 v1.4
作成日: 2026-05-22

Excel VBAツール「Aletheia」を作成してください。

## 絶対条件

ブック取込では必ず以下の両方を読む。

```text
価格情報サマリー!A4:BK5
Aletheia連携データ!A4:Z最終行
```

Aletheia連携データA:Zだけでは、公示地価中央値・取引事例中央値・四分位・鑑定評価書中央値などが不足します。

## Grimoire仕様

```text
対象: Grimoire v18.90以降
連携仕様ID: GRIMOIRE_ALETHEIA_EXCEL_V1
仕様IDセル: Aletheia連携仕様!B4
Grimoireバージョンセル: Aletheia連携仕様!B5
APIキー混入件数: APIキー混入チェック!C3
APIキー判定: APIキー混入チェック!E3
```

## 開く時

```text
マクロ強制無効
ReadOnly
UpdateLinks:=0
SaveChanges:=Falseで閉じる
AutomationSecurityは必ず復元
```

## 取込ID

```text
IMP_yyyymmdd_hhnnss_連番3桁
```

## 停止条件

```text
仕様ID不一致
APIキー混入C3が空欄・エラー・非数値・1以上
価格情報サマリー未作成
必須見出し不一致
SUMMARYなし
```

## 禁止

```text
適正価格と自動表示しない
不適正と自動表示しない
否認可能と自動表示しない
低額譲渡該当と自動表示しない
参考距離だけで採用判定しない
APIキーやAPIキー先頭8文字を保存しない
Grimoireブックを書き換えない
外部リンク数式を残さない
```

まず `SetupWorkbook_Aletheia` を実装し、次に `ImportGrimoireWorkbook` を実装してください。
