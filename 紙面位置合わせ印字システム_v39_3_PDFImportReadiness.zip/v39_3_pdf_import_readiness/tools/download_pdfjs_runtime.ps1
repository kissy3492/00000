param(
  [string]$TargetDir = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = 'Stop'
$version = '2.16.105'
$base = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/$version"
$files = @(
  @{ Name = 'pdf.min.js'; Url = "$base/pdf.min.js" },
  @{ Name = 'pdf.worker.min.js'; Url = "$base/pdf.worker.min.js" },
  @{ Name = 'PDFJS_LICENSE.txt'; Url = 'https://raw.githubusercontent.com/mozilla/pdf.js/v2.16.105/LICENSE' }
)

if(-not (Test-Path -LiteralPath $TargetDir)){
  New-Item -ItemType Directory -Path $TargetDir | Out-Null
}

Write-Host "Downloading pdf.js runtime files to $TargetDir"
foreach($file in $files){
  $dest = Join-Path $TargetDir $file.Name
  Write-Host " - $($file.Name)"
  Invoke-WebRequest -Uri $file.Url -OutFile $dest
}
Write-Host 'Done.'
