#!/usr/bin/env node
/* v38-74: apply load_order.json to index.html.
   This script only rewrites external script/link tag blocks. It never changes
   storage keys, storage schema, or field.source names. */
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const loadOrderPath = path.join(root, 'load_order.json');
const indexPath = path.join(root, 'index.html');
const loadOrder = JSON.parse(fs.readFileSync(loadOrderPath, 'utf8'));
const entries = Array.isArray(loadOrder.entries) ? loadOrder.entries : [];

function attrs(item){
  const pairs = [];
  if(item.id) pairs.push(['id', item.id]);
  if(item.rel) pairs.push(['rel', item.rel]);
  if(item.href) pairs.push(['href', item.href]);
  if(item.src) pairs.push(['src', item.src]);
  return pairs.map(([k,v]) => `${k}="${String(v).replace(/&/g, '&amp;').replace(/"/g, '&quot;')}"`).join(' ');
}
function renderEntry(item){
  if(item.tag === 'script'){
    if(!item.src) throw new Error('script entry missing src');
    return `<script ${attrs(item)}></script>`;
  }
  if(item.tag === 'link'){
    if(!item.href || !item.rel) throw new Error('link entry missing href/rel');
    return `<link ${attrs(item)}>`;
  }
  throw new Error(`unsupported load_order tag: ${item.tag}`);
}
function renderBlock(location){
  const body = entries.filter(item => item.location === location).map(renderEntry).join('\n');
  return `<!-- BEGIN LOAD_ORDER:${location} -->\n${body}\n<!-- END LOAD_ORDER:${location} -->`;
}
function replaceBlock(index, location){
  const pattern = new RegExp(`<!-- BEGIN LOAD_ORDER:${location} -->[\\s\\S]*?<!-- END LOAD_ORDER:${location} -->`);
  if(!pattern.test(index)) throw new Error(`index.html missing LOAD_ORDER block: ${location}`);
  return index.replace(pattern, renderBlock(location));
}
function validateEntries(){
  const seen = new Set();
  for(const item of entries){
    const asset = item.src || item.href;
    if(!asset) throw new Error('load_order entry missing src/href');
    if(!['head','body-end'].includes(item.location)) throw new Error(`unsupported location: ${item.location}`);
    if(seen.has(`${item.tag}:${asset}`)) throw new Error(`duplicate load_order asset: ${asset}`);
    seen.add(`${item.tag}:${asset}`);
    if(!fs.existsSync(path.join(root, asset))) throw new Error(`load_order asset missing: ${asset}`);
  }
}

validateEntries();
let index = fs.readFileSync(indexPath, 'utf8');
index = replaceBlock(index, 'head');
index = replaceBlock(index, 'body-end');
fs.writeFileSync(indexPath, index, 'utf8');
console.log('Applied load_order.json to index.html');
