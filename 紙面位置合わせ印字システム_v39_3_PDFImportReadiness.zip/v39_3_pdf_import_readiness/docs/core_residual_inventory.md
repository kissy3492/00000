# v39-3 Core残存責務台帳

> このファイルは `tools/regenerate_inventory.js` で生成します。手作業で長期運用メモを継ぎ足さず、現行ソースから再生成してください。

## `10_core.js` の現況

- 行数: 456
- 通常関数定義数: 0
- 通常関数一覧: なし
- 残す責務: アプリ定数、保存キー、`state` / `transientBg`、公開モジュール索引、v38方針メモ
- 分離しないもの: 保存キー、保存形式、`field.source` 名

## 分離済みJSファイルと関数定義数

| ファイル | 関数定義数 | 主な関数 |
|---|---:|---|
| js/00_pdf_loader.js | 0 | - |
| js/05_utilities.js | 40 | `uid`, `toast`, `announceA11y`, `ensureElementId`, `applyLabelForA11y`, `getTableA11yLabel`, `applyTableA11y`, `setInputInvalidState` ほか |
| js/06_keyboard_overlay.js | 4 | `closeLegacyModal`, `closeTopOverlayByEscape`, `setupEscapeToCloseOverlays`, `setupKeyboard` |
| js/15_address_data.js | 9 | `joinLines`, `buildOrgText`, `buildOrgFullText`, `buildNameWithHonor`, `buildSenderText`, `normalizeAddressData`, `defaultDataForTemplate`, `getFieldText` ほか |
| js/20_registries.js | 40 | `registerSource`, `hasSource`, `resolve`, `registerPostProcessor`, `applyPostProcessors`, `listSources`, `listSourceKeys`, `getLabel` ほか |
| js/30_storage.js | 58 | `addonStorageKeys`, `isInvalidAddonSnapshotValue`, `getAddonStorageSnapshot`, `captureAddonRawStorage`, `restoreAddonRawStorage`, `rollbackAddonStorageAfterRestoreFailure`, `sanitizeStage8AddonForRestore`, `sanitizeAddonForRestore` ほか |
| js/40_templates.js | 26 | `normalizeTpl`, `markLayoutChanged`, `defaultLabelConfig`, `getLabelConfig`, `labelCapacity`, `getEffectivePrintPageCount`, `buildExcludeZonesForPreset`, `tplKaku2` ほか |
| js/41_parts_actions.js | 6 | `createSenderFields`, `createStampField`, `refreshPartsActionUi`, `addSenderBlockToCurrentTpl`, `addStampToCurrentTpl`, `handleAddStampClick` |
| js/42_layout_math.js | 6 | `overlap`, `adjustFieldRect`, `approxChar`, `estimatePrintCharUnits`, `wrapTextByPrintUnits`, `fitText` |
| js/43_background_assets.js | 6 | `compressImageDataUrl`, `loadBackgroundFileInto`, `fileToDataURL`, `loadBackgroundPDF`, `loadBackgroundImage`, `setBackgroundOnTpl` |
| js/44_edit_canvas_controller.js | 25 | `renderEnvelope`, `getMMperPxOf`, `getMMperPx`, `getDragPoint`, `isPrimaryDragStart`, `preventDragDefault`, `addDragDocumentListeners`, `removeDragDocumentListeners` ほか |
| js/45_render_fields.js | 2 | `renderNormalField`, `renderZipField` |
| js/46_render_envelope.js | 4 | `renderEnvelopeInto`, `renderLabelCellInto`, `buildLabelSheetStack`, `buildPrintStack` |
| js/47_print.js | 9 | `addPrintAttempt`, `getPrintRecordCount`, `renderFinalChecklist`, `getHardPrintIssues`, `getQueueTemplateGroups`, `renderJobGroupSummary`, `renderPrintActionArea`, `executePrint` ほか |
| js/48_step1_template_ui.js | 5 | `bindEventsForStep1`, `renderStep1`, `handleTplCardClick`, `showUnadjustedGuide`, `duplicateTpl` |
| js/48_step2_edit_ui.js | 6 | `renderStep2`, `renderFieldList`, `renderZipConfig`, `renderZoneList`, `renderBgUI`, `bindEventsForStep2` |
| js/48_step3_input_core.js | 11 | `renderStep3`, `renderInputForm`, `getInputData`, `loadAddrToInput`, `clearInput`, `switchInputPane`, `addCurrentInputToQueue`, `saveCurrentInputToAddrbook` ほか |
| js/48_step3_queue_ui.js | 9 | `renderQueue`, `cloneQueueItemFromRecord`, `renderAddrbook`, `renderHistory`, `addToHistory`, `renderPasteImport`, `analyzePastedData`, `renderPastePreview` ほか |
| js/48_step4_test_print_ui.js | 9 | `renderStep4`, `renderPrinterProfileSection`, `updateStep4Summary`, `fixQueueMismatchToCurrentTemplate`, `removeQueueMismatchFromCurrentTemplate`, `printStep4Sample`, `printStep4FirstQueueItem`, `printStep4CrossTest` ほか |
| js/48_step5_final_print_ui.js | 3 | `renderStep5`, `startOverFromStep5`, `bindEventsForStep5` |
| js/48_step_navigation.js | 9 | `getActiveSteps`, `stepIndex`, `renderSteps`, `getStepStatus`, `canSkipTo`, `canGoToStep`, `reportStepNavigationError`, `callStepRenderer` ほか |
| js/49_wizard.js | 32 | `makeWizardSnapshot`, `restoreWizardSnapshot`, `getWzSteps`, `openWizard`, `closeWizard`, `renderWizard`, `renderWizardStep`, `wzFooter` ほか |
| js/50_stage5_addon.js | 28 | `loadAddon`, `saveAddon`, `stageId`, `esc`, `byId`, `toHalfWidth`, `normalizeZip`, `normalizeSpaces` ほか |
| js/52_data_management_ui.js | 19 | `buildBackupFileName`, `downloadTextFileFallback`, `saveBackupJsonToFile`, `parseBackupJsonText`, `readBackupJsonFromFileInput`, `openBackupJsonFromFile`, `restoreBackupJsonObjectWithConfirm`, `getRuntimeErrorEntries` ほか |
| js/53_adjustment_status.js | 1 | `getTplAdjustmentSummary` |
| js/54_common_ui_binder.js | 1 | `bindEventsForCommonUI` |
| js/60_stage6_addon.js | 34 | `loadStage6`, `saveStage6`, `byId`, `esc`, `half`, `fullDigits`, `normalizeZip6`, `digitStringToKanji` ほか |
| js/70_stage7_addon.js | 28 | `bindClick`, `loadAddon`, `saveAddon`, `registerSources`, `buildRecipientFull`, `getExtendedInputData`, `loadExtendedInputData`, `clearExtendedInputs` ほか |
| js/80_stage8_addon.js | 51 | `el`, `safe`, `now`, `fmt`, `deepClone`, `currentTpl`, `currentPrinter`, `qValid` ほか |
| js/90_bootstrap.js | 5 | `runBootstrapTask`, `bindEvents`, `selectLastUsedTemplate`, `initializeApp`, `scheduleInitializeApp` |
| js/91_runtime_error_trap.js | 3 | `recordRuntimeAction`, `recordRuntimeError`, `installRuntimeErrorTrap` |
| js/92_click_safety.js | 4 | `markClickHandled`, `markClickAttempted`, `getActionTargetLabel`, `safeBindClick` |
| js/93_click_fallback.js | 9 | `findActionTarget`, `actionLabel`, `closeContainingModal`, `invokeNamedAction`, `goToStepAction`, `currentTpl`, `getCriticalClickActionMap`, `routeCriticalClickFallback` ほか |
| js/94_self_diagnostics.js | 11 | `cloneDiagnosticTargetSpec`, `getInteractionDiagnosticTargets`, `getCurrentStepNumber`, `getExpectedInteractionTargetIds`, `isElementVisibleEnough`, `inspectInteractionTarget`, `detectActiveStepFromDom`, `detectActiveStepNavFromDom` ほか |
| js/99_audit_marker.js | 0 | - |

## 退役済みファイル

- `js/48_steps_ui.js` — v38-38で履歴マーカーから完全退役。Step1〜5、Step進行、共通イベントは各専用ファイルへ分離済み。

## 次の監視対象

- `js/10_core.js` は通常関数0件を維持する。
- `js/90_bootstrap.js` は起動順序と委譲だけを担当し、具体DOMイベントを増やさない。
- 過去の個別棚卸しメモは `docs/refactor_inventory_archive.md` に統合済み。最新性は本ファイルと `tools/verify_structure.js` を優先する。
