# 紙面位置合わせ印字システム v39-3 PDF Import Readiness

このパッケージは、今後の開発・レビュー・テストの基準となる **分割版本流** です。

## 位置づけ

- v38-5以降は、この分割構成を正とします。
- 単体HTMLは本流ではありません。必要な環境がある場合だけ、別途再結合して作る派生成果物です。
- 保存キー・保存スキーマ・field.source名は変更していません。
- ES Modulesではなく classic script の順序読込です。`file://` 直開きとの相性を極力維持するためです。

## 起動

`index.html` をブラウザで開きます。

## 読込順管理

`index.html` の外部 `script` / `link` の順序は `load_order.json` を正とします。

```bash
node tools/apply_load_order.js
```

手作業で `index.html` の script 順序だけを変更する運用は禁止です。`load_order.json` を更新し、`tools/apply_load_order.js` で反映してから `tools/verify.sh` を通してください。


## PDF取込について

PDF背景取込には **pdf.js** が必要です。v39-3では、`pdf.min.js` と `pdf.worker.min.js` を `index.html` と同じ階層に **同梱済み** です。

同梱ファイル:

```text
pdf.min.js
pdf.worker.min.js
PDFJS_LICENSE.txt
```

入手元・版:

- `pdfjs-dist` 2.16.105
- `build/pdf.min.js`
- `build/pdf.worker.min.js`

配置済みなので、zipを展開して `index.html` を開けばPDF背景取込が有効になります。職場環境で外部取得ができない場合でも、同梱ファイルだけでPDF取込を試せます。

ライセンス: Apache-2.0

## ファイル構成

```text
index.html
pdf.min.js
pdf.worker.min.js
PDFJS_LICENSE.txt
css/
  00_base.css
  10_app_components.css
  50_stage6.css
  60_stage7.css
  70_stage8.css
js/
  00_pdf_loader.js
  05_utilities.js
  06_keyboard_overlay.js
  15_address_data.js
  20_registries.js
  40_templates.js
  41_parts_actions.js
  42_layout_math.js
  43_background_assets.js
  44_edit_canvas_controller.js
  45_render_fields.js
  46_render_envelope.js
  47_print.js
  48_step_navigation.js
  48_step2_edit_ui.js
  48_step1_template_ui.js
  48_step3_input_core.js
  48_step3_queue_ui.js
  48_step4_test_print_ui.js
  48_step5_final_print_ui.js
  49_wizard.js
  30_storage.js
  52_data_management_ui.js
  53_adjustment_status.js
  54_common_ui_binder.js
  91_runtime_error_trap.js
  92_click_safety.js
  93_click_fallback.js
  94_self_diagnostics.js
  10_core.js
  90_bootstrap.js
  50_stage5_addon.js
  60_stage6_addon.js
  70_stage7_addon.js
  80_stage8_addon.js
  99_audit_marker.js
tests/
  README.md
  address_data_unit_tests.js
  adjustment_status_unit_tests.js
  background_assets_unit_tests.js
  bootstrap_unit_tests.js
  browser_e2e_smoke_tests.js
  load_order_contract_tests.js
  readme_release_history_tests.js
  browser_hotfix_navigation_guard_tests.js
  browser_hotfix_click_fallback_tests.js
  browser_hotfix_handler_recovery_tests.js
  browser_hotfix_self_diagnostics_tests.js
  browser_hotfix_step_nav_diagnostics_tests.js
  browser_hotfix_action_fallback_tests.js
  browser_hotfix_retreat_guardrail_tests.js
  browser_hotfix_module_split_tests.js
  common_ui_binder_unit_tests.js
  data_management_ui_unit_tests.js
  docs_inventory_consolidation_tests.js
  edit_canvas_controller_unit_tests.js
  iife_strict_phase1_tests.js
  iife_strict_phase2_tests.js
  iife_strict_phase3_tests.js
  iife_strict_phase4_tests.js
  iife_strict_phase5_tests.js
  iife_strict_phase6_tests.js
  iife_strict_phase7_tests.js
  iife_strict_phase8_tests.js
  iife_strict_phase9_tests.js
  iife_strict_phase10_tests.js
  iife_strict_phase11_tests.js
  iife_strict_phase12_tests.js
  iife_strict_phase13_tests.js
  iife_strict_phase14_tests.js
  iife_strict_phase15_tests.js
  iife_strict_phase16_tests.js
  iife_strict_phase17_tests.js
  iife_strict_phase18_tests.js
  iife_strict_phase19_tests.js
  iife_strict_phase20_tests.js
  iife_strict_phase21_tests.js
  iife_strict_phase22_tests.js
  iife_strict_phase23_tests.js
  iife_strict_phase24_tests.js
  iife_strict_phase25_tests.js
  parts_actions_unit_tests.js
  retired_steps_ui_unit_tests.js
  stage_addons_unit_tests.js
  step1_template_ui_unit_tests.js
  step2_edit_ui_unit_tests.js
  step3_input_core_unit_tests.js
  step3_input_queue_inventory_tests.js
  step4_step5_ui_unit_tests.js
  step_navigation_unit_tests.js
  storage_restore_tests.html
  storage_restore_tests.js
  version_sync_unit_tests.js
docs/
  core_residual_inventory.md
  global_scope_policy.md
  refactor_inventory_archive.md
  split_mainline_policy.md
tools/
  apply_load_order.js
  check_syntax.sh
  download_pdfjs_runtime.cmd
  download_pdfjs_runtime.ps1
  regenerate_inventory.js
  sync_version.js
  verify.sh
  verify_structure.js
load_order.json
split_manifest.json
README.md
```

## 開発方針

### v38-80 Closeout 方針

- v38-80を構造リファクタの完了整理版とし、v38-81 / Phase26 の追加を前提にしません。
- v39-1以降は、保存/復元UX、環境診断、印刷実務導線など利用者価値のある機能フェーズへ戻します。
- 新規コードでは `state` / `transientBg` の直接参照を増やさず、`EnvelopePrintCoreContract.getState()` / `getTransientBg()` または薄いhelper経由を優先します。
- `__envelopePrint*` 系の互換グローバルは残しますが、正本の観察入口として `EnvelopePrintRuntime` 名前空間を追加しました。
- READMEのリリース履歴は `tests/readme_release_history_tests.js` で欠番・逆順を検出します。
- 通常の `tools/verify.sh` ではChromium未検出時のE2E SKIPを許容しますが、`PAPERPRINT_REQUIRE_BROWSER_E2E=1 tools/verify.sh` ではSKIPを失敗扱いにします。


### v39-2 Pinned Backup Target 方針

- `showSaveFilePicker` 対応環境では、初回に選んだJSON保存先を保存先固定対象として扱います。
- 保存先ハンドルは可能な場合 `IndexedDB` に保持し、次回起動後も同じJSONファイルへ上書き保存できるようにします。
- `IndexedDB` が使えない環境では、セッション中だけ保存先を保持します。
- 未対応環境では従来どおりBlobダウンロード保存・全文コピー退避へフォールバックします。
- 保存キー・保存形式・`field.source` 名は変更しません。

### v39-1 Backup Capability UX 方針

- v39は機能フェーズとして開始します。Phase番号を増やすだけの構造リファクタは行いません。
- バックアップ管理画面に「保存環境診断」を追加し、保存先指定・ダウンロード保存・ファイル選択読込・localStorage可否を画面上で判定します。
- ユーザーが保存方式を迷わないよう、環境に応じて「推奨保存」と「推奨復元」を明示します。
- 診断結果をコピーできるようにし、職場PCで保存できない場合の原因共有・切り分けを容易にします。
- 保存キー・保存形式・`field.source` 名は変更しません。

- 修正は原則として分割版へ行います。
- v38-80で構造リファクタはCloseout済みです。以後、Phase番号を増やすだけのリファクタを継続しません。
- v39では機能追加に戻し、保存/復元UX・環境診断・ワンクリック保存導線など実務上の価値を優先します。
- Runtime観察は `EnvelopePrintRuntime` を正本とし、旧 `__envelopePrint*` グローバルは互換aliasとして扱います。
- 新規コードでは `state` / `transientBg` 直接参照を増やさず、Core Contract経由を優先します。
- `load_order.json` は `index.html` の外部script/link読込順の正本です。
- `tools/apply_load_order.js` は `load_order.json` から `index.html` のLOAD_ORDERブロックを再生成します。
- `js/05_utilities.js` は通知・コピー・a11y・モーダルなどの共通系です。
- `js/10_core.js` は状態・公開モジュール索引を中心に残し、主要処理は段階分割済みです。
- `js/20_registries.js` はFieldSource/Step拡張/InputData/Print/SampleDataのRegistry境界を担当し、`EnvelopePrintRegistryCore` として明示公開します。
- `js/41_parts_actions.js` は差出人欄・スタンプfieldの生成と追加操作を担当します。
- `js/43_background_assets.js` は背景画像/PDF取込・圧縮・テンプレート反映を担当します。
- `js/44_edit_canvas_controller.js` は詳細編集キャンバスの描画入口、mm換算、field/zoneドラッグ、避ける範囲作成を担当します。
- `js/48_step_navigation.js` はステップ一覧描画、進行可否判定、ステップ遷移を担当します。
- `js/48_step2_edit_ui.js` はStep2詳細編集画面、field一覧、郵便番号詳細、避ける範囲一覧、背景UI、Step2固定イベント接続を担当します。
- `js/48_step1_template_ui.js` はStep1テンプレート選択カード、選択、複製、削除、未調整ガイド、Step1固定ボタンのイベント接続を担当します。
- `js/48_step3_input_core.js` はStep3全体描画、手入力フォーム、入力データ収集/復元/クリア、入力ペイン切替、Step3固定イベント接続を担当します。
- `js/48_step3_queue_ui.js` はStep3のキュー、住所録、履歴、Excel貼付取込を担当します。
- `js/48_step4_test_print_ui.js` はStep4のテスト印刷、キュー整合、プリンタ補正表示、結果確認、Step4固定イベント接続を担当します。
- `js/48_step5_final_print_ui.js` はStep5の最終確認、印刷プレビュー、本印刷前UI、Step5固定イベント接続を担当します。
- `js/52_data_management_ui.js` はヘルプ・バックアップ管理・疑似モジュール概要を担当します。
- `js/53_adjustment_status.js` は背景位置合わせ・郵便番号確認・レイアウト確認・テスト印刷確認・プリンタ補正状態の判定を担当します。
- `js/54_common_ui_binder.js` はヘルプ・データ管理・表示モード切替の共通固定イベント接続を担当します。
- `js/91_runtime_error_trap.js` は実行時エラー記録とクリック/診断ログを担当します。
- `js/92_click_safety.js` は `safeBindClick()` と明示click handler保護を担当します。
- `js/93_click_fallback.js` は重要ボタンの委譲fallbackと `CRITICAL_CLICK_ACTIONS` を担当します。
- `js/94_self_diagnostics.js` はUI自己診断を担当します。
- `js/90_bootstrap.js` は起動順序とイベント接続の委譲順だけを担当し、共通UIイベントとStep別固定イベントは各専用ファイルへ委譲します。
- Stage5〜8は個別ファイルとして維持し、v38-25で保存キー・Registry接続・読込順を棚卸ししました。
- v38-26でStep1テンプレート選択UIを `js/48_step1_template_ui.js` へ分離しました。
- v38-27でStep3入力・キュー・住所録・履歴・Excel貼付取込の分離前棚卸しと静的テストを追加しました。
- v38-28でStep3手入力coreを `js/48_step3_input_core.js` へ分離しました。
- v38-29で版数表示の同期漏れを是正し、`tools/sync_version.js` とverifyの版数同期検証を追加しました。
- v38-30でStep1固定ボタンのevent binderを `js/48_step1_template_ui.js` に移し、`90_bootstrap.js` のStep1リスナー直書きを撤去しました。
- v38-31でStep3固定イベントのevent binderを `js/48_step3_input_core.js` に移し、公開APIに `Step3Input` 区分を追加しました。
- v38-32でStep3キュー・住所録・履歴・Excel貼付取込を `js/48_step3_queue_ui.js` へ分離し、公開APIに `Step3Queue` 区分を追加しました。
- v38-33でStep4テスト印刷・プリンタ補正UIを `js/48_step4_test_print_ui.js` へ、Step5本印刷プレビューUIを `js/48_step5_final_print_ui.js` へ分離し、固定イベント接続もStep側へ移しました。
- v38-34でステップ一覧描画・進行可否・ステップ遷移を `js/48_step_navigation.js` へ分離しました。
- v38-35でStep2詳細編集UIを `js/48_step2_edit_ui.js` へ分離し、`48_steps_ui.js` を残存メモ中心に縮小しました。
- v38-36でStep2固定イベントのevent binderを `js/48_step2_edit_ui.js` へ移し、`48_steps_ui.js` を履歴マーカーとして明確化しました。
- v38-37でヘルプ・データ管理・表示モード切替の共通event binderを `js/54_common_ui_binder.js` へ分離し、`90_bootstrap.js` を起動委譲役へさらに縮小しました。
- v38-38で履歴マーカー化していた `js/48_steps_ui.js` を完全退役し、`tools/regenerate_inventory.js` でcore残存台帳を再生成できるようにしました。
- v38-39で個別の棚卸しdocsを `docs/refactor_inventory_archive.md` に統合し、最新確認先を `docs/core_residual_inventory.md` とverifyへ寄せました。
- v38-40で `00_pdf_loader.js` / `42_layout_math.js` / `99_audit_marker.js` をIIFE + strict化し、Layout Mathの明示exportと検証を追加しました。
- v38-41で `45_render_fields.js` / `46_render_envelope.js` / `47_print.js` をIIFE + strict化し、描画/印刷系の明示exportと公開API索引を更新しました。
- v38-42で `40_templates.js` をIIFE + strict化し、Template Modelの明示exportと公開API索引を更新しました。
- v38-43で `20_registries.js` をIIFE + strict化し、Registry Coreの明示exportと公開API索引を更新しました。
- v38-44で `90_bootstrap.js` をIIFE + strict化し、起動委譲役の明示exportと互換グローバルを維持しました。
- v38-45で `49_wizard.js` をIIFE + strict化し、Wizard Controllerの明示exportと `wizardState` 互換参照を維持しました。
- v38-46で `05_utilities.js` をIIFE + strict化し、共通ユーティリティの明示exportと `EnvelopePrintUtilities` APIを追加しました。
- 単体HTMLへ戻す作業は標準フローではありません。

## 検証

```bash
tools/verify.sh
```

版数表示を更新する場合は、手作業で複数ファイルを書き換えず、以下を使います。

```bash
node tools/sync_version.js v39-2 "pinned backup target" "Pinned Backup Target"
```

保存・復元sanitizeの代表ケースは、ブラウザで以下を開いて確認します。

```text
tests/storage_restore_tests.html
```

## 注意

分割版は複数ファイル構成です。Teams、SharePoint、OneDrive、メール添付で配布する場合は、フォルダごとzip化して展開してから `index.html` を開いてください。

`file://` 直開きで動くよう classic script 方式にしていますが、職場PCのセキュリティ設定によって外部JS/CSS読込が制限される場合があります。その場合だけ、単体HTML再結合版を別途作る判断をします。

## v38-6 core分割 stage1

`js/10_core.js` から、依存順を壊しにくい領域として `js/20_registries.js` と `js/30_storage.js` を切り出しました。

- `20_registries.js`: FieldSource / Step3 / Step5 / PrintExecution / InputValidation / InputData / SampleData Registry
- `40_templates.js`: テンプレート定義・field生成
- `42_layout_math.js`: fitText・矩形調整・印字幅推定
- `45_render_fields.js`: field単体描画
- `46_render_envelope.js`: envelope描画・ラベル面付け・印刷スタック生成
- `47_print.js`: 印刷前チェック・印刷実行制御・印刷試行履歴
- `48_step1_template_ui.js`: Step1テンプレート選択カード、選択、複製、削除、未調整ガイド
- `48_step3_input_core.js`: Step3全体描画、手入力フォーム、入力データ収集/復元/クリア、入力ペイン切替
- `48_step3_queue_ui.js`: Step3キュー・住所録・履歴・Excel貼付取込UI
- `48_step4_test_print_ui.js`: Step4テスト印刷・プリンタ補正UI
- `48_step5_final_print_ui.js`: Step5本印刷プレビューUI
- `30_storage.js`: 保存・復元・sanitize・バックアップ・容量管理
- `10_core.js`: 状態、公開モジュール索引などを継続保持

読み込み順は `00_pdf_loader` → `05_utilities` → `06_keyboard_overlay` → `15_address_data` → `20_registries` → `40_templates` → `41_parts_actions` → `42_layout_math` → `43_background_assets` → `44_edit_canvas_controller` → `45_render_fields` → `46_render_envelope` → `47_print` → `48_step_navigation` → `48_step2_edit_ui` → `48_step1_template_ui` → `48_step3_input_core` → `48_step3_queue_ui` → `48_step4_test_print_ui` → `48_step5_final_print_ui` → `49_wizard` → `30_storage` → `52_data_management_ui` → `53_adjustment_status` → `54_common_ui_binder` → `91_runtime_error_trap` → `92_click_safety` → `93_click_fallback` → `94_self_diagnostics` → `10_core` → `90_bootstrap` → Stage5-8 です。Address Data FormatterはRegistry登録関数から呼ばれるため、Registryより前に読み込みます。

## v38-7 Template/Field Model 分離

`10_core.js` から `js/40_templates.js` を切り出しました。対象は `ENVELOPE_SIZES`、`normalizeTpl()`、標準テンプレート、field自動生成、ラベル/避ける範囲の初期設定です。

読み込み順は `06_keyboard_overlay.js` → `15_address_data.js` → `20_registries.js` → `40_templates.js` → `30_storage.js` → `10_core.js` です。RegistryはAddress Data Formatterを実行時参照し、Storageの `load()` / 復元sanitizeは `initialTemplates()` / `normalizeTpl()` を参照するため、この順序を崩しません。

## v38-8 Layout Math分離

`10_core.js` から、描画本体ではなく純粋寄りのレイアウト計算関数を `js/42_layout_math.js` へ切り出しました。

- `overlap()`
- `adjustFieldRect()`
- `approxChar()`
- `estimatePrintCharUnits()`
- `wrapTextByPrintUnits()`
- `fitText()`

`renderNormalField()` / `renderZipField()` / `renderEnvelopeInto()` / ドラッグ処理はまだ `10_core.js` 側に残しています。

## v38-9 Field Render分離

`10_core.js` から field描画関数を `js/45_render_fields.js` へ分離しました。

分離対象:

- `renderNormalField()`
- `renderZipField()`
- 画像field描画
- 印影field描画
- 郵便番号field描画

`renderEnvelopeInto()`、ドラッグ処理、画面再描画制御はまだ `10_core.js` 側に残しています。

## v38-10 Envelope Render分離

`10_core.js` から `renderEnvelopeInto()`、ラベル面付け描画、印刷スタック生成を `js/46_render_envelope.js` に分離しました。

今回あえて残したもの:

- `renderEnvelope()` は画面状態・zoom・選択状態と密接なので `10_core.js` に残す
- `attachFieldDrag()` / `attachZoneDrag()` は当時coreに残したが、v38-20で `js/44_edit_canvas_controller.js` へ分離済み
- `doPrint()` は印刷実行制御・afterprint cleanup と密接なので `47_print.js` に分離済み

読み込み順は `41_parts_actions.js` → `43_background_assets.js` → `45_render_fields.js` → `46_render_envelope.js` → `47_print.js` → `48_step1_template_ui.js` → `48_step3_input_core.js` → `48_step3_queue_ui.js` → `30_storage.js` → `52_data_management_ui.js` → `53_adjustment_status.js` → `54_common_ui_binder.js` → `91_runtime_error_trap.js` → `92_click_safety.js` → `93_click_fallback.js` → `94_self_diagnostics.js` → `10_core.js` → `90_bootstrap.js` です。

## v38-11 追加

- `js/47_print.js`: 印刷前チェック、印刷実行制御、印刷試行履歴を分離。
- `js/46_render_envelope.js`: 印刷スタック描画を維持。

## v38-12 追加

- `js/48_steps_ui.js` を追加。
- ステップ進行、Step1〜5描画、入力フォーム、キュー、住所録、履歴、Excel貼付取込UIを `10_core.js` から分離。Step1はv38-26、Step3手入力coreはv38-28でさらに分離済み。
- `bindEvents()`、ウィザード本体、初期化は依存が強いため当時 `10_core.js` に残置したが、v38-21で `js/90_bootstrap.js` へ分離済み。ドラッグ操作はv38-20で `js/44_edit_canvas_controller.js` へ分離済み。

## v38-13 追加

- `js/49_wizard.js` を追加し、位置合わせウィザード一式を `10_core.js` から分離
- `openWizard()` / `closeWizard()` / `renderWizard()` / `renderWzStep1()`〜`renderWzStep8()` / `commitWizardDraft()` をWizard Controllerへ集約
- 保存キー・保存スキーマ・field.source名は変更なし

## v38-14 Core残存責務棚卸し

`10_core.js` に残る関数を分類し、次に切り出す順序を `docs/core_residual_inventory.md` に整理しました。

## v38-15 Address Data Formatter分離

Address Data Formatterを js/15_address_data.js へ分離し、宛名整形・サンプルデータ・field text解決入口をcoreから切り出し

- README履歴整合性のため、v38-80 Closeoutで明示セクションとして補完
- 詳細な責務・検証状況は `APP_RELEASE_NOTES`、`docs/global_scope_policy.md`、関連テストを参照
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-16 Address Data Formatter是正

`js/15_address_data.js` を追加し、宛名・差出人データ整形、サンプルデータ、field text解決入口を `10_core.js` から分離しました。当時の次候補だった `js/43_background_assets.js` はv38-18で分離済みです。

## v38-17 Keyboard / Overlay分離

`10_core.js` から `js/06_keyboard_overlay.js` を切り出しました。対象は以下です。

- `closeTopOverlayByEscape()`
- `setupEscapeToCloseOverlays()`
- `setupKeyboard()`

この分離は、ESCでのモーダル/ウィザード閉じ、Step2での矢印キー微調整を一箇所に集約するためのものです。`bindEvents()`、ドラッグ編集、保存形式、印刷ロジックは変更していません。

`06_keyboard_overlay.js` は IIFE + strict + 明示 `window` export 形式です。実行時に `wizardState`、`state`、`getCurrentTpl()`、`closeWizard()` などへ接続します。

## v38-18 Background Assets分離

`10_core.js` から `js/43_background_assets.js` を切り出しました。対象は以下です。

- `compressImageDataUrl()`
- `loadBackgroundFileInto()`
- `fileToDataURL()`
- `loadBackgroundPDF()`
- `loadBackgroundImage()`
- `setBackgroundOnTpl()`
- 背景画像圧縮定数 `BG_MAX_LONG_EDGE` / `BG_JPEG_QUALITY`

Step2詳細編集と位置合わせウィザードの両方から背景取込を使うため、coreではなく独立したBackground Assets Controllerとして扱います。保存キー・保存形式・field.source名は変更していません。

画像/PDFのMIME typeが空になる環境に備え、拡張子 `.pdf` / `.png` / `.jpg` / `.jpeg` / `.gif` / `.webp` / `.bmp` でも判定します。

## v38-19 Data Management UI分離

`10_core.js` から `js/52_data_management_ui.js` を切り出しました。対象は以下です。

- `showHelp()`
- `showDataMgmt()`
- `getModuleOverview()`

ヘルプ表示、バックアップ管理、旧開発キー掃除UI、手動JSONコピー/復元、疑似モジュール概要をData Management UI Controllerへ集約しました。`bindEvents()` と初期化順序はv38-21で `js/90_bootstrap.js` へ分離済みです。保存キー・保存形式・field.source名は変更していません。

読み込み順は `30_storage.js` → `52_data_management_ui.js` → `53_adjustment_status.js` → `10_core.js` → `90_bootstrap.js` です。`showDataMgmt()` はStorage APIを呼びますが、実行はボタンクリック時のため、state本体はcore側に残しています。

## v38-20 Edit Canvas Controller分離

`10_core.js` から `js/44_edit_canvas_controller.js` を切り出しました。対象は以下です。

- `getMMperPxOf()` / `getMMperPx()`
- `getDragPoint()` / `isPrimaryDragStart()` / `preventDragDefault()`
- `addDragDocumentListeners()` / `removeDragDocumentListeners()`
- `attachFieldDrag()` / `attachZoneDrag()`
- `startAddZone()`
- `startEnvelopeZoneDraft()` / `attachEnvelopeZoneDraftHandler()`

詳細編集画面の描画入口である `renderEnvelope()` は、v38-20ではcore側に残していましたが、v38-23で `js/44_edit_canvas_controller.js` へ分離しました。

読み込み順は `43_background_assets.js` → `44_edit_canvas_controller.js` → `45_render_fields.js` → `46_render_envelope.js` → `10_core.js` です。`45_render_fields.js` と `46_render_envelope.js` は実行時に `attachFieldDrag()` / `attachZoneDrag()` を参照するため、Edit Canvas Controllerを先に読み込みます。保存キー・保存形式・field.source名は変更していません。

## v38-21 Bootstrap分離

`bindEvents()` と起動順序を `js/90_bootstrap.js` へ分離しました。

分離対象:

- `bindEvents()`
- `selectLastUsedTemplate()`
- `initializeApp()`
- 起動順序 `load()` → `setupKeyboard()` → `setupEscapeToCloseOverlays()` → `bindEvents()` → `selectLastUsedTemplate()` → `goToStep(1)` → `updateStorageStatus()`

`tests/bootstrap_unit_tests.js` を追加し、起動順序と最終使用テンプレート復元を検証します。既存動作を維持するため、`90_bootstrap.js` は `10_core.js` の直後、Stage5〜8 addonの直前に読み込みます。保存キー・保存形式・field.source名は変更していません。

## v38-22 Parts Actions分離

`10_core.js` から `js/41_parts_actions.js` を切り出しました。対象は以下です。

- `createSenderFields()`
- `createStampField()`
- `refreshPartsActionUi()`
- `addSenderBlockToCurrentTpl()`
- `addStampToCurrentTpl()`
- `handleAddStampClick()`

差出人欄・スタンプfield生成と、現在テンプレートへの追加操作をParts Actions Controllerへ集約しました。Stage5が有効な場合にスタンプライブラリへ委譲する既存挙動は `handleAddStampClick()` で維持しています。保存キー・保存形式・field.source名は変更していません。

`tests/parts_actions_unit_tests.js` を追加し、縦書き/横書きの差出人field生成、stamp source/customText契約、追加時の保存・再描画hook、Stage5委譲を検証します。読み込み順は `40_templates.js` → `41_parts_actions.js` → `42_layout_math.js` → ... → `10_core.js` → `90_bootstrap.js` です。

## v38-23 Edit Canvas Render分離

`10_core.js` から詳細編集画面の描画入口 `renderEnvelope()` を `js/44_edit_canvas_controller.js` へ移しました。

分離対象:

- `renderEnvelope()`

v38-20で分離済みだったmm換算・ドラッグ・避ける範囲作成と合わせ、Step2編集キャンバスの入口をEdit Canvas Controllerへ寄せています。`renderEnvelopeInto()`、field単体描画、印刷スタック描画は従来どおり別ファイルに残し、保存キー・保存形式・field.source名は変更していません。

`tests/edit_canvas_controller_unit_tests.js` に `renderEnvelope()` のテストを追加し、`tools/verify_structure.js` でcore側に定義が残っていないことを検証します。依存関係の棚卸しは `docs/step2_edit_canvas_inventory.md` に記録しました。

## v38-24 Adjustment Status分離

`10_core.js` から調整ステータス判定 `getTplAdjustmentSummary()` を `js/53_adjustment_status.js` へ移しました。

分離対象:

- `getTplAdjustmentSummary()`

この関数は、背景位置合わせ、郵便番号確認、レイアウト確認、テスト印刷確認、プリンタ補正済み判定を集約します。`state` 本体、プリンタ補正データ、背景データの置き場は移動せず、判定関数だけを小さな状態判定モジュールへ分離しました。保存キー・保存形式・field.source名は変更していません。

`tests/adjustment_status_unit_tests.js` を追加し、タイムスタンプがレイアウト変更後かどうかの判定、背景有無、プリンタ補正値、`printerCheckedAt` による補正済み判定を検証します。読み込み順は `52_data_management_ui.js` → `53_adjustment_status.js` → `10_core.js` です。

## v38-25 Stage5〜8 Addon棚卸し

Stage5〜8 addon層について、機能挙動は変更せず、今後の分割・改修前に必要な依存関係を固定しました。

追加内容:

- `docs/stage_addons_inventory.md`: Stage5〜8 addonの責務、保存キー、Registry接続、読込順、リスクを整理
- `tests/stage_addons_unit_tests.js`: addon保存キー、IIFE/strict、DOMContentLoaded初期化、Registry接続、getFieldText非上書き、読込順を静的検証
- `tools/verify_structure.js`: Stage5→6→7→8→audit markerの順序と保存キー維持を構造検証に追加

保存キー・保存形式・`field.source` 名は変更していません。

次候補は Step3入力・キューUI の分割です。Stage6〜8の入力拡張hookと密接なため、先にStep3依存棚卸しを作るのが安全です。

## v38-26 Step1 Template UI分離

`js/48_steps_ui.js` からStep1テンプレート選択UIを `js/48_step1_template_ui.js` へ分離しました。

分離対象:

- `renderStep1()`
- `handleTplCardClick()`
- `showUnadjustedGuide()`
- `duplicateTpl()`

Step進行、Step2〜5描画、Step3入力・キューUIは当時 `js/48_steps_ui.js` に残していました。v38-28でStep3手入力coreをさらに分離済みです。保存キー・保存形式・`field.source` 名は変更していません。

追加検証:

- `tests/step1_template_ui_unit_tests.js`
- `docs/step1_template_ui_inventory.md`
- `tools/verify_structure.js` の読込順・残存定義チェック

次候補は Step3入力・キューUI の棚卸しと分離です。

## v38-27 Step3 Input Queue棚卸し

Step3入力・キュー・住所録・履歴・Excel貼付取込は、Stage6〜8 addonのhookや拡張項目保持と絡むため、v38-27では機能分離せず、先に契約を固定しました。

追加したものは以下です。

- `docs/step3_input_queue_inventory.md`
- `tests/step3_input_queue_inventory_tests.js`

固定した主な契約は以下です。

- `renderStep3()` / `renderInputForm()` / `getInputData()` / `loadAddrToInput()` / `clearInput()` の存在
- `Step3ExtensionRegistry` / `InputDataExtensionRegistry` hookの維持
- `cloneQueueItemFromRecord()` が限定コピーではなくJSON深いコピーで拡張項目を保持すること
- キュー上下移動・削除後に `save()` / `renderQueue()` / `renderSteps()` を呼ぶこと
- Excel貼付取込の郵便番号・住所・法人・連名・差出人項目マッピングを維持すること

保存キー・保存形式・`field.source` 名は変更していません。次回分離するなら、まず `48_step3_input_core.js` と `48_step3_queue_ui.js` に分けるのが安全です。

## v38-28 Step3 Input Core分離

`js/48_steps_ui.js` からStep3手入力coreを `js/48_step3_input_core.js` へ分離しました。

分離対象:

- `renderStep3()`
- `renderInputForm()`
- `getInputData()`
- `loadAddrToInput()`
- `clearInput()`
- `switchInputPane()`

キュー、住所録、履歴、Excel貼付取込は引き続き `js/48_steps_ui.js` に残しています。`Step3ExtensionRegistry` / `InputDataExtensionRegistry` のhook、入力データキー、保存形式は変更していません。

追加検証:

- `tests/step3_input_core_unit_tests.js`
- `docs/step3_input_core_inventory.md`
- `tools/verify_structure.js` の読込順・残存定義チェック

次候補は `48_step3_queue_ui.js` です。`cloneQueueItemFromRecord()` のJSON深いコピー契約を維持しながら、キュー表示・上下移動・削除・履歴追加を切り出すのが安全です。

## v38-29 Version Sync Guard

配布ZIP名、README、manifest、画面表示、core定数、リリースノートの版数が食い違う問題を是正しました。

- `index.html` の `<title>` / 画面上の `logo-sub` / 冒頭コメントを v38-29 へ同期
- `js/10_core.js` の `APP_RELEASE_LABEL` / `APP_MODULE_API_VERSION` を v38-29 へ同期
- `APP_RELEASE_NOTES` に v38-25〜v38-29 を追記
- `tools/sync_version.js` を追加し、版数更新の手作業漏れを減らす導線を追加
- `tools/verify_structure.js` と `tests/version_sync_unit_tests.js` に版数同期検証を追加

保存キー・保存形式・`field.source` 名は変更していません。

## v38-30 Step1 Event Binder Split

`90_bootstrap.js` に残っていたStep1固定ボタンのイベント接続を `js/48_step1_template_ui.js` へ移しました。

- `bindEventsForStep1()` を追加
- `newTplCta` / `newReplyCta` / `step1Next` の接続をStep1 UI Controller側へ委譲
- `90_bootstrap.js` は `bindEventsForStep1()` を呼ぶだけに縮小
- `tests/step1_template_ui_unit_tests.js` に固定ボタンevent binderの検証を追加
- `tools/verify_structure.js` に「BootstrapがStep1固定ボタンリスナーを直接持たないこと」の検証を追加

保存キー・保存形式・`field.source` 名は変更していません。

## v38-31 Step3 Event Binder Split

`90_bootstrap.js` に残っていたStep3固定イベント接続を `js/48_step3_input_core.js` へ移しました。

- `bindEventsForStep3()` を追加
- `step3Back` / `step3Next` / 入力タブ / `btnAddQueue` / `btnSaveToAddrbook` / `btnClearInput` / `abSearch` / `btnClearQueue` / `btnClearHistory` の接続をStep3 Input Core側へ委譲
- `90_bootstrap.js` は `bindEventsForStep3()` を呼ぶだけに縮小
- `EnvelopePrintModules.Step3Input` を追加し、Step3入力系の公開APIを整理
- `tests/step3_input_core_unit_tests.js` と `tools/verify_structure.js` にStep3 event binder検証を追加

保存キー・保存形式・`field.source` 名は変更していません。

## v38-32 Step3 Queue UI分離

Step3キュー・住所録・履歴・Excel貼付取込を js/48_step3_queue_ui.js へ分離し、公開APIにStep3Queue区分を追加

- README履歴整合性のため、v38-80 Closeoutで明示セクションとして補完
- 詳細な責務・検証状況は `APP_RELEASE_NOTES`、`docs/global_scope_policy.md`、関連テストを参照
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-33 Step4/Step5 UI分離

Step4テスト印刷・プリンタ補正UIを js/48_step4_test_print_ui.js へ、Step5本印刷プレビューUIを js/48_step5_final_print_ui.js へ分離し、固定イベント接続もStep側へ移動

- README履歴整合性のため、v38-80 Closeoutで明示セクションとして補完
- 詳細な責務・検証状況は `APP_RELEASE_NOTES`、`docs/global_scope_policy.md`、関連テストを参照
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-34 Step Navigation分離

ステップ一覧描画・進行可否・ステップ遷移を js/48_step_navigation.js へ分離し、Step具体UIとの委譲境界を整理

- README履歴整合性のため、v38-80 Closeoutで明示セクションとして補完
- 詳細な責務・検証状況は `APP_RELEASE_NOTES`、`docs/global_scope_policy.md`、関連テストを参照
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-35 Step2 Edit UI Split

`js/48_steps_ui.js` に残っていたStep2詳細編集UIを `js/48_step2_edit_ui.js` へ分離しました。

- `renderStep2()` / `renderFieldList()` / `renderZipConfig()` / `renderZoneList()` / `renderBgUI()` を移動
- `EnvelopePrintModules.Step2Edit` と `getModuleOverview().Step2Edit` を追加
- `tests/step2_edit_ui_unit_tests.js` と `docs/step2_edit_ui_inventory.md` を追加
- `tools/verify_structure.js` にStep2関数の残存定義チェック、読込順、公開API検証を追加

保存キー・保存形式・`field.source` 名は変更していません。

## v38-36 Step2 Event Binder Split

`90_bootstrap.js` に残っていたStep2固定イベント接続を `js/48_step2_edit_ui.js` の `bindEventsForStep2()` へ移しました。

- `btnReWizard` / `btnUnlock` / Step2戻る・次へ / 基本情報入力 / 背景取込 / ズーム / 編集モード切替 / envelopeクリック / 避ける範囲作成handlerをStep2側に集約
- `90_bootstrap.js` は `bindEventsForStep2()` を呼ぶだけに縮小
- `48_steps_ui.js` は通常関数・イベント接続を持たない履歴マーカーとして明示
- 保存キー・保存形式・`field.source` 名は変更なし

## v38-37 Common UI Binder分離

ヘルプ・データ管理・表示モード切替の共通event binderを js/54_common_ui_binder.js へ分離し、90_bootstrap.js を起動委譲役へさらに縮小

- README履歴整合性のため、v38-80 Closeoutで明示セクションとして補完
- 詳細な責務・検証状況は `APP_RELEASE_NOTES`、`docs/global_scope_policy.md`、関連テストを参照
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-38 Retired Steps UI / Inventory Generator

履歴マーカーとして残っていた `js/48_steps_ui.js` を完全に退役しました。

- `index.html` から `js/48_steps_ui.js` の読込を削除
- `split_manifest.json` とREADMEのファイル構成から退役ファイルを削除
- 既存のStep1〜5 / Step進行 / Step3キュー系テストを、退役ファイル不在を前提に更新
- `tests/retired_steps_ui_unit_tests.js` を追加
- `tools/regenerate_inventory.js` を追加し、`docs/core_residual_inventory.md` を現行ソースから再生成可能に変更

保存キー・保存形式・`field.source` 名は変更していません。

## v38-39 Inventory Docs Consolidation

個別の棚卸しdocsを docs/refactor_inventory_archive.md に統合し、最新台帳と過去メモの参照先を整理した

- README履歴整合性のため、v38-80 Closeoutで明示セクションとして補完
- 詳細な責務・検証状況は `APP_RELEASE_NOTES`、`docs/global_scope_policy.md`、関連テストを参照
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-40 IIFE Strict Phase1

00_pdf_loader・42_layout_math・99_audit_markerをIIFE + strict化し、Layout Mathの明示exportと検証を追加した

- README履歴整合性のため、v38-80 Closeoutで明示セクションとして補完
- 詳細な責務・検証状況は `APP_RELEASE_NOTES`、`docs/global_scope_policy.md`、関連テストを参照
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-41 IIFE Strict Phase2

45_render_fields・46_render_envelope・47_printをIIFE + strict化し、描画/印刷系の明示exportと公開API索引を更新した

- README履歴整合性のため、v38-80 Closeoutで明示セクションとして補完
- 詳細な責務・検証状況は `APP_RELEASE_NOTES`、`docs/global_scope_policy.md`、関連テストを参照
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-42 IIFE Strict Phase3

40_templatesをIIFE + strict化し、Template Modelの明示exportと公開API索引を更新した

- README履歴整合性のため、v38-80 Closeoutで明示セクションとして補完
- 詳細な責務・検証状況は `APP_RELEASE_NOTES`、`docs/global_scope_policy.md`、関連テストを参照
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-43 IIFE Strict Phase4

20_registriesをIIFE + strict化し、Registry Coreの明示exportと公開API索引を更新した

- README履歴整合性のため、v38-80 Closeoutで明示セクションとして補完
- 詳細な責務・検証状況は `APP_RELEASE_NOTES`、`docs/global_scope_policy.md`、関連テストを参照
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-44 IIFE Strict Phase5

`js/90_bootstrap.js` を IIFE + strict 化しました。

- 起動順序 `load()` → `setupKeyboard()` → `setupEscapeToCloseOverlays()` → `bindEvents()` → `selectLastUsedTemplate()` → `goToStep(1)` → `updateStorageStatus()` は維持
- Step別・共通UI別のイベント委譲順は維持
- 既存互換のため `bindEvents()` / `selectLastUsedTemplate()` / `initializeApp()` は従来どおり `window` へ明示export
- まとまった公開入口として `EnvelopePrintBootstrap` を維持
- `tests/iife_strict_phase5_tests.js` を追加し、IIFE + strict、互換export、起動順序、verify連携を検証

保存キー・保存形式・`field.source` 名は変更していません。

## v38-45 IIFE Strict Phase6

`js/49_wizard.js` を IIFE + strict 化しました。

- 位置合わせウィザードの公開入口を `window` へ明示export
- 既存互換のため `openWizard()` / `closeWizard()` / `renderWizard()` / `wizardNext()` / `commitWizardDraft()` などの従来グローバル参照を維持
- `wizardState` は内部状態として閉じつつ、既存の `06_keyboard_overlay.js` / `30_storage.js` からの参照を壊さないよう `window.wizardState` アクセサで互換維持
- まとまった公開入口として `EnvelopePrintWizard` を追加
- `EnvelopePrintModules.Wizard` と `getModuleOverview().Wizard` を更新
- `tests/iife_strict_phase6_tests.js` を追加し、IIFE + strict、互換export、`wizardState` 互換、verify連携を検証

保存キー・保存形式・`field.source` 名は変更していません。

## v38-46 IIFE Strict Phase7

`js/05_utilities.js` を IIFE + strict 化しました。

- 通知・コピー・a11y・モーダル・表示補助系の公開入口を `window` へ明示export
- 既存互換のため `$()` / `uid()` / `toast()` / `escapeHtml()` / `formatBytes()` / `fmtDate()` / `showAppAlert()` / `showAppConfirm()` / `showAppPrompt()` / `copyTextToClipboard()` などの従来グローバル参照を維持
- まとまった公開入口として `EnvelopePrintUtilities` を追加
- `EnvelopePrintModules.Utilities` と `getModuleOverview().Utilities` を更新
- `tests/iife_strict_phase7_tests.js` を追加し、IIFE + strict、互換export、軽量VMロード、verify連携を検証

保存キー・保存形式・`field.source` 名は変更していません。

## v38-47 IIFE Strict Phase8

`js/15_address_data.js` を IIFE + strict 化しました。

- 宛名・差出人データ整形、サンプルデータ、field text解決入口の公開関数を `window` へ明示export
- 既存互換のため `joinLines()` / `buildOrgText()` / `buildOrgFullText()` / `buildNameWithHonor()` / `buildSenderText()` / `normalizeAddressData()` / `defaultDataForTemplate()` / `getFieldText()` / `getSampleData()` の従来グローバル参照を維持
- まとまった公開入口として `EnvelopePrintAddressData` を追加
- `EnvelopePrintModules.AddressData` と `getModuleOverview().AddressData` を更新
- `tests/iife_strict_phase8_tests.js` を追加し、IIFE + strict、互換export、軽量VMロード、Registry実行時参照、verify連携を検証

保存キー・保存形式・`field.source` 名は変更していません。

## v38-48 IIFE Strict Phase9

`js/53_adjustment_status.js` を IIFE + strict Phase9 として再整備しました。

- 調整ステータス判定 `getTplAdjustmentSummary()` の従来グローバル参照を維持
- まとまった公開入口として `EnvelopePrintAdjustmentStatus` を追加
- `state.selectedPrinterId` / `getBgImage()` / `getPrinterCorrection()` / `hasAnyCorrection()` は引き続き実行時参照
- `EnvelopePrintModules.AdjustmentStatus` と `getModuleOverview().AdjustmentStatus` を追加
- `tests/iife_strict_phase9_tests.js` を追加し、IIFE + strict、互換export、軽量VMロード、タイムスタンプ判定契約、verify連携を検証

保存キー・保存形式・`field.source` 名は変更していません。

## v38-49 IIFE Strict Phase10

54_common_ui_binderをIIFE + strict Phase10として再整備し、Common UI Binderの明示APIと概要索引の検証を強化した

- README履歴整合性のため、v38-80 Closeoutで明示セクションとして補完
- 詳細な責務・検証状況は `APP_RELEASE_NOTES`、`docs/global_scope_policy.md`、関連テストを参照
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-50 IIFE Strict Phase11

`js/41_parts_actions.js` を Parts Actions の Phase11対象として再整備しました。

- `EnvelopePrintPartsActions` を追加
- `createSenderFields()` / `createStampField()` / `refreshPartsActionUi()` / `addSenderBlockToCurrentTpl()` / `addStampToCurrentTpl()` / `handleAddStampClick()` の互換exportを維持
- Stage5スタンプライブラリへの委譲契約を維持
- 保存キー・保存形式・field.source名は変更なし
- `tests/iife_strict_phase11_tests.js` を追加

## v38-51 IIFE Strict Phase12

`js/52_data_management_ui.js` を Data Management UI の Phase12対象として再整備しました。

- `EnvelopePrintDataManagementUI` を追加
- `showHelp()` / `showDataMgmt()` / `getModuleOverview()` の互換exportを維持
- ヘルプ表示・バックアップ管理・疑似モジュール概要の責務境界を維持
- 保存キー・保存形式・field.source名は変更なし
- `EnvelopePrintModules.DataManagementUI` と `getModuleOverview().DataManagementUI` を追加
- `tests/iife_strict_phase12_tests.js` を追加し、IIFE + strict、互換export、軽量VMロード、verify連携を検証

## v38-52 IIFE Strict Phase13

`js/30_storage.js` を Storage Core の Phase13対象として再整備しました。

- `EnvelopePrintStorageCore` を追加
- `dataSnapshot()` / `dataSnapshotForBackup()` / `save()` / `backupNow()` / `restoreFullBackupSafely()` / `load()` / `getStorageUsage()` などの互換exportを維持
- `beforeunload` による未保存・保存失敗保護を維持
- アドオン保存キー、現行保存キー、保存形式、field.source名は変更なし
- `EnvelopePrintModules.StorageCore` と `getModuleOverview().StorageCore` を追加
- `tests/iife_strict_phase13_tests.js` を追加し、IIFE + strict、互換export、軽量VMロード、保存キー契約、snapshot契約、verify連携を検証

## v38-53 IIFE Strict Phase14

`js/43_background_assets.js` を Background Assets の Phase14対象として再整備しました。

- `EnvelopePrintBackgroundAssets` を追加
- `compressImageDataUrl()` / `loadBackgroundFileInto()` / `fileToDataURL()` / `loadBackgroundPDF()` / `loadBackgroundImage()` / `setBackgroundOnTpl()` の互換exportを維持
- PDF読込有効判定、画像/PDF種別判定、永続背景と非永続背景の保存先契約を維持
- 保存キー・保存形式・field.source名は変更なし
- `EnvelopePrintModules.BackgroundAssets` と `getModuleOverview().BackgroundAssets` を追加
- `tests/iife_strict_phase14_tests.js` を追加し、IIFE + strict、互換export、軽量VMロード、背景反映契約、verify連携を検証

## v38-54 IIFE Strict Phase15

`js/44_edit_canvas_controller.js` を Edit Canvas Controller の Phase15対象として再整備しました。

- `EnvelopePrintEditCanvasController` を追加
- `renderEnvelope()` / `getMMperPxOf()` / `getMMperPx()` / `getDragPoint()` / `isPrimaryDragStart()` / `preventDragDefault()` / `attachFieldDrag()` / `attachZoneDrag()` / `startAddZone()` などの互換exportを維持
- field/zoneドラッグ、避ける範囲ドラフト作成、編集キャンバス描画入口の責務境界を維持
- 保存キー・保存形式・field.source名は変更なし
- `EnvelopePrintModules.EditCanvasController` と `getModuleOverview().EditCanvasController` を追加
- 既存の `EnvelopePrintModules.EditCanvas` は `EnvelopePrintEditCanvasController` へ委譲
- `tests/iife_strict_phase15_tests.js` を追加し、IIFE + strict、互換export、軽量VMロード、ドラッグヘルパー契約、verify連携を検証

## v38-55 IIFE Strict Phase16

`js/48_step_navigation.js` を Step Navigation の Phase16対象として再整備しました。

- `EnvelopePrintStepNavigation` を追加
- `getActiveSteps()` / `stepIndex()` / `renderSteps()` / `getStepStatus()` / `canSkipTo()` / `canGoToStep()` / `goToStep()` の互換exportを維持
- Step1〜5への遷移委譲、simple modeでStep2へ進ませない契約、Step描画後のa11y適用を維持
- 保存キー・保存形式・field.source名は変更なし
- `EnvelopePrintModules.StepNavigation` と `getModuleOverview().StepNavigation` を明示APIへ更新
- `tests/iife_strict_phase16_tests.js` を追加し、IIFE + strict、互換export、軽量VMロード、Step遷移契約、verify連携を検証

## v38-56 IIFE Strict Phase17

`js/48_step1_template_ui.js` を Step1 Template UI の Phase17対象として再整備しました。

- `EnvelopePrintStep1TemplateUI` を追加
- `bindEventsForStep1()` / `renderStep1()` / `handleTplCardClick()` / `showUnadjustedGuide()` / `duplicateTpl()` の互換exportを維持
- 新規テンプレート、返信用テンプレート、Step1次へボタンの固定イベント接続契約を維持
- テンプレート複製時の調整ステータス初期化、背景画像除外、field / zone ID再採番契約を維持
- 保存キー・保存形式・field.source名は変更なし
- `EnvelopePrintModules.Step1TemplateUI` と `getModuleOverview().Step1TemplateUI` を明示APIへ更新
- `tests/iife_strict_phase17_tests.js` を追加し、IIFE + strict、互換export、軽量VMロード、Step1固定ボタン契約、verify連携を検証

## v38-57 IIFE Strict Phase18

`js/48_step2_edit_ui.js` を Step2 Edit UI の Phase18対象として再整備しました。

- `EnvelopePrintStep2EditUI` を追加
- `renderStep2()` / `renderFieldList()` / `renderZipConfig()` / `renderZoneList()` / `renderBgUI()` / `bindEventsForStep2()` の互換exportを維持
- Step2詳細編集画面、field一覧、郵便番号詳細、避ける範囲一覧、背景UI、固定イベント接続の責務境界を維持
- 背景の永続/非永続切替、field追加、Step2固定ボタン、ドラッグ開始ハンドラ接続契約を維持
- 保存キー・保存形式・field.source名は変更なし
- `EnvelopePrintModules.Step2Edit` と `getModuleOverview().Step2Edit` を明示APIへ更新
- `tests/iife_strict_phase18_tests.js` を追加し、IIFE + strict、互換export、軽量VMロード、Step2固定イベント契約、verify連携を検証

## v38-58 IIFE Strict Phase19

`js/48_step3_input_core.js` を Step3 Input Core の Phase19対象として再整備しました。

- `EnvelopePrintStep3InputCore` を追加
- `renderStep3()` / `renderInputForm()` / `getInputData()` / `loadAddrToInput()` / `clearInput()` / `switchInputPane()` / `bindEventsForStep3()` の互換exportを維持
- Step3描画、手入力フォーム、入力データ収集/復元/クリア、入力ペイン切替、固定イベント接続の責務境界を維持
- `Step3ExtensionRegistry` / `InputDataExtensionRegistry` / `InputValidationRegistry` のhook契約を維持
- 保存キー・保存形式・field.source名・入力データキーは変更なし
- `EnvelopePrintModules.Step3Input` と `getModuleOverview().Step3Input` を明示APIへ更新
- `tests/iife_strict_phase19_tests.js` を追加し、IIFE + strict、互換export、軽量VMロード、入力hook契約、verify連携を検証

## v38-59 IIFE Strict Phase20

`js/48_step3_queue_ui.js` を Step3 Queue UI の Phase20対象として再整備しました。

- `EnvelopePrintStep3QueueUI` を追加
- `renderQueue()` / `cloneQueueItemFromRecord()` / `renderAddrbook()` / `renderHistory()` / `addToHistory()` / `renderPasteImport()` / `analyzePastedData()` / `renderPastePreview()` / `doImportPaste()` の互換exportを維持
- キュー、住所録、履歴、Excel貼付取込、重複候補スキップ、住所録取込後のペイン遷移契約を維持
- 保存キー・保存形式・field.source名・入力データキー・貼付取込マッピングは変更なし
- `EnvelopePrintModules.Step3Queue` と `getModuleOverview().Step3Queue` を明示APIへ更新
- `tests/iife_strict_phase20_tests.js` を追加し、IIFE + strict、互換export、軽量VMロード、キュー複製・履歴・貼付取込契約、verify連携を検証

## v38-60 IIFE Strict Phase21

`js/48_step4_test_print_ui.js` を Step4 Test Print UI の Phase21対象として再整備しました。

- `EnvelopePrintStep4TestPrintUI` を追加
- `renderStep4()` / `renderPrinterProfileSection()` / `updateStep4Summary()` / `bindEventsForStep4()` の互換exportを維持
- キュー不整合表示、プリンタ補正表示、試し刷りサンプル/先頭宛先/十字テスト、結果確認チェックの契約を維持
- 保存キー・保存形式・field.source名・印刷実行経路は変更なし
- `EnvelopePrintModules.Step4TestPrint` と `getModuleOverview().Step4TestPrint` を明示APIへ更新
- `tests/iife_strict_phase21_tests.js` を追加し、IIFE + strict、互換export、軽量VMロード、試し刷りUI契約、verify連携を検証

## v38-61 IIFE Strict Phase22

`js/48_step5_final_print_ui.js` を Step5 Final Print UI の Phase22対象として再整備しました。

- `EnvelopePrintStep5FinalPrintUI` を追加
- `renderStep5()` / `bindEventsForStep5()` の互換exportを維持
- 本番印刷サマリー、最終チェックリスト、印刷アクション、プレビュー、Step5ExtensionRegistry hook、Step5固定イベント接続の契約を維持
- 保存キー・保存形式・field.source名・印刷実行経路は変更なし
- `EnvelopePrintModules.Step5FinalPrint` と `getModuleOverview().Step5FinalPrint` を明示APIへ更新
- `tests/iife_strict_phase22_tests.js` を追加し、IIFE + strict、互換export、軽量VMロード、本番印刷UI契約、verify連携を検証

## v38-62 Browser Hotfix Save Picker

実機検証で見えたボタン無反応/保存導線課題を受け、Phase継続を止めてブラウザ検証前提のHotfixへ切替。showSaveFilePicker対応のJSONファイル保存導線を追加した

- README履歴整合性のため、v38-80 Closeoutで明示セクションとして補完
- 詳細な責務・検証状況は `APP_RELEASE_NOTES`、`docs/global_scope_policy.md`、関連テストを参照
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-63 Browser Hotfix Bootstrap Guard

実ブラウザのボタン無反応対策として、bootstrap初期化を次tickへ遅延し、イベントbinderを個別try/catchで保護。実行時エラー記録をバックアップ画面で確認・コピーできるようにした

- README履歴整合性のため、v38-80 Closeoutで明示セクションとして補完
- 詳細な責務・検証状況は `APP_RELEASE_NOTES`、`docs/global_scope_policy.md`、関連テストを参照
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-64 Browser Hotfix Navigation Guard

- `48_step_navigation.js` に `callStepRenderer()` / `reportStepNavigationError()` を追加し、Step遷移中の描画エラーを実行時エラー記録へ送るようにしました。
- `48_step1_template_ui.js` の未調整ガイドで「このまま宛先入力へ進む」を押した場合、モーダルを閉じるだけでなく Step3 へ実際に遷移するよう修正しました。
- `tests/browser_hotfix_navigation_guard_tests.js` を追加し、ボタン無反応に見える導線を静的検証に固定しました。

## v38-65 Browser Hotfix Click Fallback

- `90_bootstrap.js` に重要クリックの委譲フォールバックを追加し、Step遷移・ヘルプ・バックアップ・未調整ガイド・モーダル閉じボタンが直接イベント接続に失敗しても最低限動くようにしました。
- click handler guard を追加し、通常のクリックイベントが処理済みかどうかを記録して、未処理クリックだけをフォールバック対象にします。
- `52_data_management_ui.js` にクリック記録パネルを追加し、バックアップ画面から「クリック記録」を確認・コピーできるようにしました。
- `tests/browser_hotfix_click_fallback_tests.js` を追加し、Click Fallback、クリック記録、verify連携を検証します。

## v38-66 Browser Hotfix Handler Recovery

実機での「ボタンを押しても反応がない」症状に対する追加Hotfixです。

- click handler guard が `__paperPrintHandled` を handler 成功後にだけ付与するよう修正
- handler が例外で落ちた場合に、document fallback が救済できる余地を残すよう変更
- handler 例外を `handler-error` としてクリック記録にも残すよう追加
- バックアップ画面のクリック記録・コピー内容に handler error の文字列を表示
- `tests/browser_hotfix_handler_recovery_tests.js` を追加

保存キー・保存形式・`field.source` 名は変更していません。

## v38-67 Browser Hotfix Self Diagnostics

実機での「押したのに反応しない」症状をさらに切り分けやすくするため、起動後の主要UI自己診断を追加しました。

- `90_bootstrap.js` に `runInteractionSelfDiagnostics()` を追加
- 起動処理の最後に主要ボタン存在・active Step・Click Fallback / Handler Guard 初期化状態を診断
- 診断結果を `window.__envelopePrintSelfDiagnostics` に保持
- バックアップ画面に「UI自己診断」パネルを追加
- バックアップ画面から診断結果の再実行・コピーが可能
- `tests/browser_hotfix_self_diagnostics_tests.js` を追加

保存キー・保存形式・`field.source` 名は変更していません。

## v38-68 Browser Hotfix Step Navigation Diagnostics

- 左側のステップ一覧クリックにも `data-step-nav` を付与し、通常click handlerが落ちた場合でも Click Fallback がStep遷移を救済できるようにした。
- `goToStep()` 後に `scheduleInteractionSelfDiagnostics()` を走らせ、Step遷移直後の主要ボタン・activeDOM・activeNav状態を自己診断へ反映するようにした。
- UI自己診断に `activeNavStep` を追加し、`state.currentStep` / 中央コンテンツ / 左ステップ一覧のズレを検出・コピーできるようにした。
- `tests/browser_hotfix_step_nav_diagnostics_tests.js` を追加し、Stepナビfallback・遷移後診断・activeNav不一致検出を検証対象にした。

## v38-69 Browser Hotfix Action Fallback

- Step3 のキュー追加・住所録保存・貼付取込、Step4 の試し刷り、Step5 の最初から戻るを named action 化し、通常イベント接続が外れた場合でも Click Fallback から呼び出せるようにしました。
- `tests/browser_hotfix_action_fallback_tests.js` を追加し、主要アクションの fallback 経路、自己診断上の fallback eligible、公開API索引の更新を検証します。

## v38-70 Hotfix Retreat Guardrail

v38-65以降で入った EventTarget.prototype 差し替え型の click handler guard を撤去し、APP_V38_REFACTOR_GATES の「モンキーパッチ禁止」に戻しました。

- `EventTarget.prototype.addEventListener/removeEventListener` の差し替えを削除
- 代替として `safeBindClick()` を追加し、Step1〜5・共通UI・Stepナビ・貼付取込などの明示イベント接続で handler error を記録
- `routeCriticalClickFallback()` の巨大 `switch` を `CRITICAL_CLICK_ACTIONS` テーブル駆動へ置換
- UI自己診断の `Handler Guard` 表示を `safeBindClick` 表示へ変更
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-71 Hotfix Module Split

Hotfix層の集積場になっていた `90_bootstrap.js` を分割し、bootstrapを初期化順序とイベント委譲に戻しました。

- `js/91_runtime_error_trap.js` を追加し、実行時エラー記録・クリック/診断ログを分離
- `js/92_click_safety.js` を追加し、`safeBindClick()` とclick handler保護を分離
- `js/93_click_fallback.js` を追加し、`CRITICAL_CLICK_ACTIONS` と委譲fallbackを分離
- `js/94_self_diagnostics.js` を追加し、UI自己診断を分離
- `js/90_bootstrap.js` は起動順序、Step/Commonイベント委譲、初期Step表示に集中
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-72 Browser E2E Smoke

実機Hotfix連発の反省として、静的検証だけではなく Chromium 上で主要導線を実際にクリックするE2Eスモークテストを導入しました。

- `tests/browser_e2e_smoke_tests.js` を追加
- 外部npmに依存せず、Chromium DevTools Protocol を直接使用
- この環境では `file://` と `localhost` ページ表示がブロックされるため、`index.html` と css/js をインライン化して `about:blank` 上で実行
- `localStorage` はE2E用の最小shimを使い、DOM/Event/Step描画/クリック処理は実ブラウザで確認
- Step1テンプレート選択 → 未調整ガイド続行 → Step3宛名入力 → キュー追加 → Step4 → Step5 を自動検証
- runtime error記録と Chrome の `Runtime.exceptionThrown` が空であることを検証
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-73 Browser E2E Coverage

Browser E2E Smokeを拡張し、実機で不具合が出やすい詳細モードとバックアップ/診断画面まで自動検証対象にしました。

- `tests/browser_e2e_smoke_tests.js` を更新
- Chromium DevTools Protocolによる実DOM・実クリック検証は維持
- 詳細モード切替 → テンプレートカードの「詳細」 → Step2表示を検証
- Step2でテンプレート名変更と `btnAddField` によるフィールド追加を検証
- Step2 → Step3 → キュー追加 → Step4 → Step5 の通し操作を検証
- バックアップ管理モーダルを開き、JSONバックアップ欄・クリック記録・UI自己診断の表示を検証
- UI自己診断の再実行とモーダルクローズを検証
- runtime error記録と Chrome の `Runtime.exceptionThrown` が空であることを引き続き検証
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-74 Load Order Contract

`index.html` の外部 `script` / `link` 読込順を `load_order.json` で管理するようにしました。

- `load_order.json` を追加し、head/body-end の読込順をデータ化
- `tools/apply_load_order.js` を追加し、LOAD_ORDERブロックをJSONから再生成可能にした
- `tests/load_order_contract_tests.js` を追加し、index.htmlの実タグ順とload_order.jsonの一致を検証
- `tools/verify_structure.js` でLOAD_ORDERマーカー、外部asset順、sync_version連携を検証
- `tools/sync_version.js` が `load_order.json` のversionも同期するように更新
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-75 Browser E2E Background Assets

Browser E2E Smokeを背景画像/PDF取込まで拡張しました。静的テストだけでなく、Chromium上で実際に `File` / `FileReader` / `Image` / `canvas` 経路を通します。

- `tests/browser_e2e_smoke_tests.js` を更新
- Step2詳細編集画面で、実 `File` とPNGデータを使った画像背景取込を検証
- `bgPersist=true` 時に `tpl.bgImage` / `tpl.bgSourceName` / `tpl.bgBytes` へ永続保存されることを検証
- pdf.js の最小スタブをE2E内で立て、PDF背景取込経路をChromium上で検証
- `bgPersist=false` 時に `transientBg[tpl.id]` へ一時背景として保持され、`tpl.bgImage` に書かれないことを検証
- 背景バッジ・背景情報表示が `取込済` / `[保存中]` / `[一時]` を反映することを検証
- runtime error記録と Chrome の `Runtime.exceptionThrown` が空であることを引き続き検証
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-76 Backup File Open Picker

バックアップ管理画面に `showOpenFilePicker` 対応の JSONファイル読込導線を追加しました。

- `52_data_management_ui.js` に `openBackupJsonFromFile()` / `parseBackupJsonText()` / `restoreBackupJsonObjectWithConfirm()` を追加
- 対応ブラウザでは「JSONファイル読込」から `.json` ファイルを直接選択して復元可能
- `showOpenFilePicker` 未対応環境では、従来のテキスト貼付復元を維持しつつ file input fallback も用意
- テキスト貼付復元とファイル読込復元の確認・自動バックアップ・復元実行経路を共通化
- `tests/data_management_ui_unit_tests.js` で showOpenFilePicker 経路と復元前バックアップ契約を検証
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-77 IIFE Strict Phase23

`js/06_keyboard_overlay.js` を Keyboard / Overlay Controller の Phase23対象として再整備しました。

- `EnvelopePrintKeyboardOverlay` を追加し、ESC閉じ・キーボード微調整の公開APIを明示
- `closeTopOverlayByEscape()` / `setupEscapeToCloseOverlays()` / `setupKeyboard()` の互換グローバルexportを維持
- `wizardState` / `state` / `getCurrentTpl()` などの実行時参照を `global` 経由に整理し、軽量VMロード時の未定義参照を避けるよう補強
- `tests/iife_strict_phase23_tests.js` を追加し、ESCモーダル閉じ、Wizard中止確認、Step2矢印微調整、公開API索引を検証
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-78 IIFE Strict Phase24

`js/70_stage7_addon.js` を Stage7 Addon の Phase24対象として再整備しました。

- `EnvelopePrintStage7` を `Object.freeze()` された明示APIとして追加
- `buildRecipientFull()` / `getExtendedInputData()` / `loadExtendedInputData()` / `clearExtendedInputs()` / `buildPostcardBackFields()` / `buildNameBadgeFields()` / `buildReceiptFields()` / `addFields()` / `showUtilityModal()` / `showGuideModal()` などをAPIとして整理
- Stage7追加 `field.source`（`recipient_full` / `issue_no` / `serial` / `amount` / `memo` / `seal_text` / `image`）の登録契約を維持
- 重要クリックは `safeBindClick` 互換の `bindClick()` 経由に寄せ、Hotfix撤退後の明示イベント保護方針に合わせた
- `tests/iife_strict_phase24_tests.js` を追加し、軽量VMロード、Registry登録、Step3/InputData hook、帳票field source契約、公開API索引を検証
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-79 Core Contract Finalization

`js/10_core.js` を Core Contract の Phase25対象として再整備しました。

- `10_core.js` を IIFE + strict 化し、通常関数0件の契約定義ファイルとして固定
- `EnvelopePrintCoreContract` を追加し、保存キー・storage schema・Step配列・`state` / `transientBg` の参照入口を明示
- 既存互換のため、`APP_*` 定数、`STORAGE_KEY`、`BACKUP_KEY`、`STEPS_SIMPLE` / `STEPS_ADVANCED` は `global` へ明示export
- `state` / `transientBg` は getter/setter により、既存の直接参照・代入を維持
- `tests/iife_strict_phase25_tests.js` を追加し、Core Contract、保存キー不変、state/transientBg互換、公開API索引を検証
- 保存キー・保存形式・`field.source` 名は変更していません

## v38-80 Refactor Closeout

v38構造リファクタの完了整理版です。

- v38を構造リファクタ専用フェーズとして閉じる方針を明文化
- v39から機能フェーズへ移る判断を `APP_V38_CLOSEOUT_DECISION` に追加
- READMEリリース履歴の欠番・逆順を是正し、`tests/readme_release_history_tests.js` を追加
- `PAPERPRINT_REQUIRE_BROWSER_E2E=1` によるBrowser E2E必須モードを追加
- Runtime観察の正本として `EnvelopePrintRuntime` 名前空間を追加し、旧 `__envelopePrint*` は互換aliasとして維持
- 新規コードでは `state` / `transientBg` 直接参照を増やさず、Core Contract経由へ寄せる方針を明記
- 保存キー・保存形式・`field.source` 名は変更していません

## v39-1 Backup Capability UX

v39機能フェーズの開始版です。保存・復元の導線を、職場PCの制約を前提に分かりやすくしました。

- バックアップ管理画面に「保存環境診断」パネルを追加
- `showSaveFilePicker` / `showOpenFilePicker` / Blobダウンロード / 通常ファイル選択 / localStorage / clipboard の可否を判定
- 環境に応じて「推奨保存」「推奨復元」を表示
- 「診断結果をコピー」ボタンを追加し、保存できない環境の切り分け情報を共有しやすくした
- JSON保存ボタンを「推奨方式で保存」、JSON読込ボタンを「推奨方式で読込」に変更
- `EnvelopePrintDataManagementUI` に `detectBackupEnvironmentCapabilities` / `renderBackupEnvironmentPanel` / `buildBackupEnvironmentReport` を追加
- 保存キー・保存形式・`field.source` 名は変更していません

## v39-2 Pinned Backup Target

保存環境診断の次段階として、対応環境ではJSONバックアップの保存先を固定し、次回以降の上書き保存をワンクリック化しました。

- `saveBackupJsonToRememberedTarget()` を追加し、保存先固定済みなら同じJSONファイルへ直接上書き保存
- `chooseBackupJsonTargetAndSave()` を追加し、「保存先を指定/変更して保存」から保存先固定と初回保存を同時実行
- `rememberBackupFileHandle()` / `forgetBackupFileHandle()` / `getRememberedBackupTargetStatus()` を追加
- File System Access API の `FileSystemFileHandle` は可能な場合 `IndexedDB` に保持
- `IndexedDB` 不可環境ではセッション中のみ保存先を保持し、永続保持できないことを画面に表示
- バックアップ管理画面に「保存先固定」パネル、状態確認、固定解除ボタンを追加
- 既存の「推奨方式で保存」を「ワンクリック保存」に変更し、対応環境では保存先固定、未対応環境では従来保存へフォールバック
- `tests/data_management_ui_unit_tests.js` に保存先固定・再利用・保存先変更の検証を追加
- 保存キー・保存形式・`field.source` 名は変更していません


## v39-3 PDF Import Readiness

v39-3は、PDF背景取込に必要な実行ファイルを同梱し、zip展開後すぐにPDF背景取込を試せるようにした版です。

- `pdfjs-dist` 2.16.105 から `build/pdf.min.js` / `build/pdf.worker.min.js` を取得して同梱
- `pdf.min.js` / `pdf.worker.min.js` を `index.html` と同階層に配置
- `PDFJS_LICENSE.txt` を同梱し、pdf.js の Apache-2.0 ライセンスを明示
- `tools/download_pdfjs_runtime.ps1` / `tools/download_pdfjs_runtime.cmd` を追加し、必要時に同じファイルを再取得できるようにした
- 画像背景取込は従来どおり追加ファイルなしで利用可能
- 保存キー・保存形式・`field.source` 名は変更していません
