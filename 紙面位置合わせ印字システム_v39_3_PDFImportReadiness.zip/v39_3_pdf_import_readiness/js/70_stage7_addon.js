(function(global){
  'use strict';
  /* ============================================================
     Stage7 Addon
     目的：封筒以外への実用展開（はがき裏面・帳票追記・証明書・名札）と、
           日付/連番/番号/画像/印影フィールド、実機手順書の追加。
     方針：単一HTMLを維持し、既存機能を削らず後付けする。
     ============================================================ */
  if(global.__stage7AddonLoaded) return;
  global.__stage7AddonLoaded = true;
  const ADDON_KEY = 'paper_position_print_system_v37_stage7_addon';
  const $id = id => global.document && typeof global.document.getElementById === 'function' ? global.document.getElementById(id) : null;
  const esc = s => (global.escapeHtml ? global.escapeHtml(s) : String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])));
  const uid7 = p => (global.uid ? global.uid(p) : p+'_'+Math.random().toString(36).slice(2,9));
  function bindClick(el, handler, label){
    if(!el || typeof handler !== 'function') return false;
    if(global.safeBindClick) return global.safeBindClick(el, handler, label || (el.id ? `Stage7.${el.id}` : 'Stage7.click'));
    el.addEventListener('click', handler);
    return true;
  }
  const toastUser = (msg, kind) => { try{ if(global.toast) global.toast(msg, kind); }catch(_e){} };
  const alertUser = msg => global.showAppAlert ? global.showAppAlert(msg) : undefined;
  const confirmUser = (msg, title, opts) => global.showAppConfirm ? global.showAppConfirm(msg, title, opts) : Promise.resolve(true);
  const closeModal = modal => global.closeAccessibleModal ? global.closeAccessibleModal(modal) : modal && modal.remove && modal.remove();
  const todayJP = ()=>{ const d=new Date(); return `${d.getFullYear()}年${d.getMonth()+1}月${d.getDate()}日`; };
  const todayISO = ()=>{ const d=new Date(); const p=n=>String(n).padStart(2,'0'); return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`; };
  function loadAddon(){
    try{return JSON.parse(global.localStorage.getItem(ADDON_KEY)||'{}')}
    catch(e){
      // v37 step8: Stage7拡張データ破損を黙殺しない。fallback自体は従来どおり空データで継続する。
      console.warn('Stage7 addon load failed', e);
      return{};
    }
  }
  let addon = Object.assign({serialNext:1, issuePrefix:'', guideSeen:false}, loadAddon());
  function saveAddon(){
    addon.savedAt = Date.now();
    try{
      global.localStorage.setItem(ADDON_KEY, JSON.stringify(addon));
      return true;
    }catch(e){
      // v37 step8: 容量超過等で保存できない場合に処理全体を落とさず、原因を残す。
      console.warn('Stage7 addon save failed', e);
      toastUser('Stage7拡張データの保存に失敗しました','warn');
      return false;
    }
  }

  function registerSources(){
    // v37 step46: Stage7追加sourceのラベル・表示順もFieldSourceRegistry登録へ集約する。
    const registry = global.FieldSourceRegistry;
    if(registry && typeof registry.registerSource === 'function'){
      const labels = {
        recipient_full:'宛先まとめ', today:'今日の日付', date:'日付', issue_no:'発行番号', serial:'連番',
        amount:'金額', memo:'備考・本文', seal_text:'印影文字', image:'画像・印影'
      };
      const label = k => labels[k] || (global.getFieldSourceLabel ? global.getFieldSourceLabel(k) : k);
      const register = (key, resolver) => {
        if(typeof registry.hasSource === 'function' && registry.hasSource(key)) return;
        registry.registerSource(key, label(key), resolver);
      };
      register('recipient_full', (f,data)=>buildRecipientFull(data||{}));
      register('today', (f,data)=>todayJP());
      register('date', (f,data)=>(data&&data.issue_date) || todayJP());
      register('issue_no', (f,data)=>{
        data=data||{};
        return data.issue_no || (addon.issuePrefix ? addon.issuePrefix + String(addon.serialNext||1).padStart(4,'0') : 'No.____');
      });
      register('serial', (f,data)=>(data&&data.serial) || String(addon.serialNext||1).padStart(4,'0'));
      register('amount', (f,data)=>(data&&data.amount) || '金額');
      register('memo', (f,data)=>(data&&data.memo) || (f&&f.customText) || '備考');
      register('seal_text', (f,data)=>(f&&f.customText) || '印');
      register('image', (f,data)=>'');
    }
  }

  function buildRecipientFull(data){
    data = data || {};
    const org = (global.buildOrgFullText ? global.buildOrgFullText(data) : [data.company,data.dept,data.title].filter(Boolean).join('\n'));
    const nm = data.name ? (global.buildNameWithHonor ? global.buildNameWithHonor(data.name, data.honor) : data.name + (data.honor||'')) : '';
    const nm2 = data.name2 ? (global.buildNameWithHonor ? global.buildNameWithHonor(data.name2, data.honor2||data.honor) : data.name2 + (data.honor2||data.honor||'')) : '';
    return [org,nm,nm2].filter(Boolean).join('\n') || '［宛先］';
  }

  function getExtendedInputData(){
    return {
      issue_no: ($id('iIssueNo')?.value || '').trim(),
      issue_date: ($id('iIssueDate')?.value || '').trim(),
      serial: ($id('iSerial')?.value || '').trim(),
      amount: ($id('iAmount')?.value || '').trim(),
      memo: ($id('iMemo')?.value || '').trim()
    };
  }
  function loadExtendedInputData(a){
    a = a || {};
    const map = {iIssueNo:'issue_no',iIssueDate:'issue_date',iSerial:'serial',iAmount:'amount',iMemo:'memo'};
    Object.entries(map).forEach(([id,k])=>{ if($id(id) && a[k]!==undefined) $id(id).value = a[k] || ''; });
  }
  function clearExtendedInputs(){
    ['iIssueNo','iIssueDate','iSerial','iAmount','iMemo'].forEach(id=>{ if($id(id)) $id(id).value=''; });
  }
  function registerSampleData(){
    const registry = global.SampleDataRegistry;
    if(!registry || typeof registry.registerDefaults !== 'function') return;
    // v37 step24: Stage7追加sourceのプレビュー用値をSampleDataRegistryへ登録する。
    registry.registerDefaults({
      issue_no:'No.0001', issue_date:todayJP(), serial:String(addon.serialNext||1).padStart(4,'0'), amount:'金10,000円', memo:'これはプレビュー用の本文です。\n必要な文面に差し替えてください。'
    }, 'Stage7 extended sample defaults');
  }

  function patchDataAndText(){
    if(global.__stage7DataPatched) return;
    global.__stage7DataPatched = true;
    const inputExt = global.InputDataExtensionRegistry;
    if(inputExt && typeof inputExt.registerCollectHook === 'function'){
      // v36 Step4: getInputDataを上書きせず、InputDataExtensionRegistry経由でStage7追加入力を合流させる。
      inputExt.registerCollectHook(()=>getExtendedInputData(), 'Stage7.getExtendedInputData.collect');
    }else{
      console.warn('InputDataExtensionRegistry is not available. Stage7 collect hook was not registered.');
    }
    if(inputExt && typeof inputExt.registerLoadHook === 'function'){
      // v36 Step4: loadAddrToInputを上書きせず、読み込み時だけStage7追加入力欄へ反映する。
      inputExt.registerLoadHook(loadExtendedInputData, 'Stage7.loadExtendedInputData.load');
    }else{
      console.warn('InputDataExtensionRegistry is not available. Stage7 load hook was not registered.');
    }
    if(inputExt && typeof inputExt.registerClearHook === 'function'){
      // v36 Step4: clearInputを上書きせず、クリア時だけStage7追加入力欄を消す。
      inputExt.registerClearHook(clearExtendedInputs, 'Stage7.clearExtendedInputs.clear');
    }else{
      console.warn('InputDataExtensionRegistry is not available. Stage7 clear hook was not registered.');
    }
    // Step5: Stage7のgetFieldTextモンキーパッチを停止済み。
    // Stage7追加sourceはregisterSources()でFieldSourceRegistryへ登録済みのため、
    // 本体getFieldText -> Registry -> postProcessor の一本化された経路で解決する。
  }

  function makeField(def){
    return Object.assign({id:uid7('f'),label:'項目',x:20,y:20,w:50,h:12,fontSize:12,vertical:false,bold:false,source:'custom',anchor:'tl',autoFit:true}, def||{});
  }
  function currentTpl(){ try{return global.getCurrentTpl ? global.getCurrentTpl() : null}catch{return null} }
  function addFields(fields){
    const t = currentTpl();
    if(!t){ alertUser('先にテンプレートを選択してください'); return; }
    if(t.locked){ alertUser('テンプレートがロックされています。詳細モードでロック解除してください。'); return; }
    t.fields.push(...fields.map(makeField));
    if(global.markLayoutChanged) global.markLayoutChanged(t);
    if(global.save) global.save();
    if(global.renderFieldList) global.renderFieldList();
    if(global.renderEnvelope) global.renderEnvelope();
    if($id('fldBadge')) $id('fldBadge').textContent = t.fields.length;
    if(global.toast) global.toast('項目を追加しました','ok');
  }

  function readImageFile(file){
    return new Promise((resolve,reject)=>{
      const reader = new global.FileReader();
      reader.onerror = reject;
      reader.onload = ()=>{
        const img = new global.Image();
        img.onload = ()=>{
          const max=900; let w=img.naturalWidth, h=img.naturalHeight;
          const ratio = Math.min(1, max/Math.max(w,h)); w=Math.round(w*ratio); h=Math.round(h*ratio);
          const cv=global.document.createElement('canvas'); cv.width=w; cv.height=h;
          cv.getContext('2d').drawImage(img,0,0,w,h);
          resolve(cv.toDataURL('image/png'));
        };
        img.onerror = reject; img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  function patchImageRendering(){
    // v37 step19: 画像・印影文字描画は本体renderNormalFieldへ統合済み。互換のため初期化呼び出しだけ残す。
  }

  function injectExtendedInputs(){
    if(!global.document || typeof global.document.querySelector !== 'function') return;
    const manual = global.document.querySelector('.input-pane[data-pane="manual"]');
    if(!manual || $id('stage7ExtendedInputs')) return;
    const anchor = $id('stage6AddressAssistPanel') || manual.querySelector('#inputForm') || manual.firstChild;
    const box = global.document.createElement('details');
    box.id='stage7ExtendedInputs'; box.className='stage7-fieldbox';
    box.innerHTML = `<summary style="cursor:pointer;font-weight:700">帳票・証明書・名札用の追加入力</summary>
      <div class="row r2" style="margin-top:8px"><div><label>発行番号・受付番号</label><input type="text" id="iIssueNo" placeholder="例：R7-001"></div><div><label>日付</label><input type="text" id="iIssueDate" placeholder="例：${todayJP()}"></div></div>
      <div class="row r2"><div><label>連番</label><input type="text" id="iSerial" placeholder="例：0001"></div><div><label>金額</label><input type="text" id="iAmount" placeholder="例：12,345円"></div></div>
      <div class="row"><label>備考・本文</label><textarea id="iMemo" placeholder="帳票追記、証明書本文、名札メモなど"></textarea></div>
      <div class="stage7-actions"><button class="btn sm ghost" id="stage7TodayBtn">日付を今日にする</button><button class="btn sm ghost" id="stage7NextSerialBtn">次の連番を入れる</button></div>`;
    if(anchor && anchor.parentNode) anchor.parentNode.insertBefore(box, anchor.nextSibling); else manual.appendChild(box);
    bindClick($id('stage7TodayBtn'), ()=>{ if($id('iIssueDate')) $id('iIssueDate').value=todayJP(); }, 'Stage7.stage7TodayBtn');
    bindClick($id('stage7NextSerialBtn'), ()=>{ const n=addon.serialNext||1; if($id('iSerial')) $id('iSerial').value=String(n).padStart(4,'0'); addon.serialNext=n+1; saveAddon(); }, 'Stage7.stage7NextSerialBtn');
  }

  function patchStep3(){
    if(global.__stage7Step3Patched) return; global.__stage7Step3Patched = true;
    const step3Ext = global.Step3ExtensionRegistry;
    if(step3Ext && typeof step3Ext.registerRenderHook === 'function'){
      // v31 Step5: Stage7もrenderStep3を上書きせず、Step3ExtensionRegistry経由で追加入力欄を注入する。
      step3Ext.registerRenderHook(injectExtendedInputs, 'Stage7.injectExtendedInputs.render');
    }else{
      console.warn('Step3ExtensionRegistry is not available. Stage7 render hook was not registered.');
    }
    if(step3Ext && typeof step3Ext.registerManualPaneHook === 'function'){
      // v31 Step5: manualタブ復帰時もRegistry経由で帳票・証明書・名札用入力欄を再注入する。
      step3Ext.registerManualPaneHook(injectExtendedInputs, 'Stage7.injectExtendedInputs.manual');
    }else{
      console.warn('Step3ExtensionRegistry is not available. Stage7 manual hook was not registered.');
    }
    if(global.setTimeout) global.setTimeout(injectExtendedInputs,0);
  }

  function registerPaperPresets(){
    if(typeof global.ENVELOPE_SIZES !== 'undefined'){
      global.ENVELOPE_SIZES['はがき・カード'] = global.ENVELOPE_SIZES['はがき・カード'] || [];
      if(!global.ENVELOPE_SIZES['はがき・カード'].some(x=>x.kind==='postcard_back')) global.ENVELOPE_SIZES['はがき・カード'].push({n:'郵便はがき 裏面・通信面',w:100,h:148,note:'通信面・案内文・日付・差出人',kind:'postcard_back'});
      global.ENVELOPE_SIZES['帳票・追記'] = global.ENVELOPE_SIZES['帳票・追記'] || [];
      if(!global.ENVELOPE_SIZES['帳票・追記'].some(x=>x.kind==='name_badge')) global.ENVELOPE_SIZES['帳票・追記'].push({n:'名札・席札カード',w:91,h:55,note:'名札・席札・管理カード',kind:'name_badge'});
      if(!global.ENVELOPE_SIZES['帳票・追記'].some(x=>x.kind==='form_receipt')) global.ENVELOPE_SIZES['帳票・追記'].push({n:'A4受付控え・管理票',w:210,h:297,note:'受付番号・日付・担当者・備考',kind:'form_receipt'});
    }
    // v37 step20: buildFieldsForPresetのStage7追加kind処理は本体へ統合済み。
    // ここでは用紙サイズ一覧への追加だけを行い、関数上書きはしない。
  }
  function buildPostcardBackFields(w,h){
    return [
      makeField({label:'見出し',x:12,y:15,w:w-24,h:14,fontSize:18,bold:true,source:'custom',customText:'ご案内',anchor:'mc'}),
      makeField({label:'本文',x:14,y:40,w:w-28,h:58,fontSize:11,source:'memo',anchor:'tl'}),
      makeField({label:'日付',x:w-48,y:108,w:36,h:8,fontSize:9,source:'date',anchor:'mr'}),
      makeField({label:'差出人',x:16,y:118,w:w-32,h:15,fontSize:8,source:'sender_full',anchor:'br'})
    ];
  }
  function buildNameBadgeFields(w,h){
    return [
      makeField({label:'部署',x:6,y:5,w:w-12,h:8,fontSize:8,source:'dept',anchor:'mc'}),
      makeField({label:'氏名',x:6,y:17,w:w-12,h:20,fontSize:20,bold:true,source:'name',anchor:'mc'}),
      makeField({label:'役職',x:6,y:39,w:w-12,h:7,fontSize:8,source:'title',anchor:'mc'}),
      makeField({label:'番号',x:6,y:48,w:w-12,h:5,fontSize:6,source:'issue_no',anchor:'bc'})
    ];
  }
  function buildReceiptFields(w,h){
    return [
      makeField({label:'受付番号',x:25,y:22,w:50,h:8,fontSize:11,source:'issue_no',anchor:'ml'}),
      makeField({label:'受付日',x:w-75,y:22,w:52,h:8,fontSize:10,source:'date',anchor:'mr'}),
      makeField({label:'宛名',x:28,y:54,w:w-56,h:12,fontSize:12,source:'recipient_full',anchor:'tl'}),
      makeField({label:'金額',x:38,y:88,w:70,h:10,fontSize:12,source:'amount',anchor:'ml'}),
      makeField({label:'備考',x:30,y:h-72,w:w-60,h:34,fontSize:10,source:'memo',anchor:'tl'}),
      makeField({label:'印',x:w-45,y:h-52,w:18,h:18,fontSize:12,bold:true,source:'seal_text',customText:'印',anchor:'mc'})
    ];
  }

  function addStage7Buttons(){
    if(!global.document || typeof global.document.querySelector !== 'function') return;
    const topbar = global.document.querySelector('.topbar'); const ref=$id('btnHelp');
    if(!topbar || $id('stage7UtilityBtn')) return;
    const b=global.document.createElement('button'); b.className='stage7-top-btn'; b.id='stage7UtilityBtn'; b.textContent='用途拡張';
    const g=global.document.createElement('button'); g.className='stage7-top-btn'; g.id='stage7GuideBtn'; g.textContent='手順';
    topbar.insertBefore(b,ref); topbar.insertBefore(g,ref);
    bindClick(b, showUtilityModal, 'Stage7.stage7UtilityBtn'); bindClick(g, showGuideModal, 'Stage7.stage7GuideBtn');
  }

  async function addImageFieldFromPicker(){
    const inp=global.document.createElement('input'); inp.type='file'; inp.accept='image/*';
    inp.onchange=async()=>{
      const file=inp.files && inp.files[0]; if(!file) return;
      try{
        const data=await readImageFile(file);
        const bytes=global.estimateDataUrlBytes ? global.estimateDataUrlBytes(data) : Math.ceil(String(data||'').length * 0.75);
        // 画像・印影はテンプレート内に保持されるため、保存容量への影響をユーザーへ明示する。
        if(bytes > 250*1024 && !await confirmUser(`画像データが大きめです（約${global.formatBytes ? global.formatBytes(bytes) : `${bytes} bytes`}）。保存容量を圧迫する可能性があります。追加しますか？`,'画像容量の確認',{okLabel:'追加する',danger:true})) return;
        addFields([makeField({label:'画像・印影',x:30,y:30,w:30,h:22,fontSize:10,source:'image',imageData:data,imageBytes:bytes,anchor:'mc',autoFit:false})]);
      }catch(e){ alertUser('画像の読込に失敗しました'); }
    };
    inp.click();
  }
  function showUtilityModal(){
    const modal=global.document.createElement('div'); modal.className='modal-overlay';
    modal.innerHTML = `<div class="modal-box" style="min-width:860px"><h3>用途拡張・帳票部品</h3>
      <p>封筒以外へ流用するためのセット項目を追加します。テンプレートを選択し、ロック解除した状態で実行してください。</p>
      <div class="stage7-tabbar"><button class="active" data-tab="sets">セット追加</button><button data-tab="fields">単項目</button><button data-tab="paper">用紙用途</button></div>
      <div id="stage7ModalBody"></div><div class="actions"><button class="btn ghost" id="stage7Close">閉じる</button></div></div>`;
    global.document.body.appendChild(modal);
    global.applyLegacyModalA11y && global.applyLegacyModalA11y(modal,{title:'用途拡張・帳票部品', initialFocus:'#stage7Close'});
    const body=modal.querySelector('#stage7ModalBody');
    function tab(name){
      modal.querySelectorAll('[data-tab]').forEach(x=>x.classList.toggle('active',x.dataset.tab===name));
      if(name==='sets') body.innerHTML = `<div class="stage7-grid">
        <div class="stage7-card"><h4>帳票追記セット</h4><p>受付番号、日付、備考欄、印影文字を追加します。</p><button class="btn sm primary" id="s7AddFormSet">追加</button></div>
        <div class="stage7-card"><h4>証明書セット</h4><p>宛名まとめ、本文、日付、印影文字を追加します。</p><button class="btn sm primary" id="s7AddCertSet">追加</button></div>
        <div class="stage7-card"><h4>名札・席札セット</h4><p>部署、氏名、役職、番号を中央配置で追加します。</p><button class="btn sm primary" id="s7AddBadgeSet">追加</button></div>
        <div class="stage7-card"><h4>はがき裏面セット</h4><p>見出し、本文、日付、差出人を追加します。</p><button class="btn sm primary" id="s7AddPostcardBackSet">追加</button></div>
      </div>`;
      else if(name==='fields') body.innerHTML = `<div class="stage7-grid">
        <div class="stage7-card"><h4>発行番号</h4><p>入力欄の発行番号を印字します。</p><button class="btn sm" id="s7AddIssue">追加</button></div>
        <div class="stage7-card"><h4>今日の日付</h4><p>印刷時の日付を自動表示します。</p><button class="btn sm" id="s7AddToday">追加</button></div>
        <div class="stage7-card"><h4>備考・本文</h4><p>追加入力欄の備考・本文を印字します。</p><button class="btn sm" id="s7AddMemo">追加</button></div>
        <div class="stage7-card"><h4>印影文字</h4><p>簡易的な丸印・角印風の文字枠を追加します。</p><button class="btn sm" id="s7AddSealText">追加</button></div>
        <div class="stage7-card"><h4>画像・印影</h4><p>印影画像・ロゴ画像を配置します。</p><button class="btn sm" id="s7AddImage">画像を選ぶ</button></div>
      </div>`;
      else body.innerHTML = `<div class="stage7-callout">新しいテンプレート作成画面に「郵便はがき 裏面・通信面」「名札・席札カード」「A4受付控え・管理票」を追加しました。これらは封筒以外の紙面位置合わせ用途です。</div>
      <table class="stage7-guide-table"><tr><th>用途</th><th>狙い</th></tr><tr><td>はがき裏面</td><td>案内文・日付・差出人など通信面への印字</td></tr><tr><td>名札</td><td>氏名を大きく中央配置、部署や役職を補助表示</td></tr><tr><td>管理票</td><td>受付番号・日付・備考・印影など帳票追記</td></tr></table>`;
      bindModalButtons();
      // v37 step49: Stage7独自タブをtablist/tabpanelとして同期し、表示切替後もaria-selectedを更新する。
      global.applyCustomTabbarA11y && global.applyCustomTabbarA11y(modal.querySelector('.stage7-tabbar'), {tabAttr:'tab', panel:body, label:'用途拡張・帳票部品の切替'});
      global.applyLabelForA11y && global.applyLabelForA11y(body);
      global.applyTableA11y && global.applyTableA11y(body);
    }
    function bindModalButtons(){
      bindClick(modal.querySelector('#s7AddFormSet'), ()=>addFields([
        {label:'受付番号',x:25,y:22,w:50,h:8,fontSize:11,source:'issue_no',anchor:'ml'}, {label:'日付',x:140,y:22,w:48,h:8,fontSize:10,source:'date',anchor:'mr'}, {label:'備考',x:30,y:235,w:150,h:25,fontSize:10,source:'memo',anchor:'tl'}, {label:'印',x:170,y:250,w:20,h:20,fontSize:12,source:'seal_text',customText:'印',anchor:'mc',bold:true}
      ]), 'Stage7.s7AddFormSet');
      bindClick(modal.querySelector('#s7AddCertSet'), ()=>addFields([
        {label:'宛名まとめ',x:45,y:75,w:207,h:18,fontSize:16,source:'recipient_full',anchor:'mc',bold:true}, {label:'証明本文',x:50,y:112,w:197,h:38,fontSize:12,source:'memo',anchor:'mc'}, {label:'日付',x:170,y:166,w:75,h:8,fontSize:10,source:'date',anchor:'mr'}, {label:'印',x:238,y:162,w:20,h:20,fontSize:12,source:'seal_text',customText:'印',anchor:'mc',bold:true}
      ]), 'Stage7.s7AddCertSet');
      bindClick(modal.querySelector('#s7AddBadgeSet'), ()=>addFields([
        {label:'部署',x:8,y:6,w:75,h:7,fontSize:8,source:'dept',anchor:'mc'}, {label:'氏名',x:8,y:18,w:75,h:18,fontSize:20,source:'name',anchor:'mc',bold:true}, {label:'役職',x:8,y:40,w:75,h:7,fontSize:8,source:'title',anchor:'mc'}, {label:'番号',x:8,y:49,w:75,h:5,fontSize:6,source:'issue_no',anchor:'bc'}
      ]), 'Stage7.s7AddBadgeSet');
      bindClick(modal.querySelector('#s7AddPostcardBackSet'), ()=>addFields(buildPostcardBackFields(100,148)), 'Stage7.s7AddPostcardBackSet');
      bindClick(modal.querySelector('#s7AddIssue'), ()=>addFields([{label:'発行番号',x:20,y:20,w:50,h:8,fontSize:10,source:'issue_no',anchor:'ml'}]), 'Stage7.s7AddIssue');
      bindClick(modal.querySelector('#s7AddToday'), ()=>addFields([{label:'今日の日付',x:20,y:32,w:55,h:8,fontSize:10,source:'today',anchor:'ml'}]), 'Stage7.s7AddToday');
      bindClick(modal.querySelector('#s7AddMemo'), ()=>addFields([{label:'備考・本文',x:20,y:44,w:100,h:25,fontSize:10,source:'memo',anchor:'tl'}]), 'Stage7.s7AddMemo');
      bindClick(modal.querySelector('#s7AddSealText'), ()=>addFields([{label:'印影文字',x:30,y:30,w:20,h:20,fontSize:12,source:'seal_text',customText:'印',anchor:'mc',bold:true}]), 'Stage7.s7AddSealText');
      bindClick(modal.querySelector('#s7AddImage'), addImageFieldFromPicker, 'Stage7.s7AddImage');
    }
    modal.querySelectorAll('[data-tab]').forEach(b=>bindClick(b, ()=>tab(b.dataset.tab), `Stage7.tab.${b.dataset.tab}`));
    bindClick(modal.querySelector('#stage7Close'), ()=>closeModal(modal), 'Stage7.stage7Close');
    bindClick(modal, e=>{ if(e.target===modal) closeModal(modal); }, 'Stage7.modalBackdrop');
    tab('sets');
  }

  function showGuideModal(){
    const modal=global.document.createElement('div'); modal.className='modal-overlay';
    modal.innerHTML = `<div class="modal-box" style="min-width:880px"><h3>実機テスト・完成品との差分ガイド</h3>
      <p>販売用完成品との差を埋めるには、機能追加だけでなく「実際に紙へ出した検証」が必要です。</p>
      <table class="stage7-guide-table"><tr><th>段階</th><th>確認内容</th><th>合格基準</th></tr>
        <tr><td>1</td><td>封筒：長3/角2で郵便番号・宛名のテスト印刷</td><td>郵便番号枠から大きくズレない。再印刷で再現する。</td></tr>
        <tr><td>2</td><td>ラベル：12面/24面の開始面指定</td><td>使いかけラベルでも狙った面から印字される。</td></tr>
        <tr><td>3</td><td>窓付き封筒：A4三つ折り位置</td><td>窓から宛名が切れずに見える。</td></tr>
        <tr><td>4</td><td>帳票追記：既存様式スキャンへの位置合わせ</td><td>受付番号・日付・備考が枠内に収まる。</td></tr>
        <tr><td>5</td><td>証明書/名札：氏名の長短</td><td>長い氏名でも崩れず、自動調整が効く。</td></tr>
      </table>
      <div class="stage7-callout">次の完成品化工程：プリンタ設定ガイドの図解、住所録のグループ管理、物理モジュール分割版、テスト結果記録シート。</div>
      <div class="actions"><button class="btn ghost" id="stage7GuideClose">閉じる</button></div></div>`;
    global.document.body.appendChild(modal);
    global.applyLegacyModalA11y && global.applyLegacyModalA11y(modal,{title:'実機テスト・完成品との差分ガイド', initialFocus:'#stage7GuideClose'});
    bindClick(modal.querySelector('#stage7GuideClose'), ()=>closeModal(modal), 'Stage7.stage7GuideClose');
    bindClick(modal, e=>{ if(e.target===modal) closeModal(modal); }, 'Stage7.modalBackdrop');
  }

  function init(){
    registerSources(); registerSampleData(); patchDataAndText(); patchImageRendering(); patchStep3(); registerPaperPresets(); addStage7Buttons(); injectExtendedInputs();
    global.EnvelopePrintStage7 = EnvelopePrintStage7;
    if(global.EnvelopePrintModules && global.EnvelopePrintModules.Extensions) global.EnvelopePrintModules.Extensions.Stage7 = EnvelopePrintStage7;
  }

  const EnvelopePrintStage7 = Object.freeze({
    addon,
    saveAddon,
    registerSources,
    buildRecipientFull,
    getExtendedInputData,
    loadExtendedInputData,
    clearExtendedInputs,
    registerSampleData,
    injectExtendedInputs,
    registerPaperPresets,
    buildPostcardBackFields,
    buildNameBadgeFields,
    buildReceiptFields,
    addFields,
    addImageFieldFromPicker,
    showUtilityModal,
    showGuideModal,
    init
  });
  global.EnvelopePrintStage7 = EnvelopePrintStage7;

  if(global.document && global.document.readyState === 'loading') global.document.addEventListener('DOMContentLoaded', init);
  else if(global.document) init();
})(typeof window !== 'undefined' ? window : globalThis);
