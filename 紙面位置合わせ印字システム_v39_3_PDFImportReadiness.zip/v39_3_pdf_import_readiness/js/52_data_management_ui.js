(function(global){
  'use strict';

/* ============================================================
   v38-19: Help / Data Management UI Controller
   - showHelp(): 使い方・開発メモ・構造メモ表示
   - showDataMgmt(): バックアップ管理・手動復元・旧キー掃除UI
   - getModuleOverview(): EnvelopePrintModules.overview 用の疑似モジュール一覧

   classic script / IIFE + explicit window export.
   保存キー・保存形式・field.source名は変更しない。
   ============================================================ */



const BACKUP_TARGET_DB_NAME = 'paper_position_print_backup_target_v1';
const BACKUP_TARGET_STORE_NAME = 'handles';
const BACKUP_TARGET_RECORD_KEY = 'json-backup-target';
let rememberedBackupTargetHandle = null;
let rememberedBackupTargetMeta = null;

function isIndexedDbAvailable(){
  try{return !!(global.indexedDB && typeof global.indexedDB.open === 'function');}
  catch(_e){return false;}
}
function openBackupTargetDb(){
  if(!isIndexedDbAvailable()) return Promise.resolve(null);
  return new Promise((resolve, reject)=>{
    let req;
    try{ req = global.indexedDB.open(BACKUP_TARGET_DB_NAME, 1); }
    catch(err){ reject(err); return; }
    req.onupgradeneeded = ()=>{
      const db = req.result;
      if(db && !db.objectStoreNames.contains(BACKUP_TARGET_STORE_NAME)) db.createObjectStore(BACKUP_TARGET_STORE_NAME, {keyPath:'id'});
    };
    req.onsuccess = ()=>resolve(req.result || null);
    req.onerror = ()=>reject(req.error || new Error('IndexedDB open failed'));
  });
}
function idbRequestToPromise(req){
  return new Promise((resolve, reject)=>{
    req.onsuccess = ()=>resolve(req.result);
    req.onerror = ()=>reject(req.error || new Error('IndexedDB request failed'));
  });
}
async function putBackupTargetRecord(record){
  const db = await openBackupTargetDb();
  if(!db) return {ok:false, unsupported:true};
  try{
    const tx = db.transaction(BACKUP_TARGET_STORE_NAME, 'readwrite');
    tx.objectStore(BACKUP_TARGET_STORE_NAME).put(record);
    await new Promise((resolve, reject)=>{
      tx.oncomplete = resolve;
      tx.onerror = ()=>reject(tx.error || new Error('IndexedDB transaction failed'));
      tx.onabort = ()=>reject(tx.error || new Error('IndexedDB transaction aborted'));
    });
    if(typeof db.close === 'function') db.close();
    return {ok:true};
  }catch(err){
    try{ if(db && typeof db.close === 'function') db.close(); }catch(_e){}
    throw err;
  }
}
async function getBackupTargetRecord(){
  if(rememberedBackupTargetHandle) return {ok:true, source:'session', handle:rememberedBackupTargetHandle, meta:rememberedBackupTargetMeta || {}};
  const db = await openBackupTargetDb();
  if(!db) return {ok:false, unsupported:true};
  try{
    const tx = db.transaction(BACKUP_TARGET_STORE_NAME, 'readonly');
    const record = await idbRequestToPromise(tx.objectStore(BACKUP_TARGET_STORE_NAME).get(BACKUP_TARGET_RECORD_KEY));
    if(typeof db.close === 'function') db.close();
    if(record && record.handle){
      rememberedBackupTargetHandle = record.handle;
      rememberedBackupTargetMeta = {fileName:record.fileName || '', savedAt:record.savedAt || null, updatedAt:record.updatedAt || null};
      return {ok:true, source:'indexeddb', handle:record.handle, meta:rememberedBackupTargetMeta};
    }
    return {ok:false, missing:true};
  }catch(err){
    try{ if(db && typeof db.close === 'function') db.close(); }catch(_e){}
    throw err;
  }
}
async function deleteBackupTargetRecord(){
  const db = await openBackupTargetDb();
  if(!db) return {ok:false, unsupported:true};
  try{
    const tx = db.transaction(BACKUP_TARGET_STORE_NAME, 'readwrite');
    tx.objectStore(BACKUP_TARGET_STORE_NAME).delete(BACKUP_TARGET_RECORD_KEY);
    await new Promise((resolve, reject)=>{
      tx.oncomplete = resolve;
      tx.onerror = ()=>reject(tx.error || new Error('IndexedDB transaction failed'));
      tx.onabort = ()=>reject(tx.error || new Error('IndexedDB transaction aborted'));
    });
    if(typeof db.close === 'function') db.close();
    return {ok:true};
  }catch(err){
    try{ if(db && typeof db.close === 'function') db.close(); }catch(_e){}
    throw err;
  }
}
async function rememberBackupFileHandle(handle, meta){
  if(!handle) return {ok:false, missingHandle:true};
  const now = Date.now();
  const info = Object.assign({}, meta || {}, {savedAt:(meta && meta.savedAt) || now, updatedAt:now});
  rememberedBackupTargetHandle = handle;
  rememberedBackupTargetMeta = info;
  try{
    const persisted = await putBackupTargetRecord(Object.assign({id:BACKUP_TARGET_RECORD_KEY, handle}, info));
    return {ok:true, persisted:!!(persisted && persisted.ok), fileName:info.fileName || ''};
  }catch(err){
    console.warn('backup target persistence failed', err);
    return {ok:true, persisted:false, persistenceError:String(err && err.message || err), fileName:info.fileName || ''};
  }
}
async function forgetBackupFileHandle(){
  rememberedBackupTargetHandle = null;
  rememberedBackupTargetMeta = null;
  try{return await deleteBackupTargetRecord();}
  catch(err){
    console.warn('backup target delete failed', err);
    return {ok:false, error:String(err && err.message || err)};
  }
}
async function ensureBackupFileHandleWritablePermission(handle){
  if(!handle) return false;
  const permissionOptions = {mode:'readwrite'};
  try{
    if(typeof handle.queryPermission === 'function'){
      const current = await handle.queryPermission(permissionOptions);
      if(current === 'granted') return true;
      if(current === 'denied' && typeof handle.requestPermission !== 'function') return false;
    }
    if(typeof handle.requestPermission === 'function'){
      return await handle.requestPermission(permissionOptions) === 'granted';
    }
    return true;
  }catch(err){
    console.warn('backup target permission check failed', err);
    return false;
  }
}
async function writeBackupJsonToFileHandle(handle, json, mimeType){
  if(!handle || typeof handle.createWritable !== 'function') throw new Error('writable file handle is required');
  const writable = await handle.createWritable();
  const BlobCtor = global.Blob || Blob;
  await writable.write(new BlobCtor([json], {type:mimeType || 'application/json'}));
  await writable.close();
}
async function getRememberedBackupTargetStatus(){
  const status = {supported:typeof global.showSaveFilePicker === 'function', persistence:isIndexedDbAvailable(), remembered:false, fileName:'', permission:'unknown', source:''};
  if(!status.supported) return status;
  try{
    const record = await getBackupTargetRecord();
    if(!record || !record.ok || !record.handle) return status;
    status.remembered = true;
    status.fileName = (record.meta && record.meta.fileName) || record.handle.name || '';
    status.source = record.source || '';
    if(typeof record.handle.queryPermission === 'function') status.permission = await record.handle.queryPermission({mode:'readwrite'});
    else status.permission = 'not-required';
  }catch(err){
    status.error = String(err && err.message || err);
  }
  return status;
}
async function saveBackupJsonToRememberedTarget(snapshot, options){
  const opt = options || {};
  if(typeof global.showSaveFilePicker !== 'function'){
    if(opt.fallback === false) return {ok:false, unsupported:true, method:'remembered-file-handle'};
    return saveBackupJsonToFile(snapshot, opt);
  }
  const data = snapshot || dataSnapshotForBackup();
  const json = JSON.stringify(data, null, 2);
  const fileName = opt.fileName || buildBackupFileName();
  const mimeType = 'application/json';
  if(!opt.forcePicker){
    try{
      const record = await getBackupTargetRecord();
      if(record && record.ok && record.handle){
        const allowed = await ensureBackupFileHandleWritablePermission(record.handle);
        if(allowed){
          await writeBackupJsonToFileHandle(record.handle, json, mimeType);
          rememberedBackupTargetMeta = Object.assign({}, rememberedBackupTargetMeta || {}, {fileName:(record.meta && record.meta.fileName) || record.handle.name || fileName, updatedAt:Date.now()});
          return {ok:true, method:'remembered-file-handle', fileName:rememberedBackupTargetMeta.fileName || fileName, persisted:record.source === 'indexeddb'};
        }
      }
    }catch(err){
      console.warn('remembered backup target failed; picker fallback will be used', err);
      if(opt.allowPicker === false && opt.fallback === false) throw err;
    }
  }
  if(opt.allowPicker === false){
    return {ok:false, missingTarget:true, method:'remembered-file-handle'};
  }
  try{
    const handle = await global.showSaveFilePicker({
      suggestedName:fileName,
      types:[{description:'JSONバックアップ', accept:{'application/json':['.json']}}]
    });
    const savedName = handle && handle.name ? handle.name : fileName;
    await rememberBackupFileHandle(handle, {fileName:savedName});
    await writeBackupJsonToFileHandle(handle, json, mimeType);
    return {ok:true, method:'remembered-file-handle-new', fileName:savedName, persisted:isIndexedDbAvailable()};
  }catch(err){
    if(err && err.name === 'AbortError') return {ok:false, canceled:true, method:'remembered-file-handle'};
    throw err;
  }
}
async function chooseBackupJsonTargetAndSave(snapshot, options){
  return saveBackupJsonToRememberedTarget(snapshot, Object.assign({}, options || {}, {forcePicker:true, allowPicker:true, fallback:false}));
}
function renderRememberedBackupTargetPanel(){
  return `<div style="background:#fff;border:1px solid rgba(147,51,234,.18);padding:9px;margin:0 0 10px;font-size:12px">
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
      <strong style="color:#7c3aed">保存先固定</strong>
      <span id="dmBackupTargetStatus" style="color:#666">確認中...</span>
      <button class="btn sm ghost" id="dmRefreshBackupTarget" style="margin-left:auto">状態確認</button>
    </div>
    <div style="margin-top:6px;color:#666;font-size:11px">対応環境では、初回に保存先を選ぶと次回から同じJSONファイルへ上書き保存できます。未対応環境では従来のダウンロード保存に切り替わります。</div>
  </div>`;
}
async function refreshBackupTargetStatusPanel(root){
  const scope = root || document;
  const el = scope.querySelector && scope.querySelector('#dmBackupTargetStatus');
  if(!el) return null;
  const status = await getRememberedBackupTargetStatus();
  if(!status.supported){
    el.innerHTML = '<span style="color:var(--warn);font-weight:700">このブラウザでは保存先固定不可</span>';
  }else if(status.remembered){
    const persist = status.persistence ? '次回起動後も保持' : 'この画面を開いている間だけ保持';
    el.innerHTML = `<span style="color:#166534;font-weight:700">設定済み</span>：${escapeHtml(status.fileName || 'JSONバックアップ')} / 権限 ${escapeHtml(status.permission || 'unknown')} / ${escapeHtml(persist)}`;
  }else{
    const persist = status.persistence ? '保存先はIndexedDBに保持可能' : 'IndexedDBなしのためセッション中のみ保持';
    el.innerHTML = `<span style="color:#666;font-weight:700">未設定</span>：初回保存時に保存先を選択します / ${escapeHtml(persist)}`;
  }
  return status;
}

function buildBackupFileName(){
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  return `paper_position_print_backup_${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}.json`;
}

function downloadTextFileFallback(text, fileName, mimeType){
  const BlobCtor = global.Blob || Blob;
  const URLApi = global.URL || URL;
  const blob = new BlobCtor([text], {type: mimeType || 'application/json'});
  const url = URLApi.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  setTimeout(()=>{
    URLApi.revokeObjectURL(url);
    if(a.parentNode) a.parentNode.removeChild(a);
  }, 0);
}

async function saveBackupJsonToFile(snapshot, options){
  const opt = options || {};
  const data = snapshot || dataSnapshotForBackup();
  const json = JSON.stringify(data, null, 2);
  const fileName = opt.fileName || buildBackupFileName();
  const mimeType = 'application/json';
  if(typeof global.showSaveFilePicker === 'function'){
    try{
      const handle = await global.showSaveFilePicker({
        suggestedName: fileName,
        types: [{ description: 'JSONバックアップ', accept: { 'application/json': ['.json'] } }]
      });
      const writable = await handle.createWritable();
      const BlobCtor = global.Blob || Blob;
      await writable.write(new BlobCtor([json], {type: mimeType}));
      await writable.close();
      return {ok:true, method:'file-system-access', fileName};
    }catch(err){
      if(err && err.name === 'AbortError') return {ok:false, canceled:true, method:'file-system-access', fileName};
      throw err;
    }
  }
  downloadTextFileFallback(json, fileName, mimeType);
  return {ok:true, method:'download-fallback', fileName};
}

function parseBackupJsonText(text){
  const d = JSON.parse(String(text || '').trim());
  if(!d || typeof d !== 'object' || Array.isArray(d)) throw new Error('invalid backup json');
  return d;
}

function readBackupJsonFromFileInput(options){
  const opt = options || {};
  if(!global.document) return Promise.reject(new Error('document is required for file input fallback'));
  return new Promise((resolve, reject)=>{
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = opt.accept || '.json,application/json';
    input.style.display = 'none';
    input.addEventListener('change', async()=>{
      const file = input.files && input.files[0];
      if(input.parentNode) input.parentNode.removeChild(input);
      if(!file){ resolve({ok:false, canceled:true, method:'file-input'}); return; }
      try{
        const text = await file.text();
        resolve({ok:true, method:'file-input', fileName:file.name || '', data:parseBackupJsonText(text), text});
      }catch(err){ reject(err); }
    }, {once:true});
    input.addEventListener('cancel', ()=>{
      if(input.parentNode) input.parentNode.removeChild(input);
      resolve({ok:false, canceled:true, method:'file-input'});
    }, {once:true});
    document.body.appendChild(input);
    input.click();
  });
}

async function openBackupJsonFromFile(options){
  const opt = options || {};
  if(typeof global.showOpenFilePicker === 'function'){
    try{
      const handles = await global.showOpenFilePicker({
        multiple:false,
        types: [{ description: 'JSONバックアップ', accept: { 'application/json': ['.json'] } }]
      });
      const handle = handles && handles[0];
      if(!handle) return {ok:false, canceled:true, method:'file-system-access'};
      const file = await handle.getFile();
      const text = await file.text();
      return {ok:true, method:'file-system-access', fileName:file.name || '', data:parseBackupJsonText(text), text};
    }catch(err){
      if(err && err.name === 'AbortError') return {ok:false, canceled:true, method:'file-system-access'};
      throw err;
    }
  }
  if(opt.noFallback) return {ok:false, unsupported:true, method:'file-system-access'};
  return readBackupJsonFromFileInput(opt);
}

async function restoreBackupJsonObjectWithConfirm(d, sourceLabel){
  if(!d || typeof d !== 'object' || Array.isArray(d)) throw new Error('invalid backup object');
  const label = sourceLabel || 'JSONバックアップ';
  if(!(await global.showAppConfirm(`復元すると現在のデータは上書きされます（自動バックアップは作成されます）。続けますか？

読込元：${label}
テンプレ${(d.templates||[]).length}件 / 住所録${(d.addressBook||[]).length}件`,'バックアップJSONからの復元',{okLabel:'復元する',danger:true}))) return false;
  if(!global.backupNow() && !(await global.showAppConfirm('自動バックアップに失敗しました。このまま復元を続行しますか？','自動バックアップ失敗',{okLabel:'復元を続行',danger:true}))) return false;
  return global.restoreFullBackupSafely(d,'読込完了');
}

function hasGlobalValue(name){
  try{return typeof global[name] !== 'undefined' && global[name] !== null;}catch(_e){return false;}
}
function isLocalStorageWritable(){
  try{
    if(!global.localStorage) return false;
    const key='__paperprint_backup_capability_probe__';
    global.localStorage.setItem(key,'1');
    global.localStorage.removeItem(key);
    return true;
  }catch(_e){return false;}
}
function detectBackupEnvironmentCapabilities(){
  const hasDocument = !!(global.document && typeof global.document.createElement === 'function');
  const hasBlob = hasGlobalValue('Blob') || (typeof Blob !== 'undefined');
  const urlApi = global.URL || (typeof URL !== 'undefined' ? URL : null);
  const hasObjectUrl = !!(urlApi && typeof urlApi.createObjectURL === 'function');
  const fileProto = (global.File && global.File.prototype) || (typeof File !== 'undefined' && File.prototype);
  const hasFileText = !!(fileProto && typeof fileProto.text === 'function');
  const hasFileReader = hasGlobalValue('FileReader');
  const fileSystemSave = typeof global.showSaveFilePicker === 'function';
  const fileSystemOpen = typeof global.showOpenFilePicker === 'function';
  const indexedDbPersistence = isIndexedDbAvailable();
  const downloadFallback = !!(hasDocument && hasBlob && hasObjectUrl);
  const fileInputRestore = !!(hasDocument && (hasFileText || hasFileReader || hasBlob));
  const clipboardWrite = !!(global.navigator && global.navigator.clipboard && typeof global.navigator.clipboard.writeText === 'function');
  const protocol = global.location && global.location.protocol ? String(global.location.protocol) : '';
  const localStorageWritable = isLocalStorageWritable();
  const recommendedSave = fileSystemSave
    ? {method:'remembered-file-handle', label:'保存先固定・ワンクリック上書き', note:indexedDbPersistence ? '初回に保存先を選ぶと、次回から同じJSONへ上書き保存できます' : '保存先指定は使えますが、保存先の記憶はこの画面を開いている間に限られます'}
    : (downloadFallback
      ? {method:'download-fallback', label:'ブラウザのダウンロード保存', note:'保存先指定APIは使えないため、ブラウザのダウンロード動作でJSONを保存します'}
      : {method:'copy-text', label:'全文コピー退避', note:'ファイル保存API/ダウンロード生成が使えないため、JSON全文コピーで退避します'});
  const recommendedOpen = fileSystemOpen
    ? {method:'file-system-access', label:'JSONファイル選択読込', note:'File System Access APIでJSONを直接選択して復元できます'}
    : (fileInputRestore
      ? {method:'file-input', label:'通常のファイル選択読込', note:'保存先指定APIは使えませんが、input[type=file]でJSONを選択して復元できます'}
      : {method:'paste-text', label:'テキスト貼付復元', note:'ファイル選択が使えないため、JSONテキスト貼付で復元します'});
  return {
    fileSystemSave,
    fileSystemOpen,
    downloadFallback,
    fileInputRestore,
    clipboardWrite,
    localStorageWritable,
    indexedDbPersistence,
    secureContext:!!global.isSecureContext,
    protocol,
    recommendedSave,
    recommendedOpen
  };
}
function renderCapabilityLine(label, ok, good, bad){
  const mark = ok ? '可' : '不可';
  const bg = ok ? '#f0fdf4' : '#fff7ed';
  const border = ok ? 'rgba(22,163,74,.25)' : 'rgba(180,95,6,.28)';
  const color = ok ? '#166534' : 'var(--warn)';
  return `<div style="background:${bg};border:1px solid ${border};padding:7px 8px;font-size:11px">
    <strong>${escapeHtml(label)}</strong>：<span style="color:${color};font-weight:700">${mark}</span><br>
    <span style="color:#666">${escapeHtml(ok ? good : bad)}</span>
  </div>`;
}
function renderBackupEnvironmentPanel(capabilities){
  const c = capabilities || detectBackupEnvironmentCapabilities();
  return `<div style="background:#f8fbff;border:1px solid rgba(37,99,235,.20);padding:10px;margin:0 0 12px;font-size:12px">
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px">
      <strong style="color:#2563eb">保存環境診断</strong>
      <span style="color:#666">このPC・ブラウザで使えるバックアップ方法を判定します。</span>
      <button class="btn sm ghost" id="dmRefreshBackupEnv" style="margin-left:auto">再診断</button>
      <button class="btn sm ghost" id="dmCopyBackupEnv">診断結果をコピー</button>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">
      <div style="background:#fff;border:1px solid var(--line-soft);padding:8px">
        <div style="font-size:11px;color:#666">推奨保存</div>
        <strong>${escapeHtml(c.recommendedSave.label)}</strong><br>
        <span style="font-size:11px;color:#666">${escapeHtml(c.recommendedSave.note)}</span>
      </div>
      <div style="background:#fff;border:1px solid var(--line-soft);padding:8px">
        <div style="font-size:11px;color:#666">推奨復元</div>
        <strong>${escapeHtml(c.recommendedOpen.label)}</strong><br>
        <span style="font-size:11px;color:#666">${escapeHtml(c.recommendedOpen.note)}</span>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
      ${renderCapabilityLine('保存先指定', c.fileSystemSave, 'showSaveFilePicker が利用できます', 'showSaveFilePicker は利用できません')}
      ${renderCapabilityLine('ファイル選択読込', c.fileSystemOpen || c.fileInputRestore, c.fileSystemOpen ? 'showOpenFilePicker が利用できます' : '通常のファイル選択で読込できます', 'ファイル選択読込は利用できません')}
      ${renderCapabilityLine('ダウンロード保存', c.downloadFallback, 'Blob URL によるJSON保存が利用できます', 'Blob URL による保存は利用できません')}
      ${renderCapabilityLine('自動保存領域', c.localStorageWritable, 'localStorage に保存できます', 'localStorage に書き込めません')}
      ${renderCapabilityLine('保存先記憶', c.indexedDbPersistence, 'IndexedDB に保存先ハンドルを保持できます', 'IndexedDB に保存先を保持できません')}
    </div>
    <div style="margin-top:7px;color:#666;font-size:11px">protocol: <code>${escapeHtml(c.protocol || 'unknown')}</code> / secureContext: <code>${c.secureContext?'yes':'no'}</code> / clipboard: <code>${c.clipboardWrite?'yes':'no'}</code></div>
  </div>`;
}
function buildBackupEnvironmentReport(capabilities){
  const c = capabilities || detectBackupEnvironmentCapabilities();
  return [
    '紙面位置合わせ印字システム 保存環境診断',
    `protocol: ${c.protocol || 'unknown'}`,
    `secureContext: ${c.secureContext ? 'yes' : 'no'}`,
    `showSaveFilePicker: ${c.fileSystemSave ? 'yes' : 'no'}`,
    `showOpenFilePicker: ${c.fileSystemOpen ? 'yes' : 'no'}`,
    `downloadFallback: ${c.downloadFallback ? 'yes' : 'no'}`,
    `fileInputRestore: ${c.fileInputRestore ? 'yes' : 'no'}`,
    `clipboardWrite: ${c.clipboardWrite ? 'yes' : 'no'}`,
    `localStorageWritable: ${c.localStorageWritable ? 'yes' : 'no'}`,
    `indexedDbPersistence: ${c.indexedDbPersistence ? 'yes' : 'no'}`,
    `recommendedSave: ${c.recommendedSave.label} (${c.recommendedSave.method})`,
    `recommendedOpen: ${c.recommendedOpen.label} (${c.recommendedOpen.method})`
  ].join('\n');
}
function copyBackupEnvironmentReport(){
  return copyTextToClipboard(buildBackupEnvironmentReport(), {successMessage:'保存環境診断をコピーしました'});
}

function getRuntimeErrorEntries(){
  try{
    const entries = global.__envelopePrintRuntimeErrors || [];
    return Array.isArray(entries) ? entries.slice(-12).reverse() : [];
  }catch(_e){ return []; }
}
function renderRuntimeErrorPanel(){
  const entries = getRuntimeErrorEntries();
  if(!entries.length){
    return `<div style="background:#f6f8f7;border:1px solid var(--line-soft);padding:9px;font-size:11px;color:#666;margin-bottom:12px">実行時エラー記録：なし</div>`;
  }
  return `<div style="background:#fff7ed;border:1px solid rgba(180,95,6,.28);padding:10px;margin-bottom:12px;font-size:12px">
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
      <strong style="color:var(--warn)">実行時エラー記録：${entries.length}件</strong>
      <span style="color:#666">ボタン無反応・Step遷移失敗の原因調査用です。最新12件だけ表示します。</span>
      <button class="btn sm ghost" id="dmCopyRuntimeErrors" style="margin-left:auto;border-color:var(--warn);color:var(--warn)">エラー内容をコピー</button>
    </div>
    <details style="margin-top:6px" open><summary>詳細</summary>
      <ul style="margin:6px 0 0 18px;line-height:1.6">
        ${entries.map(e=>`<li><code>${escapeHtml(e.scope||'runtime')}</code> — ${escapeHtml(e.name||'Error')}: ${escapeHtml(e.message||'')}<br><span style="color:#888;font-size:10px;white-space:pre-wrap">${escapeHtml(e.stack||'')}</span></li>`).join('')}
      </ul>
    </details>
  </div>`;
}
function copyRuntimeErrorReport(){
  const entries = getRuntimeErrorEntries();
  const text = entries.length ? entries.map(e=>[
    `[${fmtDate(e.at || Date.now())}] ${e.scope || 'runtime'} ${e.name || 'Error'}: ${e.message || ''}`,
    e.stack || ''
  ].join('\n')).join('\n\n---\n\n') : '実行時エラー記録なし';
  return copyTextToClipboard(text, {successMessage:'実行時エラー内容をコピーしました'});
}


function getRuntimeActionEntries(){
  try{
    const entries = global.__envelopePrintActionLog || [];
    return Array.isArray(entries) ? entries.slice(-20).reverse() : [];
  }catch(_e){ return []; }
}
function renderRuntimeActionPanel(){
  const entries = getRuntimeActionEntries();
  if(!entries.length){
    return `<div style="background:#f6f8f7;border:1px solid var(--line-soft);padding:9px;font-size:11px;color:#666;margin-bottom:12px">クリック記録：なし</div>`;
  }
  return `<div style="background:#f8fbff;border:1px solid rgba(37,99,235,.20);padding:10px;margin-bottom:12px;font-size:12px">
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
      <strong style="color:#2563eb">クリック記録：${entries.length}件</strong>
      <span style="color:#666">ボタン無反応の切り分け用です。fallback-click が出ていれば委譲フォールバックで救済しています。</span>
      <button class="btn sm ghost" id="dmCopyRuntimeActions" style="margin-left:auto">クリック記録をコピー</button>
    </div>
    <details style="margin-top:6px"><summary>詳細</summary>
      <ul style="margin:6px 0 0 18px;line-height:1.6">
        ${entries.map(e=>`<li><code>${escapeHtml(e.kind||'click')}</code> — id=<code>${escapeHtml(e.id||'')}</code> step=${escapeHtml(e.step==null?'':String(e.step))} handled=${e.handled?'yes':'no'} fallback=${e.fallback?'yes':'no'}${e.error?`<br><span style="color:var(--warn)">error: ${escapeHtml(e.error)}</span>`:''}<br><span style="color:#666">${escapeHtml(e.label||'')}</span></li>`).join('')}
      </ul>
    </details>
  </div>`;
}
function copyRuntimeActionReport(){
  const entries = getRuntimeActionEntries();
  const text = entries.length ? entries.map(e=>`[${fmtDate(e.at || Date.now())}] ${e.kind || 'click'} id=${e.id || ''} step=${e.step == null ? '' : e.step} handled=${e.handled?'yes':'no'} fallback=${e.fallback?'yes':'no'}${e.error?` error=${e.error}`:''} label=${e.label || ''}`).join('\n') : 'クリック記録なし';
  return copyTextToClipboard(text, {successMessage:'クリック記録をコピーしました'});
}


function getInteractionSelfDiagnosticsReport(){
  try{
    return global.__envelopePrintSelfDiagnostics || null;
  }catch(_e){ return null; }
}
function renderInteractionSelfDiagnosticsPanel(){
  const report = getInteractionSelfDiagnosticsReport();
  if(!report){
    return `<div style="background:#f6f8f7;border:1px solid var(--line-soft);padding:9px;font-size:11px;color:#666;margin-bottom:12px">
      UI自己診断：未実行
      <button class="btn sm ghost" id="dmRunSelfDiagnostics" style="margin-left:8px">自己診断を実行</button>
    </div>`;
  }
  const issues = Array.isArray(report.issues) ? report.issues : [];
  const targets = Array.isArray(report.targets) ? report.targets : [];
  const expected = targets.filter(t=>t.expected);
  const expectedMissing = expected.filter(t=>!t.present).length;
  const expectedHidden = expected.filter(t=>t.present && !t.visible).length;
  const ok = !issues.length;
  return `<div style="background:${ok?'#f0fdf4':'#fff7ed'};border:1px solid ${ok?'rgba(22,163,74,.25)':'rgba(180,95,6,.28)'};padding:10px;margin-bottom:12px;font-size:12px">
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
      <strong style="color:${ok?'#15803d':'var(--warn)'}">UI自己診断：${ok?'問題なし':'要確認 '+issues.length+'件'}</strong>
      <span style="color:#666">Step=${escapeHtml(String(report.currentStep ?? ''))} / activeDOM=${escapeHtml(String(report.activeDomStep ?? ''))} / activeNav=${escapeHtml(String(report.activeNavStep ?? ''))} / fallback=${report.clickFallbackInstalled?'ON':'OFF'} / safeBind=${report.safeBindClickAvailable?'ON':'OFF'}</span>
      <button class="btn sm ghost" id="dmRunSelfDiagnostics" style="margin-left:auto">再診断</button>
      <button class="btn sm ghost" id="dmCopySelfDiagnostics">診断結果をコピー</button>
    </div>
    <div style="font-size:11px;color:#666;margin-top:6px">期待ボタン ${expected.length}件 / 不在 ${expectedMissing}件 / 非表示疑い ${expectedHidden}件</div>
    ${issues.length?`<details style="margin-top:6px" open><summary>問題</summary><ul style="margin:6px 0 0 18px;line-height:1.6">${issues.map(i=>`<li><code>${escapeHtml(i.code||'issue')}</code>${i.id?` id=<code>${escapeHtml(i.id)}</code>`:''} — ${escapeHtml(i.message||'')}</li>`).join('')}</ul></details>`:''}
    <details style="margin-top:6px"><summary>主要ボタン状態</summary>
      <ul style="margin:6px 0 0 18px;line-height:1.6">${targets.map(t=>`<li>${t.expected?'<strong>期待</strong>':'任意'} id=<code>${escapeHtml(t.id||'')}</code> present=${t.present?'yes':'no'} visible=${t.visible?'yes':'no'} disabled=${t.disabled?'yes':'no'} fallback=${t.fallbackEligible?'yes':'no'} <span style="color:#666">${escapeHtml(t.label||'')}</span></li>`).join('')}</ul>
    </details>
  </div>`;
}
function copyInteractionSelfDiagnosticsReport(){
  const report = getInteractionSelfDiagnosticsReport();
  if(!report) return copyTextToClipboard('UI自己診断：未実行', {successMessage:'UI自己診断結果をコピーしました'});
  const lines = [];
  lines.push(`[${fmtDate(report.at || Date.now())}] UI自己診断`);
  lines.push(`initialized=${report.initialized?'yes':'no'} scheduled=${report.scheduled?'yes':'no'} reason=${report.reason || ''} currentStep=${report.currentStep ?? ''} activeDomStep=${report.activeDomStep ?? ''} activeNavStep=${report.activeNavStep ?? ''}`);
  lines.push(`runtimeTrap=${report.runtimeTrapInstalled?'yes':'no'} clickFallback=${report.clickFallbackInstalled?'yes':'no'} safeBindClick=${report.safeBindClickAvailable?'yes':'no'}`);
  lines.push('');
  lines.push('Issues:');
  const issues = Array.isArray(report.issues) ? report.issues : [];
  if(!issues.length) lines.push('- none');
  issues.forEach(i=>lines.push(`- ${i.level||''} ${i.code||''} ${i.id||''} ${i.message||''}`));
  lines.push('');
  lines.push('Targets:');
  (Array.isArray(report.targets) ? report.targets : []).forEach(t=>{
    lines.push(`- ${t.expected?'expected':'optional'} id=${t.id||''} present=${t.present?'yes':'no'} visible=${t.visible?'yes':'no'} disabled=${t.disabled?'yes':'no'} fallback=${t.fallbackEligible?'yes':'no'} label=${t.label||''}`);
  });
  return copyTextToClipboard(lines.join('\n'), {successMessage:'UI自己診断結果をコピーしました'});
}

function showHelp(){
  const modal=document.createElement('div');modal.className='modal-overlay';
  modal.innerHTML=`<div class="modal-box" style="min-width:540px">
    <h3>使い方</h3>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">通常の使い方（簡単モード）</h4>
    <ol style="font-size:12px;line-height:1.8;margin-left:18px">
      <li><strong>封筒を選ぶ</strong> — お気に入りや既存テンプレートから選択、または「＋新しく作る」で初回位置合わせウィザード起動</li>
      <li><strong>宛先を入力</strong> — 新規入力／住所録／履歴／Excel貼付から</li>
      <li><strong>テスト印刷</strong> — 試し刷り＆プリンタ補正を「見たまま」入力</li>
      <li><strong>本印刷</strong> — チェックリスト確認後に一括印刷</li>
    </ol>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">初回位置合わせウィザード（8ステップ）</h4>
    <p style="font-size:12px">新規封筒では、サイズ→封筒画像→背景合わせ→郵便番号→宛名→テスト印刷→プリンタ補正→保存の順で位置合わせ。一度作れば次回からは選ぶだけです</p>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">詳細モード</h4>
    <p style="font-size:12px">フィールド追加・削除、サイズ変更、避ける範囲編集等の「テンプレートを壊す可能性のある操作」が可能です</p>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">段階6：住所整形・郵便番号辞書・縦書き表記・ラベル開始位置</h4>
    <p style="font-size:12px">詳細モードで「差出人欄セット」「スタンプ」を追加できます。さらに、はがき・ラベル・帳票追記・窓付き封筒用の用紙プリセットを追加し、ラベル面付け印刷とキューのテンプレート別分割に対応しています</p>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">住所録のExcel貼付</h4>
    <p style="font-size:12px">Excelで住所表を選択→Ctrl+C→「Excel貼付」タブのテキストエリアにCtrl+V。タブ区切りを自動解析し、列の意味を推定してプレビュー表示。確認後にまとめて取込</p>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">バックアップ</h4>
    <p style="font-size:12px">自動で3世代バックアップ。「バックアップ」ボタンから世代復元・JSONテキストコピー・貼付け復元が可能</p>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">開発メモ</h4>
    <p style="font-size:12px">step番号だけでは履歴を追い切れないため、主要な改修範囲を以下に整理しています。</p>
    <ul style="font-size:11px;line-height:1.7;margin-left:18px">${APP_RELEASE_NOTES.map(n=>`<li><strong>${escapeHtml(n.step)}</strong> — ${escapeHtml(n.summary)}</li>`).join('')}</ul>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">構造メモ</h4>
    <p style="font-size:12px">v38-5以降は分割版を本流とします。単体HTMLは必要時の派生成果物とし、通常の修正・レビュー・テストはindex.html + css/js構成を基準にします。</p>
    <ul style="font-size:11px;line-height:1.7;margin-left:18px">${APP_ARCHITECTURE_DECISION.map(n=>`<li><strong>${escapeHtml(n.topic)}</strong> — ${escapeHtml(n.decision)}。${escapeHtml(n.reason)}</li>`).join('')}</ul>
    <details style="font-size:11px;margin-top:8px"><summary>疑似モジュール索引</summary><ul style="line-height:1.7;margin-left:18px">${APP_PSEUDO_MODULE_MAP.map(m=>`<li><strong>${escapeHtml(m.name)}</strong> — ${escapeHtml(m.scope)} <span class="muted">入口: ${escapeHtml(m.entry)}</span></li>`).join('')}</ul></details>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">v38リファクタ判断</h4>
    <p style="font-size:12px">v37は機能凍結候補とし、v38は新機能追加ではなく構造整理専用フェーズとして扱います。</p>
    <ul style="font-size:11px;line-height:1.7;margin-left:18px">${APP_V38_REFACTOR_DECISION.map(n=>`<li><strong>${escapeHtml(n.topic)}</strong> — ${escapeHtml(n.decision)}。${escapeHtml(n.reason)}</li>`).join('')}</ul>
    <details style="font-size:11px;margin-top:8px"><summary>v38段階計画</summary><ol style="line-height:1.7;margin-left:18px">${APP_V38_REFACTOR_PLAN.map(p=>`<li><strong>${escapeHtml(p.phase)}</strong> — ${escapeHtml(p.scope)} / 成果: ${escapeHtml(p.output)} / 完了条件: ${escapeHtml(p.done)}</li>`).join('')}</ol></details>
    <details style="font-size:11px;margin-top:8px"><summary>v38-1 構造棚卸し・実コード対応表</summary><table><thead><tr><th>領域</th><th>責務</th><th>入口</th><th>依存</th><th>抽出難度</th></tr></thead><tbody>${APP_V38_MODULE_INVENTORY.map(m=>`<tr><td><strong>${escapeHtml(m.module)}</strong><br><span class="muted">${escapeHtml(m.marker)}</span></td><td>${escapeHtml(m.owns)}</td><td><code>${escapeHtml(m.examples)}</code><br><span class="muted">${escapeHtml(m.nextAction)}</span></td><td>${escapeHtml(m.dependsOn)}</td><td>${escapeHtml(m.extractionRisk)}</td></tr>`).join('')}</tbody></table></details>
    <details style="font-size:11px;margin-top:8px"><summary>v38リファクタのゲート条件</summary><ul style="line-height:1.7;margin-left:18px">${APP_V38_REFACTOR_GATES.map(g=>`<li><strong>${escapeHtml(g.gate)}</strong> — ${escapeHtml(g.rule)}</li>`).join('')}</ul></details>
    <h4 class="serif" style="font-size:13px;margin:12px 0 6px">PDF.jsの導入（任意）</h4>
    <p style="font-size:12px"><code>pdf.min.js</code> と <code>pdf.worker.min.js</code> をこのHTMLと同フォルダに置けばPDF取込が可能。JPG/PNGなら追加不要</p>
    <div class="actions"><button class="btn primary" id="helpClose">閉じる</button></div>
  </div>`;
  document.body.appendChild(modal);
  applyLegacyModalA11y(modal,{title:'使い方', initialFocus:'#helpClose'});
  modal.querySelector('#helpClose').addEventListener('click',()=>closeAccessibleModal(modal));
  modal.addEventListener('click',e=>{if(e.target===modal) closeAccessibleModal(modal)});
}

function showDataMgmt(){
  const backups=getBackups();
  const u=getStorageUsage();
  const obsoleteEntries=getObsoleteStorageEntries();
  const obsoleteBytes=obsoleteEntries.reduce((sum,e)=>sum+(e.bytes||0),0);
  const lastSave=state.lastSavedAt?fmtDate(state.lastSavedAt):'未保存';
  const modal=document.createElement('div');modal.className='modal-overlay';
  modal.innerHTML=`<div class="modal-box" style="min-width:560px">
    <h3>バックアップ管理</h3>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;background:var(--paper-2);padding:10px;font-size:11px;margin-bottom:14px">
      <div>テンプレート：<strong>${state.templates.length}件</strong></div>
      <div>住所録：<strong>${state.addressBook.length}件</strong></div>
      <div>試行履歴：<strong>${getPrintRecordCount()}件</strong></div>
      <div>プリンタ：<strong>${state.printerProfiles.length}件</strong></div>
      <div>保存容量：<strong style="color:${u>STORAGE_WARN_BYTES?'var(--warn)':'inherit'}">${formatBytes(u)}</strong></div>
      <div>最終保存：<strong>${lastSave}</strong></div>
      <div>旧開発キー：<strong style="color:${obsoleteBytes?'var(--warn)':'inherit'}">${obsoleteEntries.length?`${obsoleteEntries.length}件 / ${formatBytes(obsoleteBytes)}`:'なし'}</strong></div>
    </div>
    ${renderRuntimeErrorPanel()}
    ${renderRuntimeActionPanel()}
    ${renderInteractionSelfDiagnosticsPanel()}
    ${obsoleteEntries.length?`<div style="background:#fff7ed;border:1px solid rgba(180,95,6,.28);padding:10px;margin-bottom:12px;font-size:12px">
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
        <strong>旧開発キーが残っています</strong>
        <span style="color:#666">旧 envelope_print_system 系キーは現在読まないため、容量圧迫だけが残ります。</span>
        <button class="btn sm ghost" id="dmCleanOldKeys" style="margin-left:auto;border-color:var(--warn);color:var(--warn)">旧キーを削除</button>
      </div>
      <details style="margin-top:6px"><summary>対象キーを表示</summary>
        <ul style="margin:6px 0 0 18px;line-height:1.7">${obsoleteEntries.map(e=>`<li><code>${escapeHtml(e.key)}</code> — ${formatBytes(e.bytes||0)}</li>`).join('')}</ul>
      </details>
    </div>`:''}
    <h4 class="serif" style="font-size:13px;margin:14px 0 6px">バックアップ世代（最大3世代）</h4>
    <div style="display:flex;flex-direction:column;gap:6px;font-size:12px">
      ${backups.length?backups.map((b,i)=>`
        <div style="display:flex;align-items:center;gap:8px;background:#fff;padding:8px;border:1px solid var(--line-soft)">
          <span>世代${i+1}: ${fmtDate(b.savedAt)} (テンプレ${(b.templates||[]).length}件/住所録${(b.addressBook||[]).length}件)</span>
          <span style="flex:1"></span>
          <button class="btn sm ghost" data-restore="${i}">復元</button>
        </div>`).join(''):'<div class="empty-state" style="padding:14px">バックアップなし</div>'}
    </div>
    <div style="margin-top:8px"><button class="btn sm" id="dmBackupNow">今すぐバックアップ</button></div>
    <h4 class="serif" style="font-size:13px;margin:18px 0 6px">手動バックアップ（JSONファイル保存・コピー）</h4>
    <p style="font-size:11px;color:#666">環境が対応していればJSONファイルの保存先指定・ファイル選択復元を直接行えます。未対応時は従来どおりコピー/貼付で退避できます</p>
    ${renderRememberedBackupTargetPanel()}
    ${renderBackupEnvironmentPanel()}
    <textarea class="backup-textarea" id="dmText" readonly>${escapeHtml(JSON.stringify(dataSnapshotForBackup(),null,2))}</textarea>
    <div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap">
      <button class="btn sm primary" id="dmSaveFile">💾 ワンクリック保存</button>
      <button class="btn sm" id="dmChooseBackupTarget">📌 保存先を指定/変更して保存</button>
      <button class="btn sm ghost" id="dmForgetBackupTarget">固定解除</button>
      <button class="btn sm primary" id="dmOpenFile">📂 推奨方式で読込</button>
      <button class="btn sm" id="dmCopy">📋 全文コピー</button>
      <button class="btn sm" id="dmShowLoad">📥 テキストから復元</button>
      ${state.uiMode==='advanced'?'<button class="btn sm ghost" style="margin-left:auto;border-color:var(--warn);color:var(--warn)" id="dmReset">🗑 全データリセット</button>':''}
    </div>
    <div id="dmLoadArea" style="display:none;margin-top:10px">
      <p style="font-size:11px;color:#666">保存したテキストを貼り付けて「読込実行」（現在のデータは自動バックアップされます）</p>
      <textarea class="backup-textarea" id="dmLoadText" placeholder='{"templates":[...]}'></textarea>
      <div style="margin-top:6px"><button class="btn sm primary" id="dmDoLoad">読込実行</button></div>
    </div>
    <div class="actions"><button class="btn ghost" id="dmClose">閉じる</button></div>
  </div>`;
  document.body.appendChild(modal);
  applyLegacyModalA11y(modal,{title:'バックアップ管理', initialFocus:'#dmClose'});
  modal.querySelector('#dmClose').addEventListener('click',()=>closeAccessibleModal(modal));
  modal.addEventListener('click',e=>{if(e.target===modal) closeAccessibleModal(modal)});
  modal.querySelector('#dmBackupNow').addEventListener('click',()=>{
    if(backupNow()){closeAccessibleModal(modal);showDataMgmt();toast('バックアップしました','ok')}
  });
  const copyRuntimeErrorsBtn=modal.querySelector('#dmCopyRuntimeErrors');
  if(copyRuntimeErrorsBtn) copyRuntimeErrorsBtn.addEventListener('click', copyRuntimeErrorReport);
  const copyRuntimeActionsBtn=modal.querySelector('#dmCopyRuntimeActions');
  if(copyRuntimeActionsBtn) copyRuntimeActionsBtn.addEventListener('click', copyRuntimeActionReport);
  const copySelfDiagnosticsBtn=modal.querySelector('#dmCopySelfDiagnostics');
  if(copySelfDiagnosticsBtn) copySelfDiagnosticsBtn.addEventListener('click', copyInteractionSelfDiagnosticsReport);
  const runSelfDiagnosticsBtn=modal.querySelector('#dmRunSelfDiagnostics');
  if(runSelfDiagnosticsBtn) runSelfDiagnosticsBtn.addEventListener('click',()=>{
    if(typeof global.runInteractionSelfDiagnostics === 'function') global.runInteractionSelfDiagnostics({manual:true});
    closeAccessibleModal(modal);
    showDataMgmt();
    toast('UI自己診断を実行しました','ok');
  });
  const copyBackupEnvBtn=modal.querySelector('#dmCopyBackupEnv');
  if(copyBackupEnvBtn) copyBackupEnvBtn.addEventListener('click', copyBackupEnvironmentReport);
  const refreshBackupEnvBtn=modal.querySelector('#dmRefreshBackupEnv');
  if(refreshBackupEnvBtn) refreshBackupEnvBtn.addEventListener('click',()=>{
    closeAccessibleModal(modal);
    showDataMgmt();
    toast('保存環境を再診断しました','ok');
  });
  refreshBackupTargetStatusPanel(modal);
  const refreshBackupTargetBtn=modal.querySelector('#dmRefreshBackupTarget');
  if(refreshBackupTargetBtn) refreshBackupTargetBtn.addEventListener('click',()=>refreshBackupTargetStatusPanel(modal));
  const chooseBackupTargetBtn=modal.querySelector('#dmChooseBackupTarget');
  if(chooseBackupTargetBtn) chooseBackupTargetBtn.addEventListener('click',async()=>{
    try{
      const result = await chooseBackupJsonTargetAndSave(dataSnapshotForBackup());
      if(result && result.canceled){ toast('保存先指定をキャンセルしました','warn'); return; }
      await refreshBackupTargetStatusPanel(modal);
      toast('保存先を固定してJSON保存しました','ok');
    }catch(err){
      console.warn('backup target choose/save failed', err);
      toast('保存先指定に失敗しました。通常保存または全文コピーで退避してください','warn');
    }
  });
  const forgetBackupTargetBtn=modal.querySelector('#dmForgetBackupTarget');
  if(forgetBackupTargetBtn) forgetBackupTargetBtn.addEventListener('click',async()=>{
    await forgetBackupFileHandle();
    await refreshBackupTargetStatusPanel(modal);
    toast('固定した保存先を解除しました','ok');
  });
  const cleanOldKeysBtn=modal.querySelector('#dmCleanOldKeys');
  if(cleanOldKeysBtn) cleanOldKeysBtn.addEventListener('click',async ()=>{
    const entries=getObsoleteStorageEntries();
    const bytes=entries.reduce((sum,e)=>sum+(e.bytes||0),0);
    if(!entries.length){toast('削除対象の旧キーはありません','ok');return}
    if(!(await showAppConfirm(`旧開発キー${entries.length}件（約${formatBytes(bytes)}）を削除しますか？\n現在の保存キー paper_position_print_system_v37 系は削除しません。`,'旧開発キーの削除',{okLabel:'削除する',danger:true}))) return;
    const result=removeObsoleteStorageKeys();
    const retry=retrySaveAfterObsoleteKeyCleanup(result);
    updateStorageStatus();
    closeAccessibleModal(modal);
    showDataMgmt();
    if(result.failed.length){
      const extra = retry.attempted && !retry.ok ? '。保存再試行にも失敗しました' : (retry.attempted && retry.ok ? '。保存状態は回復しました' : '');
      toast(`旧キー${result.count}件を削除しました。一部削除失敗: ${result.failed.length}件${extra}`,'warn');
    }else if(retry.attempted && retry.ok){
      toast(`旧キー${result.count}件（約${formatBytes(result.bytes)}）を削除し、保存状態も回復しました`,'ok');
    }else if(retry.attempted && !retry.ok){
      toast(`旧キー${result.count}件（約${formatBytes(result.bytes)}）を削除しましたが、保存再試行に失敗しました`,'warn');
    }else{
      toast(`旧キー${result.count}件（約${formatBytes(result.bytes)}）を削除しました`,'ok');
    }
  });
  modal.querySelector('#dmSaveFile').addEventListener('click',async()=>{
    try{
      const result = await saveBackupJsonToRememberedTarget(dataSnapshotForBackup(), {allowPicker:true, fallback:true});
      if(result && result.canceled){ toast('保存をキャンセルしました','warn'); return; }
      await refreshBackupTargetStatusPanel(modal);
      toast(result && result.method === 'remembered-file-handle' ? '固定した保存先へ上書きしました' : (result && result.method === 'remembered-file-handle-new' ? '保存先を固定してJSON保存しました' : 'JSONファイルの保存を開始しました'),'ok');
    }catch(err){
      console.warn('JSON file backup failed', err);
      toast('JSONファイル保存に失敗しました。全文コピーで退避してください','warn');
    }
  });
  modal.querySelector('#dmOpenFile').addEventListener('click',async()=>{
    try{
      const result = await openBackupJsonFromFile();
      if(result && result.canceled){ toast('読込をキャンセルしました','warn'); return; }
      if(!result || !result.ok || !result.data){ toast('JSONファイルを読み込めませんでした','warn'); return; }
      if(await restoreBackupJsonObjectWithConfirm(result.data, result.fileName || 'JSONファイル')) closeAccessibleModal(modal);
    }catch(err){
      console.warn('JSON file restore failed', err);
      toast('JSONファイル読込に失敗しました。形式を確認してください','warn');
    }
  });
  modal.querySelector('#dmCopy').addEventListener('click',async()=>{
    const textarea=modal.querySelector('#dmText');
    const text=textarea ? textarea.value : '';
    await copyTextToClipboard(text,{successMessage:'クリップボードにコピーしました', fallbackElement:textarea, fallbackMessage:'テキストを選択しました（Ctrl+Cでコピー）'});
  });
  modal.querySelector('#dmShowLoad').addEventListener('click',()=>{
    const area=modal.querySelector('#dmLoadArea');
    area.style.display=area.style.display==='none'?'block':'none';
  });
  modal.querySelector('#dmDoLoad').addEventListener('click',async ()=>{
    const text=modal.querySelector('#dmLoadText').value.trim();
    if(!text) return;
    try{
      const d=parseBackupJsonText(text);
      if(await restoreBackupJsonObjectWithConfirm(d,'貼付テキスト')) closeAccessibleModal(modal);
    }catch(e){toast('テキストが正しくありません','warn')}
  });
  const rb=modal.querySelector('#dmReset');
  if(rb) rb.addEventListener('click',async ()=>{
    // v37 step41: 全データ初期化確認をブラウザ標準confirmからDOMモーダルへ移行する。
    if(await showAppConfirm('全データを初期状態に戻しますか？\n（自動バックアップは作成されます）','全データリセット',{okLabel:'リセットする',danger:true})){
      if(!backupNow() && !(await showAppConfirm('自動バックアップに失敗しました。このままリセットしますか？','自動バックアップ失敗',{okLabel:'リセットを続行',danger:true}))) return;
      localStorage.removeItem(STORAGE_KEY);
      clearAddonStorage();
      transientBg={};
      state={templates:[],queue:[],addressBook:[],history:[],printAttempts:[],
        printerProfiles:[],
        selectedTplId:null,selectedFieldId:null,selectedZoneId:null,selectedPrinterId:null,
        mode:'edit',zoom:1,lastUsedTplId:null,
        currentStep:1,activeInputPane:'manual',uiMode:state.uiMode,lastSavedAt:null};
      closeAccessibleModal(modal); requestReloadAfterDataRestore('リセット完了');
    }
  });
  modal.querySelectorAll('[data-restore]').forEach(btn=>{
    btn.addEventListener('click',async ()=>{
      const idx=+btn.dataset.restore;const b=backups[idx];
      // v37 step41: 世代バックアップ復元確認をブラウザ標準confirmからDOMモーダルへ移行する。
      if(b && await showAppConfirm(`世代${idx+1}（${fmtDate(b.savedAt)}）に復元しますか？\n（現在の状態は自動バックアップされます）`,'世代バックアップの復元',{okLabel:'復元する',danger:true})){
        if(!backupNow() && !(await showAppConfirm('自動バックアップに失敗しました。このまま復元しますか？','自動バックアップ失敗',{okLabel:'復元を続行',danger:true}))) return;
        if(await restoreFullBackupSafely(b,'復元しました')) closeAccessibleModal(modal);
      }
    });
  });
}




function getModuleOverview(){
  return {
    Metadata:['APP_DISPLAY_NAME','APP_RELEASE_LABEL','APP_STORAGE_SCHEMA_VERSION','APP_MODULE_API_VERSION','STORAGE_KEY','BACKUP_KEY'],
    Architecture:['APP_RELEASE_NOTES','APP_ARCHITECTURE_DECISION','APP_PSEUDO_MODULE_MAP'],
    DataManagementUI:['EnvelopePrintDataManagementUI','showHelp','showDataMgmt','getModuleOverview','saveBackupJsonToFile','saveBackupJsonToRememberedTarget','chooseBackupJsonTargetAndSave','forgetBackupFileHandle','getRememberedBackupTargetStatus','openBackupJsonFromFile','restoreBackupJsonObjectWithConfirm','detectBackupEnvironmentCapabilities','renderBackupEnvironmentPanel','buildBackupEnvironmentReport','getRuntimeErrorEntries','getRuntimeActionEntries','getInteractionSelfDiagnosticsReport'],
    Core:['uid','toast','escapeHtml','formatBytes','estimateStorageBytes','estimateDataUrlBytes'],
    CoreContract:['EnvelopePrintCoreContract','getState','setState','getTransientBg','setTransientBg','storageKeys','storageLimits'],
    Utilities:['EnvelopePrintUtilities','$','uid','toast','announceA11y','escapeHtml','formatBytes','fmtDate','showAppAlert','showAppConfirm','showAppPrompt','copyTextToClipboard','applyScreenA11y','applyLegacyModalA11y','closeAccessibleModal'],
    KeyboardOverlay:['EnvelopePrintKeyboardOverlay','closeTopOverlayByEscape','setupEscapeToCloseOverlays','setupKeyboard'],
    Storage:['dataSnapshot','save','backupNow','load','getStorageUsage'],
    StorageCore:['EnvelopePrintStorageCore','dataSnapshot','dataSnapshotForBackup','save','backupNow','restoreFullBackupSafely','load','getStorageUsage','getBackups','clearAddonStorage','removeObsoleteStorageKeys','retrySaveAfterObsoleteKeyCleanup','sanitizeSnapshotForLoad','sanitizeSnapshotForRestore'],
    Template:['ENVELOPE_SIZES','normalizeTpl','markLayoutChanged','defaultLabelConfig','getLabelConfig','labelCapacity','getEffectivePrintPageCount','buildExcludeZonesForPreset','initialTemplates','buildFieldsForPreset','buildFieldsForSize'],
    BackgroundAssets:['EnvelopePrintBackgroundAssets','BG_MAX_LONG_EDGE','BG_JPEG_QUALITY','compressImageDataUrl','loadBackgroundFileInto','fileToDataURL','loadBackgroundPDF','loadBackgroundImage','setBackgroundOnTpl'],
    RegistryCore:['FieldSourceRegistry','Step3ExtensionRegistry','Step5ExtensionRegistry','PrintExecutionRegistry','InputValidationRegistry','InputDataExtensionRegistry','SampleDataRegistry','registerBuiltinFieldSources','getFieldSourceEntries','getFieldSourceLabel','sourceOptionsHtml','registerBuiltinSampleData'],
    StepNavigation:['EnvelopePrintStepNavigation','getActiveSteps','stepIndex','renderSteps','getStepStatus','canSkipTo','canGoToStep','callStepRenderer','goToStep'],
    Step1TemplateUI:['EnvelopePrintStep1TemplateUI','bindEventsForStep1','renderStep1','handleTplCardClick','showUnadjustedGuide','duplicateTpl'],
    Step2Edit:['EnvelopePrintStep2EditUI','renderStep2','renderFieldList','renderZipConfig','renderZoneList','renderBgUI','bindEventsForStep2'],
    AddressData:['EnvelopePrintAddressData','joinLines','buildOrgText','buildOrgFullText','buildNameWithHonor','buildSenderText','normalizeAddressData','defaultDataForTemplate','getFieldText','getSampleData'],
    Data:['normalizeAddressData','buildOrgText','buildSenderText'],
    Step3Input:['EnvelopePrintStep3InputCore','renderStep3','renderInputForm','getInputData','loadAddrToInput','clearInput','switchInputPane','addCurrentInputToQueue','saveCurrentInputToAddrbook','clearQueueWithConfirm','clearHistoryWithConfirm','bindEventsForStep3'],
    Step3Queue:['EnvelopePrintStep3QueueUI','renderQueue','cloneQueueItemFromRecord','renderAddrbook','renderHistory','addToHistory','renderPasteImport','analyzePastedData','renderPastePreview','doImportPaste'],
    Step4TestPrint:['EnvelopePrintStep4TestPrintUI','renderStep4','renderPrinterProfileSection','updateStep4Summary','fixQueueMismatchToCurrentTemplate','removeQueueMismatchFromCurrentTemplate','printStep4Sample','printStep4FirstQueueItem','printStep4CrossTest','bindEventsForStep4'],
    Step5FinalPrint:['EnvelopePrintStep5FinalPrintUI','renderStep5','startOverFromStep5','bindEventsForStep5'],
    CommonUI:['EnvelopePrintCommonUI','bindEventsForCommonUI'],
    RuntimeErrorTrap:['EnvelopePrintRuntimeErrorTrap','recordRuntimeAction','recordRuntimeError','installRuntimeErrorTrap'],
    ClickSafety:['EnvelopePrintClickSafety','safeBindClick','markClickHandled','markClickAttempted','getActionTargetLabel'],
    CriticalClickFallback:['EnvelopePrintCriticalClickFallback','getCriticalClickActionMap','installCriticalClickFallback','routeCriticalClickFallback'],
    InteractionDiagnostics:['EnvelopePrintInteractionDiagnostics','getInteractionDiagnosticTargets','runInteractionSelfDiagnostics','scheduleInteractionSelfDiagnostics','getLastInteractionSelfDiagnostics'],
    Stage7Addon:['EnvelopePrintStage7','buildRecipientFull','getExtendedInputData','loadExtendedInputData','clearExtendedInputs','buildPostcardBackFields','buildNameBadgeFields','buildReceiptFields','addFields','showUtilityModal','showGuideModal'],
    Bootstrap:['EnvelopePrintBootstrap','bindEvents','selectLastUsedTemplate','initializeApp','scheduleInitializeApp'],
    Layout:['overlap','adjustFieldRect','approxChar','estimatePrintCharUnits','wrapTextByPrintUnits','fitText','renderEnvelopeInto','renderNormalField','renderZipField','renderLabelCellInto','buildLabelSheetStack','buildPrintStack'],
    EditCanvasController:['EnvelopePrintEditCanvasController','renderEnvelope','getMMperPxOf','getMMperPx','getDragPoint','isPrimaryDragStart','preventDragDefault','addDragDocumentListeners','removeDragDocumentListeners','attachFieldDrag','attachZoneDrag','startAddZone','startEnvelopeZoneDraft','attachEnvelopeZoneDraftHandler','getEditCanvasControllerState'],
    AdjustmentStatus:['EnvelopePrintAdjustmentStatus','getTplAdjustmentSummary'],
    Adjustment:['getTplAdjustmentSummary'],
    Wizard:['EnvelopePrintWizard','openWizard','renderWizard','wizardNext','closeWizard','commitWizardDraft'],
    Print:['addPrintAttempt','getPrintRecordCount','renderFinalChecklist','getHardPrintIssues','renderPrintActionArea','executePrint','buildPrintStack','doPrint'],
    Parts:['EnvelopePrintPartsActions','createSenderFields','createStampField','refreshPartsActionUi','addSenderBlockToCurrentTpl','addStampToCurrentTpl','handleAddStampClick'],
    Jobs:['getQueueTemplateGroups','renderJobGroupSummary','getEffectivePrintPageCount'],
    Paper:['buildFieldsForPreset','buildPostcardFields','buildLabelSheetFields','buildFormOverlayFields','defaultLabelConfig','getLabelConfig','labelCapacity','buildWindowEnvelopeFields','buildWindowDocumentFields']
  };
}


const DataManagementUiApi = Object.freeze({
  showHelp,
  showDataMgmt,
  getModuleOverview,
  buildBackupFileName,
  downloadTextFileFallback,
  saveBackupJsonToFile,
  saveBackupJsonToRememberedTarget,
  chooseBackupJsonTargetAndSave,
  rememberBackupFileHandle,
  forgetBackupFileHandle,
  getRememberedBackupTargetStatus,
  refreshBackupTargetStatusPanel,
  parseBackupJsonText,
  openBackupJsonFromFile,
  readBackupJsonFromFileInput,
  restoreBackupJsonObjectWithConfirm,
  detectBackupEnvironmentCapabilities,
  renderBackupEnvironmentPanel,
  buildBackupEnvironmentReport,
  copyBackupEnvironmentReport,
  getRuntimeErrorEntries,
  getRuntimeActionEntries,
  getInteractionSelfDiagnosticsReport,
  renderInteractionSelfDiagnosticsPanel,
  copyInteractionSelfDiagnosticsReport,
  renderRuntimeErrorPanel,
  renderRuntimeActionPanel,
  copyRuntimeErrorReport,
  copyRuntimeActionReport
});

Object.assign(global, {
  showHelp,
  showDataMgmt,
  getModuleOverview,
  buildBackupFileName,
  downloadTextFileFallback,
  saveBackupJsonToFile,
  saveBackupJsonToRememberedTarget,
  chooseBackupJsonTargetAndSave,
  rememberBackupFileHandle,
  forgetBackupFileHandle,
  getRememberedBackupTargetStatus,
  refreshBackupTargetStatusPanel,
  parseBackupJsonText,
  openBackupJsonFromFile,
  readBackupJsonFromFileInput,
  restoreBackupJsonObjectWithConfirm,
  detectBackupEnvironmentCapabilities,
  renderBackupEnvironmentPanel,
  buildBackupEnvironmentReport,
  copyBackupEnvironmentReport,
  getRuntimeErrorEntries,
  getRuntimeActionEntries,
  getInteractionSelfDiagnosticsReport,
  renderInteractionSelfDiagnosticsPanel,
  copyInteractionSelfDiagnosticsReport,
  renderRuntimeErrorPanel,
  renderRuntimeActionPanel,
  copyRuntimeErrorReport,
  copyRuntimeActionReport,
  EnvelopePrintDataManagementUI: DataManagementUiApi
});
})(typeof window !== 'undefined' ? window : globalThis);
