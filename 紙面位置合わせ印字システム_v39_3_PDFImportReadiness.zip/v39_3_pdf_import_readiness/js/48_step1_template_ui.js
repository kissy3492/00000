(function(global){
  'use strict';

/* ============================================================
   v38-26: Step1 Template UI Controller
   Step1テンプレート選択カード、選択/複製/削除、未調整ガイドを担当。

   契約:
   - classic script前提。ES Modulesは使わない。
   - 保存形式・保存キー・field.source名は変更しない。
   - state / save / renderSteps / goToStep / openWizard 等は実行時参照。
   - Step2以降の描画責務は専用Step UIファイルへ委譲する。
   ============================================================ */

/* ============================================================
   ステップ1
   ============================================================ */


/* ===== v38-30: Step1 fixed button event binder ===== */
function bindEventsForStep1(){
  const bindClick = global.safeBindClick || ((el, handler)=>el.addEventListener('click', handler));
  bindClick($('newTplCta'), ()=>openWizard(null,'new',false), 'newTplCta');
  bindClick($('newReplyCta'), ()=>openWizard(null,'new',true), 'newReplyCta');
  bindClick($('step1Next'), ()=>goToStep(state.uiMode==='simple'?3:2), 'step1Next');
}

/* ===== v38-12 extracted from 10_core.js: renderStep1 ===== */
function renderStep1(){
  const pinned=state.templates.filter(t=>t.pinned);
  const others=state.templates.filter(t=>!t.pinned);
  const renderCard=t=>{
    const isSel=state.selectedTplId===t.id;
    const stat=getTplAdjustmentSummary(t);
    const notAligned = !stat.bgAligned && !t.isPreset;
    const stItem=(label,ok,warn)=>`<span class="st ${ok?'ok':(warn?'warn':'no')}"><span class="dot"></span>${label}</span>`;
    return `<div class="tpl-card ${isSel?'selected':''}${t.isReply?' reply':''}${notAligned?' not-aligned':''}" data-id="${t.id}">
      <button class="star ${t.pinned?'on':''}" data-act="pin" data-id="${t.id}">★</button>
      <div class="tpl-name">${escapeHtml(t.name)}</div>
      <div class="tpl-size">${t.w} × ${t.h} mm</div>
      <div class="tpl-meta">
        ${t.isReply?`<span class="reply-tag">返信用</span>`:''}
        ${t.isPreset?`<span class="preset-tag">標準位置</span>`:''}
        ${t.locked?`<span class="lock-tag">🔒 ロック</span>`:''}
        ${(t.excludeZones||[]).length?`<span class="pill" style="color:var(--warn)">避ける範囲${t.excludeZones.length}</span>`:''}
      </div>
      <div class="tpl-status">
        ${stItem('封筒画像', stat.bgAligned)}
        ${stItem('結果確認', stat.testPrinted, !stat.testPrinted && stat.layoutChecked)}
        ${stItem('プリンタ補正', stat.printerCalibrated)}
      </div>
      <div class="tpl-actions">
        <button data-act="wizard" data-id="${t.id}">📐 調整</button>
        <button data-act="dup" data-id="${t.id}">複製</button>
        ${state.uiMode==='advanced'?`<button data-act="edit" data-id="${t.id}">詳細</button>`:''}
        <button data-act="del" data-id="${t.id}">削除</button>
      </div>
    </div>`;
  };
  $('pinnedSection').innerHTML=pinned.length
    ?`<div class="section-divider"><span>★ よく使う封筒</span></div><div class="tpl-card-grid">${pinned.map(renderCard).join('')}</div>`:'';
  $('otherSection').innerHTML=others.length
    ?`<div class="section-divider"><span>その他のテンプレート</span></div><div class="tpl-card-grid">${others.map(renderCard).join('')}</div>`
    :(pinned.length?'':'<div class="empty-state">テンプレートがありません</div>');

  document.querySelectorAll('.tpl-card').forEach(card=>{
    card.addEventListener('click',e=>{
      if(e.target.closest('button')) return;
      handleTplCardClick(card.dataset.id);
    });
  });
  document.querySelectorAll('[data-act=pin]').forEach(b=>{
    b.addEventListener('click',e=>{
      e.stopPropagation();
      const t=getTpl(b.dataset.id);t.pinned=!t.pinned;
      save();renderStep1();
    });
  });
  document.querySelectorAll('[data-act=wizard]').forEach(b=>{
    b.addEventListener('click',e=>{
      e.stopPropagation();
      state.selectedTplId=b.dataset.id;state.lastUsedTplId=b.dataset.id;
      save();
      openWizard(getTpl(b.dataset.id), 'edit');
    });
  });
  document.querySelectorAll('[data-act=dup]').forEach(b=>{
    b.addEventListener('click',e=>{e.stopPropagation();duplicateTpl(b.dataset.id)});
  });
  document.querySelectorAll('[data-act=edit]').forEach(b=>{
    b.addEventListener('click',e=>{
      e.stopPropagation();
      state.selectedTplId=b.dataset.id;state.lastUsedTplId=b.dataset.id;
      save();goToStep(2);
    });
  });
  document.querySelectorAll('[data-act=del]').forEach(b=>{
    b.addEventListener('click',async e=>{
      e.stopPropagation();
      const t=getTpl(b.dataset.id);
      if(t.locked){toast('ロックされたテンプレートは削除できません。先にロック解除してください','warn');return}
      // v37 step37: テンプレート削除確認をブラウザ標準confirmからDOMモーダルへ移行する。
      if(await showAppConfirm(`「${t.name}」を削除しますか？`,'テンプレートの削除',{okLabel:'削除する',danger:true})){
        state.templates=state.templates.filter(x=>x.id!==t.id);
        delete transientBg[t.id];
        state.printerProfiles.forEach(p=>{if(p.perTpl) delete p.perTpl[t.id]});
        if(state.selectedTplId===t.id) state.selectedTplId=null;
        save();renderStep1();renderSteps();
        $('step1Next').disabled=!state.selectedTplId;
      }
    });
  });
  $('step1Next').disabled=!state.selectedTplId;
  $('step1Next').textContent=state.uiMode==='simple'?'次へ：宛先を入力 →':'次へ：詳細編集 →';
}


/* ===== v38-12 extracted from 10_core.js: handleTplCardClick ===== */
function handleTplCardClick(tplId){
  state.selectedTplId = tplId;
  state.lastUsedTplId = tplId;
  save();
  renderStep1();
  $('step1Next').disabled = false;
  // 未調整なら誘導
  const t = getTpl(tplId);
  const stat = getTplAdjustmentSummary(t);
  // 標準テンプレートでもテスト印刷未済なら誘導を出す
  if(!stat.testPrinted){
    showUnadjustedGuide(t, stat);
  }
}


/* ===== v38-12 extracted from 10_core.js: showUnadjustedGuide ===== */
function showUnadjustedGuide(t, stat){
  const modal=document.createElement('div');
  modal.className='modal-overlay';
  const issues = [];
  if(!stat.bgAligned && !t.isPreset) issues.push('封筒画像での位置合わせ');
  if(!stat.testPrinted) issues.push('テスト印刷結果の確認');
  const presetNotice = t.isPreset
    ? `<p style="font-size:11px;color:#888;margin-bottom:8px">※ このテンプレートは「標準位置プリセット」です。実際の封筒メーカー・プリンタによってはズレるため、必ずテスト印刷で確認してください</p>`
    : '';
  modal.innerHTML=`<div class="modal-box" style="min-width:420px">
    <h3>位置合わせが未完了です</h3>
    ${presetNotice}
    <p>この封筒は次の確認がまだです：</p>
    <ul style="font-size:12px;margin:8px 0 14px 22px;color:#444">
      ${issues.map(i=>`<li>${escapeHtml(i)}</li>`).join('')}
    </ul>
    <p>安全に印刷するには、先に封筒画像での位置合わせ・テスト印刷を行ってください。</p>
    <div class="actions">
      <button class="btn ghost" id="guideContinue">このまま宛先入力へ進む</button>
      <button class="btn primary" id="guideWizard">位置合わせを開始</button>
    </div>
  </div>`;
  document.body.appendChild(modal);
  applyLegacyModalA11y(modal,{title:'位置合わせが未完了', initialFocus:'#guideWizard'});
  (global.safeBindClick || ((el, handler)=>el.addEventListener('click', handler)))(modal.querySelector('#guideContinue'), ()=>{
    closeAccessibleModal(modal);
    goToStep(3);
  });
  (global.safeBindClick || ((el, handler)=>el.addEventListener('click', handler)))(modal.querySelector('#guideWizard'), ()=>{
    closeAccessibleModal(modal);
    openWizard(t, 'edit');
  });
  modal.addEventListener('click',e=>{if(e.target===modal) closeAccessibleModal(modal)});
}


/* ===== v38-12 extracted from 10_core.js: duplicateTpl ===== */
function duplicateTpl(id){
  const src=getTpl(id);if(!src) return;
  const copy=JSON.parse(JSON.stringify(src));
  copy.id=uid('tpl');copy.name=src.name+' (複製)';
  copy.pinned=false;copy.isPreset=false;copy.presetNote='';
  copy.locked=false;copy.createdAt=Date.now();
  copy.adjustmentStatus={
    bgAlignedAt:null,zipCheckedAt:null,layoutCheckedAt:null,
    testPrintedAt:null,printerCheckedAt:null,
    lastLayoutChangedAt:Date.now()
  };
  copy.fields=copy.fields.map(f=>({...f,id:uid('f')}));
  if(copy.excludeZones) copy.excludeZones=copy.excludeZones.map(z=>({...z,id:uid('z')}));
  delete copy.bgImage;delete copy.bgSourceName;delete copy.bgBytes;
  state.templates.push(copy);state.selectedTplId=copy.id;
  save();renderStep1();renderSteps();
  toast(`「${copy.name}」を作成`,'ok');
}


  const Step1TemplateUiApi = Object.freeze({
    bindEventsForStep1,
    renderStep1,
    handleTplCardClick,
    showUnadjustedGuide,
    duplicateTpl
  });

  Object.assign(global, {
    bindEventsForStep1,
    renderStep1,
    handleTplCardClick,
    showUnadjustedGuide,
    duplicateTpl,
    EnvelopePrintStep1TemplateUI: Step1TemplateUiApi
  });
})(typeof window !== 'undefined' ? window : globalThis);
