(function(global){
  'use strict';
  /* ============================================================
     Interaction Self Diagnostics
     v38-71: 90_bootstrap.jsから分離。診断はHotfix層として隔離する。
     ============================================================ */

const INTERACTION_DIAGNOSTIC_TARGETS = Object.freeze([
  {id:'btnHelp', label:'ヘルプ', area:'topbar', fallback:true, persistent:true},
  {id:'btnDataMgmt', label:'バックアップ', area:'topbar', fallback:true, persistent:true},
  {id:'modeSimple', label:'簡単モード', area:'topbar', fallback:true, persistent:true},
  {id:'modeAdvanced', label:'詳細モード', area:'topbar', fallback:true, persistent:true},
  {id:'newTplCta', label:'通常の封筒を作る', area:'step1', fallback:true, step:1},
  {id:'newReplyCta', label:'返信用封筒を作る', area:'step1', fallback:true, step:1},
  {id:'step1Next', label:'Step1 次へ', area:'step1', fallback:true, step:1},
  {id:'btnReWizard', label:'位置合わせウィザード', area:'step2', fallback:true, step:2},
  {id:'step2Back', label:'Step2 戻る', area:'step2', fallback:true, step:2},
  {id:'step2Next', label:'Step2 次へ', area:'step2', fallback:true, step:2},
  {id:'btnAddQueue', label:'キューに追加', area:'step3', fallback:true, step:3},
  {id:'btnSaveToAddrbook', label:'住所録に保存', area:'step3', fallback:true, step:3},
  {id:'btnClearInput', label:'入力クリア', area:'step3', fallback:true, step:3},
  {id:'btnClearQueue', label:'キュー全削除', area:'step3', fallback:true, step:3},
  {id:'btnClearHistory', label:'履歴全削除', area:'step3', fallback:true, step:3},
  {id:'pasteAnalyze', label:'貼付解析', area:'step3', fallback:true, step:3},
  {id:'pasteClear', label:'貼付クリア', area:'step3', fallback:true, step:3},
  {id:'doPasteImport', label:'貼付取込実行', area:'step3', fallback:true, step:3},
  {id:'step3Back', label:'Step3 戻る', area:'step3', fallback:true, step:3},
  {id:'step3Next', label:'Step3 次へ', area:'step3', fallback:true, step:3},
  {id:'btnFixMismatch', label:'キューを現テンプレートに揃える', area:'step4', fallback:true, step:4},
  {id:'btnRemoveMismatch', label:'不一致キュー削除', area:'step4', fallback:true, step:4},
  {id:'btnTestSample', label:'サンプル試し刷り', area:'step4', fallback:true, step:4},
  {id:'btnTestFirst', label:'先頭宛先で試し刷り', area:'step4', fallback:true, step:4},
  {id:'btnTestCross', label:'十字テスト', area:'step4', fallback:true, step:4},
  {id:'markTestPrinted', label:'テスト結果確認', area:'step4', fallback:false, step:4},
  {id:'step4Back', label:'Step4 戻る', area:'step4', fallback:true, step:4},
  {id:'step4Next', label:'Step4 次へ', area:'step4', fallback:true, step:4},
  {id:'step5Back', label:'Step5 戻る', area:'step5', fallback:true, step:5},
  {id:'btnStartOver', label:'最初から', area:'step5', fallback:true, step:5},
  {id:'guideContinue', label:'未調整ガイド 続行', area:'modal', fallback:true, modal:true},
  {id:'guideWizard', label:'未調整ガイド ウィザード', area:'modal', fallback:true, modal:true},
  {id:'helpClose', label:'ヘルプ 閉じる', area:'modal', fallback:true, modal:true},
  {id:'dmClose', label:'バックアップ 閉じる', area:'modal', fallback:true, modal:true}
]);

function cloneDiagnosticTargetSpec(spec){
  return Object.assign({}, spec);
}

function getInteractionDiagnosticTargets(){
  return INTERACTION_DIAGNOSTIC_TARGETS.map(cloneDiagnosticTargetSpec);
}

function getCurrentStepNumber(){
  try{
    return (typeof state !== 'undefined' && state && state.currentStep) ? Number(state.currentStep) : null;
  }catch(_e){ return null; }
}

function getExpectedInteractionTargetIds(){
  const step = getCurrentStepNumber() || 1;
  const ids = ['btnHelp','btnDataMgmt','modeSimple','modeAdvanced'];
  INTERACTION_DIAGNOSTIC_TARGETS.forEach(spec => {
    if(spec.step === step) ids.push(spec.id);
  });
  return ids;
}

function isElementVisibleEnough(el){
  if(!el) return false;
  try{
    if(el.hidden) return false;
    const style = global.getComputedStyle ? global.getComputedStyle(el) : null;
    if(style && (style.display === 'none' || style.visibility === 'hidden')) return false;
    return true;
  }catch(_e){ return true; }
}

function inspectInteractionTarget(spec, expectedIds){
  const doc = global.document;
  const el = doc && typeof doc.getElementById === 'function' ? doc.getElementById(spec.id) : null;
  return {
    id: spec.id,
    label: spec.label,
    area: spec.area,
    expected: expectedIds.indexOf(spec.id) >= 0,
    present: !!el,
    visible: !!el && isElementVisibleEnough(el),
    disabled: !!(el && el.disabled),
    fallbackEligible: !!spec.fallback,
    tag: el && el.tagName ? String(el.tagName).toLowerCase() : '',
    text: el && typeof global.getActionTargetLabel === 'function' ? global.getActionTargetLabel(el) : ''
  };
}

function detectActiveStepFromDom(){
  const doc = global.document;
  if(!doc || typeof doc.querySelector !== 'function') return null;
  try{
    const active = doc.querySelector('.step-content.active');
    if(active && active.dataset && active.dataset.step) return Number(active.dataset.step);
  }catch(_e){}
  return null;
}

function detectActiveStepNavFromDom(){
  const doc = global.document;
  if(!doc || typeof doc.querySelector !== 'function') return null;
  try{
    const active = doc.querySelector('.step-item.active');
    if(active && active.dataset && active.dataset.stepNav) return Number(active.dataset.stepNav);
  }catch(_e){}
  return null;
}

function scheduleInteractionSelfDiagnostics(reason, delayMs){
  const delay = typeof delayMs === 'number' ? delayMs : 0;
  const run = () => {
    try{ runInteractionSelfDiagnostics({reason: reason || 'scheduled'}); }
    catch(err){ if(typeof global.recordRuntimeError === 'function') global.recordRuntimeError('scheduleInteractionSelfDiagnostics', err); }
  };
  if(typeof global.setTimeout === 'function') global.setTimeout(run, delay);
  else run();
}

function runInteractionSelfDiagnostics(options){
  const opt = options || {};
  const at = Date.now();
  const expectedIds = getExpectedInteractionTargetIds();
  const currentStep = getCurrentStepNumber();
  const activeDomStep = detectActiveStepFromDom();
  const activeNavStep = detectActiveStepNavFromDom();
  const issues = [];
  if(!global.document){
    issues.push({level:'error', code:'document-missing', message:'document が参照できません'});
  }
  if(!global.__envelopePrintRuntimeTrapInstalled){
    issues.push({level:'warn', code:'runtime-trap-not-installed', message:'実行時エラー記録が未初期化です'});
  }
  if(!global.__envelopePrintCriticalClickFallbackInstalled){
    issues.push({level:'warn', code:'click-fallback-not-installed', message:'Click Fallback が未初期化です'});
  }
  if(typeof global.safeBindClick !== 'function'){
    issues.push({level:'warn', code:'safe-bind-click-missing', message:'safeBindClick が未公開です'});
  }
  if(activeDomStep !== null && currentStep !== null && activeDomStep !== currentStep){
    issues.push({level:'warn', code:'active-step-mismatch', message:`state.currentStep=${currentStep} と画面上のactive step=${activeDomStep} が一致しません`});
  }
  if(activeNavStep !== null && currentStep !== null && activeNavStep !== currentStep){
    issues.push({level:'warn', code:'active-step-nav-mismatch', message:`state.currentStep=${currentStep} と左ステップナビのactive step=${activeNavStep} が一致しません`});
  }
  const targets = INTERACTION_DIAGNOSTIC_TARGETS.map(spec => inspectInteractionTarget(spec, expectedIds));
  targets.forEach(t => {
    if(t.expected && !t.present) issues.push({level:'error', code:'expected-button-missing', id:t.id, message:`期待ボタン ${t.id} がDOMにありません`});
    else if(t.expected && !t.visible) issues.push({level:'warn', code:'expected-button-hidden', id:t.id, message:`期待ボタン ${t.id} が非表示の可能性があります`});
  });
  const report = {
    at,
    manual: !!opt.manual,
    initialized: !!global.__ENVELOPE_PRINT_INITIALIZED,
    scheduled: !!global.__ENVELOPE_PRINT_BOOTSTRAP_SCHEDULED,
    runtimeTrapInstalled: !!global.__envelopePrintRuntimeTrapInstalled,
    clickFallbackInstalled: !!global.__envelopePrintCriticalClickFallbackInstalled,
    safeBindClickAvailable: typeof global.safeBindClick === 'function',
    currentStep,
    activeDomStep,
    activeNavStep,
    reason: opt.reason || '',
    expectedIds,
    targets,
    issues
  };
  global.__envelopePrintSelfDiagnostics = report;
  try{
    if(typeof global.recordRuntimeAction === 'function') global.recordRuntimeAction({kind:'self-diagnostics', id:'', label:`issues=${issues.length}`, handled:true, fallback:false, issues:issues.length});
  }catch(_e){}
  return report;
}

function getLastInteractionSelfDiagnostics(){
  return global.__envelopePrintSelfDiagnostics || null;
}

const InteractionDiagnosticsApi = Object.freeze({
  getInteractionDiagnosticTargets,
  getExpectedInteractionTargetIds,
  runInteractionSelfDiagnostics,
  scheduleInteractionSelfDiagnostics,
  getLastInteractionSelfDiagnostics
});

Object.assign(global, {
  getInteractionDiagnosticTargets,
  runInteractionSelfDiagnostics,
  scheduleInteractionSelfDiagnostics,
  getLastInteractionSelfDiagnostics,
  EnvelopePrintInteractionDiagnostics: InteractionDiagnosticsApi
});
})(typeof window !== 'undefined' ? window : globalThis);
