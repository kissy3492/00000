(function(global){
  'use strict';
  /* ============================================================
     Critical Click Fallback Router
     v38-71: 90_bootstrap.jsから分離。テーブル駆動を維持する。
     ============================================================ */

function findActionTarget(event){
  if(!event || !event.target || typeof event.target.closest !== 'function') return null;
  return event.target.closest('button,[role="button"],[data-step-nav],#newTplCta,#newReplyCta,.new-tpl-cta,#guideContinue,#guideWizard');
}

function actionLabel(target){
  return typeof global.getActionTargetLabel === 'function' ? global.getActionTargetLabel(target) : '';
}

function closeContainingModal(target){
  const modal = target && typeof target.closest === 'function' ? target.closest('.modal-overlay') : null;
  if(modal && typeof global.closeAccessibleModal === 'function') global.closeAccessibleModal(modal, {suppressFocusRestore:true});
}

function invokeNamedAction(name, args){
  const fn = global[name];
  if(typeof fn !== 'function') return false;
  const result = fn.apply(global, args || []);
  return result !== false;
}

function goToStepAction(n){
  return typeof global.goToStep === 'function' ? global.goToStep(n) !== false : false;
}

function currentTpl(){
  return typeof global.getCurrentTpl === 'function' ? global.getCurrentTpl() : null;
}

const CRITICAL_CLICK_ACTIONS = Object.freeze({
  btnHelp: {action:'showHelp'},
  btnDataMgmt: {action:'showDataMgmt'},
  modeSimple: {run(){
    if(typeof state === 'undefined') return false;
    state.uiMode='simple';
    if(state.currentStep===2) state.currentStep=1;
    if(typeof global.save === 'function') global.save();
    if(typeof global.renderSteps === 'function') global.renderSteps();
    return goToStepAction(state.currentStep || 1);
  }},
  modeAdvanced: {run(){
    if(typeof state === 'undefined') return false;
    state.uiMode='advanced';
    if(typeof global.save === 'function') global.save();
    if(typeof global.renderSteps === 'function') global.renderSteps();
    return goToStepAction(state.currentStep || 1);
  }},
  newTplCta: {run(){ return invokeNamedAction('openWizard', [null, 'new', false]); }},
  newReplyCta: {run(){ return invokeNamedAction('openWizard', [null, 'new', true]); }},
  step1Next: {run(){ return goToStepAction((typeof state !== 'undefined' && state.uiMode==='simple') ? 3 : 2); }},
  step2Back: {run(){ return goToStepAction(1); }},
  step2Next: {run(){ return goToStepAction(3); }},
  step3Back: {run(){ return goToStepAction((typeof state !== 'undefined' && state.uiMode==='simple') ? 1 : 2); }},
  step3Next: {run(){ return goToStepAction(4); }},
  step4Back: {run(){ return goToStepAction(3); }},
  step4Next: {run(){ return goToStepAction(5); }},
  step5Back: {run(){ return goToStepAction(4); }},
  btnReWizard: {run(){ return currentTpl() ? invokeNamedAction('openWizard', [currentTpl(), 'edit']) : false; }},
  btnAddQueue: {action:'addCurrentInputToQueue'},
  btnSaveToAddrbook: {action:'saveCurrentInputToAddrbook'},
  btnClearInput: {action:'clearInput'},
  btnClearQueue: {action:'clearQueueWithConfirm'},
  btnClearHistory: {action:'clearHistoryWithConfirm'},
  pasteAnalyze: {action:'analyzePastedData'},
  pasteClear: {run(){
    if(!global.document) return false;
    const txt = global.document.getElementById('pasteTxt');
    const preview = global.document.getElementById('pastePreview');
    if(txt) txt.value='';
    if(preview) preview.innerHTML='';
    return true;
  }},
  doPasteImport: {action:'doImportPaste'},
  btnFixMismatch: {action:'fixQueueMismatchToCurrentTemplate'},
  btnRemoveMismatch: {action:'removeQueueMismatchFromCurrentTemplate'},
  btnTestSample: {action:'printStep4Sample'},
  btnTestFirst: {action:'printStep4FirstQueueItem'},
  btnTestCross: {action:'printStep4CrossTest'},
  btnStartOver: {action:'startOverFromStep5'},
  guideContinue: {run(target){ closeContainingModal(target); return goToStepAction(3); }},
  guideWizard: {run(target){ closeContainingModal(target); return currentTpl() ? invokeNamedAction('openWizard', [currentTpl(), 'edit']) : false; }},
  helpClose: {run(target){ closeContainingModal(target); return true; }},
  dmClose: {run(target){ closeContainingModal(target); return true; }}
});

function getCriticalClickActionMap(){
  return CRITICAL_CLICK_ACTIONS;
}

function routeCriticalClickFallback(target, event){
  const navStep = target && target.dataset ? Number(target.dataset.stepNav || 0) : 0;
  if(navStep) return goToStepAction(navStep);
  const id = target && target.id;
  if(!id) return false;
  const spec = CRITICAL_CLICK_ACTIONS[id];
  if(!spec) return false;
  if(typeof spec.run === 'function') return spec.run(target, event) !== false;
  if(spec.action) return invokeNamedAction(spec.action);
  return false;
}

function installCriticalClickFallback(){
  if(global.__envelopePrintCriticalClickFallbackInstalled) return;
  if(!global.document || typeof global.document.addEventListener !== 'function') return;
  global.__envelopePrintCriticalClickFallbackInstalled = true;
  global.document.addEventListener('click', event => {
    const target = findActionTarget(event);
    if(!target) return;
    const id = target.id || '';
    const label = actionLabel(target);
    const wasHandled = !!event.__paperPrintHandled;
    if(typeof global.recordRuntimeAction === 'function') global.recordRuntimeAction({kind:'click', id, label, handled:wasHandled, fallback:false});
    if(wasHandled) return;
    try{
      const routed = routeCriticalClickFallback(target, event);
      if(routed){
        if(event && typeof event.preventDefault === 'function') event.preventDefault();
        if(typeof global.markClickHandled === 'function') global.markClickHandled(event);
        if(typeof global.recordRuntimeAction === 'function') global.recordRuntimeAction({kind:'fallback-click', id, label, handled:false, fallback:true});
        if(typeof global.scheduleInteractionSelfDiagnostics === 'function') global.scheduleInteractionSelfDiagnostics('fallback-click:'+(id || label || 'unknown'));
      }else if(id || target.tagName === 'BUTTON'){
        if(typeof global.recordRuntimeAction === 'function') global.recordRuntimeAction({kind:'unhandled-click', id, label, handled:false, fallback:false});
      }
    }catch(err){
      if(typeof global.recordRuntimeError === 'function') global.recordRuntimeError(`critical click fallback:${id || label || 'unknown'}`, err);
    }
  }, false);
}

const CriticalClickFallbackApi = Object.freeze({
  findActionTarget,
  closeContainingModal,
  invokeNamedAction,
  getCriticalClickActionMap,
  routeCriticalClickFallback,
  installCriticalClickFallback
});

Object.assign(global, {
  getCriticalClickActionMap,
  installCriticalClickFallback,
  routeCriticalClickFallback,
  EnvelopePrintCriticalClickFallback: CriticalClickFallbackApi
});
})(typeof window !== 'undefined' ? window : globalThis);
