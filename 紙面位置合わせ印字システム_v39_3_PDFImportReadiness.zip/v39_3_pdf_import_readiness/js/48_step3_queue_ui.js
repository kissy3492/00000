(function(global){
  'use strict';

/* ============================================================
   v38-32: Step3 Queue UI
   Step3のキュー、住所録、履歴、Excel貼付取込を担当。

   契約:
   - classic script / IIFE + explicit window export。ES Modulesは使わない。
   - 保存キー・保存形式・field.source名・入力データキーは変更しない。
   - cloneQueueItemFromRecord() は拡張項目保持のため、限定コピーではなくJSON深いコピーを維持する。
   - Step3 input core は renderStep3() から本モジュールの描画関数を呼ぶ。
   ============================================================ */


/* ===== v38-12 extracted from 10_core.js: renderQueue ===== */
function renderQueue(){
  const list=$('queueList');
  $('qCount').textContent=state.queue.length+'件';
  if(!state.queue.length){
    list.innerHTML='<div class="empty-state" style="padding:20px 10px">キューは空です</div>';return;
  }
  list.innerHTML='';
  state.queue.forEach((q,i)=>{
    const tplOfQ=getTpl(q.tplId);
    const mismatch=q.tplId!==state.selectedTplId;
    const el=document.createElement('div');
    el.className='queue-item'+(mismatch?' mismatch':'');
    const primary=q.name||q.corp||'(無名)';
    const secondary=q.name&&q.corp?q.corp:(q.addr||'');
    el.innerHTML=`<span class="idx">${String(i+1).padStart(2,'0')}</span>
      <div>
        <div class="qi-name">${escapeHtml(primary)} ${escapeHtml(q.honor||'')}</div>
        <div class="qi-addr">${escapeHtml((secondary||'').slice(0,28))}${(secondary||'').length>28?'…':''}</div>
        <div class="qi-tpl">▸ ${escapeHtml(tplOfQ?tplOfQ.name:'(削除済)')}${mismatch?' ⚠':''}</div>
      </div>
      <div class="qi-acts">
        <button data-i="${i}" data-act="up">↑</button>
        <button data-i="${i}" data-act="dn">↓</button>
        <button data-i="${i}" data-act="rm">×</button>
      </div>`;
    list.appendChild(el);
  });
  list.querySelectorAll('button').forEach(b=>{
    b.addEventListener('click',()=>{
      const i=+b.dataset.i,a=b.dataset.act;
      if(a==='up'&&i>0) [state.queue[i-1],state.queue[i]]=[state.queue[i],state.queue[i-1]];
      if(a==='dn'&&i<state.queue.length-1) [state.queue[i+1],state.queue[i]]=[state.queue[i],state.queue[i+1]];
      if(a==='rm') state.queue.splice(i,1);
      save();renderQueue();
      $('step3Next').disabled=state.queue.length===0;
      renderSteps();
    });
  });
}

/* ===== v38-12 extracted from 10_core.js: cloneQueueItemFromRecord ===== */
function cloneQueueItemFromRecord(record, tplId){
  // v26: 住所録・履歴からキューへ戻す際にStage7等の拡張項目を落とさないため、限定コピーではなく安全な複製を使う。
  const q = JSON.parse(JSON.stringify(record || {}));
  delete q.id;
  delete q.printedAt;
  delete q.attemptedAt;
  delete q.historyKind;
  delete q.status;
  delete q.savedAt;
  q.tplId = tplId;
  return q;
}


/* ===== v38-12 extracted from 10_core.js: renderAddrbook ===== */
function renderAddrbook(){
  const list=$('abList');
  const q=($('abSearch')&&$('abSearch').value||'').toLowerCase();
  const filtered=state.addressBook.filter(a=>{
    if(!q) return true;
    return (a.name||'').toLowerCase().includes(q)||(a.corp||'').toLowerCase().includes(q)||(a.addr||'').toLowerCase().includes(q);
  });
  if(!filtered.length){
    list.innerHTML=q?'<div class="empty-state">該当なし</div>':'<div class="empty-state">住所録は空です。<br>「Excel貼付」タブから一括取込もできます</div>';
    return;
  }
  list.innerHTML='';
  filtered.forEach(a=>{
    const el=document.createElement('div');el.className='addrbook-item';
    el.innerHTML=`<div>
      <div class="nm">${escapeHtml(a.name||a.corp||'(無名)')} ${escapeHtml(a.honor||'')}</div>
      ${a.corp&&a.name?`<div class="ad">${escapeHtml(a.corp)}</div>`:''}
      <div class="ad">${escapeHtml(a.zip||'')} ${escapeHtml((a.addr||'').slice(0,40))}${(a.addr||'').length>40?'…':''}</div>
    </div>
    <div class="acts">
      <button data-id="${a.id}" data-act="add">＋ キュー</button>
      <button data-id="${a.id}" data-act="edit">編集</button>
      <button data-id="${a.id}" data-act="del">×</button>
    </div>`;
    el.querySelector('[data-act=add]').addEventListener('click',()=>{
      state.queue.push(cloneQueueItemFromRecord(a, state.selectedTplId));
      save();renderQueue();
      $('step3Next').disabled=state.queue.length===0;
      renderSteps();
      toast(`「${a.name||a.corp}」をキューに追加`,'ok');
    });
    el.querySelector('[data-act=edit]').addEventListener('click',()=>{
      loadAddrToInput(a);switchInputPane('manual');
    });
    el.querySelector('[data-act=del]').addEventListener('click',async ()=>{
      // v37 step36: 本体住所録削除確認をブラウザ標準confirmからDOMモーダルへ移行する。
      if(await showAppConfirm(`「${a.name||a.corp}」を住所録から削除しますか？`,'住所録の削除',{okLabel:'削除する',danger:true})){
        state.addressBook=state.addressBook.filter(x=>x.id!==a.id);
        save();renderAddrbook();
        $('abTabCount').textContent=state.addressBook.length?`(${state.addressBook.length})`:'';
      }
    });
    list.appendChild(el);
  });
}

/* ===== v38-12 extracted from 10_core.js: renderHistory ===== */
function renderHistory(){
  const list=$('histList');
  if(!state.history.length){list.innerHTML='<div class="empty-state">印刷履歴はまだありません</div>';return}
  list.innerHTML='';
  [...state.history].reverse().slice(0,100).forEach(h=>{
    const t=getTpl(h.tplId);
    const currentT=getCurrentTpl();
    const mismatch=h.tplId!==state.selectedTplId;
    const el=document.createElement('div');el.className='history-item';
    el.innerHTML=`<div>
      <div class="dt">${fmtDate(h.printedAt)}</div>
      <div class="nm">${escapeHtml(h.name||h.corp||'(無名)')} ${escapeHtml(h.honor||'')}</div>
      ${h.corp&&h.name?`<div class="meta">${escapeHtml(h.corp)}</div>`:''}
      <div class="meta">${escapeHtml((h.addr||'').slice(0,40))}</div>
      <div class="meta">▸ 印刷時テンプレ：${escapeHtml(t?t.name:'(削除済)')}</div>
    </div>
    <div class="acts">
      ${t?`<button data-id="${h.id}" data-act="addOrig">＋ 元テンプレで</button>`:''}
      ${mismatch&&currentT?`<button data-id="${h.id}" data-act="addCur">＋ 現「${escapeHtml(currentT.name.slice(0,8))}」で</button>`:''}
    </div>`;
    const ob=el.querySelector('[data-act=addOrig]');
    if(ob) ob.addEventListener('click',()=>{
      state.queue.push(cloneQueueItemFromRecord(h, h.tplId));
      save();renderQueue();
      $('step3Next').disabled=state.queue.length===0;
      renderSteps();
      toast(`元のテンプレでキューに追加`,'ok');
    });
    const cb=el.querySelector('[data-act=addCur]');
    if(cb) cb.addEventListener('click',()=>{
      state.queue.push(cloneQueueItemFromRecord(h, state.selectedTplId));
      save();renderQueue();
      $('step3Next').disabled=state.queue.length===0;
      renderSteps();
      toast(`現テンプレでキューに追加`,'ok');
    });
    list.appendChild(el);
  });
}

/* ===== v38-12 extracted from 10_core.js: addToHistory ===== */
function addToHistory(item){
  state.history.push({id:uid('h'),printedAt:Date.now(),...item});
  if(state.history.length>500) state.history=state.history.slice(-500);
}

/* ============================================================
   Excel貼付け式住所録取込
   ============================================================ */

/* ===== v38-12 extracted from 10_core.js: renderPasteImport ===== */
function renderPasteImport(){
  const area=$('pasteImportArea');
  area.innerHTML=`<div class="paste-import">
    <h4 class="serif" style="font-size:14px;margin-bottom:8px">Excelからまとめて取込</h4>
    <p style="font-size:11px;color:#666;margin-bottom:10px">Excelで住所表を選択 → Ctrl+C → 下のテキスト欄にCtrl+V。タブ区切り（Excel標準）/ カンマ区切りテキスト 両対応。CSVファイル読込ではありません</p>
    <textarea class="paste-textarea" id="pasteTxt" placeholder="ここに貼り付け

例：
郵便番号	住所	会社名	氏名	敬称
123-4567	東京都...	株式会社A	山田太郎	様
234-5678	大阪府...	株式会社B	田中花子	様"></textarea>
    <div style="display:flex;gap:6px;margin-top:8px">
      <button class="btn sm primary" id="pasteAnalyze">▼ 解析してプレビュー</button>
      <button class="btn sm ghost" id="pasteClear">クリア</button>
    </div>
    <div id="pastePreview" style="margin-top:14px"></div>
  </div>`;
  (global.safeBindClick || ((el, handler)=>el.addEventListener('click', handler)))($('pasteAnalyze'), analyzePastedData, 'pasteAnalyze');
  (global.safeBindClick || ((el, handler)=>el.addEventListener('click', handler)))($('pasteClear'), ()=>{
    $('pasteTxt').value='';
    $('pastePreview').innerHTML='';
    pasteAnalysis=null;
  });
}

let pasteAnalysis=null;

/* ===== v38-12 extracted from 10_core.js: analyzePastedData ===== */
function analyzePastedData(){
  const raw=$('pasteTxt').value.trim();
  if(!raw){toast('テキストを貼り付けてください','warn');return}
  const lines=raw.split(/\r?\n/).filter(l=>l.trim().length);
  if(!lines.length){toast('データがありません','warn');return}
  const useTab=lines[0].includes('\t');
  const rows=lines.map(line=>{
    if(useTab) return line.split('\t').map(s=>s.trim());
    const cells=[];let cur='',inQ=false;
    for(let i=0;i<line.length;i++){
      const c=line[i];
      if(c==='"'){if(inQ&&line[i+1]==='"'){cur+='"';i++}else inQ=!inQ}
      else if(c===','&&!inQ){cells.push(cur.trim());cur=''}
      else cur+=c;
    }
    cells.push(cur.trim());
    return cells;
  });
  const colCount=Math.max(...rows.map(r=>r.length));
  const header=rows[0];
  const isHeader=header.some(h=>/郵便|住所|氏名|名前|会社|部署|役職|敬称|建物|連名|差出|電話|zip|addr|name|company|dept|title/i.test(h));
  const dataRows=isHeader?rows.slice(1):rows;
  const headerRow=isHeader?header:Array.from({length:colCount},(_,i)=>`列${i+1}`);
  const guessMap={};
  for(let i=0;i<colCount;i++){
    const h=(headerRow[i]||'').toLowerCase();
    const samples=dataRows.slice(0,5).map(r=>r[i]||'').join(' ');
    let key='_skip';
    if(/差出.*郵便|sender.*zip/i.test(h)) key='sender_zip';
    else if(/差出.*住所|sender.*addr/i.test(h)) key='sender_addr';
    else if(/差出.*会社|sender.*company/i.test(h)) key='sender_company';
    else if(/差出.*部署|sender.*dept/i.test(h)) key='sender_dept';
    else if(/差出.*氏名|差出.*名前|sender.*name/i.test(h)) key='sender_name';
    else if(/電話|tel|phone/i.test(h)) key='sender_tel';
    else if(/郵便|zip|postal/i.test(h)) key='zip';
    else if(/住所2|建物|マンション|ビル|addr2|building/i.test(h)) key='addr2';
    else if(/住所|addr|address/i.test(h)) key='addr';
    else if(/会社|法人|company|corp|organization/i.test(h)) key='company';
    else if(/部署|部門|課|係|dept|section/i.test(h)) key='dept';
    else if(/役職|肩書|title|position/i.test(h)) key='title';
    else if(/連名|name2/i.test(h)) key='name2';
    else if(/氏名|名前|name/i.test(h)&&!/会社|company/i.test(h)) key='name';
    else if(/敬称|honor/i.test(h)) key='honor';
    else {
      if(/^\d{3}-?\d{4}/.test((samples.trim().split(/\s+/)[0]||''))) key='zip';
      else if(/[都道府県市区町村]/.test(samples)) key='addr';
      else if(/(株式会社|有限会社|合同会社)/.test(samples)) key='company';
      else if(/(部|課|係|室)$/.test(samples.trim())) key='dept';
    }
    guessMap[i]=key;
  }
  pasteAnalysis={rows:dataRows,headerRow,guessMap,colCount};
  renderPastePreview();
}

/* ===== v38-12 extracted from 10_core.js: renderPastePreview ===== */
function renderPastePreview(){
  if(!pasteAnalysis) return;
  const {rows,headerRow,guessMap,colCount}=pasteAnalysis;
  const previewRows=rows.slice(0,10);
  const fieldOptions=[
    {v:'_skip',l:'─ 取込まない ─'},
    {v:'zip',l:'郵便番号'},
    {v:'addr',l:'住所1'},
    {v:'addr2',l:'住所2・建物名'},
    {v:'company',l:'会社名'},
    {v:'dept',l:'部署名'},
    {v:'title',l:'役職名'},
    {v:'corp',l:'会社・部署まとめ'},
    {v:'name',l:'氏名'},
    {v:'honor',l:'敬称'},
    {v:'name2',l:'連名'},
    {v:'honor2',l:'連名敬称'},
    {v:'sender_zip',l:'差出人郵便番号'},
    {v:'sender_addr',l:'差出人住所'},
    {v:'sender_company',l:'差出人会社'},
    {v:'sender_dept',l:'差出人部署'},
    {v:'sender_name',l:'差出人氏名'},
    {v:'sender_tel',l:'差出人電話'}
  ];
  const candidates=rows.map(r=>{
    const obj={};
    for(let i=0;i<colCount;i++){
      const k=guessMap[i];
      if(k!=='_skip') obj[k]=r[i]||'';
    }
    return obj;
  });
  const duplicates=new Set();
  candidates.forEach((c,idx)=>{
    if(c.name||c.corp){
      const exists=state.addressBook.find(a=>a.name===c.name&&a.corp===c.corp&&a.addr===c.addr);
      if(exists) duplicates.add(idx);
    }
  });
  $('pastePreview').innerHTML=`
    <h5 class="serif" style="font-size:12px;margin-bottom:6px">列の対応を確認</h5>
    <div class="column-mapping">
      ${Array.from({length:colCount},(_,i)=>`
        <div class="col-row">
          <label>${escapeHtml(headerRow[i]||`列${i+1}`)}</label>
          <select data-col="${i}">${fieldOptions.map(o=>`<option value="${o.v}" ${guessMap[i]===o.v?'selected':''}>${o.l}</option>`).join('')}</select>
        </div>`).join('')}
    </div>
    <h5 class="serif" style="font-size:12px;margin:14px 0 6px">プレビュー（先頭${previewRows.length}件 / 全${rows.length}件）${duplicates.size?` <span style="color:var(--warn)">⚠ ${duplicates.size}件が住所録と重複</span>`:''}</h5>
    <div style="overflow-x:auto;max-height:200px">
      <table class="preview-table">
        <thead><tr>${Array.from({length:colCount},(_,i)=>`<th>${escapeHtml(headerRow[i]||`列${i+1}`)} <small style="font-weight:400;color:#888">[${({_skip:'－',zip:'郵',addr:'住1',addr2:'住2',company:'会',dept:'部',title:'役',corp:'会部',name:'氏',honor:'敬',name2:'連',honor2:'連敬',sender_zip:'差郵',sender_addr:'差住',sender_company:'差会',sender_dept:'差部',sender_name:'差氏',sender_tel:'差電'}[guessMap[i]]||'?')}]</small></th>`).join('')}</tr></thead>
        <tbody>
          ${previewRows.map((r,idx)=>`<tr ${duplicates.has(idx)?'class="skip" title="重複候補"':''}>${Array.from({length:colCount},(_,i)=>`<td>${escapeHtml(r[i]||'')}</td>`).join('')}</tr>`).join('')}
        </tbody>
      </table>
    </div>
    <div style="display:flex;gap:8px;margin-top:14px;align-items:center;flex-wrap:wrap">
      <label class="checkbox-row"><input type="checkbox" id="skipDuplicates" ${duplicates.size?'checked':''}><span>重複候補をスキップ</span></label>
      <div style="flex:1"></div>
      <button class="btn primary" id="doPasteImport">${rows.length}件を住所録に取込</button>
    </div>
  `;
  applyScreenA11y($('pastePreview'));
  document.querySelectorAll('[data-col]').forEach(sel=>{
    sel.addEventListener('change',e=>{
      pasteAnalysis.guessMap[+e.target.dataset.col]=e.target.value;
      renderPastePreview();
    });
  });
  (global.safeBindClick || ((el, handler)=>el.addEventListener('click', handler)))($('doPasteImport'), ()=>doImportPaste(duplicates), 'doPasteImport');
}

/* ===== v38-12 extracted from 10_core.js: doImportPaste ===== */
function doImportPaste(duplicates){
  if(!pasteAnalysis) return;
  const skipDup=$('skipDuplicates').checked;
  const {rows,guessMap,colCount}=pasteAnalysis;
  let added=0,skipped=0;
  rows.forEach((r,idx)=>{
    if(skipDup&&duplicates.has(idx)){skipped++;return}
    const obj={id:uid('a')};
    for(let i=0;i<colCount;i++){
      const k=guessMap[i];
      if(k!=='_skip') obj[k]=(r[i]||'').replace(/^〒\s*/,'');
    }
    if(!obj.honor){
      const t=getCurrentTpl();
      obj.honor=t&&t.isReply?'行':'様';
    }
    // v37 step8: normalize後に空行判定する。companyのみの法人宛先を誤ってスキップしないため。
    const normalized = normalizeAddressData(obj);
    if(!normalized.name && !normalized.corp && !normalized.company){skipped++;return}
    state.addressBook.push(normalized);
    added++;
  });
  save();
  pasteAnalysis=null;
  $('pasteTxt').value='';
  $('pastePreview').innerHTML='';
  renderAddrbook();
  $('abTabCount').textContent=state.addressBook.length?`(${state.addressBook.length})`:'';
  renderSteps();
  toast(`${added}件取込（${skipped}件スキップ）`,'ok');
  switchInputPane('addrbook');
}


  const Step3QueueUiApi = Object.freeze({
    renderQueue,
    cloneQueueItemFromRecord,
    renderAddrbook,
    renderHistory,
    addToHistory,
    renderPasteImport,
    analyzePastedData,
    renderPastePreview,
    doImportPaste
  });

  Object.assign(global, {
    renderQueue,
    cloneQueueItemFromRecord,
    renderAddrbook,
    renderHistory,
    addToHistory,
    renderPasteImport,
    analyzePastedData,
    renderPastePreview,
    doImportPaste,
    EnvelopePrintStep3QueueUI: Step3QueueUiApi
  });
})(typeof window !== 'undefined' ? window : globalThis);
