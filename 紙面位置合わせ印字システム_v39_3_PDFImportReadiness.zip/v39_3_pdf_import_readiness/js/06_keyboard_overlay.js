(function(global){
  'use strict';
  /* ============================================================
     Keyboard / Overlay Controller
     v38-77: IIFE Strict Phase23として明示API化。

     契約:
     - classic script前提。ES Modulesは使わない。
     - closeAccessibleModal / showAppConfirm 等は js/05_utilities.js 由来。
     - wizardState / closeWizard / state / getCurrentTpl 等は実行時参照。
     - このモジュールは保存形式・印刷ロジックを変更しない。
     ============================================================ */

  function closeLegacyModal(top){
    if(typeof global.closeAccessibleModal === 'function') global.closeAccessibleModal(top);
    else if(top && typeof top.remove === 'function') top.remove();
  }

  async function closeTopOverlayByEscape(){
    const doc = global.document;
    if(!doc || typeof doc.querySelectorAll !== 'function') return false;
    // v37 step17: ESCキーでDOM上のモーダル/ウィザードを閉じる。ブラウザ標準confirm/alert/promptには介入しない。
    const overlays = Array.from(doc.querySelectorAll('.modal-overlay'));
    const top = overlays.length ? overlays[overlays.length - 1] : null;
    // v37 step42: showAppAlert/showAppConfirm/showAppPromptはPromise解決が必要なため、ウィザードより先に既存ボタン経由で閉じる。
    if(top && top.dataset && top.dataset.appConfirm){
      const cancel = top.querySelector('[data-app-confirm-cancel]');
      if(cancel) cancel.click();
      else top.remove();
      return true;
    }
    if(top && top.dataset && top.dataset.appAlert){
      const close = top.querySelector('[data-app-alert-close]');
      if(close) close.click();
      else top.remove();
      return true;
    }
    if(top && top.dataset && top.dataset.appPrompt){
      const cancel = top.querySelector('[data-app-prompt-cancel]');
      if(cancel) cancel.click();
      else top.remove();
      return true;
    }
    if(top && top.dataset && top.dataset.legacyModal){
      closeLegacyModal(top);
      return true;
    }
    const wizard = doc.querySelector('.wizard-overlay');
    if(wizard && global.wizardState){
      // v37 step38: ESCでのウィザード中止確認もDOMモーダルへ移行する。
      const confirm = typeof global.showAppConfirm === 'function'
        ? global.showAppConfirm
        : async()=>true;
      if(await confirm('ウィザードを中止しますか？\n（未保存の調整内容は破棄されます）','ウィザードの中止',{okLabel:'中止する',danger:true})){
        if(typeof global.closeWizard === 'function') global.closeWizard();
      }
      return true;
    }
    if(!top) return false;
    const host = top.parentElement && top.parentElement.id === 'modalContainer' ? top.parentElement : null;
    if(host){ closeLegacyModal(top); host.innerHTML = ''; }
    else closeLegacyModal(top);
    return true;
  }

  function setupEscapeToCloseOverlays(){
    const doc = global.document;
    if(!doc || typeof doc.addEventListener !== 'function') return false;
    doc.addEventListener('keydown', async e=>{
      if(e.key !== 'Escape') return;
      if(await closeTopOverlayByEscape()){
        e.preventDefault();
        e.stopPropagation();
      }
    });
    return true;
  }

  function setupKeyboard(){
    const doc = global.document;
    if(!doc || typeof doc.addEventListener !== 'function') return false;
    doc.addEventListener('keydown',e=>{
      const tag=(e.target && e.target.tagName || '').toLowerCase();
      if(['input','textarea','select'].includes(tag)) return;
      const appState = global.state;
      if(!appState || appState.currentStep!==2) return;
      if(!appState.selectedFieldId&&!appState.selectedZoneId) return;
      if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)) return;
      if(typeof global.getCurrentTpl !== 'function') return;
      const t=global.getCurrentTpl();
      if(!t||t.locked) return;
      e.preventDefault();
      let target=appState.selectedFieldId
        ?t.fields.find(f=>f.id===appState.selectedFieldId)
        :(t.excludeZones||[]).find(z=>z.id===appState.selectedZoneId);
      if(!target) return;
      const step=e.shiftKey?5:0.5;
      const isResize=e.ctrlKey||e.metaKey;
      let dx=0,dy=0;
      if(e.key==='ArrowLeft') dx=-step;
      if(e.key==='ArrowRight') dx=step;
      if(e.key==='ArrowUp') dy=-step;
      if(e.key==='ArrowDown') dy=step;
      if(isResize){target.w=Math.max(5,target.w+dx);target.h=Math.max(5,target.h+dy);}
      else {target.x=Math.max(0,target.x+dx);target.y=Math.max(0,target.y+dy);}
      if(typeof global.markLayoutChanged === 'function') global.markLayoutChanged(t);
      if(typeof global.renderEnvelope === 'function') global.renderEnvelope();
      if(typeof global.renderFieldList === 'function') global.renderFieldList();
      if(typeof global.renderZoneList === 'function') global.renderZoneList();
      if(typeof global.save === 'function') global.save();
    });
    return true;
  }

  const EnvelopePrintKeyboardOverlay = Object.freeze({
    closeTopOverlayByEscape,
    setupEscapeToCloseOverlays,
    setupKeyboard
  });

  Object.assign(global, {
    closeTopOverlayByEscape,
    setupEscapeToCloseOverlays,
    setupKeyboard,
    EnvelopePrintKeyboardOverlay
  });
})(typeof window !== 'undefined' ? window : globalThis);
