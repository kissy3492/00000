(function(global){
  'use strict';

/* ============================================================
   v38-60: Step4 Test Print UI / IIFE Strict Phase21
   Step4のテスト印刷、キュー整合、プリンタ補正表示、結果確認チェック、Step4固定イベント接続を担当。

   契約:
   - classic script / IIFE + explicit window export。ES Modulesは使わない。
   - 保存キー・保存形式・field.source名は変更しない。
   - 印刷実行本体は js/47_print.js、補正判定は js/53_adjustment_status.js の公開関数を実行時参照する。
   ============================================================ */

/* ============================================================
   ステップ4：テスト印刷＋プリンタ補正
   ============================================================ */

/* ===== v38-12 extracted from 10_core.js: renderStep4 ===== */
function renderStep4(){
  const t=getCurrentTpl();if(!t) return;
  const mismatch=state.queue.filter(q=>q.tplId!==state.selectedTplId);
  if(mismatch.length){
    const tpls=[...new Set(mismatch.map(q=>q.tplId))].map(id=>{const tt=getTpl(id);return tt?tt.name:'(削除済)'});
    $('queueMismatchBanner').style.display='block';
    $('mismatchDetail').innerHTML=`${mismatch.length}件の宛先が現テンプレ「${escapeHtml(t.name)}」と異なります（${tpls.map(escapeHtml).join(', ')}）`;
  } else $('queueMismatchBanner').style.display='none';

  // レイアウト変更検知
  const stat=getTplAdjustmentSummary(t);
  if(t.adjustmentStatus && t.adjustmentStatus.lastLayoutChangedAt && !stat.testPrinted){
    $('layoutChangedBanner').style.display='block';
    $('layoutChangedBanner').innerHTML=`<h4>⚠ レイアウト変更後、テスト印刷結果が未確認です</h4>背景・宛名の位置や、補正値を変更した後は、必ず再度テスト印刷し、結果を確認してください`;
  } else {
    $('layoutChangedBanner').style.display='none';
  }
  renderPrinterProfileSection();
  updateStep4Summary();
  $('markTestPrinted').checked = stat.testPrinted;
}

/* ===== v38-12 extracted from 10_core.js: renderPrinterProfileSection ===== */
function renderPrinterProfileSection(){
  const sec=$('printerProfileSection');
  const t=getCurrentTpl();if(!t) return;
  sec.innerHTML=renderPrinterCalibForm(t);
  bindPrinterCalibForm(t);
}

/* ===== v38-12 extracted from 10_core.js: updateStep4Summary ===== */
function updateStep4Summary(){
  const t=getCurrentTpl();
  const p=getCurrentPrinter();
  $('sumPrinter').textContent=p?p.name:'（未選択）';
  if(t&&p){
    const c=getPrinterCorrection(p.id,t.id);
    $('sumRightShift').textContent=c.rightShift+' mm';
    $('sumDownShift').textContent=c.downShift+' mm';
    $('sumWidthDiff').textContent=c.widthDiff+' mm';
    $('sumHeightDiff').textContent=c.heightDiff+' mm';
  } else {
    $('sumRightShift').textContent='0 mm';
    $('sumDownShift').textContent='0 mm';
    $('sumWidthDiff').textContent='0 mm';
    $('sumHeightDiff').textContent='0 mm';
  }
  const stat=t?getTplAdjustmentSummary(t):null;
  $('sumTestStatus').textContent = stat&&stat.testPrinted?'結果確認済':'未確認';
  $('sumTestStatus').style.color = stat&&stat.testPrinted?'var(--ok)':'var(--warn)';
}



/* ===== v38-69 Browser Hotfix: expose Step4 print actions for delegated fallback ===== */
async function fixQueueMismatchToCurrentTemplate(){
  // v37 step38: キュー整合確認をブラウザ標準confirmからDOMモーダルへ移行する。
  if(await showAppConfirm('キュー全件を現テンプレートに揃えますか？','キューのテンプレート整合',{okLabel:'揃える'})){
    state.queue.forEach(q=>q.tplId=state.selectedTplId);
    save();renderStep4();renderQueue();toast('全件を揃えました','ok');
    return true;
  }
  return false;
}

function removeQueueMismatchFromCurrentTemplate(){
  const before=state.queue.length;
  state.queue=state.queue.filter(q=>q.tplId===state.selectedTplId);
  const removed=before-state.queue.length;
  save();renderStep4();renderQueue();renderSteps();
  toast(`${removed}件削除`,'ok');
  return removed > 0;
}

function printStep4Sample(){
  const t=getCurrentTpl();if(!t) return false;
  const sample=Object.assign({}, getSampleData(t), {tplId:t.id});
  doPrint({queue:[sample]});
  return true;
}

function printStep4FirstQueueItem(){
  const valid=state.queue.filter(q=>q.tplId===state.selectedTplId);
  if(!valid.length){toast('現テンプレに対応する宛先がキューにありません','warn');return false}
  doPrint({queue:[valid[0]]});
  return true;
}

function printStep4CrossTest(){
  doPrint({queue:[],testCross:true});
  return true;
}

/* ===== v38-33: Step4 fixed event binder ===== */
function bindEventsForStep4(){
  const bindClick = global.safeBindClick || ((el, handler)=>el.addEventListener('click', handler));
  bindClick($('step4Back'), ()=>goToStep(3), 'step4Back');
  bindClick($('step4Next'), ()=>goToStep(5), 'step4Next');
  bindClick($('btnFixMismatch'), fixQueueMismatchToCurrentTemplate, 'btnFixMismatch');
  bindClick($('btnRemoveMismatch'), removeQueueMismatchFromCurrentTemplate, 'btnRemoveMismatch');
  bindClick($('btnTestSample'), printStep4Sample, 'btnTestSample');
  bindClick($('btnTestFirst'), printStep4FirstQueueItem, 'btnTestFirst');
  bindClick($('btnTestCross'), printStep4CrossTest, 'btnTestCross');
  $('markTestPrinted').addEventListener('change',e=>{
    const t=getCurrentTpl();if(!t) return;
    if(e.target.checked){
      if(!t.adjustmentStatus) t.adjustmentStatus={};
      // v37 step15: testPrintedAtは実印刷成功ではなく、ユーザによるテスト印刷結果確認の時刻として扱う。
      t.adjustmentStatus.testPrintedAt=Date.now();
      save();renderSteps();renderStep4();
      toast('テスト印刷結果確認済','ok');
    } else {
      if(t.adjustmentStatus) t.adjustmentStatus.testPrintedAt=null;
      save();renderSteps();renderStep4();
    }
  });
}

const Step4TestPrintUiApi = Object.freeze({
  renderStep4,
  renderPrinterProfileSection,
  updateStep4Summary,
  fixQueueMismatchToCurrentTemplate,
  removeQueueMismatchFromCurrentTemplate,
  printStep4Sample,
  printStep4FirstQueueItem,
  printStep4CrossTest,
  bindEventsForStep4
});

  Object.assign(global, {
    renderStep4,
    renderPrinterProfileSection,
    updateStep4Summary,
    fixQueueMismatchToCurrentTemplate,
    removeQueueMismatchFromCurrentTemplate,
    printStep4Sample,
    printStep4FirstQueueItem,
    printStep4CrossTest,
    bindEventsForStep4,
    EnvelopePrintStep4TestPrintUI: Step4TestPrintUiApi
  });
})(typeof window !== 'undefined' ? window : globalThis);
