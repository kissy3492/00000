(function(global){
  'use strict';
  /* ============================================================
     Runtime Error Trap / Action Log
     v38-71: 90_bootstrap.jsから分離。bootstrapは初期化順序に戻す。
     ============================================================ */

function recordRuntimeAction(action){
  const item = Object.assign({
    at: Date.now(),
    step: (typeof state !== 'undefined' && state && state.currentStep) ? state.currentStep : null
  }, action || {});
  const bucket = global.__envelopePrintActionLog || (global.__envelopePrintActionLog = []);
  bucket.push(item);
  if(bucket.length > 60) bucket.splice(0, bucket.length - 60);
  return item;
}

function recordRuntimeError(scope, err){
  const error = err instanceof Error ? err : new Error(String(err && err.message ? err.message : err));
  const item = {
    at: Date.now(),
    scope: scope || 'runtime',
    name: error.name || 'Error',
    message: error.message || String(error),
    stack: error.stack || ''
  };
  const bucket = global.__envelopePrintRuntimeErrors || (global.__envelopePrintRuntimeErrors = []);
  bucket.push(item);
  if(bucket.length > 30) bucket.splice(0, bucket.length - 30);
  try{ console.error('[PaperPrint Runtime]', item.scope, error); }catch(_e){}
  return item;
}

function installRuntimeErrorTrap(){
  if(global.__envelopePrintRuntimeTrapInstalled) return;
  global.__envelopePrintRuntimeTrapInstalled = true;
  if(typeof global.addEventListener !== 'function') return;
  global.addEventListener('error', event => {
    recordRuntimeError('window.error', event && (event.error || event.message));
  });
  global.addEventListener('unhandledrejection', event => {
    recordRuntimeError('unhandledrejection', event && event.reason);
  });
}

const RuntimeErrorTrapApi = Object.freeze({
  recordRuntimeAction,
  recordRuntimeError,
  installRuntimeErrorTrap
});

Object.assign(global, {
  recordRuntimeAction,
  recordRuntimeError,
  installRuntimeErrorTrap,
  EnvelopePrintRuntimeErrorTrap: RuntimeErrorTrapApi
});
})(typeof window !== 'undefined' ? window : globalThis);
