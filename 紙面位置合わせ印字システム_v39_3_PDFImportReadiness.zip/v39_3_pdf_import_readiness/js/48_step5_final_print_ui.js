(function(global){
  'use strict';

/* ============================================================
   v38-61: Step5 Final Print UI / IIFE Strict Phase22

   契約:
   - classic script / IIFE + explicit window export。ES Modulesは使わない。
   - 保存キー・保存形式・field.source名は変更しない。
   - Step5ExtensionRegistry hookを維持する。
   - 印刷実行本体・チェックリスト描画・印刷アクション描画は js/47_print.js の公開関数を実行時参照する。
   ============================================================ */

/* ============================================================
   ステップ5：本印刷
   ============================================================ */

/* ===== v38-12 extracted from 10_core.js: renderStep5 ===== */
function renderStep5(){
  const t=getCurrentTpl();
  $('sumTpl').textContent=t?t.name:'—';
  $('sumSize').textContent=t?`${t.w}×${t.h} mm`:'—';
  const validQueueForCount=state.queue.filter(q=>q.tplId===state.selectedTplId);
  const pageCount=t?getEffectivePrintPageCount(t, validQueueForCount.length):0;
  $('sumCount').textContent=t&&t.paperKind==='label_sheet'?`${validQueueForCount.length}件 / ${pageCount}ページ`:state.queue.length+' 枚';
  const p=getCurrentPrinter();
  if(t&&p){
    const c=getPrinterCorrection(p.id,t.id);
    const hasCorr=hasAnyCorrection(c);
    $('sumCorrection').textContent=hasCorr?p.name:'なし';
  } else $('sumCorrection').textContent='なし';

  renderFinalChecklist();
  renderPrintActionArea();
  // v37 step21: Step5描画後の拡張UIはrenderStep5ラッパーではなくRegistry経由で差し込む。
  if(window.Step5ExtensionRegistry && typeof window.Step5ExtensionRegistry.runRenderHooks === 'function'){
    window.Step5ExtensionRegistry.runRenderHooks({tpl:t});
  }

  const stack=$('printPreviewStack');stack.innerHTML='';
  if(!t||!state.queue.length){stack.innerHTML='<div class="empty-state">印刷キューが空です</div>';return}
  const validQueue=state.queue.filter(q=>q.tplId===state.selectedTplId);
  const previewScale=0.5;
  if(t.paperKind==='label_sheet'){
    const cfg=getLabelConfig(t);
    const cap=labelCapacity(t);
    const pages=getEffectivePrintPageCount(t, validQueue.length);
    const info=document.createElement('div');
    info.className='info-banner';
    info.innerHTML=`<h4>ラベル面付け印刷</h4><div>1ページあたり${cap}面、${validQueue.length}件を${pages}ページに分けて印刷します。プレビューは先頭ページです。</div>`;
    stack.appendChild(info);
    const env=document.createElement('div');
    env.className='mini-envelope';
    env.style.width=(t.w*previewScale)+'mm';env.style.height=(t.h*previewScale)+'mm';env.style.position='relative';
    const pageLayer=document.createElement('div');pageLayer.className='print-layer';env.appendChild(pageLayer);
    // v37 step21: プレビュー先頭ページにもラベル開始位置を反映する。
    const start=Math.max(1, Math.min(cap, +(t.labelStartIndex||1)));
    const offset=start-1;
    for(let slot=0; slot<cap; slot++){
      const qi=slot-offset;
      if(qi<0 || qi>=validQueue.length) continue;
      const q=validQueue[qi];
      const col=slot%cfg.cols,row=Math.floor(slot/cfg.cols);
      renderLabelCellInto(pageLayer,t,normalizeAddressData(Object.assign({},q)),(cfg.marginX+col*(cfg.labelW+cfg.gapX))*previewScale,(cfg.marginY+row*(cfg.labelH+cfg.gapY))*previewScale,Object.assign({},cfg,{labelW:cfg.labelW*previewScale,labelH:cfg.labelH*previewScale}));
      Array.from(pageLayer.querySelectorAll('.field')).forEach(el=>{
        if(!el.dataset.scaled){
          el.dataset.scaled='1';
          el.style.left=(parseFloat(el.style.left)*previewScale)+'mm';
          el.style.top=(parseFloat(el.style.top)*previewScale)+'mm';
          el.style.width=(parseFloat(el.style.width)*previewScale)+'mm';
          el.style.height=(parseFloat(el.style.height)*previewScale)+'mm';
          el.style.fontSize=(parseFloat(el.style.fontSize)*previewScale)+'pt';
        }
      });
    }
    stack.appendChild(env);
    return;
  }
  validQueue.slice(0,10).forEach((q,i)=>{
    const env=document.createElement('div');
    env.className='mini-envelope';
    env.style.width=(t.w*previewScale)+'mm';
    env.style.height=(t.h*previewScale)+'mm';
    env.style.position='relative';
    const data=normalizeAddressData(Object.assign({}, q));
    renderEnvelopeInto(env, t, data, {
      editable:false, scale:previewScale, interactive:false, showBg:false, showZones:false, applyCorrection:false
    });
    const wrap=document.createElement('div');wrap.style.textAlign='center';
    const label=document.createElement('div');
    label.style.cssText='font-family:monospace;font-size:10px;color:#666;margin-bottom:6px';
    label.textContent=`#${String(i+1).padStart(2,'0')}  ${q.name||q.corp||''} ${q.honor||''}`;
    wrap.appendChild(label);wrap.appendChild(env);
    stack.appendChild(wrap);
  });
  if(validQueue.length>10){
    const more=document.createElement('div');
    more.style.cssText='font-size:11px;color:#888;margin-top:10px;text-align:center';
    more.textContent=`...他 ${validQueue.length-10}件`;
    stack.appendChild(more);
  }
}



/* ===== v38-69 Browser Hotfix: expose Step5 start-over action for delegated fallback ===== */
async function startOverFromStep5(){
  // v37 step40: 最初のステップへ戻る確認をブラウザ標準confirmからDOMモーダルへ移行する。
  if(await showAppConfirm('最初のステップに戻りますか？','最初のステップへ戻る',{okLabel:'戻る'})){
    goToStep(1);
    return true;
  }
  return false;
}

/* ===== v38-33: Step5 fixed event binder ===== */
function bindEventsForStep5(){
  const bindClick = global.safeBindClick || ((el, handler)=>el.addEventListener('click', handler));
  bindClick($('step5Back'), ()=>goToStep(4), 'step5Back');
  bindClick($('btnStartOver'), startOverFromStep5, 'btnStartOver');
}

const Step5FinalPrintUiApi = Object.freeze({
  renderStep5,
  startOverFromStep5,
  bindEventsForStep5
});

  Object.assign(global, {
    renderStep5,
    startOverFromStep5,
    bindEventsForStep5,
    EnvelopePrintStep5FinalPrintUI: Step5FinalPrintUiApi
  });
})(typeof window !== 'undefined' ? window : globalThis);
