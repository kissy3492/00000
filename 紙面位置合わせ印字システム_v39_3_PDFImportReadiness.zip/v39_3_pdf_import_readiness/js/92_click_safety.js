(function(global){
  'use strict';
  /* ============================================================
     Click Safety / Safe Binding
     v38-71: EventTargetプロトタイプを触らず、明示bindだけを安全化する。
     ============================================================ */

function markClickHandled(event){
  if(!event || event.__paperPrintHandled) return;
  try{ Object.defineProperty(event, '__paperPrintHandled', {value:true, configurable:true}); }
  catch(_e){ event.__paperPrintHandled = true; }
}

function markClickAttempted(event){
  if(!event || event.__paperPrintHandlerAttempted) return;
  try{ Object.defineProperty(event, '__paperPrintHandlerAttempted', {value:true, configurable:true}); }
  catch(_e){ event.__paperPrintHandlerAttempted = true; }
}

function getActionTargetLabel(target){
  if(!target) return '';
  return String(target.textContent || target.getAttribute('aria-label') || target.title || target.id || target.className || '').replace(/\s+/g, ' ').trim().slice(0, 80);
}

function safeBindClick(targetOrId, handler, label){
  const target = typeof targetOrId === 'string' && typeof global.$ === 'function' ? global.$(targetOrId) : targetOrId;
  if(!target || typeof target.addEventListener !== 'function' || typeof handler !== 'function') return false;
  const actionId = target.id || String(label || 'click');
  const actionLabel = label || getActionTargetLabel(target) || actionId;
  target.addEventListener('click', function(event){
    markClickAttempted(event);
    try{
      const result = handler.call(this, event);
      markClickHandled(event);
      if(typeof global.recordRuntimeAction === 'function') global.recordRuntimeAction({kind:'safe-click', id:actionId, label:actionLabel, handled:true, fallback:false});
      if(result && typeof result.catch === 'function'){
        result.catch(err => {
          if(typeof global.recordRuntimeError === 'function') global.recordRuntimeError(`click handler:${actionId}`, err);
          if(typeof global.recordRuntimeAction === 'function') global.recordRuntimeAction({kind:'handler-error', id:actionId, label:actionLabel, handled:true, fallback:false, error:err && err.message || String(err)});
        });
      }
      return result;
    }catch(err){
      if(typeof global.recordRuntimeError === 'function') global.recordRuntimeError(`click handler:${actionId}`, err);
      if(typeof global.recordRuntimeAction === 'function') global.recordRuntimeAction({kind:'handler-error', id:actionId, label:actionLabel, handled:false, fallback:false, error:err && err.message || String(err)});
      // Do not mark handled on synchronous failure. The delegated fallback may still rescue critical actions.
      return false;
    }
  });
  return true;
}

const ClickSafetyApi = Object.freeze({
  markClickHandled,
  markClickAttempted,
  getActionTargetLabel,
  safeBindClick
});

Object.assign(global, {
  markClickHandled,
  markClickAttempted,
  getActionTargetLabel,
  safeBindClick,
  EnvelopePrintClickSafety: ClickSafetyApi
});
})(typeof window !== 'undefined' ? window : globalThis);
