(function(global){
  'use strict';
  /* ============================================================
     Bootstrap Controller
     v38-71: runtime trap / click safety / click fallback / diagnosticsを
     91〜94へ分離し、bootstrapを初期化順序とイベント委譲に戻す。
     ============================================================ */

function runBootstrapTask(label, fn){
  try{
    if(typeof fn !== 'function') throw new Error(`${label} is not available`);
    return fn();
  }catch(err){
    if(typeof global.recordRuntimeError === 'function') global.recordRuntimeError(label, err);
    try{
      if(typeof global.toast === 'function') global.toast(`${label} でエラーが発生しました。バックアップ画面の実行時エラーを確認してください`, 'warn');
    }catch(_e){}
    return null;
  }
}

function bindEvents(){
  // delegate markers retained for static tests: bindEventsForCommonUI(); bindEventsForStep1(); bindEventsForStep2(); bindEventsForStep3(); bindEventsForStep4(); bindEventsForStep5();
  const binders = [
    ['bindEventsForCommonUI', global.bindEventsForCommonUI],
    ['bindEventsForStep1', global.bindEventsForStep1],
    ['bindEventsForStep2', global.bindEventsForStep2],
    ['bindEventsForStep3', global.bindEventsForStep3],
    ['bindEventsForStep4', global.bindEventsForStep4],
    ['bindEventsForStep5', global.bindEventsForStep5]
  ];
  binders.forEach(([label, fn]) => runBootstrapTask(label, fn));
}

function selectLastUsedTemplate(){
  if(state.lastUsedTplId && getTpl(state.lastUsedTplId)) state.selectedTplId = state.lastUsedTplId;
  return state.selectedTplId || null;
}

function initializeApp(options){
  const hooks = options || {};
  if(global.__ENVELOPE_PRINT_INITIALIZED && !hooks.force) return false;
  runBootstrapTask('installRuntimeErrorTrap', hooks.installRuntimeErrorTrap || global.installRuntimeErrorTrap);
  runBootstrapTask('installCriticalClickFallback', hooks.installCriticalClickFallback || global.installCriticalClickFallback);
  runBootstrapTask('load', hooks.load || global.load);
  runBootstrapTask('setupKeyboard', hooks.setupKeyboard || global.setupKeyboard);
  runBootstrapTask('setupEscapeToCloseOverlays', hooks.setupEscapeToCloseOverlays || global.setupEscapeToCloseOverlays);
  runBootstrapTask('bindEvents', hooks.bindEvents || bindEvents);
  runBootstrapTask('selectLastUsedTemplate', hooks.selectLastUsedTemplate || selectLastUsedTemplate);
  runBootstrapTask('goToStep(1)', () => (hooks.goToStep || global.goToStep)(1));
  runBootstrapTask('updateStorageStatus', hooks.updateStorageStatus || global.updateStorageStatus);
  runBootstrapTask('runInteractionSelfDiagnostics', hooks.runInteractionSelfDiagnostics || global.runInteractionSelfDiagnostics);
  global.__ENVELOPE_PRINT_INITIALIZED = true;
  return true;
}

function scheduleInitializeApp(){
  if(global.__ENVELOPE_PRINT_BOOTSTRAP_SCHEDULED) return;
  global.__ENVELOPE_PRINT_BOOTSTRAP_SCHEDULED = true;
  const run = () => initializeApp();
  if(typeof global.setTimeout === 'function') global.setTimeout(run, 0);
  else run();
}

const EnvelopePrintBootstrap = Object.freeze({
  bindEvents,
  selectLastUsedTemplate,
  initializeApp,
  scheduleInitializeApp,
  runBootstrapTask
});

Object.assign(global, {
  bindEvents,
  selectLastUsedTemplate,
  initializeApp,
  scheduleInitializeApp,
  EnvelopePrintBootstrap
});

if(!global.__ENVELOPE_PRINT_BOOTSTRAP_TEST_MODE){
  scheduleInitializeApp();
}
})(typeof window !== 'undefined' ? window : globalThis);
