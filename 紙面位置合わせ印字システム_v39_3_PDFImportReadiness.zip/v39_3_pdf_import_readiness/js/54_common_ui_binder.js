(function(global){
'use strict';
/* ============================================================
   Common UI Binder
   v38-49: Common UI BinderをIIFE Strict Phase10として再整備。
   保存キー・保存形式・field.source名は変更しない。
   ============================================================ */

function bindEventsForCommonUI(){
  const bindClick = global.safeBindClick || ((el, handler)=>el.addEventListener('click', handler));
  bindClick($('btnHelp'), showHelp, 'btnHelp');
  bindClick($('btnDataMgmt'), showDataMgmt, 'btnDataMgmt');

  bindClick($('modeSimple'), ()=>{
    state.uiMode='simple';
    $('modeSimple').classList.add('active');
    $('modeAdvanced').classList.remove('active');
    if(state.currentStep===2) state.currentStep=1;
    renderSteps();
    goToStep(state.currentStep);
  });
  bindClick($('modeAdvanced'), ()=>{
    state.uiMode='advanced';
    $('modeAdvanced').classList.add('active');
    $('modeSimple').classList.remove('active');
    renderSteps();
    goToStep(state.currentStep);
  });
}

const CommonUiApi = Object.freeze({
  bindEventsForCommonUI
});

global.bindEventsForCommonUI = bindEventsForCommonUI;
global.EnvelopePrintCommonUI = CommonUiApi;
})(window);
