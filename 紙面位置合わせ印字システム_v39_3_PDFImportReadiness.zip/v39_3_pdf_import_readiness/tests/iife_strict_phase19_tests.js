#!/usr/bin/env node
/* v38-58 IIFE Strict Phase19 tests: Step3 Input Core scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const step3 = fs.readFileSync(path.join(root, 'js', '48_step3_input_core.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataMgmtUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

function ok(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

const legacyFns = ['renderStep3','renderInputForm','getInputData','loadAddrToInput','clearInput','switchInputPane','bindEventsForStep3'];

ok('step3 input core starts with IIFE + strict', ()=>{
  assert.ok(/^\(function\(global\)\{/.test(step3), 'Step3 Input Core must start with IIFE');
  assert.ok(step3.slice(0, 260).includes("'use strict';"), 'Step3 Input Core must enable strict mode near the top');
});

ok('step3 input core exposes legacy globals and EnvelopePrintStep3InputCore API', ()=>{
  for(const name of legacyFns){
    assert.ok(new RegExp(`function\\s+${name}\\s*\\(`).test(step3), `${name} must remain present`);
  }
  assert.ok(/const\s+Step3InputCoreApi\s*=\s*Object\.freeze\(\{[\s\S]*renderStep3[\s\S]*bindEventsForStep3/.test(step3), 'Step3InputCoreApi freeze block missing');
  assert.ok(/EnvelopePrintStep3InputCore:\s*Step3InputCoreApi/.test(step3), 'EnvelopePrintStep3InputCore export missing');
  assert.ok(/Object\.assign\(global,[\s\S]*renderStep3[\s\S]*bindEventsForStep3[\s\S]*EnvelopePrintStep3InputCore/.test(step3), 'legacy Step3 exports must remain assigned to global');
});

ok('lightweight VM load exposes step3 API and preserves input contracts', ()=>{
  function makeElement(id){
    return {
      id,
      value:'',
      textContent:'',
      innerHTML:'',
      disabled:false,
      dataset:{pane:id.replace('tab','').toLowerCase() || 'manual'},
      handlers:{},
      style:{display:''},
      classList:{toggle(){}, add(){}, remove(){}},
      addEventListener(type, fn){ this.handlers[type] = fn; },
      focus(){ this.focused = true; }
    };
  }
  const elements = {};
  const ids = ['inputForm','iZip','iAddr','iAddr2','iCompany','iDept','iTitle','iCorp','iName','iHonor','iName2','iHonor2','iSenderZip','iSenderAddr','iSenderCompany','iSenderDept','iSenderName','iSenderTel','step3Title','step3Subtitle','replyBanner3','abTabCount','histTabCount','step3Next','step3Back','btnAddQueue','btnSaveToAddrbook','btnClearInput','abSearch','btnClearQueue','btnClearHistory'];
  for(const id of ids) elements[id] = makeElement(id);
  elements.iName.value = '  山田太郎  ';
  elements.iCompany.value = ' 株式会社A ';
  elements.iAddr.value = ' 青森市 ';
  elements.iHonor.value = '様';
  elements.iHonor2.value = '様';
  const tabs = [makeElement('tabManual'), makeElement('tabAddrbook')];
  tabs[0].dataset.pane = 'manual';
  tabs[1].dataset.pane = 'addrbook';
  const panes = [makeElement('paneManual'), makeElement('paneAddrbook')];
  panes[0].dataset.pane = 'manual';
  panes[1].dataset.pane = 'addrbook';
  const inputTabsContainer = makeElement('inputTabs');
  const calls = [];
  const sandbox = {
    console,
    window:null,
    globalThis:null,
    state:{selectedTplId:'tpl1', queue:[], addressBook:[], history:[], printAttempts:[], activeInputPane:'manual', uiMode:'advanced'},
    document:{
      activeElement:tabs[0],
      querySelectorAll(sel){
        if(sel === '.input-tab') return tabs;
        if(sel === '.input-pane') return panes;
        return [];
      },
      querySelector(sel){
        if(sel === '.input-tabs') return inputTabsContainer;
        if(sel === '#inputForm input:not([type=hidden]),#inputForm textarea') return elements.iName;
        return null;
      }
    },
    $(id){ return elements[id] || (elements[id] = makeElement(id)); },
    getCurrentTpl(){ return {id:'tpl1', isReply:false}; },
    renderQueue(){ calls.push('renderQueue'); },
    renderAddrbook(){ calls.push('renderAddrbook'); },
    renderHistory(){ calls.push('renderHistory'); },
    renderPasteImport(){ calls.push('renderPasteImport'); },
    getPrintRecordCount(){ return 0; },
    applyScreenA11y(){ calls.push('applyScreenA11y'); },
    applyInputTabsA11y(){ calls.push('applyInputTabsA11y'); },
    normalizeAddressData(data){ return Object.assign({normalized:true}, data); },
    clearInputInvalidStates(){ calls.push('clearInputInvalidStates'); },
    markInputFieldsInvalid(ids, msg){ calls.push(['markInputFieldsInvalid', ids, msg]); },
    toast(msg, type){ calls.push(['toast', msg, type]); },
    save(){ calls.push('save'); },
    renderSteps(){ calls.push('renderSteps'); },
    uid(prefix){ return `${prefix}_1`; },
    goToStep(n){ calls.push(['goToStep', n]); },
    showAppConfirm: async () => true,
    Step3ExtensionRegistry:{
      runRenderHooks(){ calls.push('runRenderHooks'); },
      runManualPaneHooks(){ calls.push('runManualPaneHooks'); }
    },
    InputDataExtensionRegistry:{
      runCollectHooks(data){ calls.push('runCollectHooks'); return Object.assign({collected:true}, data); },
      runLoadHooks(data){ calls.push(['runLoadHooks', data.name]); },
      runClearHooks(){ calls.push('runClearHooks'); }
    },
    InputValidationRegistry:{
      runBeforeAddQueueHooks(ctx){ calls.push(['runBeforeAddQueueHooks', ctx.source]); return true; }
    }
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(step3, sandbox, {filename:'js/48_step3_input_core.js'});

  assert.strictEqual(typeof sandbox.EnvelopePrintStep3InputCore, 'object');
  assert.ok(Object.isFrozen(sandbox.EnvelopePrintStep3InputCore), 'EnvelopePrintStep3InputCore must be frozen');
  assert.strictEqual(sandbox.EnvelopePrintStep3InputCore.getInputData, sandbox.getInputData);
  const data = sandbox.getInputData();
  assert.strictEqual(data.name, '山田太郎');
  assert.strictEqual(data.collected, true);
  sandbox.loadAddrToInput({name:'佐藤', zip:'〒030-0000'});
  assert.strictEqual(elements.iZip.value, '030-0000');
  sandbox.clearInput();
  assert.strictEqual(elements.iName.value, '');
  assert.ok(calls.includes('runClearHooks'));
  sandbox.switchInputPane('manual');
  assert.ok(calls.includes('runManualPaneHooks'));
  sandbox.bindEventsForStep3();
  elements.iName.value = '山田太郎';
  elements.iCompany.value = '';
  elements.iCorp.value = '';
  elements.btnAddQueue.handlers.click();
  assert.strictEqual(sandbox.state.queue.length, 1);
  assert.strictEqual(sandbox.state.queue[0].tplId, 'tpl1');
  assert.ok(calls.some(item => Array.isArray(item) && item[0] === 'runBeforeAddQueueHooks' && item[1] === 'manual'));
});

ok('global module indexes expose Step3 Input Core API', ()=>{
  assert.ok(/Step3Input:EnvelopePrintStep3InputCore/.test(core), 'EnvelopePrintModules must expose EnvelopePrintStep3InputCore');
  assert.ok(/Step3Input:\['EnvelopePrintStep3InputCore','renderStep3','renderInputForm','getInputData','loadAddrToInput','clearInput','switchInputPane','addCurrentInputToQueue','saveCurrentInputToAddrbook','clearQueueWithConfirm','clearHistoryWithConfirm','bindEventsForStep3'\]/.test(dataMgmtUi), 'getModuleOverview must expose Step3 Input Core API');
});

ok('verification pipeline includes phase19 guard', ()=>{
  assert.ok(verify.includes('js/48_step3_input_core.js'), 'verify_structure must include Step3 input core guard');
  assert.ok(verify.includes('EnvelopePrintStep3InputCore'), 'verify_structure must check EnvelopePrintStep3InputCore');
  assert.ok(verifySh.includes('tests/iife_strict_phase19_tests.js'), 'verify.sh must run phase19 tests');
});

console.log('IIFE strict phase19 tests: OK');
