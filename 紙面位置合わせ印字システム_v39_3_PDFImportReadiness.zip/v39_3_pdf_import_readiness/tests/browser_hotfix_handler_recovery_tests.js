#!/usr/bin/env node
/* v38-66 Browser Hotfix Handler Recovery tests.
   click handler が例外を投げた場合に fallback を塞がないことを固定する。 */
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const bootstrap = fs.readFileSync(path.join(root, 'js', '90_bootstrap.js'), 'utf8');
const clickSafety = fs.readFileSync(path.join(root, 'js', '92_click_safety.js'), 'utf8');
const dataUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

function test(name, fn){
  try{ fn(); console.log(`OK ${name}`); }
  catch(err){ console.error(`NG ${name}`); throw err; }
}

test('safeBindClick marks handled only after handler success and keeps fallback open on throw', ()=>{
  const attemptedIdx = clickSafety.indexOf('__paperPrintHandlerAttempted');
  const callIdx = clickSafety.indexOf('handler.call(this, event)');
  const handledIdx = clickSafety.indexOf('markClickHandled(event)', callIdx);
  assert.ok(attemptedIdx >= 0, 'handler attempted marker must exist');
  assert.ok(callIdx >= 0, 'safeBindClick handler call must exist');
  assert.ok(handledIdx > callIdx, 'handled marker must be set after handler call so throwing handlers do not block fallback');
  const catchIdx = clickSafety.indexOf('catch(err)', callIdx);
  assert.ok(catchIdx > callIdx, 'safeBindClick catch must exist after handler call');
  const catchBlock = bootstrap.slice(catchIdx, catchIdx + 900);
  assert.ok(!/markClickHandled\(event\)/.test(catchBlock), 'throwing click handlers must not mark event handled');
});

test('click handler errors are recorded in action log with id and label', ()=>{
  assert.match(clickSafety, /kind:'handler-error'/);
  assert.match(clickSafety, /recordRuntimeAction\(\{[\s\S]*kind:'handler-error'[\s\S]*error:err && err\.message/s);
  assert.match(clickSafety, /recordRuntimeError\(`click handler:\$\{actionId\}`, err\)/);
});

test('data management action report includes handler error text', ()=>{
  assert.match(dataUi, /e\.error\?`<br><span style="color:var\(--warn\)">error:/);
  assert.match(dataUi, /e\.error\?` error=\$\{e\.error\}`/);
});

test('release notes and verify include v38-66 handler recovery guard', ()=>{
  assert.match(core, /\{step:'v38-66'[\s\S]*Handler Recovery/);
  assert.ok(verifySh.includes('tests/browser_hotfix_handler_recovery_tests.js'), 'verify.sh must run handler recovery tests');
});

console.log('Browser hotfix handler recovery tests: OK');
