#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');

const addons = [
  {
    file: 'js/50_stage5_addon.js',
    key: 'paper_position_print_system_v37_stage5_addons',
    exports: ['EnvelopePrintStage5', 'EnvelopePrintModules.Extensions.Stage5'],
    registries: ['Step3ExtensionRegistry', 'InputValidationRegistry']
  },
  {
    file: 'js/60_stage6_addon.js',
    key: 'paper_position_print_system_v37_stage6',
    exports: ['Stage6'],
    registries: ['FieldSourceRegistry.registerPostProcessor', 'Step3ExtensionRegistry', 'Step5ExtensionRegistry']
  },
  {
    file: 'js/70_stage7_addon.js',
    key: 'paper_position_print_system_v37_stage7_addon',
    exports: ['EnvelopePrintStage7', 'EnvelopePrintModules.Extensions.Stage7'],
    registries: ['FieldSourceRegistry', 'SampleDataRegistry', 'InputDataExtensionRegistry', 'Step3ExtensionRegistry']
  },
  {
    file: 'js/80_stage8_addon.js',
    key: 'paper_position_print_system_v37_stage8_validation',
    exports: ['Extensions.Stage8'],
    registries: ['Step5ExtensionRegistry', 'PrintExecutionRegistry']
  }
];

for (const addon of addons) {
  const src = read(addon.file);
  assert(/\(function\s*\([^)]*\)\s*\{/.test(src) || /\(function\s*\(\)\s*\{/.test(src), `${addon.file}: should be isolated in an IIFE`);
  assert(/['"]use strict['"]/.test(src), `${addon.file}: should use strict mode`);
  assert(src.includes(addon.key), `${addon.file}: stable ADDON_KEY is missing or changed`);
  assert(/DOMContentLoaded/.test(src), `${addon.file}: should preserve DOMContentLoaded/init guard pattern`);
  for (const token of addon.exports) {
    assert(src.includes(token), `${addon.file}: expected export/namespace token missing: ${token}`);
  }
  for (const token of addon.registries) {
    assert(src.includes(token), `${addon.file}: expected registry connection missing: ${token}`);
  }
  assert(!/window\.getFieldText\s*=/.test(src), `${addon.file}: must not monkey patch window.getFieldText`);
  assert(!/\bgetFieldText\s*=\s*function/.test(src), `${addon.file}: must not reassign getFieldText`);
  assert(!/\bfunction\s+renderEnvelopeInto\s*\(/.test(src), `${addon.file}: must not define core renderer`);
  assert(!/\bfunction\s+save\s*\(/.test(src), `${addon.file}: must not define core save`);
}

const index = read('index.html');
const scriptOrder = Array.from(index.matchAll(/<script[^>]+src="([^"]+)"/g)).map(m => m[1]);
const pos = name => scriptOrder.indexOf(name);
assert(pos('js/90_bootstrap.js') >= 0, 'bootstrap script missing');
assert(pos('js/99_audit_marker.js') >= 0, 'audit marker script missing');
for (const addon of addons) {
  assert(pos(addon.file) > pos('js/90_bootstrap.js'), `${addon.file}: must load after bootstrap`);
  assert(pos(addon.file) < pos('js/99_audit_marker.js'), `${addon.file}: must load before audit marker`);
}
assert(pos('js/50_stage5_addon.js') < pos('js/60_stage6_addon.js'), 'Stage5 must load before Stage6');
assert(pos('js/60_stage6_addon.js') < pos('js/70_stage7_addon.js'), 'Stage6 must load before Stage7');
assert(pos('js/70_stage7_addon.js') < pos('js/80_stage8_addon.js'), 'Stage7 must load before Stage8');

console.log('Stage addon static tests: 4 files OK');
