#!/usr/bin/env node
/* v39-1: README release history and v39 feature-start tests. */
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
function read(p){ return fs.readFileSync(path.join(root, p), 'utf8'); }

const readme = read('README.md');
const core = read('js/10_core.js');
const manifest = JSON.parse(read('split_manifest.json'));
const manifestReleaseId = (manifest.version.match(/v\d+-\d+/) || [])[0];
assert(manifestReleaseId, 'manifest version must include a release id');

const v38Headings = Array.from(readme.matchAll(/^## v38-(\d+)\b.*$/gm)).map(m => Number(m[1]));
const expectedV38 = [];
for(let n = 6; n <= 80; n++) expectedV38.push(n);
assert.deepStrictEqual(v38Headings, expectedV38, 'README v38 release headings must remain complete, ascending, and gapless from v38-6 to v38-80');
assert.strictEqual(new Set(v38Headings).size, v38Headings.length, 'README v38 release headings must not contain duplicates');

for(let n = 25; n <= 80; n++){
  assert(core.includes(`{step:'v38-${n}'`), `APP_RELEASE_NOTES missing v38-${n}`);
}

assert(readme.includes('## v38-80 Refactor Closeout'), 'README must include v38-80 Closeout section');
assert(readme.includes('v38-80を構造リファクタの完了整理版'), 'README must declare v38-80 as refactor closeout');
assert(core.includes('APP_V38_CLOSEOUT_DECISION'), 'core must expose APP_V38_CLOSEOUT_DECISION');
assert(core.includes('Phase26を追加しない'), 'core must explicitly guard against ritual Phase26 continuation');
assert(core.includes('EnvelopePrintRuntime'), 'core must expose EnvelopePrintRuntime namespace');
assert(readme.includes('PAPERPRINT_REQUIRE_BROWSER_E2E=1'), 'README must document required Browser E2E mode');

if(/^v39-/.test(manifestReleaseId)){
  const v39Minor = Number(manifestReleaseId.split('-')[1]);
  const v39Headings = Array.from(readme.matchAll(/^## v39-(\d+)\b.*$/gm)).map(m => Number(m[1]));
  const expectedV39 = [];
  for(let n = 1; n <= v39Minor; n++) expectedV39.push(n);
  assert.deepStrictEqual(v39Headings, expectedV39, 'README v39 release headings must be complete, ascending, and gapless from v39-1 to latest');
  for(let n = 1; n <= v39Minor; n++){
    assert(core.includes(`{step:'v39-${n}'`), `APP_RELEASE_NOTES missing v39-${n}`);
  }
  assert(readme.includes('## v39-1 Backup Capability UX'), 'README must include v39-1 feature-start section');
  assert(readme.includes('保存環境診断'), 'README must document backup capability diagnostics');
  assert(core.includes('Backup Capability UX'), 'core release notes must document v39-1 Backup Capability UX');
  if(v39Minor >= 2){
    assert(readme.includes('## v39-2 Pinned Backup Target'), 'README must include v39-2 pinned backup target section');
    assert(readme.includes('保存先固定'), 'README must document pinned backup target');
    assert(core.includes('Pinned Backup Target'), 'core release notes must document v39-2 Pinned Backup Target');
  }
  if(v39Minor >= 3){
    assert(readme.includes('## v39-3 PDF Import Readiness'), 'README must include v39-3 PDF Import Readiness section');
    assert(readme.includes('pdf.min.js') && readme.includes('pdf.worker.min.js'), 'README must document PDF runtime files');
    assert(core.includes('PDF Import Readiness'), 'core release notes must document v39-3 PDF Import Readiness');
  }
}


console.log('README Release History tests: OK');
