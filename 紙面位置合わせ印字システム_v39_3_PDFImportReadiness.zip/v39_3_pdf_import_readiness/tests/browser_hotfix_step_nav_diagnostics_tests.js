#!/usr/bin/env node
const assert = require('assert');
const fs = require('fs');
const vm = require('vm');

const bootstrap = fs.readFileSync('js/90_bootstrap.js', 'utf8');
const runtimeTrap = fs.readFileSync('js/91_runtime_error_trap.js', 'utf8');
const clickSafety = fs.readFileSync('js/92_click_safety.js', 'utf8');
const clickFallback = fs.readFileSync('js/93_click_fallback.js', 'utf8');
const diagnostics = fs.readFileSync('js/94_self_diagnostics.js', 'utf8');
const stepNav = fs.readFileSync('js/48_step_navigation.js', 'utf8');
const dataMgmt = fs.readFileSync('js/52_data_management_ui.js', 'utf8');
const verify = fs.readFileSync('tools/verify.sh', 'utf8');
const structure = fs.readFileSync('tools/verify_structure.js', 'utf8');
const readme = fs.readFileSync('README.md', 'utf8');

function assertIncludes(src, needle, message){ assert(src.includes(needle), message); }

assertIncludes(stepNav, "el.dataset.stepNav=String(s.n)", 'renderSteps must mark sidebar step items with data-step-nav');
assertIncludes(stepNav, "el.setAttribute('role','button')", 'sidebar step items must be role=button fallback targets');
assertIncludes(stepNav, "scheduleInteractionSelfDiagnostics('goToStep:'", 'goToStep must schedule post-navigation diagnostics');
assertIncludes(clickFallback, '[data-step-nav]', 'click fallback must include data-step-nav targets');
assertIncludes(clickFallback, 'Number(target.dataset.stepNav || 0)', 'click fallback must route sidebar step nav dataset');
assertIncludes(diagnostics, 'function scheduleInteractionSelfDiagnostics', 'self diagnostics module must define scheduleInteractionSelfDiagnostics');
assertIncludes(diagnostics, 'active-step-nav-mismatch', 'self diagnostics must detect active sidebar mismatch');
assertIncludes(dataMgmt, 'activeNav=', 'data management panel must display active sidebar step');
assertIncludes(dataMgmt, 'activeNavStep=', 'copy report must include active sidebar step');
assertIncludes(verify, 'browser_hotfix_step_nav_diagnostics_tests.js', 'verify.sh must run step nav diagnostics tests');
assertIncludes(structure, 'Browser Hotfix Step Navigation Diagnostics guards', 'verify_structure must include v38-68 guards');
assertIncludes(readme, 'v38-68 Browser Hotfix Step Navigation Diagnostics', 'README must document v38-68');

const fakeDocument = {
  getElementById(){ return null; },
  querySelector(sel){
    if(sel === '.step-content.active') return {dataset:{step:'3'}};
    if(sel === '.step-item.active') return {dataset:{stepNav:'2'}};
    return null;
  },
  addEventListener(){}
};
const context = {
  console,
  __ENVELOPE_PRINT_BOOTSTRAP_TEST_MODE: true,
  __envelopePrintRuntimeTrapInstalled: true,
  __envelopePrintCriticalClickFallbackInstalled: true,
  __ENVELOPE_PRINT_INITIALIZED: true,
  __ENVELOPE_PRINT_BOOTSTRAP_SCHEDULED: true,
  document: fakeDocument,
  state: {currentStep: 3, uiMode: 'simple'},
  getComputedStyle(){ return {display:'block', visibility:'visible'}; },
  setTimeout(fn){ fn(); return 1; },
  addEventListener(){}
};
context.window = context;
vm.createContext(context);
vm.runInContext(runtimeTrap, context, {filename:'91_runtime_error_trap.js'});
vm.runInContext(clickSafety, context, {filename:'92_click_safety.js'});
vm.runInContext(diagnostics, context, {filename:'94_self_diagnostics.js'});
assert.strictEqual(typeof context.scheduleInteractionSelfDiagnostics, 'function', 'scheduleInteractionSelfDiagnostics must be exported');
assert.strictEqual(typeof context.EnvelopePrintInteractionDiagnostics.scheduleInteractionSelfDiagnostics, 'function', 'diagnostics API must expose scheduleInteractionSelfDiagnostics');
context.scheduleInteractionSelfDiagnostics('unit-test');
const report = context.__envelopePrintSelfDiagnostics;
assert(report, 'scheduled diagnostics must store a report');
assert.strictEqual(report.reason, 'unit-test', 'scheduled diagnostics must preserve reason');
assert.strictEqual(report.activeNavStep, 2, 'diagnostics must read active sidebar step');
assert(report.issues.some(i => i.code === 'active-step-nav-mismatch'), 'active sidebar mismatch must become issue');
console.log('OK browser hotfix step navigation diagnostics tests passed');
