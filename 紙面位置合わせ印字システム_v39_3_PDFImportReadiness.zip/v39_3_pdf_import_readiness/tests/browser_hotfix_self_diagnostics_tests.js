#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const bootstrap = fs.readFileSync(path.join(root, 'js/90_bootstrap.js'), 'utf8');
const runtimeTrap = fs.readFileSync(path.join(root, 'js/91_runtime_error_trap.js'), 'utf8');
const clickSafety = fs.readFileSync(path.join(root, 'js/92_click_safety.js'), 'utf8');
const diagnostics = fs.readFileSync(path.join(root, 'js/94_self_diagnostics.js'), 'utf8');
const dataMgmt = fs.readFileSync(path.join(root, 'js/52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools/verify.sh'), 'utf8');
const structure = fs.readFileSync(path.join(root, 'tools/verify_structure.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js/10_core.js'), 'utf8');

assert(/function\s+runInteractionSelfDiagnostics\s*\(/.test(diagnostics), 'self diagnostics module must define runInteractionSelfDiagnostics');
assert(/INTERACTION_DIAGNOSTIC_TARGETS/.test(diagnostics), 'self diagnostics module must define diagnostic target specs');
assert(/runBootstrapTask\('runInteractionSelfDiagnostics'/.test(bootstrap), 'initializeApp must run self diagnostics');
assert(/__envelopePrintSelfDiagnostics/.test(diagnostics), 'self diagnostics report must be stored globally');
assert(/getInteractionSelfDiagnosticsReport/.test(dataMgmt), 'Data Management UI must read self diagnostics');
assert(/renderInteractionSelfDiagnosticsPanel/.test(dataMgmt), 'Data Management UI must render self diagnostics panel');
assert(/dmRunSelfDiagnostics/.test(dataMgmt), 'Data Management UI must provide rerun self diagnostics button');
assert(/dmCopySelfDiagnostics/.test(dataMgmt), 'Data Management UI must provide copy self diagnostics button');
assert(/v38-67/.test(core), 'APP_RELEASE_NOTES must mention v38-67');
assert(/browser_hotfix_self_diagnostics_tests\.js/.test(verify), 'verify.sh must run self diagnostics tests');
assert(/Browser Hotfix Self Diagnostics guards/.test(structure), 'verify_structure must include v38-67 guard comments');

function makeEl(id, opts = {}){
  return {
    id,
    tagName: opts.tagName || 'BUTTON',
    textContent: opts.textContent || id,
    title: '',
    className: '',
    disabled: !!opts.disabled,
    hidden: !!opts.hidden,
    getAttribute(){ return ''; }
  };
}
const elements = new Map([
  ['btnHelp', makeEl('btnHelp')],
  ['btnDataMgmt', makeEl('btnDataMgmt')],
  ['modeSimple', makeEl('modeSimple')],
  ['modeAdvanced', makeEl('modeAdvanced')],
  ['btnAddQueue', makeEl('btnAddQueue')],
  ['step3Back', makeEl('step3Back')]
]);
const fakeDocument = {
  getElementById(id){ return elements.get(id) || null; },
  querySelector(sel){
    if(sel === '.step-content.active') return {dataset:{step:'3'}};
    return null;
  },
  addEventListener(){}
};
const context = {
  console,
  __ENVELOPE_PRINT_BOOTSTRAP_TEST_MODE: true,
  __envelopePrintRuntimeTrapInstalled: true,
  __envelopePrintCriticalClickFallbackInstalled: true,
  __ENVELOPE_PRINT_INITIALIZED: true,
  __ENVELOPE_PRINT_BOOTSTRAP_SCHEDULED: true,
  document: fakeDocument,
  state: {currentStep: 3, uiMode: 'simple'},
  getComputedStyle(){ return {display:'block', visibility:'visible'}; },
  addEventListener(){}
};
context.window = context;
vm.createContext(context);
vm.runInContext(runtimeTrap, context, {filename:'91_runtime_error_trap.js'});
vm.runInContext(clickSafety, context, {filename:'92_click_safety.js'});
vm.runInContext(diagnostics, context, {filename:'94_self_diagnostics.js'});
assert.strictEqual(typeof context.runInteractionSelfDiagnostics, 'function', 'runInteractionSelfDiagnostics must be exported');
assert.strictEqual(typeof context.EnvelopePrintInteractionDiagnostics.runInteractionSelfDiagnostics, 'function', 'diagnostics API must expose runInteractionSelfDiagnostics');
const report = context.runInteractionSelfDiagnostics({manual:true});
assert.strictEqual(report.currentStep, 3, 'diagnostics must read current step');
assert.strictEqual(report.activeDomStep, 3, 'diagnostics must read active DOM step');
assert(report.expectedIds.includes('step3Next'), 'step3Next must be expected on step3');
assert(report.targets.some(t => t.id === 'step3Next' && t.expected && !t.present), 'missing expected step3Next must be reported as target');
assert(report.issues.some(i => i.code === 'expected-button-missing' && i.id === 'step3Next'), 'missing expected button must become issue');
assert.strictEqual(context.__envelopePrintSelfDiagnostics, report, 'diagnostics report must be stored globally');
assert((context.__envelopePrintActionLog || []).some(a => a.kind === 'self-diagnostics'), 'diagnostics must leave action log breadcrumb');
console.log('OK browser hotfix self diagnostics tests passed');
