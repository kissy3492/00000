#!/usr/bin/env node
/* v38-75: Browser E2E Smoke Test.
   外部npmに依存せず、Chromium DevTools Protocolを直接叩く。
   この実行環境では file:// と localhost ページ表示がポリシーでブロックされるため、
   index.html をインライン化して about:blank に document.write する。DOM/Event/描画JSは実ブラウザで動かす。
*/
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const childProcess = require('child_process');

const root = path.resolve(__dirname, '..');

function read(relativePath){
  return fs.readFileSync(path.join(root, relativePath), 'utf8');
}

const manifest = JSON.parse(read('split_manifest.json'));
const manifestReleaseId = (manifest.version.match(/v\d+-\d+/) || [])[0];

function findChromium(){
  const candidates = [
    process.env.CHROMIUM_BIN,
    process.env.PUPPETEER_EXECUTABLE_PATH,
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
    '/usr/bin/google-chrome',
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
  ].filter(Boolean);
  return candidates.find(p => fs.existsSync(p));
}

function skipBrowserE2E(reason){
  const message = `SKIP browser E2E smoke tests: ${reason}`;
  if(process.env.PAPERPRINT_REQUIRE_BROWSER_E2E === '1'){
    throw new Error(`${message}; PAPERPRINT_REQUIRE_BROWSER_E2E=1 requires a real Chromium run`);
  }
  console.log(message);
}

function escapeScriptEnd(text){
  return String(text).replace(/<\/script/gi, '<\\/script');
}

function inlineIndexHtml(){
  let html = read('index.html');
  html = html.replace(/<script\b([^>]*?)\bsrc="([^"]+)"([^>]*)><\/script>/g, (_m, before, src, after) => {
    const scriptPath = src.replace(/^\.\//, '');
    const code = read(scriptPath);
    return `<script${before}${after}>\n${escapeScriptEnd(code)}\n<\/script>`;
  });
  html = html.replace(/<link\b([^>]*?)\bhref="([^"]+\.css)"([^>]*)>/g, (_m, before, href) => {
    const cssPath = href.replace(/^\.\//, '');
    return `<style data-inline-from="${cssPath}">\n${read(cssPath)}\n</style>`;
  });
  const storageShim = `<script>
(function(){
  const store = Object.create(null);
  const api = {};
  Object.defineProperties(api, {
    getItem: {value: function(k){ k=String(k); return Object.prototype.hasOwnProperty.call(store,k) ? store[k] : null; }},
    setItem: {value: function(k,v){ store[String(k)] = String(v); }},
    removeItem: {value: function(k){ delete store[String(k)]; }},
    clear: {value: function(){ Object.keys(store).forEach(function(k){ delete store[k]; }); }},
    key: {value: function(i){ return Object.keys(store)[Number(i)] || null; }},
    length: {get: function(){ return Object.keys(store).length; }}
  });
  Object.defineProperty(window, 'localStorage', {value: api, configurable: true});
  window.__BROWSER_E2E_STORAGE_SHIM = true;
})();
<\/script>`;
  return html.replace('<head>', `<head>\n${storageShim}`);
}

function delay(ms){
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function waitFor(fn, timeoutMs = 8000, intervalMs = 100){
  const started = Date.now();
  let lastError = null;
  while(Date.now() - started < timeoutMs){
    try{
      const value = await fn();
      if(value) return value;
    }catch(err){
      lastError = err;
    }
    await delay(intervalMs);
  }
  throw lastError || new Error(`waitFor timeout after ${timeoutMs}ms`);
}

class CdpSession{
  constructor(wsUrl){
    this.ws = new WebSocket(wsUrl);
    this.nextId = 0;
    this.pending = new Map();
    this.events = [];
    this.exceptions = [];
    this.ready = new Promise((resolve, reject) => {
      this.ws.onopen = resolve;
      this.ws.onerror = reject;
    });
    this.ws.onmessage = event => {
      const msg = JSON.parse(event.data);
      if(msg.id && this.pending.has(msg.id)){
        const {resolve, reject, timer} = this.pending.get(msg.id);
        clearTimeout(timer);
        this.pending.delete(msg.id);
        if(msg.error) reject(new Error(msg.error.message || JSON.stringify(msg.error)));
        else resolve(msg.result || {});
        return;
      }
      if(msg.method === 'Runtime.exceptionThrown') this.exceptions.push(msg.params.exceptionDetails);
      this.events.push(msg);
    };
  }

  async send(method, params){
    await this.ready;
    const id = ++this.nextId;
    this.ws.send(JSON.stringify({id, method, params: params || {}}));
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        if(this.pending.has(id)){
          this.pending.delete(id);
          reject(new Error(`CDP timeout: ${method}`));
        }
      }, 12000);
      this.pending.set(id, {resolve, reject, timer});
    });
  }

  async evaluate(expression){
    const result = await this.send('Runtime.evaluate', {
      expression,
      awaitPromise: true,
      returnByValue: true,
      userGesture: true
    });
    if(result.exceptionDetails){
      throw new Error(`browser evaluation failed: ${JSON.stringify(result.exceptionDetails)}`);
    }
    return result.result ? result.result.value : undefined;
  }

  close(){
    try{ this.ws.close(); }catch(_err){}
  }
}

async function connectToFirstPage(debugPort){
  const endpoint = `http://127.0.0.1:${debugPort}/json/list`;
  const page = await waitFor(async () => {
    const res = await fetch(endpoint);
    if(!res.ok) return null;
    const pages = await res.json();
    return pages.find(p => p.type === 'page') || pages[0] || null;
  }, 12000, 200);
  assert(page.webSocketDebuggerUrl, 'Chrome DevTools websocket URL must be available');
  return new CdpSession(page.webSocketDebuggerUrl);
}

async function runSmoke(){
  if(process.env.PAPERPRINT_SKIP_BROWSER_E2E === '1'){
    skipBrowserE2E('PAPERPRINT_SKIP_BROWSER_E2E=1');
    return;
  }
  const chromium = findChromium();
  if(!chromium){
    skipBrowserE2E('Chromium executable was not found');
    return;
  }

  const debugPort = 44000 + Math.floor(Math.random() * 10000);
  const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'paperprint-browser-e2e-'));
  const browser = childProcess.spawn(chromium, [
    '--headless=new',
    '--no-sandbox',
    '--disable-gpu',
    '--disable-dev-shm-usage',
    '--no-first-run',
    '--no-default-browser-check',
    `--remote-debugging-port=${debugPort}`,
    `--user-data-dir=${userDataDir}`,
    'about:blank'
  ], {stdio: ['ignore', 'ignore', 'pipe']});

  let stderr = '';
  browser.stderr.on('data', chunk => { stderr += chunk.toString(); });
  let cdp = null;
  try{
    cdp = await connectToFirstPage(debugPort);
    await cdp.send('Runtime.enable');
    await cdp.send('Page.enable');

    const html = inlineIndexHtml();
    await cdp.evaluate(`document.open(); document.write(${JSON.stringify(html)}); document.close(); true;`);

    await waitFor(() => cdp.evaluate(`Boolean(window.__ENVELOPE_PRINT_INITIALIZED && document.querySelector('.tpl-card') && document.getElementById('step1Next'))`), 10000, 100);

    const boot = await cdp.evaluate(`({
      title: document.title,
      initialized: !!window.__ENVELOPE_PRINT_INITIALIZED,
      storageShim: !!window.__BROWSER_E2E_STORAGE_SHIM,
      cards: document.querySelectorAll('.tpl-card').length,
      currentStep: state.currentStep,
      runtimeErrors: (window.__envelopePrintRuntimeErrors || []).map(e => e.scope + ':' + e.message)
    })`);
    assert(boot.title.includes(manifestReleaseId), `browser title should be synchronized to ${manifestReleaseId}: ${boot.title}`);
    assert.strictEqual(boot.initialized, true, 'app should initialize in Chromium');
    assert.strictEqual(boot.storageShim, true, 'storage shim should be active in about:blank harness');
    assert(boot.cards >= 1, 'Step1 template cards should render');
    assert.strictEqual(boot.currentStep, 1, 'initial currentStep should be Step1');
    assert.deepStrictEqual(boot.runtimeErrors, [], 'runtime error log should be empty after boot');

    await cdp.evaluate(`document.getElementById('modeAdvanced').click(); true;`);
    await waitFor(() => cdp.evaluate(`state.uiMode === 'advanced' && Boolean(document.querySelector('.tpl-card [data-act="edit"]'))`), 6000, 100);
    await cdp.evaluate(`document.querySelector('.tpl-card [data-act="edit"]').click(); true;`);
    await waitFor(() => cdp.evaluate(`state.currentStep === 2 && document.querySelector('.step-content[data-step="2"]').classList.contains('active') && Boolean(document.getElementById('btnAddField')) && Boolean(document.getElementById('tName'))`), 6000, 100);

    const step2Before = await cdp.evaluate(`({
      currentStep: state.currentStep,
      selectedTplId: state.selectedTplId,
      name: getCurrentTpl().name,
      fields: getCurrentTpl().fields.length,
      fieldListItems: document.querySelectorAll('#fieldList .field-mini').length,
      envelopePresent: !!document.getElementById('envelope')
    })`);
    assert.strictEqual(step2Before.currentStep, 2, 'advanced-mode detail button should open Step2');
    assert.strictEqual(step2Before.envelopePresent, true, 'Step2 edit canvas should be present');
    assert(step2Before.fields >= 1, 'Step2 should load existing template fields');

    await cdp.evaluate(`
      const tName = document.getElementById('tName');
      tName.value = 'E2E 詳細編集テンプレート';
      tName.dispatchEvent(new Event('input', {bubbles:true}));
      true;
    `);
    await waitFor(() => cdp.evaluate(`getCurrentTpl().name === 'E2E 詳細編集テンプレート' && document.getElementById('step2Title').textContent.includes('E2E 詳細編集テンプレート')`), 6000, 100);

    await cdp.evaluate(`document.getElementById('btnAddField').click(); true;`);
    await waitFor(() => cdp.evaluate(`getCurrentTpl().fields.length > ${step2Before.fields} && document.querySelectorAll('#fieldList .field-mini').length > ${step2Before.fieldListItems}`), 6000, 100);

    const backgroundImageReport = await cdp.evaluate(`(async()=>{
      const pngBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII=';
      const raw = atob(pngBase64);
      const bytes = new Uint8Array(raw.length);
      for(let i=0;i<raw.length;i++) bytes[i] = raw.charCodeAt(i);
      const file = new File([bytes], 'e2e-bg.png', {type:'image/png'});
      const tpl = getCurrentTpl();
      tpl.bgPersist = true;
      delete tpl.bgImage; delete tpl.bgSourceName; delete tpl.bgBytes; delete transientBg[tpl.id];
      renderBgUI();
      await loadBackgroundFileInto(file, tpl, {onLoaded:()=>{ renderBgUI(); renderEnvelope(); }});
      return {
        bgPersist: !!tpl.bgPersist,
        hasPersistentImage: !!tpl.bgImage,
        sourceName: tpl.bgSourceName,
        bytes: tpl.bgBytes || 0,
        hasTransient: !!transientBg[tpl.id],
        bgBadge: document.getElementById('bgBadge').textContent,
        bgInfo: document.getElementById('bgInfo').textContent,
        envelopeBg: !!document.querySelector('#envelope .bg-layer, #envelope img, #envelope [style*=background]') || document.getElementById('envelope').innerHTML.includes('e2e-bg.png') || !!tpl.bgImage
      };
    })()`);
    assert.strictEqual(backgroundImageReport.bgPersist, true, 'E2E image load should run with persistent background enabled');
    assert.strictEqual(backgroundImageReport.hasPersistentImage, true, 'E2E image load should save persistent tpl.bgImage');
    assert.strictEqual(backgroundImageReport.sourceName, 'e2e-bg.png', 'E2E image load should preserve source filename');
    assert(backgroundImageReport.bytes > 0, 'E2E image load should record compressed byte size');
    assert.strictEqual(backgroundImageReport.hasTransient, false, 'persistent image load must not leave transient background');
    assert.strictEqual(backgroundImageReport.bgBadge, '取込済', 'background badge should show imported after image load');
    assert(backgroundImageReport.bgInfo.includes('e2e-bg.png') && backgroundImageReport.bgInfo.includes('[保存中]'), 'background info should show persistent image source');

    const backgroundPdfReport = await cdp.evaluate(`(async()=>{
      window.__pdfjsAvailable = true;
      window.pdfjsLib = {
        getDocument(){
          return {promise: Promise.resolve({
            getPage: async function(){
              return {
                getViewport: function(){ return {width: 120, height: 60}; },
                render: function(args){
                  const ctx = args.canvasContext;
                  ctx.fillStyle = '#fff';
                  ctx.fillRect(0, 0, 120, 60);
                  ctx.fillStyle = '#111';
                  ctx.fillRect(8, 8, 60, 20);
                  return {promise: Promise.resolve()};
                }
              };
            }
          })};
        }
      };
      const tpl = getCurrentTpl();
      tpl.bgPersist = false;
      delete tpl.bgImage; delete tpl.bgSourceName; delete tpl.bgBytes; delete transientBg[tpl.id];
      renderBgUI();
      const file = new File([new Uint8Array([37,80,68,70,45,49,46,52,10])], 'e2e-bg.pdf', {type:'application/pdf'});
      await loadBackgroundFileInto(file, tpl, {onLoaded:()=>{ renderBgUI(); renderEnvelope(); }});
      const transient = transientBg[tpl.id] || {};
      return {
        bgPersist: !!tpl.bgPersist,
        hasPersistentImage: !!tpl.bgImage,
        transientName: transient.name,
        transientBytes: transient.bytes || 0,
        transientHasDataUrl: String(transient.dataUrl || '').startsWith('data:image/jpeg'),
        bgBadge: document.getElementById('bgBadge').textContent,
        bgInfo: document.getElementById('bgInfo').textContent
      };
    })()`);
    assert.strictEqual(backgroundPdfReport.bgPersist, false, 'E2E PDF load should run with transient background mode');
    assert.strictEqual(backgroundPdfReport.hasPersistentImage, false, 'transient PDF load must not write tpl.bgImage');
    assert.strictEqual(backgroundPdfReport.transientName, 'e2e-bg.pdf', 'E2E PDF load should preserve PDF source filename');
    assert(backgroundPdfReport.transientBytes > 0, 'E2E PDF load should record compressed transient byte size');
    assert.strictEqual(backgroundPdfReport.transientHasDataUrl, true, 'E2E PDF load should render into a JPEG data URL');
    assert.strictEqual(backgroundPdfReport.bgBadge, '取込済', 'background badge should show imported after PDF load');
    assert(backgroundPdfReport.bgInfo.includes('e2e-bg.pdf') && backgroundPdfReport.bgInfo.includes('[一時]'), 'background info should show transient PDF source');

    await cdp.evaluate(`document.getElementById('step2Next').click(); true;`);
    await waitFor(() => cdp.evaluate(`state.currentStep === 3 && document.querySelector('.step-content[data-step="3"]').classList.contains('active') && Boolean(document.getElementById('iName'))`), 6000, 100);

    await cdp.evaluate(`
      document.getElementById('iZip').value = '123-4567';
      document.getElementById('iAddr').value = '東京都千代田区テスト1-1';
      document.getElementById('iName').value = '山田太郎';
      true;
    `);
    await cdp.evaluate(`document.getElementById('btnAddQueue').click(); true;`);
    await waitFor(() => cdp.evaluate(`state.queue.length === 1 && !document.getElementById('step3Next').disabled`), 6000, 100);

    await cdp.evaluate(`document.getElementById('step3Next').click(); true;`);
    await waitFor(() => cdp.evaluate(`state.currentStep === 4 && document.querySelector('.step-content[data-step="4"]').classList.contains('active')`), 6000, 100);

    await cdp.evaluate(`document.getElementById('step4Next').click(); true;`);
    await waitFor(() => cdp.evaluate(`state.currentStep === 5 && document.querySelector('.step-content[data-step="5"]').classList.contains('active')`), 6000, 100);

    await cdp.evaluate(`document.getElementById('btnDataMgmt').click(); true;`);
    await waitFor(() => cdp.evaluate(`Boolean(document.getElementById('dmText')) && Boolean(document.getElementById('dmRunSelfDiagnostics')) && Boolean(document.getElementById('dmClose'))`), 6000, 100);
    const dataMgmtBefore = await cdp.evaluate(`({
      modalOpen: !!document.querySelector('.modal-overlay'),
      backupJsonHasTemplates: document.getElementById('dmText').value.includes('"templates"'),
      hasRuntimeActionPanel: document.body.textContent.includes('クリック記録'),
      hasSelfDiagnosticsPanel: document.body.textContent.includes('UI自己診断')
    })`);
    assert.strictEqual(dataMgmtBefore.modalOpen, true, 'Data Management modal should open from top button');
    assert.strictEqual(dataMgmtBefore.backupJsonHasTemplates, true, 'Data Management backup textarea should contain JSON snapshot');
    assert.strictEqual(dataMgmtBefore.hasRuntimeActionPanel, true, 'Data Management should show click/action log panel');
    assert.strictEqual(dataMgmtBefore.hasSelfDiagnosticsPanel, true, 'Data Management should show UI diagnostics panel');

    await cdp.evaluate(`document.getElementById('dmRunSelfDiagnostics').click(); true;`);
    await waitFor(() => cdp.evaluate(`Boolean(document.getElementById('dmText')) && Boolean(window.__envelopePrintSelfDiagnostics) && window.__envelopePrintSelfDiagnostics.currentStep === 5`), 6000, 100);
    await cdp.evaluate(`document.getElementById('dmClose').click(); true;`);
    await waitFor(() => cdp.evaluate(`!document.querySelector('.modal-overlay')`), 5000, 100);

    const finalReport = await cdp.evaluate(`({
      currentStep: state.currentStep,
      uiMode: state.uiMode,
      queueCount: state.queue.length,
      selectedTplName: getCurrentTpl().name,
      fieldCount: getCurrentTpl().fields.length,
      actionKinds: (window.__envelopePrintActionLog || []).map(a => a.kind),
      runtimeErrors: (window.__envelopePrintRuntimeErrors || []).map(e => e.scope + ':' + e.message),
      selfIssues: (window.__envelopePrintSelfDiagnostics && window.__envelopePrintSelfDiagnostics.issues || []).map(i => i.code),
      finalChecklistPresent: !!document.getElementById('finalChecklist'),
      previewRendered: !!document.getElementById('printPreviewStack'),
      modalOpen: !!document.querySelector('.modal-overlay')
    })`);
    assert.strictEqual(finalReport.currentStep, 5, 'Step2 -> Step3 -> Step4 -> Step5 navigation should work in Chromium');
    assert.strictEqual(finalReport.uiMode, 'advanced', 'advanced mode should survive the E2E flow');
    assert.strictEqual(finalReport.queueCount, 1, 'queue should contain one address after Add Queue click');
    assert.strictEqual(finalReport.selectedTplName, 'E2E 詳細編集テンプレート', 'Step2 template name input should update the selected template');
    assert(finalReport.fieldCount > step2Before.fields, 'Step2 Add Field should update the selected template');
    assert.strictEqual(finalReport.finalChecklistPresent, true, 'Step5 final checklist container should exist');
    assert.strictEqual(finalReport.previewRendered, true, 'Step5 preview container should exist');
    assert.strictEqual(finalReport.modalOpen, false, 'Data Management modal should close cleanly');
    assert.deepStrictEqual(finalReport.runtimeErrors, [], `runtime error log should remain empty: ${finalReport.runtimeErrors.join('\n')}`);
    assert.strictEqual(cdp.exceptions.length, 0, `Chrome Runtime.exceptionThrown should be empty: ${JSON.stringify(cdp.exceptions)}`);

    console.log('Browser E2E Smoke tests: OK');
  }finally{
    if(cdp) cdp.close();
    if(!browser.killed) browser.kill('SIGTERM');
    await delay(500);
    try{ fs.rmSync(userDataDir, {recursive: true, force: true}); }catch(_err){ await delay(500); try{ fs.rmSync(userDataDir, {recursive: true, force: true}); }catch(_err2){} }
    if(browser.exitCode && browser.exitCode !== 0 && stderr && process.env.PAPERPRINT_DEBUG_BROWSER_E2E === '1'){
      console.error(stderr);
    }
  }
}

runSmoke().catch(err => {
  console.error(err && err.stack ? err.stack : err);
  process.exit(1);
});
