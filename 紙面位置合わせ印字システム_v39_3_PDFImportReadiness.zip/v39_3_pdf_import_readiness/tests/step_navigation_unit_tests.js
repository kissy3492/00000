#!/usr/bin/env node
/* v38-34: Step Navigation static tests.
   目的: ステップ一覧描画・進行可否・ステップ遷移が専用ファイルへ分離され、Step2詳細編集UIに残っていないことを固定する。 */
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const nav = fs.readFileSync(path.join(root, 'js', '48_step_navigation.js'), 'utf8');
const retiredStepsPath = path.join(root, 'js', '48_steps_ui.js');
const steps = fs.existsSync(retiredStepsPath) ? fs.readFileSync(retiredStepsPath, 'utf8') : '';
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const index = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

function test(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

const navFns = ['getActiveSteps','stepIndex','renderSteps','getStepStatus','canSkipTo','canGoToStep','goToStep'];

test('Step Navigation module defines and exports navigation functions', ()=>{
  assert.match(nav, /\(function\(global\)\{[\s\S]*'use strict';/);
  for(const fn of navFns){
    assert.match(nav, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} missing from step navigation module`);
    assert.match(nav, new RegExp(`\\b${fn}\\b`), `${fn} missing from export block`);
  }
  assert.match(nav, /const\s+StepNavigationApi\s*=\s*Object\.freeze\(\{[\s\S]*getActiveSteps[\s\S]*goToStep/);
  assert.match(nav, /EnvelopePrintStepNavigation:\s*StepNavigationApi/);
  assert.match(nav, /Object\.assign\(global,\s*\{[\s\S]*getActiveSteps[\s\S]*goToStep[\s\S]*EnvelopePrintStepNavigation/);
});

test('retired 48_steps_ui no longer defines navigation functions', ()=>{
  assert.strictEqual(fs.existsSync(retiredStepsPath), false, '48_steps_ui.js must remain retired');
  for(const fn of navFns){
    assert.doesNotMatch(steps, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} must not remain in 48_steps_ui.js`);
  }
});

test('navigation keeps core routing and status contracts', ()=>{
  assert.match(nav, /state\.uiMode==='simple'\?STEPS_SIMPLE:STEPS_ADVANCED/);
  assert.match(nav, /if\(n===2\) contentRendered = callStepRenderer\('renderStep2', renderStep2\);/);
  assert.match(nav, /if\(n===3\) contentRendered = callStepRenderer\('renderStep3', renderStep3\);/);
  assert.match(nav, /if\(n===4\) contentRendered = callStepRenderer\('renderStep4', renderStep4\);/);
  assert.match(nav, /if\(n===5\) contentRendered = callStepRenderer\('renderStep5', renderStep5\);/);
  assert.match(nav, /updateStorageStatus\(\);/);
  assert.match(nav, /getPrintRecordCount\(\)/);
});

test('script order loads navigation before step UIs, core, and bootstrap', ()=>{
  const order = Array.from(index.matchAll(/<script[^>]+src="([^"]+)"/g)).map(m=>m[1]);
  const pos = name => order.indexOf(name);
  for(const name of ['js/47_print.js','js/48_step_navigation.js','js/48_step1_template_ui.js','js/10_core.js','js/90_bootstrap.js']){
    assert.ok(pos(name) >= 0, `${name} missing from script order`);
  }
  assert.strictEqual(pos('js/48_steps_ui.js'), -1, 'retired 48_steps_ui.js must not be loaded');
  assert.ok(pos('js/47_print.js') < pos('js/48_step_navigation.js'));
  assert.ok(pos('js/48_step_navigation.js') < pos('js/48_step1_template_ui.js'));
  assert.ok(pos('js/48_step_navigation.js') < pos('js/10_core.js'));
  assert.ok(pos('js/10_core.js') < pos('js/90_bootstrap.js'));
});

test('public module index exposes StepNavigation API', ()=>{
  assert.match(core, /StepNavigation:EnvelopePrintStepNavigation/);
  assert.match(dataUi, /StepNavigation:\['EnvelopePrintStepNavigation','getActiveSteps','stepIndex','renderSteps','getStepStatus','canSkipTo','canGoToStep','callStepRenderer','goToStep'\]/);
  assert.match(core, /\{step:'v38-34'[\s\S]*48_step_navigation\.js/);
});

console.log('OK 5 step navigation tests passed');
