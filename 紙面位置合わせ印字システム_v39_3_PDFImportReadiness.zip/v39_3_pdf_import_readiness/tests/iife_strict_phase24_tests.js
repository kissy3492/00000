#!/usr/bin/env node
/* v38-78 IIFE Strict Phase24 tests: Stage7 Addon scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const stage7 = fs.readFileSync(path.join(root, 'js', '70_stage7_addon.js'), 'utf8');
const dataMgmtUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

async function ok(name, fn){
  try{
    await fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

function makeSandbox(){
  const calls = [];
  const sandbox = {
    console,
    window:null,
    globalThis:null,
    localStorage:{
      getItem(key){ calls.push(['getItem', key]); return '{}'; },
      setItem(key, value){ calls.push(['setItem', key, value]); }
    },
    document:{
      readyState:'loading',
      addEventListener(type, fn){ calls.push(['doc.addEventListener', type]); this.domContentLoaded = fn; },
      getElementById(){ return null; }
    },
    FieldSourceRegistry:{
      sources:{},
      hasSource(key){ return !!this.sources[key]; },
      registerSource(key, label, resolver){ this.sources[key] = {label, resolver}; }
    },
    SampleDataRegistry:{
      defaults:null,
      registerDefaults(obj, label){ this.defaults = {obj, label}; }
    },
    InputDataExtensionRegistry:{
      collect:[], load:[], clear:[],
      registerCollectHook(fn, label){ this.collect.push({fn, label}); },
      registerLoadHook(fn, label){ this.load.push({fn, label}); },
      registerClearHook(fn, label){ this.clear.push({fn, label}); }
    },
    Step3ExtensionRegistry:{
      render:[], manual:[],
      registerRenderHook(fn, label){ this.render.push({fn, label}); },
      registerManualPaneHook(fn, label){ this.manual.push({fn, label}); }
    },
    ENVELOPE_SIZES:{},
    EnvelopePrintModules:{Extensions:{}},
    safeBindClick(el, handler, label){ calls.push(['safeBindClick', label]); if(el) el.__click = handler; return true; },
    uid(prefix){ return `${prefix}_fixed`; },
    getCurrentTpl(){ return sandbox.currentTplValue || null; },
    markLayoutChanged(tpl){ calls.push(['markLayoutChanged', tpl.id]); },
    save(){ calls.push('save'); },
    renderFieldList(){ calls.push('renderFieldList'); },
    renderEnvelope(){ calls.push('renderEnvelope'); },
    toast(message, kind){ calls.push(['toast', message, kind]); },
    showAppAlert(message){ calls.push(['alert', message]); },
    buildOrgFullText(data){ return [data.company, data.dept, data.title].filter(Boolean).join('\n'); },
    buildNameWithHonor(name, honor){ return name + (honor || ''); },
    getFieldSourceLabel(key){ return `base:${key}`; },
    calls
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  return sandbox;
}

(async()=>{

await ok('stage7 addon starts with global IIFE + strict', ()=>{
  assert.ok(/^\(function\(global\)\{/.test(stage7), 'Stage7 must start with explicit global IIFE');
  assert.ok(stage7.slice(0, 180).includes("'use strict';"), 'Stage7 must enable strict mode near the top');
});

await ok('stage7 exposes frozen EnvelopePrintStage7 API and preserves addon key', ()=>{
  assert.ok(stage7.includes("paper_position_print_system_v37_stage7_addon"), 'Stage7 stable ADDON_KEY must not change');
  assert.ok(/const\s+EnvelopePrintStage7\s*=\s*Object\.freeze\(\{[\s\S]*buildRecipientFull[\s\S]*getExtendedInputData[\s\S]*buildReceiptFields[\s\S]*showUtilityModal[\s\S]*init/.test(stage7), 'EnvelopePrintStage7 freeze block is incomplete');
  assert.ok(/global\.EnvelopePrintStage7\s*=\s*EnvelopePrintStage7/.test(stage7), 'Stage7 explicit API must be assigned to global');
  assert.ok(/EnvelopePrintModules\.Extensions\.Stage7\s*=\s*EnvelopePrintStage7/.test(stage7), 'Stage7 must still attach to EnvelopePrintModules.Extensions.Stage7');
});

await ok('stage7 uses safeBindClick instead of raw critical click binding', ()=>{
  assert.ok(/function\s+bindClick\s*\(/.test(stage7), 'Stage7 must define bindClick helper');
  assert.ok(/global\.safeBindClick/.test(stage7), 'Stage7 bindClick must delegate to safeBindClick when available');
  assert.ok(/bindClick\(b,\s*showUtilityModal/.test(stage7), 'Stage7 top utility button must use bindClick');
  assert.ok(/bindClick\(modal\.querySelector\('#s7AddFormSet'\)/.test(stage7), 'Stage7 modal add buttons must use bindClick');
  assert.ok(!/EventTarget\.prototype/.test(stage7), 'Stage7 must not use EventTarget prototype monkey patching');
});

await ok('lightweight VM load exposes Stage7 API and registers extension hooks without DOM execution', ()=>{
  const sandbox = makeSandbox();
  vm.createContext(sandbox);
  vm.runInContext(stage7, sandbox, {filename:'js/70_stage7_addon.js'});
  assert.strictEqual(typeof sandbox.EnvelopePrintStage7, 'object', 'EnvelopePrintStage7 must be exported on load');
  assert.ok(Object.isFrozen(sandbox.EnvelopePrintStage7), 'EnvelopePrintStage7 must be frozen');
  assert.strictEqual(sandbox.EnvelopePrintStage7.buildRecipientFull({company:'青森商事', dept:'総務', name:'森谷', honor:'様'}), '青森商事\n総務\n森谷様');

  sandbox.EnvelopePrintStage7.init();
  assert.strictEqual(sandbox.EnvelopePrintModules.Extensions.Stage7, sandbox.EnvelopePrintStage7, 'Stage7 extension namespace must point to API');
  assert.deepStrictEqual(Object.keys(sandbox.FieldSourceRegistry.sources), ['recipient_full','today','date','issue_no','serial','amount','memo','seal_text','image'], 'Stage7 field sources must remain stable');
  assert.strictEqual(sandbox.FieldSourceRegistry.sources.issue_no.resolver(null, {}), 'No.____');
  assert.ok(sandbox.SampleDataRegistry.defaults.obj.memo.includes('プレビュー用'), 'Stage7 sample defaults must be registered');
  assert.strictEqual(sandbox.InputDataExtensionRegistry.collect[0].label, 'Stage7.getExtendedInputData.collect');
  assert.strictEqual(sandbox.Step3ExtensionRegistry.render[0].label, 'Stage7.injectExtendedInputs.render');
});

await ok('Stage7 field builders and addFields preserve source contracts', ()=>{
  const sandbox = makeSandbox();
  vm.createContext(sandbox);
  vm.runInContext(stage7, sandbox, {filename:'js/70_stage7_addon.js'});
  const receipt = sandbox.EnvelopePrintStage7.buildReceiptFields(210, 297);
  assert.deepStrictEqual(JSON.parse(JSON.stringify(receipt.map(f => f.source))), ['issue_no','date','recipient_full','amount','memo','seal_text'], 'receipt set source order must stay stable');
  const postcard = sandbox.EnvelopePrintStage7.buildPostcardBackFields(100, 148);
  assert.ok(postcard.some(f => f.source === 'sender_full'), 'postcard back set must keep sender_full source');

  sandbox.currentTplValue = {id:'tpl1', locked:false, fields:[]};
  sandbox.EnvelopePrintStage7.addFields([{label:'追加', source:'memo', x:1, y:2}]);
  assert.strictEqual(sandbox.currentTplValue.fields.length, 1, 'addFields must append field to current template');
  assert.strictEqual(sandbox.currentTplValue.fields[0].source, 'memo');
  assert.ok(sandbox.calls.some(x => Array.isArray(x) && x[0] === 'markLayoutChanged'), 'addFields must mark layout changed');
  assert.ok(sandbox.calls.includes('save'), 'addFields must save');
  assert.ok(sandbox.calls.includes('renderEnvelope'), 'addFields must refresh envelope');
});

await ok('Stage7 module overview and verification pipeline are updated', ()=>{
  assert.ok(/Stage7Addon:\['EnvelopePrintStage7'/.test(dataMgmtUi), 'getModuleOverview must expose Stage7Addon API');
  assert.ok(verify.includes('js/70_stage7_addon.js'), 'verify_structure must include Stage7 guard');
  assert.ok(verify.includes('EnvelopePrintStage7'), 'verify_structure must check EnvelopePrintStage7');
  assert.ok(verifySh.includes('tests/iife_strict_phase24_tests.js'), 'verify.sh must run phase24 tests');
});

console.log('IIFE strict phase24 tests: OK');
})().catch(err=>{
  console.error(err);
  process.exit(1);
});
