#!/usr/bin/env node
/* v38-19: Help / Data Management UI Controller unit tests.
   目的: 分離後も公開入口と概要APIが壊れていないことを確認する。 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const code = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const sandbox = { console, window: {} };
sandbox.globalThis = sandbox.window;
vm.createContext(sandbox);
vm.runInContext(code, sandbox, { filename: 'js/52_data_management_ui.js' });
const api = sandbox.window;
sandbox.escapeHtml = v => String(v == null ? '' : v).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));

async function test(name, fn){
  try{
    await fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

(async()=>{
await test('exports expected UI entry points', ()=>{
  assert.strictEqual(typeof api.showHelp, 'function');
  assert.strictEqual(typeof api.showDataMgmt, 'function');
  assert.strictEqual(typeof api.getModuleOverview, 'function');
  assert.strictEqual(typeof api.EnvelopePrintDataManagementUI, 'object');
  assert.strictEqual(api.EnvelopePrintDataManagementUI.showHelp, api.showHelp);
  assert.strictEqual(api.EnvelopePrintDataManagementUI.showDataMgmt, api.showDataMgmt);
  assert.strictEqual(api.EnvelopePrintDataManagementUI.getModuleOverview, api.getModuleOverview);
  assert.strictEqual(typeof api.saveBackupJsonToFile, 'function');
  assert.strictEqual(typeof api.saveBackupJsonToRememberedTarget, 'function');
  assert.strictEqual(typeof api.chooseBackupJsonTargetAndSave, 'function');
  assert.strictEqual(typeof api.rememberBackupFileHandle, 'function');
  assert.strictEqual(typeof api.forgetBackupFileHandle, 'function');
  assert.strictEqual(typeof api.getRememberedBackupTargetStatus, 'function');
  assert.strictEqual(typeof api.openBackupJsonFromFile, 'function');
  assert.strictEqual(typeof api.restoreBackupJsonObjectWithConfirm, 'function');
  assert.strictEqual(typeof api.detectBackupEnvironmentCapabilities, 'function');
  assert.strictEqual(typeof api.renderBackupEnvironmentPanel, 'function');
  assert.strictEqual(typeof api.buildBackupEnvironmentReport, 'function');
  assert.strictEqual(typeof api.copyBackupEnvironmentReport, 'function');
  assert.strictEqual(api.EnvelopePrintDataManagementUI.saveBackupJsonToFile, api.saveBackupJsonToFile);
  assert.strictEqual(api.EnvelopePrintDataManagementUI.saveBackupJsonToRememberedTarget, api.saveBackupJsonToRememberedTarget);
  assert.strictEqual(api.EnvelopePrintDataManagementUI.openBackupJsonFromFile, api.openBackupJsonFromFile);
});

await test('getModuleOverview keeps core module buckets', ()=>{
  const overview = api.getModuleOverview();
  for(const key of ['Metadata','Architecture','DataManagementUI','Core','Storage','Template','Data','Step3Input','Layout','EditCanvasController','Adjustment','Wizard','Print','Parts','Jobs','Paper']){
    assert.ok(Array.isArray(overview[key]), `${key} must be an array`);
  }
  assert.ok(overview.Storage.includes('backupNow'));
  assert.ok(overview.DataManagementUI.includes('saveBackupJsonToFile'));
  assert.ok(overview.DataManagementUI.includes('saveBackupJsonToRememberedTarget'));
  assert.ok(overview.DataManagementUI.includes('chooseBackupJsonTargetAndSave'));
  assert.ok(overview.DataManagementUI.includes('forgetBackupFileHandle'));
  assert.ok(overview.DataManagementUI.includes('getRememberedBackupTargetStatus'));
  assert.ok(overview.DataManagementUI.includes('openBackupJsonFromFile'));
  assert.ok(overview.DataManagementUI.includes('restoreBackupJsonObjectWithConfirm'));
  assert.ok(overview.DataManagementUI.includes('detectBackupEnvironmentCapabilities'));
  assert.ok(overview.DataManagementUI.includes('renderBackupEnvironmentPanel'));
  assert.ok(overview.DataManagementUI.includes('buildBackupEnvironmentReport'));
  assert.ok(overview.Step3Input.includes('bindEventsForStep3'));
  assert.ok(overview.Step3Input.includes('loadAddrToInput'));
  assert.ok(overview.Layout.includes('buildPrintStack'));
  assert.ok(overview.EditCanvasController.includes('attachFieldDrag'));
  assert.ok(overview.EditCanvasController.includes('EnvelopePrintEditCanvasController'));
  assert.ok(overview.Parts.includes('addStampToCurrentTpl'));
  assert.ok(overview.Adjustment.includes('getTplAdjustmentSummary'));
});


await test('backup environment detection recommends file-system access when supported', ()=>{
  api.showSaveFilePicker = async()=>({});
  api.showOpenFilePicker = async()=>[];
  api.isSecureContext = true;
  api.location = {protocol:'file:'};
  api.localStorage = {setItem(){}, removeItem(){}};
  api.navigator = {clipboard:{writeText(){}}};
  api.document = {createElement(){ return {}; }};
  api.Blob = function(){};
  api.URL = {createObjectURL(){ return 'blob:test'; }, revokeObjectURL(){}};
  const caps = api.detectBackupEnvironmentCapabilities();
  assert.strictEqual(caps.fileSystemSave, true);
  assert.strictEqual(caps.fileSystemOpen, true);
  assert.strictEqual(caps.downloadFallback, true);
  assert.strictEqual(caps.localStorageWritable, true);
  assert.strictEqual(caps.recommendedSave.method, 'remembered-file-handle');
  assert.strictEqual(caps.recommendedOpen.method, 'file-system-access');
  const report = api.buildBackupEnvironmentReport(caps);
  assert.ok(report.includes('showSaveFilePicker: yes'));
  assert.ok(report.includes('recommendedSave: 保存先固定・ワンクリック上書き'));
  assert.ok(report.includes('indexedDbPersistence:'));
});

await test('backup environment panel falls back to download/copy guidance safely', ()=>{
  delete api.showSaveFilePicker;
  delete api.showOpenFilePicker;
  api.isSecureContext = false;
  api.location = {protocol:'file:'};
  api.localStorage = {setItem(){ throw new Error('blocked'); }, removeItem(){}};
  api.navigator = {};
  api.document = {createElement(){ return {}; }};
  api.Blob = function(){};
  api.URL = {createObjectURL(){ return 'blob:test'; }, revokeObjectURL(){}};
  const caps = api.detectBackupEnvironmentCapabilities();
  assert.strictEqual(caps.fileSystemSave, false);
  assert.strictEqual(caps.fileSystemOpen, false);
  assert.strictEqual(caps.downloadFallback, true);
  assert.strictEqual(caps.localStorageWritable, false);
  assert.strictEqual(caps.recommendedSave.method, 'download-fallback');
  const html = api.renderBackupEnvironmentPanel(caps);
  assert.ok(html.includes('保存環境診断'));
  assert.ok(html.includes('ブラウザのダウンロード保存'));
  assert.ok(html.includes('localStorage に書き込めません'));
});

await test('showSaveFilePicker backup path writes JSON through file handle when available', async()=>{
  const writes = [];
  api.dataSnapshotForBackup = () => ({templates:[{id:'tpl1'}], addressBook:[]});
  api.Blob = function(parts, opts){ this.parts = parts; this.type = opts && opts.type; };
  api.showSaveFilePicker = async opts => {
    writes.push(['picker', opts.suggestedName, opts.types[0].accept['application/json'][0]]);
    return {
      async createWritable(){
        return {
          async write(blob){ writes.push(['write', blob.parts.join(''), blob.type]); },
          async close(){ writes.push(['close']); }
        };
      }
    };
  };
  const result = await api.saveBackupJsonToFile({templates:[{id:'tpl1'}], addressBook:[]}, {fileName:'backup.json'});
  assert.strictEqual(result.ok, true);
  assert.strictEqual(result.method, 'file-system-access');
  assert.strictEqual(result.fileName, 'backup.json');
  assert.deepStrictEqual(writes[0], ['picker', 'backup.json', '.json']);
  assert.ok(writes[1][1].includes('"templates"'));
  assert.deepStrictEqual(writes[2], ['close']);
});

await test('remembered backup target reuses the same file handle without picker', async()=>{
  const writes = [];
  let pickerCalled = 0;
  api.Blob = function(parts, opts){ this.parts = parts; this.type = opts && opts.type; };
  api.showSaveFilePicker = async () => { pickerCalled++; throw new Error('picker should not be called'); };
  const handle = {
    name:'fixed.json',
    async queryPermission(){ return 'granted'; },
    async createWritable(){
      return {
        async write(blob){ writes.push(['write', blob.parts.join(''), blob.type]); },
        async close(){ writes.push(['close']); }
      };
    }
  };
  const remembered = await api.rememberBackupFileHandle(handle, {fileName:'fixed.json'});
  assert.strictEqual(remembered.ok, true);
  const result = await api.saveBackupJsonToRememberedTarget({templates:[{id:'fixed'}], addressBook:[]}, {allowPicker:false, fallback:false});
  assert.strictEqual(result.ok, true);
  assert.strictEqual(result.method, 'remembered-file-handle');
  assert.strictEqual(result.fileName, 'fixed.json');
  assert.strictEqual(pickerCalled, 0);
  assert.ok(writes[0][1].includes('"fixed"'));
  assert.deepStrictEqual(writes[1], ['close']);
});

await test('remembered backup target can choose and remember a new target', async()=>{
  await api.forgetBackupFileHandle();
  const writes = [];
  api.Blob = function(parts, opts){ this.parts = parts; this.type = opts && opts.type; };
  api.showSaveFilePicker = async opts => {
    assert.strictEqual(opts.suggestedName, 'chosen.json');
    return {
      name:'chosen.json',
      async queryPermission(){ return 'granted'; },
      async createWritable(){
        return {
          async write(blob){ writes.push(['write', blob.parts.join(''), blob.type]); },
          async close(){ writes.push(['close']); }
        };
      }
    };
  };
  const result = await api.chooseBackupJsonTargetAndSave({templates:[{id:'chosen'}], addressBook:[]}, {fileName:'chosen.json'});
  assert.strictEqual(result.ok, true);
  assert.strictEqual(result.method, 'remembered-file-handle-new');
  const status = await api.getRememberedBackupTargetStatus();
  assert.strictEqual(status.remembered, true);
  assert.strictEqual(status.fileName, 'chosen.json');
  assert.ok(writes[0][1].includes('"chosen"'));
});


await test('showOpenFilePicker restore path reads JSON from selected file', async()=>{
  const calls = [];
  api.showOpenFilePicker = async opts => {
    calls.push(['picker', opts.multiple, opts.types[0].accept['application/json'][0]]);
    return [{
      async getFile(){
        return {
          name:'restore.json',
          async text(){ return JSON.stringify({templates:[{id:'tpl_restore'}], addressBook:[{id:'addr1'}]}); }
        };
      }
    }];
  };
  const result = await api.openBackupJsonFromFile({noFallback:true});
  assert.strictEqual(result.ok, true);
  assert.strictEqual(result.method, 'file-system-access');
  assert.strictEqual(result.fileName, 'restore.json');
  assert.strictEqual(result.data.templates[0].id, 'tpl_restore');
  assert.strictEqual(result.data.addressBook[0].id, 'addr1');
  assert.deepStrictEqual(calls[0], ['picker', false, '.json']);
});

await test('restoreBackupJsonObjectWithConfirm backs up before restore', async()=>{
  const calls = [];
  api.showAppConfirm = async (message, title) => { calls.push(['confirm', title, message]); return true; };
  api.backupNow = () => { calls.push(['backup']); return true; };
  api.restoreFullBackupSafely = async (d, message) => { calls.push(['restore', d.templates.length, message]); return true; };
  const ok = await api.restoreBackupJsonObjectWithConfirm({templates:[{id:'tpl1'}], addressBook:[]}, 'restore.json');
  assert.strictEqual(ok, true);
  assert.strictEqual(calls[0][0], 'confirm');
  assert.ok(calls[0][2].includes('restore.json'));
  assert.deepStrictEqual(calls[1], ['backup']);
  assert.deepStrictEqual(calls[2], ['restore', 1, '読込完了']);
});

await test('help/data UI file does not eagerly touch DOM during load', ()=>{
  assert.ok(true, 'module loaded without document stub');
});

console.log('OK data management UI tests passed');
})();
