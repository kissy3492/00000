#!/usr/bin/env node
/* v38-74: load_order.json contract tests. */
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const exists = p => fs.existsSync(path.join(root, p));
const loadOrder = JSON.parse(read('load_order.json'));
const index = read('index.html');
const applyTool = read('tools/apply_load_order.js');

assert(Array.isArray(loadOrder.entries), 'load_order.json must expose entries[]');
assert(loadOrder.entries.length >= 40, 'load_order.json must include current script/style entries');
assert(index.includes('<!-- BEGIN LOAD_ORDER:head -->'), 'index must contain head load-order marker');
assert(index.includes('<!-- BEGIN LOAD_ORDER:body-end -->'), 'index must contain body-end load-order marker');
assert(/function renderEntry/.test(applyTool), 'apply_load_order.js must render entries');
assert(/replaceBlock\(index, 'head'\)/.test(applyTool), 'apply_load_order.js must rewrite head block');
assert(/replaceBlock\(index, 'body-end'\)/.test(applyTool), 'apply_load_order.js must rewrite body-end block');

function assetOf(item){ return item.src || item.href; }
function indexExternalAssets(){
  const items = [];
  for(const match of index.matchAll(/<(script|link)\b([^>]*)>/g)){
    const tag = match[1];
    const attrs = match[2];
    const src = (attrs.match(/\bsrc="([^"]+)"/) || [])[1];
    const href = (attrs.match(/\bhref="([^"]+)"/) || [])[1];
    if(src || href) items.push({ tag, asset:src || href });
  }
  return items;
}

const expected = loadOrder.entries.map(item => ({ tag:item.tag, asset:assetOf(item) }));
const actual = indexExternalAssets();
assert.deepStrictEqual(actual, expected, 'index external asset order must exactly match load_order.json entries');

const seen = new Set();
for(const item of loadOrder.entries){
  assert(['head','body-end'].includes(item.location), `unsupported location: ${item.location}`);
  assert(['script','link'].includes(item.tag), `unsupported tag: ${item.tag}`);
  const asset = assetOf(item);
  assert(asset, 'load-order entry must have src or href');
  assert(exists(asset), `asset must exist: ${asset}`);
  assert(!seen.has(`${item.tag}:${asset}`), `duplicate asset in load_order.json: ${asset}`);
  seen.add(`${item.tag}:${asset}`);
}

function pos(asset){ return expected.findIndex(item => item.asset === asset); }
assert(pos('js/91_runtime_error_trap.js') < pos('js/10_core.js'), 'runtime trap must load before core');
assert(pos('js/92_click_safety.js') < pos('js/10_core.js'), 'click safety must load before core');
assert(pos('js/93_click_fallback.js') < pos('js/10_core.js'), 'click fallback must load before core');
assert(pos('js/94_self_diagnostics.js') < pos('js/10_core.js'), 'self diagnostics must load before core');
assert(pos('js/10_core.js') < pos('js/90_bootstrap.js'), 'core must load before bootstrap');
assert(pos('js/90_bootstrap.js') < pos('js/50_stage5_addon.js'), 'bootstrap must preserve existing stage addon order');
assert(pos('js/48_step_navigation.js') < pos('js/48_step2_edit_ui.js'), 'Step navigation must load before Step2 UI');
assert(pos('js/48_step2_edit_ui.js') < pos('js/48_step1_template_ui.js'), 'existing Step2-before-Step1 load order is explicit in load_order.json');

console.log('Load order contract tests: OK');
