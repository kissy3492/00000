#!/usr/bin/env node
/* v38-64 Browser Hotfix Navigation Guard tests.
   実機で見えた「次に進まない」「ボタン無反応」に直結する導線を固定する。 */
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const nav = fs.readFileSync(path.join(root, 'js', '48_step_navigation.js'), 'utf8');
const step1 = fs.readFileSync(path.join(root, 'js', '48_step1_template_ui.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

function test(name, fn){
  try{ fn(); console.log(`OK ${name}`); }
  catch(err){ console.error(`NG ${name}`); throw err; }
}

test('Step renderer errors are routed to runtime error recording instead of silent no-op', ()=>{
  assert.match(nav, /function\s+reportStepNavigationError\s*\(/);
  assert.match(nav, /recordRuntimeError\(scope, err\)/);
  assert.match(nav, /function\s+callStepRenderer\s*\(/);
  assert.match(nav, /catch\(err\)\{\s*reportStepNavigationError\(label, err\);\s*return false;/);
  assert.match(nav, /if\(n===3\) contentRendered = callStepRenderer\('renderStep3', renderStep3\);/);
});

test('guide continue button actually advances to address input Step3', ()=>{
  assert.match(step1, /safeBindClick[\s\S]*#guideContinue'[\s\S]*closeAccessibleModal\(modal\);[\s\S]*goToStep\(3\);/);
});

test('release notes and verify include v38-64 hotfix guard', ()=>{
  assert.match(core, /\{step:'v38-64'[\s\S]*Navigation Guard/);
  assert.ok(verifySh.includes('tests/browser_hotfix_navigation_guard_tests.js'), 'verify.sh must run browser hotfix navigation guard tests');
});

console.log('Browser hotfix navigation guard tests: OK');
