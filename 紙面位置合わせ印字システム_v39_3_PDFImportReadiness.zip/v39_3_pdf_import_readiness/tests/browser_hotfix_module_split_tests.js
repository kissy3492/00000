#!/usr/bin/env node
/* v38-71 Browser Hotfix Module Split tests.
   目的: v38-70で撤退したHotfix層を90_bootstrap.jsから分離し、bootstrapを初期化順序へ戻す。 */
const fs = require('fs');
const assert = require('assert');
const vm = require('vm');

function read(p){ return fs.readFileSync(p, 'utf8'); }
function ok(name, fn){
  try{ fn(); console.log(`OK ${name}`); }
  catch(err){ console.error(`NG ${name}`); throw err; }
}

const index = read('index.html');
const bootstrap = read('js/90_bootstrap.js');
const runtimeTrap = read('js/91_runtime_error_trap.js');
const clickSafety = read('js/92_click_safety.js');
const clickFallback = read('js/93_click_fallback.js');
const diagnostics = read('js/94_self_diagnostics.js');
const dataUi = read('js/52_data_management_ui.js');
const core = read('js/10_core.js');
const verify = read('tools/verify.sh');

ok('hotfix support modules are split into four IIFE strict files', ()=>{
  for(const [name, src, api] of [
    ['runtime trap', runtimeTrap, 'EnvelopePrintRuntimeErrorTrap'],
    ['click safety', clickSafety, 'EnvelopePrintClickSafety'],
    ['click fallback', clickFallback, 'EnvelopePrintCriticalClickFallback'],
    ['self diagnostics', diagnostics, 'EnvelopePrintInteractionDiagnostics']
  ]){
    assert.match(src, /^\(function\(global\)\{/m, `${name} must start with IIFE`);
    assert.match(src.slice(0, 180), /'use strict';/, `${name} must enable strict mode`);
    assert.ok(src.includes(api), `${name} must expose ${api}`);
  }
});

ok('index loads hotfix support modules before core and bootstrap', ()=>{
  const order = [
    'js/91_runtime_error_trap.js',
    'js/92_click_safety.js',
    'js/93_click_fallback.js',
    'js/94_self_diagnostics.js',
    'js/10_core.js',
    'js/90_bootstrap.js'
  ].map(x => index.indexOf(x));
  for(const [i, pos] of order.entries()) assert.ok(pos >= 0, `script missing at ${i}`);
  assert.deepStrictEqual(order, [...order].sort((a,b)=>a-b), 'script order must be dependency order');
});

ok('90_bootstrap no longer owns hotfix support implementations', ()=>{
  assert.ok(!/function\s+recordRuntimeAction\s*\(/.test(bootstrap), 'runtime action log must be outside bootstrap');
  assert.ok(!/function\s+safeBindClick\s*\(/.test(bootstrap), 'safeBindClick must be outside bootstrap');
  assert.ok(!/const\s+CRITICAL_CLICK_ACTIONS\s*=\s*Object\.freeze/.test(bootstrap), 'click fallback table must be outside bootstrap');
  assert.ok(!/function\s+runInteractionSelfDiagnostics\s*\(/.test(bootstrap), 'self diagnostics must be outside bootstrap');
  assert.match(bootstrap, /runBootstrapTask\('installRuntimeErrorTrap'/);
  assert.match(bootstrap, /runBootstrapTask\('installCriticalClickFallback'/);
  assert.match(bootstrap, /runBootstrapTask\('runInteractionSelfDiagnostics'/);
});

ok('module overview exposes split hotfix APIs', ()=>{
  assert.match(core, /RuntimeErrorTrap:EnvelopePrintRuntimeErrorTrap/);
  assert.match(core, /ClickSafety:EnvelopePrintClickSafety/);
  assert.match(core, /CriticalClickFallback:EnvelopePrintCriticalClickFallback/);
  assert.match(core, /InteractionDiagnostics:EnvelopePrintInteractionDiagnostics/);
  assert.match(dataUi, /RuntimeErrorTrap:\['EnvelopePrintRuntimeErrorTrap','recordRuntimeAction','recordRuntimeError','installRuntimeErrorTrap'\]/);
  assert.match(dataUi, /ClickSafety:\['EnvelopePrintClickSafety','safeBindClick','markClickHandled','markClickAttempted','getActionTargetLabel'\]/);
  assert.match(dataUi, /CriticalClickFallback:\['EnvelopePrintCriticalClickFallback','getCriticalClickActionMap','installCriticalClickFallback','routeCriticalClickFallback'\]/);
  assert.match(dataUi, /InteractionDiagnostics:\['EnvelopePrintInteractionDiagnostics','getInteractionDiagnosticTargets','runInteractionSelfDiagnostics','scheduleInteractionSelfDiagnostics','getLastInteractionSelfDiagnostics'\]/);
});

ok('split modules can be loaded together in a lightweight VM', ()=>{
  const context = {
    console,
    window:null,
    globalThis:null,
    document:{addEventListener(){}, getElementById(){return null;}, querySelector(){return null;}},
    addEventListener(){},
    setTimeout(fn){ fn(); return 1; },
    state:{currentStep:1, uiMode:'simple'},
    getComputedStyle(){ return {display:'block', visibility:'visible'}; }
  };
  context.window = context;
  context.globalThis = context;
  vm.createContext(context);
  for(const file of ['js/91_runtime_error_trap.js','js/92_click_safety.js','js/93_click_fallback.js','js/94_self_diagnostics.js']){
    vm.runInContext(read(file), context, {filename:file});
  }
  assert.strictEqual(typeof context.recordRuntimeAction, 'function');
  assert.strictEqual(typeof context.safeBindClick, 'function');
  assert.strictEqual(typeof context.getCriticalClickActionMap, 'function');
  assert.strictEqual(typeof context.runInteractionSelfDiagnostics, 'function');
  assert.ok(Object.isFrozen(context.EnvelopePrintRuntimeErrorTrap));
  assert.ok(Object.isFrozen(context.EnvelopePrintClickSafety));
  assert.ok(Object.isFrozen(context.EnvelopePrintCriticalClickFallback));
  assert.ok(Object.isFrozen(context.EnvelopePrintInteractionDiagnostics));
});

ok('release notes and verify include v38-71 module split guard', ()=>{
  assert.match(core, /step:'v38-71'[\s\S]*90_bootstrap/);
  assert.ok(verify.includes('browser_hotfix_module_split_tests.js'), 'verify.sh must run v38-71 tests');
});

console.log('Browser hotfix module split tests: OK');
