#!/usr/bin/env node
/* v38-65 Browser Hotfix Click Fallback tests.
   実機で見えたボタン無反応に対し、重要ボタンの委譲フォールバックとクリック記録を固定する。 */
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const bootstrap = fs.readFileSync(path.join(root, 'js', '90_bootstrap.js'), 'utf8');
const runtimeTrap = fs.readFileSync(path.join(root, 'js', '91_runtime_error_trap.js'), 'utf8');
const clickSafety = fs.readFileSync(path.join(root, 'js', '92_click_safety.js'), 'utf8');
const clickFallback = fs.readFileSync(path.join(root, 'js', '93_click_fallback.js'), 'utf8');
const dataUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

function test(name, fn){
  try{ fn(); console.log(`OK ${name}`); }
  catch(err){ console.error(`NG ${name}`); throw err; }
}

test('bootstrap records click actions and exposes action API', ()=>{
  assert.match(runtimeTrap, /function\s+recordRuntimeAction\s*\(/);
  assert.match(runtimeTrap, /__envelopePrintActionLog/);
  assert.match(runtimeTrap, /recordRuntimeAction,[\s\S]*EnvelopePrintRuntimeErrorTrap/);
});

test('critical click fallback is installed without EventTarget prototype guard', ()=>{
  const fallbackIdx = bootstrap.indexOf("runBootstrapTask('installCriticalClickFallback'");
  assert.ok(fallbackIdx >= 0, 'critical fallback install must exist');
  assert.ok(!/EventTarget\.prototype|proto\.addEventListener|installEventHandlerGuard/.test(bootstrap), 'prototype-level event handler guard must not return');
  assert.match(clickSafety, /function\s+safeBindClick\s*\(/);
});

test('fallback routes core navigation and modal buttons through action table', ()=>{
  assert.match(clickFallback, /function\s+routeCriticalClickFallback\s*\(/);
  assert.match(clickFallback, /const\s+CRITICAL_CLICK_ACTIONS\s*=\s*Object\.freeze/);
  for(const id of ['btnHelp','btnDataMgmt','step1Next','step2Next','step3Next','step4Next','step5Back','guideContinue','guideWizard','dmClose']){
    assert.ok(clickFallback.includes(`${id}:`), `fallback route missing: ${id}`);
  }
  assert.match(clickFallback, /guideContinue:[\s\S]*goToStepAction\(3\)/);
});

test('data management UI exposes click log panel and copy action', ()=>{
  assert.match(dataUi, /function\s+getRuntimeActionEntries\s*\(/);
  assert.match(dataUi, /function\s+renderRuntimeActionPanel\s*\(/);
  assert.match(dataUi, /function\s+copyRuntimeActionReport\s*\(/);
  assert.match(dataUi, /\$\{renderRuntimeActionPanel\(\)\}/);
  assert.match(dataUi, /#dmCopyRuntimeActions/);
  assert.match(dataUi, /getRuntimeActionEntries/);
});

test('release notes and verify include v38-65 click fallback guard', ()=>{
  assert.match(core, /\{step:'v38-65'[\s\S]*Click Fallback/);
  assert.ok(verifySh.includes('tests/browser_hotfix_click_fallback_tests.js'), 'verify.sh must run browser hotfix click fallback tests');
});

console.log('Browser hotfix click fallback tests: OK');
