#!/usr/bin/env node
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.resolve(__dirname, '..');
function read(p){ return fs.readFileSync(path.join(root, p), 'utf8'); }
const core = read('js/10_core.js');

assert.match(core, /^\(function\(global\)\{\n'use strict';/, '10_core.js must start with explicit global IIFE and strict mode');
assert.match(core, /const\s+EnvelopePrintCoreContract\s*=\s*Object\.freeze\(\{[\s\S]*getState\(\)\{return state;\}[\s\S]*setState\(nextState\)/, '10_core.js must define frozen EnvelopePrintCoreContract with state accessor contract');
assert.match(core, /Object\.defineProperties\(global,\s*\{[\s\S]*state:\{[\s\S]*get\(\)\{return state;\}[\s\S]*set\(nextState\)[\s\S]*transientBg:\{[\s\S]*get\(\)\{return transientBg;\}/, '10_core.js must expose state/transientBg through global getter/setter compatibility accessors');
assert.match(core, /Object\.assign\(global,\s*\{[\s\S]*APP_DISPLAY_NAME[\s\S]*STORAGE_KEY[\s\S]*STEPS_SIMPLE[\s\S]*EnvelopePrintCoreContract[\s\S]*EnvelopePrintModules/, '10_core.js must explicitly export core constants and module APIs');
assert.match(core, /CoreContract:EnvelopePrintCoreContract/, 'EnvelopePrintModules must expose CoreContract');
assert.doesNotMatch(core, /window\.EnvelopePrintModules\s*=/, '10_core.js must not use direct window.EnvelopePrintModules assignment after IIFE conversion');

const stubNames = [
  'getModuleOverview','EnvelopePrintDataManagementUI','uid','toast','escapeHtml','formatBytes','estimateStorageBytes','estimateDataUrlBytes','EnvelopePrintUtilities','EnvelopePrintKeyboardOverlay','EnvelopePrintStorageCore','dataSnapshot','save','backupNow','load','getStorageUsage','ENVELOPE_SIZES','normalizeTpl','markLayoutChanged','defaultLabelConfig','getLabelConfig','labelCapacity','getEffectivePrintPageCount','buildExcludeZonesForPreset','initialTemplates','buildFieldsForPreset','buildFieldsForSize','EnvelopePrintBackgroundAssets','EnvelopePrintRegistryCore','EnvelopePrintStepNavigation','EnvelopePrintStep1TemplateUI','EnvelopePrintStep2EditUI','EnvelopePrintAddressData','normalizeAddressData','buildOrgText','buildSenderText','getInputData','EnvelopePrintStep3InputCore','EnvelopePrintStep3QueueUI','EnvelopePrintStep4TestPrintUI','EnvelopePrintStep5FinalPrintUI','EnvelopePrintCommonUI','EnvelopePrintRuntimeErrorTrap','EnvelopePrintClickSafety','EnvelopePrintCriticalClickFallback','EnvelopePrintInteractionDiagnostics','FieldSourceRegistry','Step3ExtensionRegistry','InputDataExtensionRegistry','overlap','adjustFieldRect','approxChar','estimatePrintCharUnits','wrapTextByPrintUnits','fitText','renderEnvelope','renderEnvelopeInto','renderNormalField','renderZipField','renderLabelCellInto','buildLabelSheetStack','buildPrintStack','EnvelopePrintEditCanvasController','EnvelopePrintAdjustmentStatus','getTplAdjustmentSummary','EnvelopePrintWizard','addPrintAttempt','getPrintRecordCount','renderFinalChecklist','getHardPrintIssues','renderPrintActionArea','executePrint','doPrint','EnvelopePrintPartsActions','getQueueTemplateGroups','renderJobGroupSummary','buildPostcardFields','buildLabelSheetFields','buildFormOverlayFields','sanitizeSnapshotForLoad','sanitizeSnapshotForRestore','sanitizeStage8AddonForRestore','normalizeRestoreField','normalizeRestoreTemplateFields','normalizeRestoreTemplateIds','normalizeRestorePrinterIds','normalizeRestoreSafeId','isRestoreSafeIdString','addonStorageKeys','joinLines','buildOrgFullText','buildNameWithHonor','buildSenderText','defaultDataForTemplate','getFieldText','getSampleData'
];
const sandbox = { console };
for(const name of stubNames){
  if(name.startsWith('EnvelopePrint') || name.endsWith('Registry') || name === 'ENVELOPE_SIZES' || name === 'FieldSourceRegistry' || name === 'Step3ExtensionRegistry' || name === 'InputDataExtensionRegistry') sandbox[name] = Object.freeze({name});
  else sandbox[name] = function stub(){ return null; };
}
sandbox.initialTemplates = [];
sandbox.ANCHOR_KEYS = undefined;
vm.createContext(sandbox);
vm.runInContext(core, sandbox, {filename:'js/10_core.js'});

assert.ok(sandbox.EnvelopePrintCoreContract, 'EnvelopePrintCoreContract must be exported to global');
assert.ok(Object.isFrozen(sandbox.EnvelopePrintCoreContract), 'EnvelopePrintCoreContract must be frozen');
assert.strictEqual(sandbox.STORAGE_KEY, 'paper_position_print_system_v37', 'STORAGE_KEY must stay stable');
assert.strictEqual(sandbox.BACKUP_KEY, 'paper_position_print_system_v37_backups', 'BACKUP_KEY must stay stable');
assert.strictEqual(sandbox.APP_STORAGE_SCHEMA_VERSION, 19, 'storage schema version must stay stable');
assert.ok(Array.isArray(sandbox.STEPS_SIMPLE) && Array.isArray(sandbox.STEPS_ADVANCED), 'step arrays must be exported');
assert.strictEqual(sandbox.EnvelopePrintModules.CoreContract, sandbox.EnvelopePrintCoreContract, 'EnvelopePrintModules.CoreContract must point to CoreContract API');
assert.strictEqual(sandbox.EnvelopePrintCoreContract.getState(), sandbox.state, 'CoreContract.getState must return global state view');
vm.runInContext('state = {currentStep:4, uiMode:"advanced"};', sandbox);
assert.strictEqual(sandbox.EnvelopePrintCoreContract.getState().currentStep, 4, 'global state assignment must update IIFE private state');
sandbox.EnvelopePrintCoreContract.setTransientBg({abc:{name:'fixture'}});
assert.strictEqual(sandbox.transientBg.abc.name, 'fixture', 'CoreContract.setTransientBg must update global transientBg view');
vm.runInContext('transientBg = {xyz:{name:"via-global"}};', sandbox);
assert.strictEqual(sandbox.EnvelopePrintCoreContract.getTransientBg().xyz.name, 'via-global', 'global transientBg assignment must update IIFE private transientBg');

const verify = read('tools/verify_structure.js');
assert.ok(verify.includes("'js/10_core.js'") && verify.includes("assertIifeStrictSource('js/10_core.js')"), 'verify_structure must enforce 10_core IIFE strict');
assert.match(read('tools/verify.sh'), /iife_strict_phase25_tests\.js/, 'verify.sh must run phase25 tests');
assert.match(read('README.md'), /v38-79 Core Contract Finalization/, 'README must document v38-79');
assert.match(core, /\{step:'v38-79'/, 'APP_RELEASE_NOTES must include v38-79');

console.log('IIFE Strict Phase25 core contract tests: OK');
