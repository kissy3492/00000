#!/usr/bin/env node
/* v38-70 Hotfix Retreat Guardrail tests.
   目的: v38-65で混入したEventTargetプロトタイプ差し替えを撤去し、明示的なsafeBindClickとテーブル駆動fallbackへ戻す。 */
const fs = require('fs');
const assert = require('assert');

const bootstrap = fs.readFileSync('js/90_bootstrap.js', 'utf8');
const clickSafety = fs.readFileSync('js/92_click_safety.js', 'utf8');
const clickFallback = fs.readFileSync('js/93_click_fallback.js', 'utf8');
const diagnostics = fs.readFileSync('js/94_self_diagnostics.js', 'utf8');
const common = fs.readFileSync('js/54_common_ui_binder.js', 'utf8');
const step1 = fs.readFileSync('js/48_step1_template_ui.js', 'utf8');
const step2 = fs.readFileSync('js/48_step2_edit_ui.js', 'utf8');
const step3 = fs.readFileSync('js/48_step3_input_core.js', 'utf8');
const step3Queue = fs.readFileSync('js/48_step3_queue_ui.js', 'utf8');
const step4 = fs.readFileSync('js/48_step4_test_print_ui.js', 'utf8');
const step5 = fs.readFileSync('js/48_step5_final_print_ui.js', 'utf8');
const stepNav = fs.readFileSync('js/48_step_navigation.js', 'utf8');
const dataUi = fs.readFileSync('js/52_data_management_ui.js', 'utf8');
const core = fs.readFileSync('js/10_core.js', 'utf8');
const verify = fs.readFileSync('tools/verify.sh', 'utf8');

function ok(name, fn){
  try{ fn(); console.log(`OK ${name}`); }
  catch(err){ console.error(`NG ${name}`); throw err; }
}

ok('EventTarget prototype monkey patch is absent from runtime code', ()=>{
  for(const src of [bootstrap, clickSafety, clickFallback, diagnostics]){
    assert.ok(!/function\s+installEventHandlerGuard\s*\(/.test(src), 'installEventHandlerGuard must be removed');
    assert.ok(!/EventTarget\.prototype|proto\.addEventListener|proto\.removeEventListener/.test(src), 'EventTarget prototype patch must be absent');
    assert.ok(!/__envelopePrintEventHandlerGuardInstalled/.test(src), 'handler guard singleton flag must be removed');
  }
});

ok('safeBindClick is the explicit handler protection API', ()=>{
  assert.match(clickSafety, /function\s+safeBindClick\s*\(/);
  assert.match(clickSafety, /markClickAttempted\(event\)/);
  assert.match(clickSafety, /handler\.call\(this, event\)/);
  assert.match(clickSafety, /markClickHandled\(event\)/);
  assert.match(clickSafety, /kind:'handler-error'/);
  assert.match(clickSafety, /safeBindClick,[\s\S]*EnvelopePrintClickSafety/);
});

ok('critical fallback is table-driven, not switch-driven', ()=>{
  assert.match(clickFallback, /const\s+CRITICAL_CLICK_ACTIONS\s*=\s*Object\.freeze\(/);
  assert.match(clickFallback, /function\s+getCriticalClickActionMap\s*\(/);
  const routeStart = clickFallback.indexOf('function routeCriticalClickFallback');
  const routeEnd = clickFallback.indexOf('function installCriticalClickFallback');
  const route = clickFallback.slice(routeStart, routeEnd);
  assert.ok(!/switch\s*\(/.test(route), 'routeCriticalClickFallback must not reintroduce a switch router');
  assert.match(route, /CRITICAL_CLICK_ACTIONS\[id\]/);
});

ok('Step/common binders use safeBindClick for critical buttons', ()=>{
  for(const [name, src, needles] of [
    ['common', common, ['btnHelp','btnDataMgmt','modeSimple','modeAdvanced']],
    ['step1', step1, ['newTplCta','newReplyCta','step1Next','guideContinue','guideWizard']],
    ['step2', step2, ['btnReWizard','step2Back','step2Next']],
    ['step3', step3, ['step3Back','step3Next','btnAddQueue','btnSaveToAddrbook','btnClearQueue','btnClearHistory']],
    ['step3Queue', step3Queue, ['pasteAnalyze','pasteClear','doPasteImport']],
    ['step4', step4, ['step4Back','step4Next','btnTestSample','btnTestCross']],
    ['step5', step5, ['step5Back','btnStartOver']],
    ['stepNav', stepNav, ['stepNav']]
  ]){
    assert.ok(src.includes('safeBindClick'), `${name} must reference safeBindClick`);
    for(const n of needles) assert.ok(src.includes(n), `${name} must keep ${n}`);
  }
});

ok('UI diagnostics report safeBindClick instead of Handler Guard', ()=>{
  assert.match(diagnostics, /safeBindClickAvailable/);
  assert.ok(!/handlerGuardInstalled/.test(diagnostics), 'diagnostics must not expose handlerGuardInstalled');
  assert.ok(dataUi.includes('safeBindClick='), 'copy report must include safeBindClick');
  assert.ok(dataUi.includes('safeBind='), 'panel must display safeBind status');
});

ok('release notes and verify include v38-70 guardrail', ()=>{
  assert.match(core, /step:'v38-70'[\s\S]*モンキーパッチを撤去/);
  assert.ok(verify.includes('browser_hotfix_retreat_guardrail_tests.js'), 'verify.sh must run v38-70 retreat guardrail tests');
});

console.log('Browser hotfix retreat guardrail tests: OK');
