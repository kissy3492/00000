#!/usr/bin/env node
/* v38-77 IIFE Strict Phase23 tests: Keyboard / Overlay Controller scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const keyboard = fs.readFileSync(path.join(root, 'js', '06_keyboard_overlay.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataMgmtUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

async function ok(name, fn){
  try{
    await fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

function makeEvent(overrides){
  return Object.assign({
    key:'',
    target:{tagName:'DIV'},
    shiftKey:false,
    ctrlKey:false,
    metaKey:false,
    defaultPrevented:false,
    propagationStopped:false,
    preventDefault(){ this.defaultPrevented = true; },
    stopPropagation(){ this.propagationStopped = true; }
  }, overrides || {});
}

function makeDocument(){
  const handlers = {};
  const doc = {
    handlers,
    overlays:[],
    wizard:null,
    addEventListener(type, fn){ handlers[type] = fn; },
    querySelectorAll(selector){ return selector === '.modal-overlay' ? this.overlays : []; },
    querySelector(selector){ return selector === '.wizard-overlay' ? this.wizard : null; }
  };
  return doc;
}

(async()=>{

await ok('keyboard overlay module starts with IIFE + strict', ()=>{
  assert.ok(/^\(function\(global\)\{/.test(keyboard), 'Keyboard Overlay must start with IIFE');
  assert.ok(keyboard.slice(0, 180).includes("'use strict';"), 'Keyboard Overlay must enable strict mode near the top');
});

await ok('keyboard overlay exposes legacy globals and EnvelopePrintKeyboardOverlay API', ()=>{
  for(const name of ['closeTopOverlayByEscape','setupEscapeToCloseOverlays','setupKeyboard']){
    assert.ok(new RegExp(`function\\s+${name}\\s*\\(`).test(keyboard), `${name} must remain present`);
  }
  assert.ok(/const\s+EnvelopePrintKeyboardOverlay\s*=\s*Object\.freeze\(\{[\s\S]*closeTopOverlayByEscape[\s\S]*setupEscapeToCloseOverlays[\s\S]*setupKeyboard/.test(keyboard), 'EnvelopePrintKeyboardOverlay freeze block missing');
  assert.ok(/Object\.assign\(global,[\s\S]*closeTopOverlayByEscape[\s\S]*setupEscapeToCloseOverlays[\s\S]*setupKeyboard[\s\S]*EnvelopePrintKeyboardOverlay/.test(keyboard), 'legacy keyboard exports must remain assigned to global');
});

await ok('lightweight VM load exposes keyboard API and preserves escape/key contracts', async()=>{
  const doc = makeDocument();
  const calls = [];
  const tpl = {id:'tpl1', locked:false, fields:[{id:'f1', x:10, y:10, w:20, h:10}], excludeZones:[{id:'z1', x:5, y:5, w:10, h:10}]};
  const sandbox = {
    console,
    window:null,
    globalThis:null,
    document:doc,
    state:{currentStep:2, selectedFieldId:'f1', selectedZoneId:null},
    getCurrentTpl(){ return tpl; },
    markLayoutChanged(t){ calls.push(['markLayoutChanged', t.id]); },
    renderEnvelope(){ calls.push('renderEnvelope'); },
    renderFieldList(){ calls.push('renderFieldList'); },
    renderZoneList(){ calls.push('renderZoneList'); },
    save(){ calls.push('save'); },
    closeAccessibleModal(el){ calls.push(['closeAccessibleModal', el && el.id]); if(el) el.closed = true; },
    showAppConfirm: async()=>{ calls.push('showAppConfirm'); return true; },
    closeWizard(){ calls.push('closeWizard'); }
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(keyboard, sandbox, {filename:'js/06_keyboard_overlay.js'});

  assert.strictEqual(typeof sandbox.EnvelopePrintKeyboardOverlay, 'object');
  assert.ok(Object.isFrozen(sandbox.EnvelopePrintKeyboardOverlay), 'EnvelopePrintKeyboardOverlay must be frozen');
  assert.strictEqual(sandbox.EnvelopePrintKeyboardOverlay.setupKeyboard, sandbox.setupKeyboard);

  assert.strictEqual(sandbox.setupKeyboard(), true, 'setupKeyboard must attach listener');
  const moveEvent = makeEvent({key:'ArrowRight'});
  doc.handlers.keydown(moveEvent);
  assert.strictEqual(moveEvent.defaultPrevented, true, 'arrow key editing must prevent default');
  assert.strictEqual(tpl.fields[0].x, 10.5, 'ArrowRight must move selected field by 0.5mm');
  assert.ok(calls.includes('renderEnvelope'), 'keyboard edit must refresh envelope');
  assert.ok(calls.includes('save'), 'keyboard edit must save');

  const inputEvent = makeEvent({key:'ArrowRight', target:{tagName:'INPUT'}});
  doc.handlers.keydown(inputEvent);
  assert.strictEqual(inputEvent.defaultPrevented, false, 'keyboard edit must ignore form controls');

  assert.strictEqual(sandbox.setupEscapeToCloseOverlays(), true, 'setupEscapeToCloseOverlays must attach listener');
  const legacyOverlay = {id:'modal1', dataset:{legacyModal:'1'}, parentElement:null, querySelector(){ return null; }, remove(){ this.removed = true; }};
  doc.overlays = [legacyOverlay];
  const escEvent = makeEvent({key:'Escape'});
  await doc.handlers.keydown(escEvent);
  assert.strictEqual(escEvent.defaultPrevented, true, 'Escape modal close must prevent default');
  assert.ok(calls.some(item => Array.isArray(item) && item[0] === 'closeAccessibleModal' && item[1] === 'modal1'), 'Escape must close legacy modal through closeAccessibleModal');

  doc.overlays = [];
  doc.wizard = {className:'wizard-overlay'};
  sandbox.wizardState = {step:1};
  const wizardEsc = makeEvent({key:'Escape'});
  await doc.handlers.keydown(wizardEsc);
  assert.ok(calls.includes('showAppConfirm'), 'Escape wizard close must confirm');
  assert.ok(calls.includes('closeWizard'), 'Escape wizard close must call closeWizard after confirm');
});

await ok('global module indexes expose Keyboard Overlay API', ()=>{
  assert.ok(/KeyboardOverlay:EnvelopePrintKeyboardOverlay/.test(core), 'EnvelopePrintModules must expose EnvelopePrintKeyboardOverlay');
  assert.ok(/KeyboardOverlay:\['EnvelopePrintKeyboardOverlay','closeTopOverlayByEscape','setupEscapeToCloseOverlays','setupKeyboard'\]/.test(dataMgmtUi), 'getModuleOverview must expose Keyboard Overlay API');
});

await ok('verification pipeline includes phase23 guard', ()=>{
  assert.ok(verify.includes('js/06_keyboard_overlay.js'), 'verify_structure must include Keyboard Overlay guard');
  assert.ok(verify.includes('EnvelopePrintKeyboardOverlay'), 'verify_structure must check EnvelopePrintKeyboardOverlay');
  assert.ok(verifySh.includes('tests/iife_strict_phase23_tests.js'), 'verify.sh must run phase23 tests');
});

console.log('IIFE strict phase23 tests: OK');
})().catch(err=>{
  console.error(err);
  process.exit(1);
});
