#!/usr/bin/env node
/* v38-21: Bootstrap Controller unit tests.
   目的: coreから分離した起動順序・最終使用テンプレート選択が単独で壊れていないことを確認する。 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const code = fs.readFileSync(path.join(root, 'js', '90_bootstrap.js'), 'utf8');

const sandbox = {
  console,
  window: null,
  globalThis: null,
  __ENVELOPE_PRINT_BOOTSTRAP_TEST_MODE: true,
  state: { selectedTplId: null, lastUsedTplId: null },
  getTpl: () => null
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(code, sandbox, { filename: 'js/90_bootstrap.js' });
const api = sandbox.EnvelopePrintBootstrap;

function test(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(e){
    console.error(`NG ${name}`);
    throw e;
  }
}

test('exports expected bootstrap API', ()=>{
  assert.ok(api, 'EnvelopePrintBootstrap must be exported');
  for(const name of ['bindEvents','selectLastUsedTemplate','initializeApp','scheduleInitializeApp']){
    assert.strictEqual(typeof api[name], 'function', `${name} must be exported`);
  }
});

test('test mode prevents automatic initialization', ()=>{
  assert.strictEqual(sandbox.state.selectedTplId, null);
  assert.strictEqual(sandbox.state.lastUsedTplId, null);
});

test('selectLastUsedTemplate restores a valid last-used template', ()=>{
  sandbox.state.selectedTplId = 'current';
  sandbox.state.lastUsedTplId = 'last-valid';
  sandbox.getTpl = id => id === 'last-valid' ? {id} : null;
  assert.strictEqual(api.selectLastUsedTemplate(), 'last-valid');
  assert.strictEqual(sandbox.state.selectedTplId, 'last-valid');
});

test('selectLastUsedTemplate keeps current selection when last-used id is missing', ()=>{
  sandbox.state.selectedTplId = 'current';
  sandbox.state.lastUsedTplId = 'missing';
  sandbox.getTpl = () => null;
  assert.strictEqual(api.selectLastUsedTemplate(), 'current');
  assert.strictEqual(sandbox.state.selectedTplId, 'current');
});

test('initializeApp calls bootstrap hooks in the expected order', ()=>{
  const order = [];
  api.initializeApp({
    installRuntimeErrorTrap:()=>order.push('installRuntimeErrorTrap'),
    installCriticalClickFallback:()=>order.push('installCriticalClickFallback'),
    load:()=>order.push('load'),
    setupKeyboard:()=>order.push('setupKeyboard'),
    setupEscapeToCloseOverlays:()=>order.push('setupEscapeToCloseOverlays'),
    bindEvents:()=>order.push('bindEvents'),
    selectLastUsedTemplate:()=>order.push('selectLastUsedTemplate'),
    goToStep:n=>order.push(`goToStep:${n}`),
    updateStorageStatus:()=>order.push('updateStorageStatus'),
    runInteractionSelfDiagnostics:()=>order.push('runInteractionSelfDiagnostics')
  });
  assert.deepStrictEqual(order, [
    'installRuntimeErrorTrap',
    'installCriticalClickFallback',
    'load',
    'setupKeyboard',
    'setupEscapeToCloseOverlays',
    'bindEvents',
    'selectLastUsedTemplate',
    'goToStep:1',
    'updateStorageStatus',
    'runInteractionSelfDiagnostics'
  ]);
});
