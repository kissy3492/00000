#!/usr/bin/env node
/* v38-61 IIFE Strict Phase22 tests: Step5 Final Print UI scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const step5 = fs.readFileSync(path.join(root, 'js', '48_step5_final_print_ui.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataMgmtUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

async function ok(name, fn){
  try{
    await fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

(async()=>{

const legacyFns = ['renderStep5','bindEventsForStep5'];

await ok('step5 final print UI starts with IIFE + strict', ()=>{
  assert.ok(/^\(function\(global\)\{/.test(step5), 'Step5 Final Print UI must start with IIFE');
  assert.ok(step5.slice(0, 180).includes("'use strict';"), 'Step5 Final Print UI must enable strict mode near the top');
});

await ok('step5 final print UI exposes legacy globals and EnvelopePrintStep5FinalPrintUI API', ()=>{
  for(const name of legacyFns){
    assert.ok(new RegExp(`function\\s+${name}\\s*\\(`).test(step5), `${name} must remain present`);
  }
  assert.ok(/const\s+Step5FinalPrintUiApi\s*=\s*Object\.freeze\(\{[\s\S]*renderStep5[\s\S]*bindEventsForStep5/.test(step5), 'Step5FinalPrintUiApi freeze block missing');
  assert.ok(/EnvelopePrintStep5FinalPrintUI:\s*Step5FinalPrintUiApi/.test(step5), 'EnvelopePrintStep5FinalPrintUI export missing');
  assert.ok(/Object\.assign\(global,[\s\S]*renderStep5[\s\S]*bindEventsForStep5[\s\S]*EnvelopePrintStep5FinalPrintUI/.test(step5), 'legacy Step5 exports must remain assigned to global');
});

await ok('lightweight VM load exposes step5 API and preserves preview/render contracts', ()=>{
  function makeElement(id){
    return {
      id,
      className:'',
      dataset:{},
      checked:false,
      textContent:'',
      innerHTML:'',
      disabled:false,
      style:{},
      children:[],
      handlers:{},
      appendChild(child){ this.children.push(child); return child; },
      querySelectorAll(selector){
        const found = [];
        const visit = node => {
          if(selector === '.field' && String(node.className || '').split(/\s+/).includes('field')) found.push(node);
          for(const child of node.children || []) visit(child);
        };
        for(const child of this.children) visit(child);
        return found;
      },
      addEventListener(type, fn){ this.handlers[type] = fn; }
    };
  }
  const elements = {};
  for(const id of ['sumTpl','sumSize','sumCount','sumCorrection','printPreviewStack','step5Back','btnStartOver']){
    elements[id] = makeElement(id);
  }
  const calls = [];
  const tpl = {id:'tpl1', name:'長3封筒', w:120, h:235, paperKind:'envelope'};
  const sandbox = {
    console,
    window:null,
    globalThis:null,
    state:{
      selectedTplId:'tpl1',
      selectedPrinterId:'p1',
      queue:[{tplId:'tpl1', name:'山田', honor:'様'}, {tplId:'tpl2', name:'佐藤', honor:'様'}, {tplId:'tpl1', corp:'株式会社A'}]
    },
    document:{ createElement(tag){ const el = makeElement(tag); el.tagName = tag.toUpperCase(); return el; } },
    $(id){ return elements[id] || (elements[id] = makeElement(id)); },
    getCurrentTpl(){ return tpl; },
    getEffectivePrintPageCount(t, count){ calls.push(['getEffectivePrintPageCount', t.id, count]); return count; },
    getCurrentPrinter(){ return {id:'p1', name:'Main Printer'}; },
    getPrinterCorrection(){ return {rightShift:0, downShift:0, widthDiff:0, heightDiff:0}; },
    hasAnyCorrection(c){ return !!(c.rightShift || c.downShift || c.widthDiff || c.heightDiff); },
    renderFinalChecklist(){ calls.push('renderFinalChecklist'); },
    renderPrintActionArea(){ calls.push('renderPrintActionArea'); },
    normalizeAddressData(data){ calls.push(['normalizeAddressData', data.name || data.corp]); return Object.assign({normalized:true}, data); },
    renderEnvelopeInto(env, t, data, opts){ calls.push(['renderEnvelopeInto', data.name || data.corp, opts]); env.appendChild(makeElement('rendered-envelope')); },
    goToStep(n){ calls.push(['goToStep', n]); },
    showAppConfirm: async () => true,
    Step5ExtensionRegistry:{ runRenderHooks(payload){ calls.push(['step5Hook', payload.tpl && payload.tpl.id]); } }
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(step5, sandbox, {filename:'js/48_step5_final_print_ui.js'});

  assert.strictEqual(typeof sandbox.EnvelopePrintStep5FinalPrintUI, 'object');
  assert.ok(Object.isFrozen(sandbox.EnvelopePrintStep5FinalPrintUI), 'EnvelopePrintStep5FinalPrintUI must be frozen');
  assert.strictEqual(sandbox.EnvelopePrintStep5FinalPrintUI.renderStep5, sandbox.renderStep5);

  sandbox.renderStep5();
  assert.strictEqual(elements.sumTpl.textContent, '長3封筒');
  assert.strictEqual(elements.sumSize.textContent, '120×235 mm');
  assert.strictEqual(elements.sumCount.textContent, '3 枚');
  assert.strictEqual(elements.sumCorrection.textContent, 'なし');
  assert.ok(calls.includes('renderFinalChecklist'), 'final checklist must be rendered');
  assert.ok(calls.includes('renderPrintActionArea'), 'print action area must be rendered');
  assert.ok(calls.some(item => Array.isArray(item) && item[0] === 'step5Hook' && item[1] === 'tpl1'), 'Step5 render hook must run');
  const renderedNames = calls.filter(item => Array.isArray(item) && item[0] === 'renderEnvelopeInto').map(item => item[1]);
  assert.deepStrictEqual(renderedNames, ['山田','株式会社A'], 'preview must render only queue items for selected template');
  const firstRender = calls.find(item => Array.isArray(item) && item[0] === 'renderEnvelopeInto');
  assert.strictEqual(JSON.stringify(firstRender[2]), JSON.stringify({editable:false, scale:0.5, interactive:false, showBg:false, showZones:false, applyCorrection:false}));

  sandbox.bindEventsForStep5();
  elements.step5Back.handlers.click();
  assert.ok(calls.some(item => Array.isArray(item) && item[0] === 'goToStep' && item[1] === 4), 'step5Back must return to Step4');
  return elements.btnStartOver.handlers.click().then(()=>{
    assert.ok(calls.some(item => Array.isArray(item) && item[0] === 'goToStep' && item[1] === 1), 'btnStartOver must return to Step1 after confirmation');
  });
});

await ok('global module indexes expose Step5 Final Print UI API', ()=>{
  assert.ok(/Step5FinalPrint:EnvelopePrintStep5FinalPrintUI/.test(core), 'EnvelopePrintModules must expose EnvelopePrintStep5FinalPrintUI');
  assert.ok(/Step5FinalPrint:\['EnvelopePrintStep5FinalPrintUI','renderStep5','startOverFromStep5','bindEventsForStep5'\]/.test(dataMgmtUi), 'getModuleOverview must expose Step5 Final Print UI API');
});

await ok('verification pipeline includes phase22 guard', ()=>{
  assert.ok(verify.includes('js/48_step5_final_print_ui.js'), 'verify_structure must include Step5 Final Print UI guard');
  assert.ok(verify.includes('EnvelopePrintStep5FinalPrintUI'), 'verify_structure must check EnvelopePrintStep5FinalPrintUI');
  assert.ok(verifySh.includes('tests/iife_strict_phase22_tests.js'), 'verify.sh must run phase22 tests');
});

console.log('IIFE strict phase22 tests: OK');
})().catch(err=>{
  console.error(err);
  process.exit(1);
});
