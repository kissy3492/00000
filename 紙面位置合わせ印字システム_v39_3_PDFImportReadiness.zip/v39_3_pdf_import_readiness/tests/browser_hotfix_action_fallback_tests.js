#!/usr/bin/env node
/* v38-69 Browser Hotfix Action Fallback tests.
   目的: 動的描画後に固定イベントが外れても、主要なStep3/4/5アクションを委譲fallbackで救済できることを固定する。 */
const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
function read(p){ return fs.readFileSync(path.join(root, p), 'utf8'); }
function bodyOf(src, fnName){
  const marker = `function ${fnName}(`;
  const start = src.indexOf(marker);
  assert.ok(start >= 0, `${fnName} must exist`);
  const brace = src.indexOf('{', start);
  let depth = 0;
  for(let i=brace; i<src.length; i++){
    const ch = src[i];
    if(ch === '{') depth++;
    if(ch === '}') depth--;
    if(depth === 0) return src.slice(start, i + 1);
  }
  throw new Error(`could not parse ${fnName}`);
}
function ok(name, fn){
  try{ fn(); console.log(`OK ${name}`); }
  catch(err){ console.error(`NG ${name}`); throw err; }
}

const bootstrap = read('js/90_bootstrap.js');
const clickFallback = read('js/93_click_fallback.js');
const diagnostics = read('js/94_self_diagnostics.js');
const step3 = read('js/48_step3_input_core.js');
const step4 = read('js/48_step4_test_print_ui.js');
const step5 = read('js/48_step5_final_print_ui.js');
const dataUi = read('js/52_data_management_ui.js');
const core = read('js/10_core.js');
const verify = read('tools/verify.sh');

ok('Step3 action bodies are named, exported, and reused by fixed listeners', ()=>{
  for(const fn of ['addCurrentInputToQueue','saveCurrentInputToAddrbook','clearQueueWithConfirm','clearHistoryWithConfirm']){
    assert.match(step3, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} missing`);
    assert.match(step3, new RegExp(`\\b${fn}\\b[\\s\\S]*EnvelopePrintStep3InputCore`), `${fn} must be exported`);
  }
  const binder = bodyOf(step3, 'bindEventsForStep3');
  assert.match(binder, /btnAddQueue[\s\S]*addCurrentInputToQueue/);
  assert.match(binder, /btnSaveToAddrbook[\s\S]*saveCurrentInputToAddrbook/);
  assert.match(bodyOf(step3, 'addCurrentInputToQueue'), /InputValidationRegistry[\s\S]*runBeforeAddQueueHooks/);
});

ok('Step4 and Step5 action bodies are named and exported for fallback reuse', ()=>{
  for(const fn of ['fixQueueMismatchToCurrentTemplate','removeQueueMismatchFromCurrentTemplate','printStep4Sample','printStep4FirstQueueItem','printStep4CrossTest']){
    assert.match(step4, new RegExp(`function\\s+${fn}\\s*\\(`), `${fn} missing`);
    assert.match(step4, new RegExp(`\\b${fn}\\b[\\s\\S]*EnvelopePrintStep4TestPrintUI`), `${fn} must be exported`);
  }
  assert.match(step5, /function\s+startOverFromStep5\s*\(/);
  assert.match(step5, /startOverFromStep5[\s\S]*EnvelopePrintStep5FinalPrintUI/);
});

ok('critical click fallback routes Step3/4/5 action buttons through table', ()=>{
  const mapStart = clickFallback.indexOf('const CRITICAL_CLICK_ACTIONS');
  assert.ok(mapStart >= 0, 'CRITICAL_CLICK_ACTIONS table missing');
  const map = clickFallback.slice(mapStart, clickFallback.indexOf('function getCriticalClickActionMap'));
  const pairs = [
    ['btnAddQueue','addCurrentInputToQueue'],
    ['btnSaveToAddrbook','saveCurrentInputToAddrbook'],
    ['btnClearQueue','clearQueueWithConfirm'],
    ['pasteAnalyze','analyzePastedData'],
    ['doPasteImport','doImportPaste'],
    ['btnFixMismatch','fixQueueMismatchToCurrentTemplate'],
    ['btnRemoveMismatch','removeQueueMismatchFromCurrentTemplate'],
    ['btnTestSample','printStep4Sample'],
    ['btnTestFirst','printStep4FirstQueueItem'],
    ['btnTestCross','printStep4CrossTest'],
    ['btnStartOver','startOverFromStep5']
  ];
  for(const [id, fn] of pairs){
    assert.ok(map.includes(`${id}:`), `${id} table entry missing`);
    assert.ok(map.includes(fn), `${id} must route to ${fn}`);
  }
  assert.match(bodyOf(clickFallback, 'routeCriticalClickFallback'), /CRITICAL_CLICK_ACTIONS\[id\]/);
});

ok('self diagnostics mark newly rescued action buttons as fallback eligible', ()=>{
  for(const id of ['btnAddQueue','btnSaveToAddrbook','btnClearInput','btnClearQueue','pasteAnalyze','doPasteImport','btnFixMismatch','btnTestSample','btnTestFirst','btnTestCross','btnStartOver']){
    assert.match(diagnostics, new RegExp(`id:'${id}'[\\s\\S]{0,120}fallback:true`), `${id} must be fallback eligible`);
  }
});

ok('module overview exposes new action-level APIs', ()=>{
  assert.match(dataUi, /Step3Input:\['EnvelopePrintStep3InputCore','renderStep3','renderInputForm','getInputData','loadAddrToInput','clearInput','switchInputPane','addCurrentInputToQueue','saveCurrentInputToAddrbook','clearQueueWithConfirm','clearHistoryWithConfirm','bindEventsForStep3'\]/);
  assert.match(dataUi, /Step4TestPrint:\['EnvelopePrintStep4TestPrintUI','renderStep4','renderPrinterProfileSection','updateStep4Summary','fixQueueMismatchToCurrentTemplate','removeQueueMismatchFromCurrentTemplate','printStep4Sample','printStep4FirstQueueItem','printStep4CrossTest','bindEventsForStep4'\]/);
  assert.match(dataUi, /Step5FinalPrint:\['EnvelopePrintStep5FinalPrintUI','renderStep5','startOverFromStep5','bindEventsForStep5'\]/);
});

ok('release notes and verify include v38-69 action fallback guard', ()=>{
  assert.match(core, /step:'v38-69'[\s\S]*Action Fallback/);
  assert.ok(verify.includes('browser_hotfix_action_fallback_tests.js'), 'verify.sh must run v38-69 tests');
});

console.log('Browser hotfix action fallback tests: OK');
