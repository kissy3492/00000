#!/usr/bin/env node
/* v38-55 IIFE Strict Phase16 tests: Step Navigation scope/API guard. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const nav = fs.readFileSync(path.join(root, 'js', '48_step_navigation.js'), 'utf8');
const core = fs.readFileSync(path.join(root, 'js', '10_core.js'), 'utf8');
const dataMgmtUi = fs.readFileSync(path.join(root, 'js', '52_data_management_ui.js'), 'utf8');
const verify = fs.readFileSync(path.join(root, 'tools', 'verify_structure.js'), 'utf8');
const verifySh = fs.readFileSync(path.join(root, 'tools', 'verify.sh'), 'utf8');

function ok(name, fn){
  try{
    fn();
    console.log(`OK ${name}`);
  }catch(err){
    console.error(`NG ${name}`);
    throw err;
  }
}

const legacyFns = ['getActiveSteps','stepIndex','renderSteps','getStepStatus','canSkipTo','canGoToStep','goToStep'];

ok('step navigation starts with IIFE + strict', ()=>{
  assert.ok(/^\(function\(global\)\{/.test(nav), 'Step Navigation must start with IIFE');
  assert.ok(nav.slice(0, 220).includes("'use strict';"), 'Step Navigation must enable strict mode near the top');
});

ok('step navigation exposes legacy globals and EnvelopePrintStepNavigation API', ()=>{
  for(const name of legacyFns){
    assert.ok(new RegExp(`function\\s+${name}\\s*\\(`).test(nav), `${name} must remain present`);
  }
  assert.ok(/const\s+StepNavigationApi\s*=\s*Object\.freeze\(\{[\s\S]*getActiveSteps[\s\S]*goToStep/.test(nav), 'StepNavigationApi freeze block missing');
  assert.ok(/EnvelopePrintStepNavigation:\s*StepNavigationApi/.test(nav), 'EnvelopePrintStepNavigation export missing');
  assert.ok(/Object\.assign\(global,[\s\S]*getActiveSteps[\s\S]*goToStep[\s\S]*EnvelopePrintStepNavigation/.test(nav), 'legacy step navigation exports must remain assigned to global');
});

ok('lightweight VM load exposes step navigation API and preserves navigation contracts', ()=>{
  const classToggleLog = [];
  const stepContents = [
    {dataset:{step:'1'}, classList:{toggle(cls, active){ classToggleLog.push([1, cls, active]); }}},
    {dataset:{step:'2'}, classList:{toggle(cls, active){ classToggleLog.push([2, cls, active]); }}},
    {dataset:{step:'3'}, classList:{toggle(cls, active){ classToggleLog.push([3, cls, active]); }}}
  ];
  const calls = [];
  const sandbox = {
    console,
    window:null,
    globalThis:null,
    state:{uiMode:'advanced', currentStep:1, selectedTplId:'tpl1', templates:[{id:'tpl1', name:'長いテンプレート名サンプル', w:100, h:148}], queue:[{id:'q1'}], addressBook:[{}]},
    STEPS_SIMPLE:[{n:1,title:'テンプレート',desc:'選択'},{n:3,title:'入力',desc:'宛名'}],
    STEPS_ADVANCED:[{n:1,title:'テンプレート',desc:'選択'},{n:2,title:'詳細',desc:'編集'},{n:3,title:'入力',desc:'宛名'},{n:4,title:'試し刷り',desc:'確認'},{n:5,title:'本番',desc:'印刷'}],
    __pdfjsAvailable:false,
    $(){ return {innerHTML:'', textContent:'', appendChild(){}, addEventListener(){}}; },
    getPrintRecordCount(){ return 2; },
    updateStorageStatus(){ calls.push('updateStorageStatus'); },
    getCurrentTpl(){ return sandbox.state.templates[0]; },
    getCurrentPrinter(){ return {name:'補正プリンタA'}; },
    toast(msg, type){ calls.push(['toast', msg, type]); },
    renderStep1(){ calls.push('renderStep1'); },
    renderStep2(){ calls.push('renderStep2'); },
    renderStep3(){ calls.push('renderStep3'); },
    renderStep4(){ calls.push('renderStep4'); },
    renderStep5(){ calls.push('renderStep5'); },
    applyScreenA11y(){ calls.push('applyScreenA11y'); },
    document:{
      querySelectorAll(selector){
        assert.strictEqual(selector, '.step-content');
        return stepContents;
      },
      querySelector(selector){
        assert.strictEqual(selector, '.main');
        return {scrollTop:99};
      },
      createElement(){ return {className:'', innerHTML:'', addEventListener(){}, appendChild(){}}; }
    }
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(nav, sandbox, {filename:'js/48_step_navigation.js'});

  assert.strictEqual(typeof sandbox.EnvelopePrintStepNavigation, 'object');
  assert.ok(Object.isFrozen(sandbox.EnvelopePrintStepNavigation), 'EnvelopePrintStepNavigation must be frozen');
  assert.strictEqual(sandbox.EnvelopePrintStepNavigation.goToStep, sandbox.goToStep);
  assert.deepStrictEqual(sandbox.getActiveSteps().map(s=>s.n), [1,2,3,4,5]);
  assert.strictEqual(sandbox.stepIndex(3), 2);
  assert.strictEqual(sandbox.canSkipTo(4), true);
  assert.strictEqual(sandbox.canGoToStep(2), true);
  sandbox.state.uiMode = 'simple';
  assert.deepStrictEqual(sandbox.getActiveSteps().map(s=>s.n), [1,3]);
  assert.strictEqual(sandbox.canGoToStep(2), false);
  sandbox.state.uiMode = 'advanced';
  sandbox.goToStep(3);
  assert.strictEqual(sandbox.state.currentStep, 3);
  assert.ok(calls.includes('renderStep3'), 'goToStep(3) must route to renderStep3');
  assert.ok(calls.includes('applyScreenA11y'), 'goToStep must apply a11y');
  assert.deepStrictEqual(classToggleLog.map(x=>[x[0], x[2]]), [[1,false],[2,false],[3,true]]);

  const recorded = [];
  sandbox.EnvelopePrintBootstrap = { recordRuntimeError(scope, err){ recorded.push([scope, err && err.message]); } };
  sandbox.renderStep4 = () => { throw new Error('render boom'); };
  assert.strictEqual(sandbox.goToStep(4), false, 'goToStep must return false when target renderer fails');
  assert.deepStrictEqual(recorded[0], ['renderStep4', 'render boom']);
});

ok('global module indexes expose Step Navigation API', ()=>{
  assert.ok(/StepNavigation:EnvelopePrintStepNavigation/.test(core), 'EnvelopePrintModules must expose EnvelopePrintStepNavigation');
  assert.ok(/StepNavigation:\['EnvelopePrintStepNavigation','getActiveSteps','stepIndex','renderSteps','getStepStatus','canSkipTo','canGoToStep','callStepRenderer','goToStep'\]/.test(dataMgmtUi), 'getModuleOverview must expose Step Navigation API');
});

ok('verification pipeline includes phase16 guard', ()=>{
  assert.ok(verify.includes('js/48_step_navigation.js'), 'verify_structure must include step navigation guard');
  assert.ok(verify.includes('EnvelopePrintStepNavigation'), 'verify_structure must check EnvelopePrintStepNavigation');
  assert.ok(verifySh.includes('tests/iife_strict_phase16_tests.js'), 'verify.sh must run phase16 tests');
});

console.log('IIFE strict phase16 tests: OK');
