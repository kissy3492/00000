# v39-3 テスト（分割版本流）

保存・復元sanitizeは `storage_restore_tests.html` をブラウザで開いて確認します。Address Data Formatterは `node tests/address_data_unit_tests.js`、Background Assets Controllerは `node tests/background_assets_unit_tests.js`、Parts Actions Controllerは `node tests/parts_actions_unit_tests.js`、Edit Canvas Controllerは `node tests/edit_canvas_controller_unit_tests.js`、Step Navigationは `node tests/step_navigation_unit_tests.js`、Step2 Edit UIは `node tests/step2_edit_ui_unit_tests.js`、Step1 Template UIは `node tests/step1_template_ui_unit_tests.js`、Step3 Input Coreは `node tests/step3_input_core_unit_tests.js`、Step3 Queue UIは `node tests/step3_input_queue_inventory_tests.js`、Step4/Step5 UIは `node tests/step4_step5_ui_unit_tests.js`、Data Management UI Controllerは `node tests/data_management_ui_unit_tests.js`、Common UI Binderは `node tests/common_ui_binder_unit_tests.js`、Adjustment Statusは `node tests/adjustment_status_unit_tests.js`、Bootstrap Controllerは `node tests/bootstrap_unit_tests.js`、Browser E2E Smokeは `node tests/browser_e2e_smoke_tests.js`、README Release History Closeoutは `node tests/readme_release_history_tests.js`、Version Sync Guardは `node tests/version_sync_unit_tests.js`、Docs Inventory Consolidationは `node tests/docs_inventory_consolidation_tests.js`、IIFE Strict Phase1は `node tests/iife_strict_phase1_tests.js`、IIFE Strict Phase2は `node tests/iife_strict_phase2_tests.js`、IIFE Strict Phase3は `node tests/iife_strict_phase3_tests.js`、IIFE Strict Phase4は `node tests/iife_strict_phase4_tests.js`、IIFE Strict Phase5は `node tests/iife_strict_phase5_tests.js`、IIFE Strict Phase6は `node tests/iife_strict_phase6_tests.js`、IIFE Strict Phase7は `node tests/iife_strict_phase7_tests.js`、IIFE Strict Phase8は `node tests/iife_strict_phase8_tests.js`、IIFE Strict Phase9は `node tests/iife_strict_phase9_tests.js`、IIFE Strict Phase10は `node tests/iife_strict_phase10_tests.js`、IIFE Strict Phase11は `node tests/iife_strict_phase11_tests.js`、IIFE Strict Phase12は `node tests/iife_strict_phase12_tests.js`、IIFE Strict Phase13は `node tests/iife_strict_phase13_tests.js`、IIFE Strict Phase14は `node tests/iife_strict_phase14_tests.js`、IIFE Strict Phase15は `node tests/iife_strict_phase15_tests.js`、IIFE Strict Phase16は `node tests/iife_strict_phase16_tests.js`、IIFE Strict Phase17は `node tests/iife_strict_phase17_tests.js`、IIFE Strict Phase18は `node tests/iife_strict_phase18_tests.js`、IIFE Strict Phase19は `node tests/iife_strict_phase19_tests.js`、IIFE Strict Phase20は `node tests/iife_strict_phase20_tests.js`、IIFE Strict Phase21は `node tests/iife_strict_phase21_tests.js`、IIFE Strict Phase22は `node tests/iife_strict_phase22_tests.js`、IIFE Strict Phase23は `node tests/iife_strict_phase23_tests.js`、IIFE Strict Phase24は `node tests/iife_strict_phase24_tests.js`、IIFE Strict Phase25は `node tests/iife_strict_phase25_tests.js` で確認します。

このテストは `../index.html` を iframe で読み込み、`EnvelopePrintModules.TestHooks` から保存・復元sanitize関数を呼び出します。

## テスト対象

- 不正fieldの安全補正
- template.idの安全化とtplId参照変換
- printerProfile.idの安全化とselectedPrinterId参照変換
- Stage8 addonの検証記録・手動チェック進捗ID変換

## 注意

- 分割版本流の品質確認用です。配布時もこのテストを基本確認に使います。
- localStorageへ保存するテストではありません。


## Address Data Formatter単体テスト

```bash
node tests/address_data_unit_tests.js
```

`buildOrgText` と `buildOrgFullText` の優先順位差、プレーンテキスト返却契約、Registry委譲を検証します。


## Background Assets Controller単体テスト

```bash
node tests/background_assets_unit_tests.js
```

`setBackgroundOnTpl()` の永続/一時背景保存、空テンプレートの安全拒否、`fileToDataURL()` のラッパー、未対応形式とPDF拡張子判定を検証します。




## Parts Actions Controller単体テスト

```bash
node tests/parts_actions_unit_tests.js
```

`createSenderFields()` / `createStampField()` のfield契約、差出人欄・スタンプ追加時の保存/再描画hook、Stage5スタンプライブラリ委譲を検証します。

## Edit Canvas Controller単体テスト

```bash
node tests/edit_canvas_controller_unit_tests.js
```

`getMMperPxOf()`、`getDragPoint()`、主要ドラッグ判定、document listenerの追加/解除、fieldドラッグ、避ける範囲追加モード、envelopeドラフトhandler接続を検証します。


## Step Navigation単体テスト

```bash
node tests/step_navigation_unit_tests.js
```

ステップ一覧描画・進行可否・ステップ遷移の関数配置、Step2詳細編集UIからの除去、公開API、読込順を静的検証します。

## Step2 Edit UI静的テスト

```bash
node tests/step2_edit_ui_unit_tests.js
```

Step2詳細編集UIの関数配置、event binder委譲、`48_steps_ui.js` からの除去、公開API、読込順、field/zip/zone編集時の保存・再描画契約を静的検証します。

## Step1 Template UI単体テスト

```bash
node tests/step1_template_ui_unit_tests.js
```

`bindEventsForStep1()` / `renderStep1()` / `handleTplCardClick()` / `duplicateTpl()` の公開、`48_steps_ui.js` からのStep1具体関数除去、Step1固定ボタンevent binder、テンプレート選択・複製の基本契約を検証します。

## Step3 Input Core単体テスト

```bash
node tests/step3_input_core_unit_tests.js
```

`renderStep3()` / `renderInputForm()` / `getInputData()` / `loadAddrToInput()` / `clearInput()` / `switchInputPane()` の分離、hook維持、読込順を静的検証します。

## Step3 Queue UI静的テスト

```bash
node tests/step3_input_queue_inventory_tests.js
```

Step3 queue UI分離後に、キュー・住所録・履歴・Excel貼付取込の関数配置、Extension Registry hook、拡張項目を落とさないキュー複製、貼付取込マッピングを静的検証します。

## Step4 / Step5 UI静的テスト

```bash
node tests/step4_step5_ui_unit_tests.js
```

Step4テスト印刷・プリンタ補正UIとStep5本印刷プレビューUIの関数配置、固定イベント委譲、公開API、読込順を静的検証します。

## Data Management UI Controller単体テスト

```bash
node tests/data_management_ui_unit_tests.js
```

`showHelp()` / `showDataMgmt()` / `getModuleOverview()` の公開入口、疑似モジュール概要、`showSaveFilePicker` 保存経路、保存先固定・再利用経路、`showOpenFilePicker` 読込経路、保存環境診断、復元前バックアップ契約を検証します。



## Common UI Binder単体テスト

```bash
node tests/common_ui_binder_unit_tests.js
```

`bindEventsForCommonUI()` の公開、ヘルプ・データ管理・表示モード切替イベント、Bootstrapからの共通固定イベント除去、公開APIと読込順を検証します。

## Adjustment Status単体テスト

```bash
node tests/adjustment_status_unit_tests.js
```

`getTplAdjustmentSummary()` のタイムスタンプ判定、背景有無、プリンタ補正済み判定を検証します。

## Bootstrap Controller単体テスト

```bash
node tests/bootstrap_unit_tests.js
```

`selectLastUsedTemplate()` と `initializeApp()` の起動順序を検証します。自動起動はテスト時だけ `__ENVELOPE_PRINT_BOOTSTRAP_TEST_MODE` で抑止します。

## stage_addons_unit_tests.js

Stage5〜8 addonの静的検証です。保存キー、IIFE/strict、DOMContentLoaded初期化、Registry接続、`getFieldText()` 非上書き、読込順を確認します。


## Version Sync Guard単体テスト

```bash
node tests/version_sync_unit_tests.js
```

`split_manifest.json`、README、`index.html`、`js/10_core.js` の現在版表示が一致していること、`APP_RELEASE_NOTES` に v38-25〜現在版まで欠落がないこと、`tools/sync_version.js` が存在することを検証します。

## retired_steps_ui_unit_tests.js

```bash
node tests/retired_steps_ui_unit_tests.js
```

`js/48_steps_ui.js` が完全退役し、実ファイル・index読込・manifest・READMEファイル構成に残っていないことを検証します。

## Docs Inventory Consolidation静的テスト

```bash
node tests/docs_inventory_consolidation_tests.js
```

個別の棚卸しdocsが `docs/refactor_inventory_archive.md` に統合され、README・リリースノート・現行台帳の参照先が整理されていることを検証します。


## IIFE Strict Phase1静的・軽量実行テスト

```bash
node tests/iife_strict_phase1_tests.js
node tests/iife_strict_phase2_tests.js
node tests/iife_strict_phase3_tests.js
node tests/iife_strict_phase4_tests.js
```

`00_pdf_loader.js` / `42_layout_math.js` / `99_audit_marker.js` がIIFE + strictになっていること、Layout Mathの既存グローバル互換exportと `EnvelopePrintLayoutMath` 公開を検証します。


## IIFE Strict Phase4静的・軽量実行テスト

```bash
node tests/iife_strict_phase4_tests.js
```

`20_registries.js` がIIFE + strictになっていること、既存Registryのグローバル互換exportと `EnvelopePrintRegistryCore` 公開、組み込みsource・hook・SampleData既定値の基本契約を検証します。


## IIFE Strict Phase5静的・軽量実行テスト

```bash
node tests/iife_strict_phase5_tests.js
```

`90_bootstrap.js` の IIFE + strict 化、`EnvelopePrintBootstrap` と互換グローバルexport、イベント委譲順、起動順序、構造検証への組込みを確認します。


## IIFE Strict Phase6静的・軽量実行テスト

```bash
node tests/iife_strict_phase6_tests.js
```

`49_wizard.js` の IIFE + strict 化、`EnvelopePrintWizard` と互換グローバルexport、`wizardState` 互換アクセサ、構造検証への組込みを確認します。


## IIFE Strict Phase7静的・軽量実行テスト

```bash
node tests/iife_strict_phase7_tests.js
```

`05_utilities.js` の IIFE + strict 化、`EnvelopePrintUtilities` と互換グローバルexport、軽量VMロード、構造検証への組込みを確認します。

## IIFE Strict Phase8静的・軽量実行テスト

```bash
node tests/iife_strict_phase8_tests.js
```

`15_address_data.js` の IIFE + strict 化、`EnvelopePrintAddressData` と互換グローバルexport、プレーンテキスト契約、Registry実行時参照、構造検証への組込みを確認します。



## IIFE Strict Phase9静的・軽量実行テスト

```bash
node tests/iife_strict_phase9_tests.js
```

`53_adjustment_status.js` の IIFE + strict 化、`EnvelopePrintAdjustmentStatus` と互換グローバルexport、タイムスタンプ判定契約、構造検証への組込みを確認します。


## IIFE Strict Phase12静的・軽量実行テスト

```bash
node tests/iife_strict_phase12_tests.js
```

`52_data_management_ui.js` の IIFE + strict 化、`EnvelopePrintDataManagementUI` と互換グローバルexport、軽量VMロード、構造検証への組込みを確認します。


## IIFE Strict Phase13静的・軽量実行テスト

```bash
node tests/iife_strict_phase13_tests.js
```

`30_storage.js` の IIFE + strict 化、`EnvelopePrintStorageCore` と互換グローバルexport、軽量VMロード、保存キー契約、snapshot契約、構造検証への組込みを確認します。

## IIFE Strict Phase14静的・軽量実行テスト

```bash
node tests/iife_strict_phase14_tests.js
```

`43_background_assets.js` の IIFE + strict 化、`EnvelopePrintBackgroundAssets` と互換グローバルexport、軽量VMロード、永続/非永続背景反映契約、構造検証への組込みを確認します。

## IIFE Strict Phase15静的・軽量実行テスト

```bash
node tests/iife_strict_phase15_tests.js
```

`44_edit_canvas_controller.js` の IIFE + strict 化、`EnvelopePrintEditCanvasController` と互換グローバルexport、軽量VMロード、ドラッグヘルパー契約、構造検証への組込みを確認します。


## IIFE Strict Phase16静的・軽量実行テスト

```bash
node tests/iife_strict_phase16_tests.js
```

`48_step_navigation.js` の IIFE + strict 化、`EnvelopePrintStepNavigation` と互換グローバルexport、軽量VMロード、Step遷移契約、構造検証への組込みを確認します。


## IIFE Strict Phase17静的・軽量実行テスト

```bash
node tests/iife_strict_phase17_tests.js
```

`48_step1_template_ui.js` の IIFE + strict 化、`EnvelopePrintStep1TemplateUI` と互換グローバルexport、軽量VMロード、Step1固定ボタン契約、構造検証への組込みを確認します。


## IIFE Strict Phase18静的・軽量実行テスト

```bash
node tests/iife_strict_phase18_tests.js
```

`48_step2_edit_ui.js` の IIFE + strict 化、`EnvelopePrintStep2EditUI` と互換グローバルexport、軽量VMロード、Step2固定イベント契約、構造検証への組込みを確認します。


## IIFE Strict Phase19静的・軽量実行テスト

```bash
node tests/iife_strict_phase19_tests.js
```

`48_step3_input_core.js` の IIFE + strict 化、`EnvelopePrintStep3InputCore` と互換グローバルexport、軽量VMロード、入力データhook・Step3固定イベント契約、構造検証への組込みを確認します。

## IIFE Strict Phase20静的・軽量実行テスト

```bash
node tests/iife_strict_phase20_tests.js
```

`48_step3_queue_ui.js` の IIFE + strict 化、`EnvelopePrintStep3QueueUI` と互換グローバルexport、軽量VMロード、キュー複製・履歴・Excel貼付取込契約、構造検証への組込みを確認します。

## IIFE Strict Phase21静的・軽量実行テスト

```bash
node tests/iife_strict_phase21_tests.js
```

`48_step4_test_print_ui.js` の IIFE + strict 化、`EnvelopePrintStep4TestPrintUI` と互換グローバルexport、軽量VMロード、試し刷りUI契約、構造検証への組込みを確認します。


## IIFE Strict Phase22静的・軽量実行テスト

```bash
node tests/iife_strict_phase22_tests.js
```

`48_step5_final_print_ui.js` の IIFE + strict 化、`EnvelopePrintStep5FinalPrintUI` と互換グローバルexport、軽量VMロード、本番印刷UI契約、構造検証への組込みを確認します。

## v38-64 Browser Hotfix Navigation Guard

`tests/browser_hotfix_navigation_guard_tests.js` は、Step遷移時の描画エラー記録と、未調整ガイドからStep3へ進む導線を検証します。


## v38-65 Browser Hotfix Click Fallback

```bash
node tests/browser_hotfix_click_fallback_tests.js
```

重要ボタンの委譲フォールバック、クリック記録、バックアップ画面へのクリックログ表示、verifyへの組込みを検証します。

## v38-66 Browser Hotfix Handler Recovery

`tests/browser_hotfix_handler_recovery_tests.js` を追加しました。

- click handler が例外で落ちた場合に fallback を塞がないこと
- `handler-error` がクリック記録に残ること
- バックアップ画面のクリック記録に error 文字列が出ること
- verify に v38-66 Hotfix guard が組み込まれていること

を検証します。



## v38-69 Browser Hotfix Action Fallback

```bash
node tests/browser_hotfix_action_fallback_tests.js
```

Step3 のキュー追加・住所録保存・貼付取込、Step4 の試し刷り、Step5 の最初から戻るが named action として公開され、Click Fallback から救済できることを検証します。

## v38-68 Browser Hotfix Step Navigation Diagnostics

- `tests/browser_hotfix_step_nav_diagnostics_tests.js`
- 左ステップ一覧に `data-step-nav` と `role=button` が付与されること
- Click Fallback が左ステップ一覧クリックを救済対象にすること
- `goToStep()` 後に自己診断が自動更新されること
- UI自己診断が `activeNavStep` と `active-step-nav-mismatch` を扱えること
- verify に v38-68 Hotfix guard が組み込まれていること

## v38-67 Browser Hotfix Self Diagnostics

`tests/browser_hotfix_self_diagnostics_tests.js` を追加しました。

- `runInteractionSelfDiagnostics()` が実装・公開されていること
- 起動処理の最後で自己診断が実行されること
- 主要ボタンの存在、active Step、Click Fallback / Handler Guard の初期化状態を診断すること
- 診断結果を `__envelopePrintSelfDiagnostics` に保持すること
- バックアップ画面に UI自己診断パネル、再診断ボタン、コピー導線が出ること
- verify に v38-67 Hotfix guard が組み込まれていること

を検証します。

## v38-70 Hotfix Retreat Guardrail tests

- `EventTarget.prototype` 差し替え型の Event Handler Guard が再混入していないこと
- `safeBindClick()` が明示的な click handler 保護APIとして公開されていること
- Click Fallback が巨大 `switch` ではなく `CRITICAL_CLICK_ACTIONS` テーブル駆動であること
- Step/Common の主要ボタンが `safeBindClick` 経由で接続されること
- UI自己診断が Handler Guard ではなく safeBindClick 状態を表示・コピーすること

## v38-71 Hotfix Module Split tests

```bash
node tests/browser_hotfix_module_split_tests.js
```

`90_bootstrap.js` から Runtime Error Trap / Click Safety / Critical Click Fallback / Self Diagnostics が `91〜94` へ分離され、bootstrapが初期化順序へ戻っていることを検証します。


## Browser E2E Smokeテスト

```bash
node tests/browser_e2e_smoke_tests.js
```

Chromium DevTools Protocolを直接使い、外部npmなしで実ブラウザ上の主要導線を検証します。

確認する流れ:

- アプリ初期化とStep1テンプレートカード描画
- 詳細モード切替
- テンプレートカードの「詳細」からStep2へ遷移
- Step2でテンプレート名変更と `btnAddField` によるフィールド追加
- Step2で実 `File` による画像背景取込を行い、永続背景保存を検証
- Step2でpdf.js最小スタブによるPDF背景取込を行い、一時背景保存を検証
- Step2 → Step3 遷移
- Step3で宛名入力
- `btnAddQueue` クリックによるキュー追加
- Step3 → Step4 → Step5 遷移
- バックアップ管理モーダル表示
- UI自己診断の再実行とモーダルクローズ
- runtime error記録と Chrome `Runtime.exceptionThrown` が空であること

この実行環境では `file://` と `localhost` ページ表示がブロックされるため、`index.html` とcss/jsをインライン化して `about:blank` に注入し、localStorageだけ最小shimで補います。DOM/Event/描画JSはChromium上で実行されます。Chromiumが見つからない環境ではSKIPします。ただし `PAPERPRINT_REQUIRE_BROWSER_E2E=1` を指定した場合は、Chromium未検出または明示SKIPを失敗扱いにします。



## README Release History Closeout

```bash
node tests/readme_release_history_tests.js
```

README.md の v38 リリース履歴が v38-6〜v38-80まで昇順・欠番なし・重複なしで並んでいること、v39履歴がv39-1から昇順で並ぶこと、v38-80 Closeout宣言、v39-1 Backup Capability UX、v39-2 Pinned Backup Target、v39-3 PDF Import Readiness、`APP_V38_CLOSEOUT_DECISION`、`EnvelopePrintRuntime`、Browser E2E必須モードの記載が存在することを検証します。

## Load Order Contract

`tests/load_order_contract_tests.js` は、`load_order.json` と `index.html` の外部 `script` / `link` 順序が完全一致していること、`tools/apply_load_order.js` が head/body-end のLOAD_ORDERブロックを再生成できることを検証します。




## IIFE Strict Phase25 Core Contractテスト

```bash
node tests/iife_strict_phase25_tests.js
```

`js/10_core.js` が IIFE + strict 形式を維持し、`EnvelopePrintCoreContract` と既存互換の `state` / `transientBg` getter/setter、保存キー不変、公開API索引、verify組込みを検証します。

## IIFE Strict Phase24静的・軽量実行テスト

```bash
node tests/iife_strict_phase24_tests.js
```

`js/70_stage7_addon.js` が IIFE + strict 形式を維持し、`EnvelopePrintStage7` と既存Stage7拡張契約を公開すること、Stage7追加field source、InputData/Step3 hook、safeBindClick連携、帳票field source契約、公開API索引、verify組込みを検証します。

## IIFE Strict Phase23静的・軽量実行テスト

```bash
node tests/iife_strict_phase23_tests.js
```

`js/06_keyboard_overlay.js` が IIFE + strict 形式を維持し、`EnvelopePrintKeyboardOverlay` と既存互換APIを公開すること、ESCによるモーダル/ウィザード閉じ、Step2矢印キー微調整、公開API索引、verify組込みを検証します。

